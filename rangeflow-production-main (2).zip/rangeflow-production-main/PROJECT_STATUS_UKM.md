# PROJECT STATUS — EDGE RangeFlow @ UKM

Read this file first before continuing any RangeFlow @ UKM work. Purpose: prevent GPT/session drift, duplicate Coolify apps, wrong URL usage, wrong org slug, and repeated work.

## Hard Rules

- Do not create new Coolify apps for UKM unless the user explicitly asks.
- Do not use `bukitunggul` for UKM.
- Active UKM org slug: `drukm`.
- Source repo: `duniabiz2udotcom/rangeflow-production`.
- Supabase project: `cgewjbfycnqbyczyuthp` / `https://cgewjbfycnqbyczyuthp.supabase.co`.
- Always update this file after major work.
- Before any new instruction, state target app, folder, route, expected result, commit, and which Coolify app to redeploy.

## Active Deployment Mapping

### Customer App — LIVE / KEEP

Use for customer QR order, bay page, payment, receipt.

```text
Coolify Project: rangeos
Application: rangeflow-production:codex/complete-rangeflow-standard-package-thw9q52xl3357l1a8iwiqgus
URL: http://thw9q52xl3357l1a8iwiqgus.5.223.94.81.sslip.io
Base directory: customer
```

Routes:

```text
/
/b/07
/b/07/order
/pay/[bookingId]
/receipt/[bookingId]
```

### Operations App — LIVE / KEEP

Use for staff/admin/owner operations.

```text
Coolify Project: My first project
Application: rangeflow-operations
URL: http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io
Base directory: operations
```

Routes:

```text
/
/counter
/owner
/menu
/payments
/stock
/pos
```

## Legacy / Duplicate Apps — Do Not Use for UKM Live

```text
http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io
http://s8lbafk5vhuorm1itoaclixb.5.223.94.81.sslip.io
http://tvrtb4qixifs3a411r1jqez3.5.223.94.81.sslip.io
```

Treat these as archive/duplicate until UKM live is stable. Do not delete immediately.

## Finalized Realistic UKM Operation Flow

RangeFlow @ UKM is not a heavy ecommerce checkout.

Real flow:

1. Customer arrives with golf bag.
2. Customer chooses available bay.
3. Customer places bag at bay.
4. Customer walks to counter for first purchase.
5. Staff creates counter-first order for that bay.
6. Customer scans TNG/DuitNow QR and pays.
7. Customer self-picks up bucket/drink/ready item.
8. Customer starts playing.
9. Later, customer scans ORDER QR at bay for add-on balls/drinks/food.
10. Bay QR add-on order auto-detects bay.
11. Customer chooses Self Pickup or Deliver to Bay.
12. Payment flow stays simple: no mandatory payer name, transaction ID, or screenshot upload.
13. Staff verifies payment and processes pickup/delivery.
14. Owner monitors operations through dashboard.

Payment instruction:

```text
Please keep payment proof if requested by staff.
```

## Pricing Source of Truth

```text
Walk-in / public: 100 balls = RM12
UKM student/staff: 100 balls = RM8
```

## Completed Work

### Supabase

- Added fulfillment/session/order-channel/customer-type/payment-instruction fields.
- Added simplified payment verification fields.
- Created views:

```text
v_rangeflow_staff_bay_grid
v_rangeflow_payment_verification_queue
v_rangeflow_fulfillment_queue
v_rangeflow_owner_dashboard_today
```

- Created helper functions:

```text
create_counter_first_order()
mark_booking_paid()
release_bay_session()
```

- Corrected UKM bucket pricing to RM12 / RM8.

### Customer App

- Landing page `/` redesigned with BM/EN and dark/light toggle.
- Bay page `/b/07` simplified and linked to landing page.
- Order page `/b/07/order` compacted for mobile 2-column menu.
- Added Walk-in / UKM Staff/Student rate selector.
- Added Self Pickup / Deliver to Bay.
- Removed mandatory payer name / transaction ID / screenshot upload as main flow.
- Receipt Done route changed back to bay page.
- Added safety redirect `/counter` in customer app to operations app.

### Operations App

- `operations/lib/supabase.ts` is locked to UKM org slug `drukm`.
- `/counter` was rebuilt into a Staff Counter Dashboard using Supabase operational views.
- `/counter` was further redesigned as a professional bay-centric touch order board.
- Current latest `/counter` design:

```text
Header: Staff Counter
Left top: Bay Overview with larger bay tiles
Inside bay tile: status, amount, payment/session/help, queue badges
Inside Bay Overview: selected bay detail + selected bay queue + print dropdown + release
Left middle: Touch to Add menu grid
Menu categories: Popular, Ball, Drinks, Food, Rental, Other
Menu source: Supabase get_operations_menu_items, with fallback items if empty
Right side: Queue, Need Help, Payments
Bottom: Sticky Cart + Total + Add to Bay
```

Latest important commit for `/counter`:

```text
c9519f9e24b964f960ec1e52f93ca29f1151abc8
```

## Current Problem / Next Action

Current issue: screenshots may still show the old/intermediate `/counter` layout if Coolify has not deployed the latest commit. The old/intermediate layout shows:

```text
Staff Counter Dashboard
Bay grid + separate Add Counter Order horizontal list
Separate selected bay detail row with large text
No Touch to Add category grid
No sticky cart bottom
```

Meaning: `rangeflow-operations` app is still running an older image/cache.

Next exact action:

```text
Target app: rangeflow-operations
Target folder: operations
Target route: /counter
Expected result: professional bay-centric Touch to Add board
Commit required: c9519f9e24b964f960ec1e52f93ca29f1151abc8 or newer
Coolify Project: My first project
Application: rangeflow-operations
URL: http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io
Action: Redeploy / Force Rebuild
```

After redeploy, open:

```text
http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io/counter
```

Expected visible signs of latest UI:

```text
Title: Staff Counter
Section: Touch to Add
Tabs: Popular / Ball / Drinks / Food / Rental / Other
Right side: Queue / Need Help / Payments
Bottom: Sticky Cart + Total + Add to Bay
```

If these do not appear, check deployment log commit SHA. It must be `c9519f9e24b964f960ec1e52f93ca29f1151abc8` or newer.

## Future Response Format

Before giving instructions, use:

```text
Target app:
Target folder:
Target route:
Current issue:
Expected result:
Commit:
Which Coolify app to redeploy:
```

Do not jump to visual polish, new modules, or new deployments until the current next action is complete.
