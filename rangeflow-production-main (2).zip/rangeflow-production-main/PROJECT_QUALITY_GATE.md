# RangeFlow Quality Gate

Last updated: 2026-05-28

This file defines what must happen before RangeFlow is considered sellable or ready to show to an operator/client.

## Current mode

RangeFlow is now in finishing mode, not exploration mode.

No new paid tools. No new apps. No new deployments. No new modules. No redesign loops without acceptance checks.

## Definition of Done

A route is not done until all items below pass on a real phone and desktop browser:

1. Page opens without server error.
2. Page uses the correct canonical app and org slug `drukm`.
3. Layout looks professional, compact, and serious.
4. No oversized text, oversized cards, childish spacing, or clipped buttons.
5. Primary flow can be completed by a non-technical staff/customer.
6. Data saves to Supabase correctly.
7. UI reflects latest Supabase data after refresh.
8. No old fallback/demo wording appears.
9. No duplicate item, duplicate route, or wrong bay issue appears.
10. Screenshot proof is captured or user confirms visible pass.

## Immediate routes to finish first

Customer:

- `/b/07/order`
- `/pay/[bookingId]`
- `/receipt/[bookingId]`

Operations:

- `/owner`
- `/counter`
- `/stock`
- `/pos?bay=07`

Do not move to optional routes until these are stable.

## Visual quality rules

Customer mobile order page must follow the approved compact premium UI direction in `PROJECT_STATE_RANGEFLOW.md`.

Staff and owner pages must follow the Owner Dashboard visual identity.

Forbidden UI defects:

- giant product cards on mobile
- giant typography on mobile
- one-column product menu unless phone is extremely narrow
- clipped checkout bar
- childish icon-heavy layout without professional spacing
- inconsistent colors between pages
- excessive explanatory text
- old demo/fallback pages resurfacing

## Technical quality rules

Before calling any issue fixed:

1. Confirm GitHub commit SHA.
2. Confirm correct Coolify app was rebuilt.
3. Confirm live route is not stale deployment.
4. Confirm Supabase RPC/table required by the page exists.
5. Confirm no old duplicate app/link is being used as test reference.

## Cost and scope rules

Refer to `PROJECT_COST_LOCK.md`.

No new paid dependency may be introduced for RangeFlow stabilization.

## User burden rule

The user should only verify visible behavior:

- can open / cannot open
- looks correct / not correct
- button works / does not work
- flow is correct / wrong

The technical assistant/developer is responsible for code, schema, deployment, and source-of-truth updates.
