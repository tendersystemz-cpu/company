# RangeFlow Cost Lock

Last updated: 2026-05-28

This project is now under strict cost-control mode.

## Hard rule

Do not recommend, request, or introduce any new paid tool, cloud platform, API key, VPS, connector, AI worker, external service, or subscription to continue RangeFlow stabilization unless the user explicitly asks for it.

## Use existing stack only

Current allowed stack for stabilization:

- GitHub repository: `duniabiz2udotcom/rangeflow-production`
- Supabase project already used for RangeFlow
- Coolify canonical apps already defined in `PROJECT_STATE_RANGEFLOW.md`
- Existing VPS/Coolify deployment only

## Do not add back into the workflow

Do not use these as required dependencies for RangeFlow stabilization:

- Netlify
- Emergent
- Claude/Cowork
- Gemini Cloud API
- OpenRouter API
- Vultr
- additional Hetzner VPS
- OpenClaw
- Hermes
- Telegram automation
- any new payment gateway or automation platform

They may be historical references only. They must not become blockers or required services.

## Stabilization principle

Finish the system using the existing canonical customer and operations apps. Reduce complexity. Do not create new apps, new deployments, or new infrastructure to hide unfinished work.

The user verifies visible operational behavior only. Technical burden, deployment logic, schema/RPC checks, and source-of-truth updates must be handled by the technical assistant/developer.
