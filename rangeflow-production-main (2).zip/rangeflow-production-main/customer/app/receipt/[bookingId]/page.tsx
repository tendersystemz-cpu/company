'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase';

type PageProps = { params: { bookingId: string } };
type OrderLine = { id: string; item_name: string; quantity: number; subtotal: number; status: string };
type ReceiptData = {
  booking?: {
    id: string;
    qr_token: string;
    customer_name?: string | null;
    customer_phone?: string | null;
    status: string;
    payment_status: string;
    total_amount: number;
    paid_at?: string | null;
  };
  bay?: { code: string; display_name: string };
  location?: { name: string };
  orders?: OrderLine[];
};

function money(value: number | string | null | undefined) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function statusText(status?: string | null) {
  const value = String(status || '').toLowerCase();
  if (value === 'paid') return 'Paid';
  if (value === 'pending') return 'Waiting Verify';
  if (value === 'preparing') return 'Preparing';
  if (value === 'ready') return 'Ready';
  if (value === 'delivered' || value === 'completed') return 'Completed';
  if (value === 'unpaid') return 'Unpaid';
  return status || 'Received';
}

export default function ReceiptPage({ params }: PageProps) {
  const [data, setData] = useState<ReceiptData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  async function load() {
    const { data: receipt, error: receiptError } = await supabase.rpc('get_customer_receipt', {
      p_booking_id: params.bookingId,
    });

    setLoading(false);

    if (receiptError) {
      setError(receiptError.message || 'Receipt tidak dijumpai.');
      return;
    }

    setError(null);
    setData(receipt as ReceiptData);
  }

  useEffect(() => {
    let cancelled = false;

    async function safeLoad() {
      const { data: receipt, error: receiptError } = await supabase.rpc('get_customer_receipt', {
        p_booking_id: params.bookingId,
      });

      if (cancelled) return;
      setLoading(false);

      if (receiptError) {
        setError(receiptError.message || 'Receipt tidak dijumpai.');
        return;
      }

      setError(null);
      setData(receipt as ReceiptData);
    }

    safeLoad();
    const timer = window.setInterval(safeLoad, 10000);
    return () => { cancelled = true; window.clearInterval(timer); };
  }, [params.bookingId]);

  const bayCode = data?.bay?.code || '01';
  const bayName = data?.bay?.display_name || `Bay ${bayCode}`;
  const total = Number(data?.booking?.total_amount || 0);
  const paid = data?.booking?.payment_status === 'paid';
  const completed = ['completed', 'delivered'].includes(String(data?.booking?.status || '').toLowerCase());
  const itemCount = (data?.orders || []).reduce((sum, item) => sum + Number(item.quantity || 0), 0);

  return (
    <main className="receiptPage">
      <section className="slipCard">
        <header className="slipHead">
          <div className="brand"><span>DG</span><b>EDGE RANGE OS</b></div>
          <div className="bayTag"><small>Status</small><strong>{bayName}</strong></div>
        </header>

        <section className={`statusBand ${paid ? 'paid' : 'pending'}`}>
          <span>{paid ? 'Payment Verified' : 'Order Received'}</span>
          <b>{paid ? 'Thank You' : 'Waiting Verify'}</b>
          <em>{paid ? 'Item sedang diproses.' : 'Bayar guna QR TNG/DuitNow fizikal dan tunjuk bukti jika staff minta.'}</em>
        </section>

        {loading ? <div className="notice">Loading receipt...</div> : null}
        {error ? <div className="notice error">{error}</div> : null}

        {data ? <>
          <section className="tokenBox">
            <span>Order Token</span>
            <b>{data.booking?.qr_token}</b>
          </section>

          <section className="metaGrid">
            <Info label="Bay" value={bayName} />
            <Info label="Payment" value={statusText(data.booking?.payment_status)} />
            <Info label="Order" value={statusText(data.booking?.status)} />
            <Info label="Total" value={money(total)} />
          </section>

          <section className="itemsBox">
            <div className="boxTitle"><b>Purchase Slip</b><span>{itemCount} item</span></div>
            {(data.orders || []).map((item) => (
              <div className="itemRow" key={item.id}>
                <span>{item.quantity}x {item.item_name}</span>
                <b>{money(item.subtotal)}</b>
              </div>
            ))}
            {(data.orders || []).length === 0 ? <p>No item found.</p> : null}
            <div className="totalRow"><span>Total</span><b>{money(total)}</b></div>
          </section>

          <section className="nextBox">
            <b>{completed ? 'Completed' : paid ? 'Please collect or wait at bay' : 'Staff will verify payment'}</b>
            <span>{completed ? 'Selesai. Enjoy your session.' : paid ? 'Ambil di kaunter atau tunggu penghantaran ke bay.' : 'Sila simpan bukti bayaran jika diminta staff.'}</span>
          </section>
        </> : null}

        <div className="actions">
          <button type="button" onClick={() => load()}>Refresh</button>
          <Link href={`/b/${bayCode}/order`}>Order Again</Link>
        </div>

        <p className="saveHint">Screenshot this slip for your reference.</p>
      </section>

      <style jsx>{styles}</style>
    </main>
  );
}

function Info({ label, value }: { label: string; value: string }) {
  return <article><span>{label}</span><b>{value}</b></article>;
}

const styles = `
.receiptPage{--bg:#f6faf3;--panel:#fff;--text:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--text);font-family:Inter,Arial,sans-serif;padding:8px 8px 110px}.slipCard{max-width:520px;margin:0 auto;border:1px solid var(--line);background:var(--panel);border-radius:22px;padding:12px;box-shadow:0 10px 24px rgba(7,28,22,.07)}.slipHead{display:flex;align-items:center;justify-content:space-between;gap:10px;border-radius:18px;background:linear-gradient(135deg,#031810,#0e4a28);color:#fff;padding:10px 12px}.brand{display:flex;align-items:center;gap:9px;min-width:0}.brand span{width:34px;height:34px;border-radius:12px;background:var(--accent);display:grid;place-items:center;color:#06110d;font-weight:950}.brand b{font-size:15px;letter-spacing:.03em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.bayTag{text-align:right}.bayTag small{display:block;color:#b9d8c6;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.08em}.bayTag strong{font-size:17px}.statusBand{margin-top:10px;border-radius:18px;padding:13px 14px;color:#fff;background:linear-gradient(135deg,#92400e,#f59e0b);text-align:center}.statusBand.paid{background:linear-gradient(135deg,#061c14,#0f773a)}.statusBand span{display:block;font-size:10px;text-transform:uppercase;letter-spacing:.13em;font-weight:950;color:#f0fff4}.statusBand b{display:block;margin-top:5px;font-size:28px;line-height:1;letter-spacing:-.04em}.statusBand em{display:block;margin-top:7px;color:#fffbe9;font-style:normal;font-size:12px;font-weight:850;line-height:1.35}.notice{margin:8px 0 0;border-radius:14px;padding:9px 10px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900;font-size:12px}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.tokenBox{margin-top:10px;border:1px dashed #cfe0ca;background:#fbfdf9;border-radius:18px;padding:12px;text-align:center}.tokenBox span{display:block;color:var(--muted);font-size:10px;font-weight:950;text-transform:uppercase;letter-spacing:.12em}.tokenBox b{display:block;font-size:30px;letter-spacing:.08em;margin-top:3px}.metaGrid{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:10px}.metaGrid article{border:1px solid var(--line);background:#fff;border-radius:15px;padding:10px}.metaGrid span{display:block;color:var(--muted);font-size:10px;font-weight:950;text-transform:uppercase}.metaGrid b{display:block;margin-top:4px;font-size:14px}.itemsBox,.nextBox{border:1px solid var(--line);background:#fbfdf9;border-radius:18px;padding:11px;margin-top:10px}.boxTitle{display:flex;justify-content:space-between;align-items:center;margin-bottom:7px}.boxTitle b{font-size:16px}.boxTitle span{color:var(--muted);font-size:12px;font-weight:900}.itemRow{display:flex;justify-content:space-between;gap:10px;border-top:1px solid var(--line);padding:9px 0}.itemRow span{font-size:13px;font-weight:900;line-height:1.25}.itemRow b{white-space:nowrap;font-size:13px}.totalRow{display:flex;justify-content:space-between;align-items:center;border-top:2px solid #d3e4cf;margin-top:2px;padding-top:10px}.totalRow span{color:var(--muted);font-size:12px;font-weight:950;text-transform:uppercase}.totalRow b{font-size:22px;color:var(--green);letter-spacing:-.04em}.nextBox b,.nextBox span{display:block}.nextBox b{font-size:15px}.nextBox span{color:var(--muted);font-size:13px;font-weight:850;line-height:1.35;margin-top:3px}.actions{display:grid;grid-template-columns:1fr 1.25fr;gap:8px;margin-top:10px}.actions a,.actions button{border:0;border-radius:15px;padding:12px 10px;text-align:center;text-decoration:none;font-size:13px;font-weight:950}.actions button{background:#f3f7f1;color:var(--text);border:1px solid var(--line)}.actions a{background:linear-gradient(135deg,#9be84f,#17b26a);color:#06110d}.saveHint{margin:10px 0 0;color:var(--muted);text-align:center;font-size:11px;font-weight:850}@media(max-width:420px){.receiptPage{padding:8px 8px 104px}.slipCard{border-radius:20px}.brand b{font-size:14px}.statusBand b{font-size:26px}.tokenBox b{font-size:27px}.metaGrid{grid-template-columns:1fr 1fr}.actions{grid-template-columns:1fr 1fr}}@media(max-width:340px){.metaGrid,.actions{grid-template-columns:1fr}.brand b{max-width:160px}}
`;