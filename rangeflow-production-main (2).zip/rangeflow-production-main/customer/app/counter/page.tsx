import { redirect } from 'next/navigation';

const OPS_BASE_URL = process.env.NEXT_PUBLIC_OPERATIONS_BASE_URL || 'http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io';

export default function CustomerCounterRedirectPage() {
  redirect(`${OPS_BASE_URL}/counter`);
}
