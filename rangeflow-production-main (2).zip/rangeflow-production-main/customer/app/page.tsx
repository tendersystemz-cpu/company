'use client';

import Link from 'next/link';
import { useState } from 'react';

type Lang = 'bm' | 'en';

type Copy = {
  badge: string;
  title: string;
  lead: string;
  start: string;
  bay: string;
  owner: string;
  ownerHint: string;
  rates: string;
  flow: string[];
  payment: string;
  pickup: string;
  deliver: string;
};

const OPERATIONS_OWNER_URL = 'http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io/owner';

const copy: Record<Lang, Copy> = {
  bm: {
    badge: 'Driving Range @ UKM',
    title: 'Order dari bay. Main tanpa gangguan.',
    lead: 'Tambah bola, minuman dan makanan terus dari bay. Pilih self pickup atau deliver to bay, bayar dengan QR dan teruskan sesi.',
    start: 'Mula Order Bay 07',
    bay: 'Buka Bay 07',
    owner: 'Owner / Admin',
    ownerHint: 'Akses berkunci untuk pemilik dan staff operasi sahaja.',
    rates: 'Walk-in RM12 · UKM Staff/Student RM8',
    flow: ['Scan QR', 'Pilih item', 'Bayar QR', 'Ambil / Terima'],
    payment: 'TNG / DuitNow QR',
    pickup: 'Self Pickup',
    deliver: 'Deliver to Bay',
  },
  en: {
    badge: 'Driving Range @ UKM',
    title: 'Order from your bay. Keep playing.',
    lead: 'Add balls, drinks and food from your bay. Choose self pickup or deliver to bay, pay by QR and continue your session.',
    start: 'Start Bay 07 Order',
    bay: 'Open Bay 07',
    owner: 'Owner / Admin',
    ownerHint: 'Locked access for owner and operations staff only.',
    rates: 'Walk-in RM12 · UKM Staff/Student RM8',
    flow: ['Scan QR', 'Choose items', 'Pay QR', 'Pickup / Receive'],
    payment: 'TNG / DuitNow QR',
    pickup: 'Self Pickup',
    deliver: 'Deliver to Bay',
  },
};

export default function HomePage() {
  const [lang, setLang] = useState<Lang>('bm');
  const t = copy[lang];

  return (
    <main className="landing">
      <style>{styles}</style>

      <header className="nav">
        <Link href="/" className="brand"><span>DG</span><b>EDGE RANGE OS</b></Link>
        <div className="navActions">
          <a className="ownerMini" href={OPERATIONS_OWNER_URL}>🔒 Owner</a>
          <button type="button" onClick={() => setLang(lang === 'bm' ? 'en' : 'bm')}>{lang === 'bm' ? 'EN' : 'BM'}</button>
          <Link href="/b/07/order">Bay 07</Link>
        </div>
      </header>

      <section className="hero">
        <div className="copyBlock">
          <p className="badge">{t.badge}</p>
          <h1>{t.title}</h1>
          <p className="lead">{t.lead}</p>
          <div className="actions">
            <Link className="primary" href="/b/07/order">{t.start}</Link>
            <Link className="secondary" href="/b/07">{t.bay}</Link>
          </div>
          <a className="ownerCard" href={OPERATIONS_OWNER_URL}>
            <span>🔒</span>
            <b>{t.owner}</b>
            <small>{t.ownerHint}</small>
          </a>
          <div className="rate">{t.rates}</div>
        </div>

        <aside className="qrCard">
          <div className="qrHead"><span>Driving Range @ UKM</span><b>Bay 07</b></div>
          <div className="qrBox">QR</div>
          <div className="chips"><span>{t.payment}</span><span>{t.pickup}</span><span>{t.deliver}</span></div>
        </aside>
      </section>

      <section className="flow">
        {t.flow.map((step, index) => <article key={step}><span>{index + 1}</span><b>{step}</b></article>)}
      </section>

      <footer className="footer">
        <span>Powered by EDGE Ecosystem</span>
        <small>Customer QR Order · EDGE RANGE OS</small>
      </footer>
    </main>
  );
}

const styles = `
.landing{--bg:#06130f;--panel:#0a2119;--panel2:#0f3024;--text:#f6fff8;--muted:#b8d4c2;--line:rgba(190,242,196,.18);--green:#7ee33f;--green2:#16b56c;min-height:100vh;background:radial-gradient(circle at 18% 12%,rgba(126,227,63,.18),transparent 32%),linear-gradient(135deg,#020907,#062419 64%,#020907);color:var(--text);font-family:Inter,Arial,sans-serif}.nav{height:72px;max-width:1120px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;padding:0 18px}.brand{display:flex;align-items:center;gap:12px;color:var(--text);text-decoration:none}.brand span{width:40px;height:40px;border-radius:14px;background:linear-gradient(135deg,var(--green),var(--green2));display:grid;place-items:center;color:#03130d;font-weight:1000}.brand b{font-size:19px;letter-spacing:.08em}.navActions{display:flex;gap:9px;align-items:center}.navActions button,.navActions a{border:1px solid var(--line);background:rgba(255,255,255,.06);color:var(--text);border-radius:999px;padding:10px 13px;font-weight:900;text-decoration:none}.navActions .ownerMini{background:rgba(126,227,63,.1);border-color:rgba(126,227,63,.32);color:#dcffd0}.hero{max-width:1120px;margin:0 auto;min-height:calc(100vh - 180px);display:grid;grid-template-columns:minmax(0,1fr) 340px;gap:32px;align-items:center;padding:34px 18px}.badge{color:var(--green);font-size:12px;text-transform:uppercase;letter-spacing:.2em;font-weight:1000;margin:0 0 14px}.copyBlock h1{max-width:720px;font-size:clamp(42px,6.5vw,82px);line-height:.95;letter-spacing:-.055em;margin:0 0 18px}.lead{max-width:620px;color:var(--muted);font-size:clamp(16px,2vw,21px);line-height:1.55;margin:0}.actions{display:flex;flex-wrap:wrap;gap:12px;margin-top:26px}.primary,.secondary{border-radius:999px;padding:15px 20px;font-weight:1000;text-decoration:none}.primary{background:linear-gradient(135deg,var(--green),var(--green2));color:#03130d;box-shadow:0 16px 44px rgba(22,181,108,.24)}.secondary{border:1px solid var(--line);color:var(--text);background:rgba(255,255,255,.05)}.ownerCard{display:grid;grid-template-columns:34px minmax(0,1fr);gap:2px 10px;align-items:center;max-width:430px;margin-top:16px;padding:13px 14px;border:1px solid rgba(126,227,63,.28);border-radius:20px;background:rgba(126,227,63,.08);color:var(--text);text-decoration:none}.ownerCard span{grid-row:1/3;width:34px;height:34px;border-radius:12px;background:rgba(255,255,255,.08);display:grid;place-items:center}.ownerCard b{font-size:15px}.ownerCard small{color:var(--muted);font-size:12px;font-weight:850;line-height:1.3}.rate{display:inline-flex;margin-top:20px;padding:10px 13px;border:1px solid var(--line);border-radius:999px;color:var(--muted);font-weight:900}.qrCard{border:1px solid var(--line);border-radius:30px;background:linear-gradient(180deg,rgba(255,255,255,.08),rgba(255,255,255,.035));padding:18px;box-shadow:0 28px 80px rgba(0,0,0,.35)}.qrHead{display:flex;justify-content:space-between;gap:10px;align-items:center}.qrHead span{color:var(--green);font-size:11px;text-transform:uppercase;letter-spacing:.14em;font-weight:1000}.qrHead b{background:var(--panel2);border:1px solid var(--line);border-radius:999px;padding:8px 12px}.qrBox{height:170px;border:1px dashed var(--line);border-radius:26px;background:var(--panel);display:grid;place-items:center;color:var(--green);font-size:54px;font-weight:1000;margin:20px 0}.chips{display:grid;gap:9px}.chips span{background:var(--panel);border:1px solid var(--line);border-radius:15px;padding:12px;color:var(--muted);font-weight:900}.flow{max-width:1120px;margin:0 auto;padding:0 18px 34px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.flow article{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:16px}.flow span{width:34px;height:34px;border-radius:999px;background:linear-gradient(135deg,var(--green),var(--green2));color:#03130d;display:grid;place-items:center;font-weight:1000;margin-bottom:12px}.flow b{font-size:17px}.footer{border-top:1px solid var(--line);max-width:1120px;margin:0 auto;padding:20px 18px;color:var(--muted);font-weight:800;display:flex;justify-content:space-between;gap:16px}.footer small{color:rgba(184,212,194,.78);font-weight:900}@media(max-width:820px){.nav{height:68px}.brand b{font-size:17px}.hero{grid-template-columns:1fr;min-height:auto;padding:28px 16px}.copyBlock h1{font-size:46px}.lead{font-size:16px}.qrCard{max-width:420px}.flow{grid-template-columns:1fr 1fr;padding:0 16px 28px}.footer{display:block}.footer small{display:block;margin-top:8px}.navActions a:not(.ownerMini){display:none}}@media(max-width:430px){.brand span{width:36px;height:36px}.brand b{font-size:15px}.navActions .ownerMini{padding:9px 11px;font-size:12px}.copyBlock h1{font-size:39px}.primary,.secondary{width:100%;text-align:center}.ownerCard{grid-template-columns:30px minmax(0,1fr);border-radius:18px}.ownerCard span{width:30px;height:30px}.qrBox{height:135px}.flow{grid-template-columns:1fr 1fr}.flow article{padding:14px}.rate{font-size:13px}}
`;