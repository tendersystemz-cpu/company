'use client';

import { useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';

type PageProps = { params: { bayCode: string } };

export default function BayEntryPage({ params }: PageProps) {
  const router = useRouter();
  const bayCode = useMemo(() => params.bayCode.toUpperCase().padStart(2, '0'), [params.bayCode]);

  useEffect(() => {
    router.replace(`/b/${bayCode}/order`);
  }, [router, bayCode]);

  return (
    <main className="bayRedirect">
      <section>
        <span>EDGE RANGE OS</span>
        <h1>Bay {bayCode}</h1>
        <p>Opening order page...</p>
      </section>
      <style>{styles}</style>
    </main>
  );
}

const styles = `
.bayRedirect{min-height:100vh;display:grid;place-items:center;background:linear-gradient(135deg,#020907,#062419 64%,#020907);color:#f7fff9;font-family:Inter,Arial,sans-serif;padding:18px}.bayRedirect section{width:min(360px,100%);border:1px solid rgba(190,242,196,.18);background:rgba(10,33,25,.92);border-radius:28px;padding:28px;text-align:center;box-shadow:0 28px 80px rgba(0,0,0,.34)}.bayRedirect span{color:#9be84f;font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.bayRedirect h1{font-size:46px;margin:12px 0 8px;letter-spacing:-.05em}.bayRedirect p{margin:0;color:#b8d4c2;font-weight:900}
`;