'use client';

import Link from 'next/link';
import { useEffect, useMemo, useState } from 'react';
import { useRouter } from 'next/navigation';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type PageProps = { params: { bayCode: string } };
type FulfillmentType = 'self_pickup' | 'deliver_to_bay';
type CustomerType = 'walkin' | 'ukm_student_staff';
type CategoryKey = 'All' | 'Ball' | 'Drinks' | 'Food' | 'Snack' | 'Equipment' | 'Other';
type MenuItem = { id: string; category: string; name: string; description?: string | null; price: number | string };
type ProductCard = { id: string; title: string; subtitle: string; price: number; category: CategoryKey; icon: string; isBucket?: boolean };
type OrderOptions = {
  bucket?: { name: string; unit_price: number | string };
  menu_items?: MenuItem[];
  bay?: { display_name: string };
  location?: { name: string };
};

const CATEGORIES: CategoryKey[] = ['All', 'Ball', 'Drinks', 'Food', 'Snack', 'Equipment', 'Other'];

function publicName(name?: string | null) {
  return name?.trim() || 'Driving Range @ UKM';
}

function money(value: number | string | null | undefined) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function isBucketMenuItem(item: MenuItem) {
  const category = String(item.category || '').toLowerCase();
  const name = String(item.name || '').trim().toLowerCase();
  const text = `${category} ${name} ${item.description || ''}`.toLowerCase();
  return category === 'bucket' || /^100$/.test(name) || text.includes('bucket') || text.includes('ball') || text.includes('bola');
}

function categoryOf(item: MenuItem): CategoryKey {
  const raw = `${item.category} ${item.name}`.toLowerCase();
  if (raw.includes('drink') || raw.includes('minum') || raw.includes('air') || raw.includes('water') || raw.includes('teh') || raw.includes('kopi') || raw.includes('coffee') || raw.includes('juice')) return 'Drinks';
  if (raw.includes('snack') || raw.includes('nugget') || raw.includes('fries') || raw.includes('kentang') || raw.includes('kerepek')) return 'Snack';
  if (raw.includes('equipment') || raw.includes('rental') || raw.includes('sewa') || raw.includes('club') || raw.includes('glove') || raw.includes('tee')) return 'Equipment';
  if (raw.includes('food') || raw.includes('fb') || raw.includes('makan') || raw.includes('burger') || raw.includes('rice') || raw.includes('meal') || raw.includes('nasi')) return 'Food';
  return 'Other';
}

function iconOf(product: Pick<ProductCard, 'title' | 'category'>) {
  const name = product.title.toLowerCase();
  if (product.category === 'Ball') return '●';
  if (name.includes('water') || name.includes('air')) return '💧';
  if (name.includes('coffee') || name.includes('kopi')) return '☕';
  if (name.includes('burger')) return '🍔';
  if (name.includes('fries') || name.includes('kentang')) return '🍟';
  if (name.includes('nugget')) return '🍗';
  if (name.includes('nasi')) return '🍚';
  if (name.includes('roti')) return '🥞';
  if (product.category === 'Drinks') return '🥤';
  if (product.category === 'Food') return '🍽';
  if (product.category === 'Snack') return '•';
  if (product.category === 'Equipment') return '⛳';
  return '＋';
}

export default function OrderPage({ params }: PageProps) {
  const router = useRouter();
  const bayCode = useMemo(() => params.bayCode.toUpperCase().padStart(2, '0'), [params.bayCode]);
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerType, setCustomerType] = useState<CustomerType>('walkin');
  const [fulfillmentType, setFulfillmentType] = useState<FulfillmentType>('self_pickup');
  const [activeCategory, setActiveCategory] = useState<CategoryKey>('All');
  const [bucketQty, setBucketQty] = useState(0);
  const [options, setOptions] = useState<OrderOptions | null>(null);
  const [qty, setQty] = useState<Record<string, number>>({});
  const [showContact, setShowContact] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [helping, setHelping] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [helpMessage, setHelpMessage] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setLoading(true);
      setError(null);

      const { data, error } = await supabase.rpc('get_customer_order_options', {
        p_org_slug: ORG_SLUG,
        p_bay_code: bayCode,
      });

      if (cancelled) return;
      setLoading(false);

      if (error) setError(error.message || 'Gagal load menu.');
      else setOptions(data as OrderOptions);
    }

    load();
    return () => { cancelled = true; };
  }, [bayCode]);

  const rawMenuItems = options?.menu_items || [];
  const menuItems = useMemo(() => rawMenuItems.filter((item) => !isBucketMenuItem(item)), [rawMenuItems]);
  const unitPrice = customerType === 'ukm_student_staff' ? 8 : 12;

  const products = useMemo<ProductCard[]>(() => {
    const bucket: ProductCard = {
      id: 'bucket',
      title: '100 Balls',
      subtitle: customerType === 'ukm_student_staff' ? 'UKM Staff / Student' : 'Walk-in',
      price: unitPrice,
      category: 'Ball',
      icon: '●',
      isBucket: true,
    };

    const menuProducts = menuItems.map((item) => {
      const category = categoryOf(item);
      const base = {
        id: item.id,
        title: item.name,
        subtitle: item.description || category,
        price: Number(item.price || 0),
        category,
        icon: '',
        isBucket: false,
      };
      return { ...base, icon: iconOf(base) };
    });

    return [bucket, ...menuProducts];
  }, [customerType, menuItems, unitPrice]);

  const visibleProducts = activeCategory === 'All' ? products : products.filter((item) => item.category === activeCategory);
  const ballTotal = bucketQty * unitPrice;
  const menuTotal = menuItems.reduce((sum, item) => sum + Number(item.price || 0) * (qty[item.id] || 0), 0);
  const total = ballTotal + menuTotal;
  const cartCount = bucketQty + Object.values(qty).reduce((sum, value) => sum + value, 0);
  const cartLines = products.filter((item) => (item.isBucket ? bucketQty > 0 : (qty[item.id] || 0) > 0));

  function productQty(product: ProductCard) {
    return product.isBucket ? bucketQty : qty[product.id] || 0;
  }

  function changeProduct(product: ProductCard, delta: number) {
    if (product.isBucket) {
      setBucketQty((current) => Math.max(0, current + delta));
      return;
    }

    setQty((current) => ({ ...current, [product.id]: Math.max(0, (current[product.id] || 0) + delta) }));
  }

  async function requestHelp() {
    setHelping(true);
    setError(null);
    setHelpMessage(null);

    const { error: helpError } = await supabase.rpc('create_assistance_request', {
      p_org_slug: ORG_SLUG,
      p_bay_code: bayCode,
      p_message: 'Customer requested assistance from order page.',
    });

    setHelping(false);
    if (helpError) {
      setError(helpError.message || 'Gagal hantar bantuan.');
      return;
    }

    setHelpMessage('Staff notified. Bantuan telah dimaklumkan kepada staff.');
  }

  async function submitOrder() {
    if (total <= 0) {
      setError('Sila pilih item sebelum checkout.');
      return;
    }

    setSubmitting(true);
    setError(null);

    const selectedMenu = menuItems
      .filter((item) => (qty[item.id] || 0) > 0)
      .map((item) => ({ menu_item_id: item.id, quantity: qty[item.id] }));

    const { data, error } = await supabase.rpc('create_customer_order', {
      p_org_slug: ORG_SLUG,
      p_bay_code: bayCode,
      p_customer_name: customerName || null,
      p_customer_phone: customerPhone || null,
      p_bucket_qty: bucketQty,
      p_menu_items: selectedMenu,
      p_fulfillment_type: fulfillmentType,
      p_customer_type: customerType,
    });

    setSubmitting(false);

    if (error) {
      setError(error.message || 'Order gagal dihantar.');
      return;
    }

    const bookingId = data?.booking_id;
    if (!bookingId) {
      setError('Order berjaya tetapi booking ID tidak diterima.');
      return;
    }

    router.push(`/pay/${bookingId}`);
  }

  return (
    <main className="rfOrder">
      <header className="topBar">
        <Link href="/" className="brand" aria-label="EDGE RANGE OS home">
          <span>DG</span>
          <b>EDGE RANGE OS</b>
        </Link>
        <div className="bayMeta">
          <small>{publicName(options?.location?.name)}</small>
          <strong>Bay {bayCode}</strong>
        </div>
      </header>

      <section className="heroCard">
        <div className="heroTop">
          <div>
            <span>Add-on Order</span>
            <h1>Bay {bayCode}</h1>
          </div>
          <button className="helpBtn" type="button" disabled={helping} onClick={requestHelp}>
            {helping ? 'Sending...' : 'Need Help'}
          </button>
        </div>

        <p className="hint">Pay using the TNG / DuitNow QR placed at counter or bay. Keep proof if staff asks.</p>

        <div className="modeGrid" aria-label="Order options">
          <OptionButton active={customerType === 'walkin'} title="Walk-in" subtitle="RM12" onClick={() => setCustomerType('walkin')} />
          <OptionButton active={customerType === 'ukm_student_staff'} title="UKM" subtitle="RM8" onClick={() => setCustomerType('ukm_student_staff')} />
          <OptionButton active={fulfillmentType === 'self_pickup'} title="Self Pickup" subtitle="Ambil sendiri" onClick={() => setFulfillmentType('self_pickup')} />
          <OptionButton active={fulfillmentType === 'deliver_to_bay'} title="Deliver to Bay" subtitle="Hantar ke bay" onClick={() => setFulfillmentType('deliver_to_bay')} />
        </div>

        <button type="button" className="optionalToggle" onClick={() => setShowContact((value) => !value)}>
          <span>{showContact ? 'Hide optional contact details' : 'Add optional contact details'}</span>
          <b>›</b>
        </button>

        {showContact ? (
          <div className="miniFields">
            <input value={customerName} onChange={(event) => setCustomerName(event.target.value)} placeholder="Name optional" />
            <input value={customerPhone} onChange={(event) => setCustomerPhone(event.target.value)} placeholder="WhatsApp optional" />
          </div>
        ) : null}
      </section>

      {error ? <div className="notice error">{error}</div> : null}
      {helpMessage ? <div className="notice success">{helpMessage}</div> : null}
      {loading ? <div className="notice">Loading menu...</div> : null}

      <nav className="categoryBar" aria-label="Menu category">
        {CATEGORIES.map((cat) => (
          <button key={cat} type="button" className={activeCategory === cat ? 'active' : ''} onClick={() => setActiveCategory(cat)}>
            {cat}
          </button>
        ))}
      </nav>

      <section className="menuGrid" aria-label="Menu items">
        {visibleProducts.map((product) => (
          <OrderCard
            key={product.id}
            product={product}
            count={productQty(product)}
            onMinus={() => changeProduct(product, -1)}
            onPlus={() => changeProduct(product, 1)}
          />
        ))}
      </section>

      <section className="cartBar" aria-label="Checkout summary">
        <div className="cartText">
          <span>{fulfillmentType === 'self_pickup' ? 'Self Pickup' : `Deliver Bay ${bayCode}`} · {cartCount} item</span>
          <strong>{money(total)}</strong>
          <small>{cartLines.length > 0 ? cartLines.slice(0, 2).map((item) => `${productQty(item)}x ${item.title}`).join(' · ') : 'Select item to continue'}</small>
        </div>
        <button type="button" disabled={submitting || loading || total <= 0} onClick={submitOrder}>
          {submitting ? 'Processing' : 'Checkout'} <span>›</span>
        </button>
      </section>

      <style jsx>{styles}</style>
    </main>
  );
}

function OptionButton({ active, title, subtitle, onClick }: { active: boolean; title: string; subtitle: string; onClick: () => void }) {
  return (
    <button type="button" className={`optionBtn ${active ? 'active' : ''}`} onClick={onClick}>
      <span>
        <b>{title}</b>
        <small>{subtitle}</small>
      </span>
      <em>{active ? '✓' : ''}</em>
    </button>
  );
}

function OrderCard({ product, count, onMinus, onPlus }: { product: ProductCard; count: number; onMinus: () => void; onPlus: () => void }) {
  return (
    <article className={`itemCard ${count > 0 ? 'selected' : ''}`}>
      <button className="tapArea" type="button" onClick={onPlus}>
        <i>{product.icon}</i>
        <h3>{product.title}</h3>
        <strong>{money(product.price)}</strong>
      </button>
      <div className="stepper">
        <button type="button" className={count > 0 ? '' : 'ghost'} onClick={onMinus} aria-label={`Remove ${product.title}`}>−</button>
        <b>{count}</b>
        <button type="button" onClick={onPlus} aria-label={`Add ${product.title}`}>+</button>
      </div>
    </article>
  );
}

const styles = `
.rfOrder{--bg:#f6faf3;--text:#071812;--muted:#5d7066;--line:#dfeadd;--green:#08783b;--deep:#031a12;min-height:100vh;background:radial-gradient(circle at top left,rgba(143,225,69,.16),transparent 28%),var(--bg);color:var(--text);font-family:Inter,Arial,sans-serif;padding:8px 8px calc(188px + env(safe-area-inset-bottom));overflow-x:hidden}.topBar,.heroCard,.categoryBar,.menuGrid,.notice{max-width:560px;margin-left:auto;margin-right:auto}.topBar{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:56px;padding:10px 12px;border-radius:20px;background:linear-gradient(135deg,#031810 0%,#08301f 58%,#0e4a28 100%);box-shadow:0 12px 28px rgba(3,24,16,.18)}.brand{display:flex;align-items:center;gap:9px;min-width:0;color:#fff;text-decoration:none}.brand span{display:grid;place-items:center;width:34px;height:34px;border-radius:12px;background:#8fe145;color:#05351f;font-weight:950}.brand b{font-size:13px;line-height:1.05;letter-spacing:.03em}.bayMeta{display:flex;flex-direction:column;align-items:flex-end;gap:2px;min-width:82px;color:#e9fff0}.bayMeta small{max-width:130px;overflow:hidden;color:rgba(233,255,240,.72);font-size:10px;font-weight:750;text-overflow:ellipsis;white-space:nowrap}.bayMeta strong{font-size:17px;line-height:1}.heroCard{margin-top:8px;padding:12px;border:1px solid var(--line);border-radius:22px;background:rgba(255,255,255,.96);box-shadow:0 8px 22px rgba(27,54,40,.08)}.heroTop,.optionBtn,.optionalToggle,.cartBar{display:flex;align-items:center}.heroTop{align-items:flex-start;justify-content:space-between;gap:12px}.heroTop span{display:block;color:var(--green);font-size:11px;font-weight:900;letter-spacing:.08em;text-transform:uppercase}.heroTop h1{margin:2px 0 0;color:var(--deep);font-size:27px;line-height:.95;letter-spacing:-.06em}.helpBtn{min-height:30px;border:0;border-radius:999px;background:#ecf9df;color:#155829;font-size:12px;font-weight:900;padding:0 12px;white-space:nowrap}.hint{margin:8px 0 10px;color:var(--muted);font-size:12px;line-height:1.32}.modeGrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px}.optionBtn{justify-content:space-between;min-height:48px;border:1px solid #dce8d8;border-radius:15px;background:#fbfdf8;color:var(--text);padding:8px 9px;text-align:left}.optionBtn span{min-width:0}.optionBtn b,.optionBtn small{display:block}.optionBtn b{overflow:hidden;font-size:12px;line-height:1.1;text-overflow:ellipsis;white-space:nowrap}.optionBtn small{margin-top:2px;color:var(--muted);font-size:10px;font-weight:800;line-height:1.05}.optionBtn em{display:grid;flex:0 0 auto;place-items:center;width:17px;height:17px;border-radius:50%;color:white;font-size:10px;font-style:normal;font-weight:900}.optionBtn.active{border-color:rgba(8,120,59,.42);background:linear-gradient(180deg,#f3ffe9,#fff)}.optionBtn.active em{background:var(--green)}.optionalToggle{justify-content:space-between;width:100%;margin-top:8px;border:0;border-radius:14px;background:#f4f8ef;color:#42584c;font-size:12px;font-weight:850;padding:9px 10px}.optionalToggle b{color:var(--green);font-size:19px;line-height:.7}.miniFields{display:grid;grid-template-columns:1fr 1fr;gap:7px;margin-top:7px}.miniFields input{width:100%;min-width:0;border:1px solid var(--line);border-radius:13px;background:#fff;color:var(--text);font-size:13px;font-weight:750;padding:10px 9px;outline:none}.notice{margin-top:8px;border:1px solid #dce8d8;border-radius:14px;background:#fff;color:var(--muted);font-size:12px;font-weight:800;padding:9px 10px}.notice.error{border-color:#ffd3d3;background:#fff7f7;color:#9b1c1c}.notice.success{border-color:#cbeeba;background:#f4ffef;color:#1f6e2f}.categoryBar{display:flex;gap:6px;overflow-x:auto;margin-top:9px;padding:1px 0 6px;scrollbar-width:none}.categoryBar::-webkit-scrollbar{display:none}.categoryBar button{flex:0 0 auto;min-height:31px;border:1px solid #dbe7d7;border-radius:999px;background:#fff;color:#53675d;font-size:12px;font-weight:900;padding:0 12px}.categoryBar button.active{border-color:var(--green);background:var(--deep);color:#fff}.menuGrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-top:2px}.itemCard{min-width:0;overflow:hidden;border:1px solid #dfe9dc;border-radius:17px;background:#fff;box-shadow:0 7px 18px rgba(25,55,37,.07)}.itemCard.selected{border-color:rgba(8,120,59,.62);box-shadow:0 0 0 1px rgba(8,120,59,.13),0 9px 20px rgba(25,55,37,.08)}.tapArea{display:flex;flex-direction:column;align-items:flex-start;width:100%;min-height:78px;border:0;background:transparent;color:var(--text);padding:8px 8px 4px;text-align:left}.tapArea i{display:grid;place-items:center;width:24px;height:24px;margin-bottom:5px;border-radius:10px;background:#eff7e9;color:var(--green);font-size:13px;font-style:normal;font-weight:900}.tapArea h3{display:-webkit-box;min-height:24px;margin:0;overflow:hidden;-webkit-box-orient:vertical;-webkit-line-clamp:2;font-size:10.5px;font-weight:900;line-height:1.12}.tapArea strong{margin-top:auto;color:var(--green);font-size:11px;font-weight:950;letter-spacing:-.03em}.stepper{display:grid;grid-template-columns:25px 1fr 25px;align-items:center;gap:2px;border-top:1px solid #eef4eb;padding:4px}.stepper button{display:grid;place-items:center;width:25px;height:25px;border:0;border-radius:10px;background:var(--deep);color:#fff;font-size:16px;font-weight:900;line-height:1}.stepper button.ghost{background:#eef4eb;color:#a5b5aa}.stepper b{text-align:center;color:var(--deep);font-size:12px;font-weight:950}.cartBar{position:fixed;left:50%;bottom:calc(86px + env(safe-area-inset-bottom));transform:translateX(-50%);z-index:50;justify-content:space-between;gap:10px;width:min(calc(100vw - 16px),560px);max-width:560px;margin:0;border:1px solid rgba(255,255,255,.18);border-radius:20px;background:rgba(3,24,16,.98);box-shadow:0 16px 40px rgba(3,24,16,.3);padding:9px 9px 9px 12px}.cartText{min-width:0;flex:1 1 auto;color:#fff}.cartText span,.cartText small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.cartText span{color:rgba(255,255,255,.68);font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.08em}.cartText strong{display:block;margin-top:1px;color:#b9ff72;font-size:22px;font-weight:950;letter-spacing:-.06em;line-height:1}.cartText small{margin-top:3px;color:rgba(255,255,255,.64);font-size:10px;font-weight:750}.cartBar button{flex:0 0 124px;height:50px;border:0;border-radius:15px;background:linear-gradient(135deg,#9af451,#42c96a);color:#062012;font-size:14px;font-weight:950;box-shadow:0 10px 22px rgba(137,225,67,.25)}.cartBar button:disabled{opacity:.46;box-shadow:none}.cartBar button span{font-size:18px;line-height:0}button{cursor:pointer;-webkit-tap-highlight-color:transparent}@media(max-width:370px){.rfOrder{padding-left:7px;padding-right:7px}.menuGrid{grid-template-columns:repeat(3,minmax(0,1fr))}.cartBar{bottom:calc(82px + env(safe-area-inset-bottom));width:min(calc(100vw - 14px),560px)}.cartBar button{flex-basis:108px}}@media(min-width:620px){.rfOrder{padding-top:16px}.cartBar{bottom:calc(18px + env(safe-area-inset-bottom))}}
`;