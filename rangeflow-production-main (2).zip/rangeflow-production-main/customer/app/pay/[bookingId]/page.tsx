'use client';

import Link from 'next/link';
import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabase';

type PageProps = { params: { bookingId: string } };
type Method = 'tng' | 'duitnow_qr' | 'bank_transfer';
type PaymentSettings = {
  duitnow_qr_url?: string;
  tng_qr_url?: string;
  bank_name?: string;
  bank_account_name?: string;
  bank_account_no?: string;
};
type ReceiptData = {
  booking?: { id: string; qr_token: string; total_amount: number; payment_status: string };
  bay?: { code: string; display_name: string };
  location?: { name: string; payment_settings?: PaymentSettings };
};

function money(value: number | string | null | undefined) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function readProofFile(file?: File | null) {
  return new Promise<string>((resolve, reject) => {
    if (!file) return resolve('');
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ''));
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export default function PayPage({ params }: PageProps) {
  const router = useRouter();
  const [data, setData] = useState<ReceiptData | null>(null);
  const [method, setMethod] = useState<Method>('tng');
  const [payerName, setPayerName] = useState('');
  const [paymentReference, setPaymentReference] = useState('');
  const [proofUrl, setProofUrl] = useState('');
  const [note, setNote] = useState('');
  const [showProof, setShowProof] = useState(false);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      const { data: receipt, error: receiptError } = await supabase.rpc('get_customer_receipt', {
        p_booking_id: params.bookingId,
      });

      if (cancelled) return;
      setLoading(false);

      if (receiptError) setError(receiptError.message || 'Booking tidak dijumpai.');
      else setData(receipt as ReceiptData);
    }

    load();
    return () => { cancelled = true; };
  }, [params.bookingId]);

  async function onProofFile(file?: File | null) {
    setError(null);
    try {
      setProofUrl(await readProofFile(file));
    } catch {
      setError('Gagal baca gambar bukti bayaran.');
    }
  }

  async function submitOptionalProof() {
    if (!data) return;
    if (!paymentReference.trim() && !proofUrl.trim()) {
      setError('Reference atau screenshot hanya perlu jika staff minta.');
      return;
    }

    setSubmitting(true);
    setError(null);

    const { error: submitError } = await supabase.rpc('submit_customer_payment_proof', {
      p_booking_id: params.bookingId,
      p_method: method,
      p_payer_name: payerName || null,
      p_payment_reference: paymentReference || null,
      p_proof_url: proofUrl || null,
      p_note: note || null,
    });

    setSubmitting(false);

    if (submitError) {
      setError(submitError.message || 'Gagal submit bukti bayaran.');
      return;
    }

    router.push(`/receipt/${params.bookingId}`);
  }

  const bayCode = data?.bay?.code || '01';
  const bayName = data?.bay?.display_name || `Bay ${bayCode}`;
  const total = Number(data?.booking?.total_amount || 0);
  const settings = data?.location?.payment_settings || {};
  const isPaid = data?.booking?.payment_status === 'paid';
  const qrUrl = method === 'tng' ? settings.tng_qr_url || settings.duitnow_qr_url : settings.duitnow_qr_url;

  return (
    <main className="payPage">
      <header className="topBar">
        <Link href={`/b/${bayCode}/order`} className="brand"><span>DG</span><b>EDGE RANGE OS</b></Link>
        <div><small>Manual QR Payment</small><strong>{bayName}</strong></div>
      </header>

      <section className="payCard">
        <div className="amountBox">
          <span>Total to Pay</span>
          <h1>{money(total)}</h1>
          <p>{data?.booking?.qr_token || 'Loading'} · {isPaid ? 'Paid' : 'Waiting staff verify'}</p>
        </div>

        {loading ? <div className="notice">Loading payment...</div> : null}
        {error ? <div className="notice error">{error}</div> : null}

        {data ? <>
          <section className="manualBox">
            <b>Scan the operator TNG / DuitNow QR</b>
            <span>Use the QR placed at the counter or beside this bay QR. This system does not process payment gateway checkout.</span>
          </section>

          <div className="tabs">
            <button type="button" className={method === 'tng' ? 'active' : ''} onClick={() => setMethod('tng')}>TNG</button>
            <button type="button" className={method === 'duitnow_qr' ? 'active' : ''} onClick={() => setMethod('duitnow_qr')}>DuitNow</button>
            <button type="button" className={method === 'bank_transfer' ? 'active' : ''} onClick={() => setMethod('bank_transfer')}>Bank</button>
          </div>

          {method === 'bank_transfer' ? (
            <section className="bankBox">
              <Row label="Bank" value={settings.bank_name || 'Refer counter'} />
              <Row label="Name" value={settings.bank_account_name || 'Refer counter'} />
              <Row label="Account" value={settings.bank_account_no || 'Refer counter'} />
              <Row label="Amount" value={money(total)} />
            </section>
          ) : (
            <section className="qrBox">
              {qrUrl ? <img src={qrUrl} alt="Operator payment QR" /> : <div className="qrPlaceholder">Use physical QR at counter / bay</div>}
              <b>{method === 'tng' ? 'TNG / DuitNow QR' : 'DuitNow QR'}</b>
              <span>Pay exact amount: {money(total)}</span>
            </section>
          )}

          <section className="steps">
            <article><b>1</b><span>Scan QR</span></article>
            <article><b>2</b><span>Pay exact amount</span></article>
            <article><b>3</b><span>Show staff if requested</span></article>
          </section>

          <p className="proofNote">Please keep payment proof if requested by staff. Screenshot upload is optional only.</p>

          <div className="actions">
            <Link className="primary" href={`/receipt/${params.bookingId}`}>{isPaid ? 'Open Receipt' : 'Open Slip'}</Link>
            <button className="secondary" type="button" onClick={() => setShowProof(!showProof)}>Optional Proof</button>
            <Link className="secondary" href={`/b/${bayCode}/order`}>Back</Link>
          </div>

          {showProof ? <section className="proofBox">
            <b>Optional proof only if staff requests</b>
            <input value={payerName} onChange={(e) => setPayerName(e.target.value)} placeholder="Payer name optional" />
            <input value={paymentReference} onChange={(e) => setPaymentReference(e.target.value)} placeholder="Reference / Transaction ID optional" />
            <input type="file" accept="image/*" onChange={(e) => onProofFile(e.target.files?.[0])} />
            {proofUrl ? <div className="preview"><img src={proofUrl} alt="Payment proof" /></div> : null}
            <input value={note} onChange={(e) => setNote(e.target.value)} placeholder="Note optional" />
            <button type="button" disabled={submitting} onClick={submitOptionalProof}>{submitting ? 'Submitting...' : 'Submit Optional Proof'}</button>
          </section> : null}
        </> : null}
      </section>

      <style jsx>{styles}</style>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return <div className="row"><span>{label}</span><b>{value}</b></div>;
}

const styles = `
.payPage{--bg:#f6faf3;--panel:#fff;--text:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--text);font-family:Inter,Arial,sans-serif;padding:8px 8px 24px}.topBar{max-width:560px;margin:0 auto 8px;background:linear-gradient(135deg,#031810,#0e4a28);color:#fff;border-radius:20px;padding:10px 12px;display:flex;align-items:center;justify-content:space-between;gap:12px;box-shadow:0 12px 28px rgba(7,28,22,.12)}.brand{display:flex;align-items:center;gap:9px;color:#fff;text-decoration:none}.brand span{width:34px;height:34px;border-radius:12px;background:var(--accent);display:grid;place-items:center;color:#06110d;font-weight:950}.brand b{font-size:15px;letter-spacing:.03em}.topBar div{text-align:right}.topBar small{display:block;color:#b9d8c6;font-size:10px;font-weight:900;text-transform:uppercase;letter-spacing:.08em}.topBar strong{font-size:18px}.payCard{max-width:560px;margin:0 auto;border:1px solid var(--line);background:var(--panel);border-radius:22px;padding:12px;box-shadow:0 10px 24px rgba(7,28,22,.07)}.amountBox{background:linear-gradient(135deg,#061c14,#0a3322);color:#fff;border-radius:20px;padding:14px;text-align:center}.amountBox span{color:#b9d8c6;font-size:10px;font-weight:950;text-transform:uppercase;letter-spacing:.12em}.amountBox h1{font-size:38px;line-height:1;margin:6px 0 4px}.amountBox p{margin:0;color:#d4f8df;font-size:12px;font-weight:900}.manualBox{margin-top:10px;border:1px solid #cfe5c5;background:#f6fff0;border-radius:18px;padding:11px 12px}.manualBox b,.manualBox span{display:block}.manualBox b{font-size:15px}.manualBox span{margin-top:4px;color:var(--muted);font-size:12px;font-weight:850;line-height:1.35}.notice{margin:8px 0 0;border-radius:14px;padding:9px 10px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900;font-size:12px}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin:10px 0}.tabs button{border:1px solid var(--line);background:#fff;color:var(--muted);border-radius:14px;padding:10px;font-size:12px;font-weight:950}.tabs button.active{background:var(--deep);border-color:var(--deep);color:#fff}.qrBox,.bankBox{border:1px solid var(--line);background:#fbfdf9;border-radius:20px;padding:12px;text-align:center}.qrBox img{max-width:220px;width:100%;max-height:240px;margin:0 auto 8px;border-radius:16px;display:block}.qrPlaceholder{height:150px;border:2px dashed #b6c5b8;border-radius:16px;display:grid;place-items:center;color:var(--muted);font-weight:950;background:#fff;margin-bottom:8px;text-align:center;padding:12px}.qrBox b,.qrBox span{display:block}.qrBox span{margin-top:3px;color:var(--muted);font-size:12px;font-weight:900}.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:9px 0}.row:last-child{border-bottom:0}.row span{color:var(--muted);font-weight:900}.row b{text-align:right}.steps{display:grid;grid-template-columns:repeat(3,1fr);gap:7px;margin:10px 0}.steps article{border:1px solid var(--line);background:#fff;border-radius:16px;padding:9px 7px;text-align:center}.steps b{width:25px;height:25px;border-radius:999px;background:linear-gradient(135deg,var(--accent),var(--green2));color:#06110d;display:grid;place-items:center;margin:0 auto 6px;font-size:12px}.steps span{display:block;font-size:11px;font-weight:950;line-height:1.15}.proofNote{margin:0 0 10px;color:var(--muted);font-size:12px;font-weight:850;text-align:center;line-height:1.35}.actions{display:grid;grid-template-columns:1.25fr 1fr .7fr;gap:7px}.actions a,.actions button,.proofBox button{border:0;border-radius:15px;padding:12px 10px;text-align:center;text-decoration:none;font-weight:950;font-size:13px}.primary{background:linear-gradient(135deg,var(--accent),var(--green2));color:#06110d}.secondary{background:#f3f7f1;color:var(--text);border:1px solid var(--line)!important}.proofBox{margin-top:10px;border:1px dashed var(--line);background:#fbfdf9;border-radius:18px;padding:10px;display:grid;gap:7px}.proofBox b{font-size:13px}.proofBox input{border:1px solid var(--line);border-radius:13px;background:#fff;padding:10px 11px;color:var(--text);font-size:13px;font-weight:800;min-width:0}.proofBox button{background:var(--green);color:#fff}.preview{border:1px solid var(--line);border-radius:14px;padding:8px;background:#fff}.preview img{max-height:180px;margin:0 auto;border-radius:12px;display:block}@media(max-width:420px){.payPage{padding:8px}.amountBox h1{font-size:34px}.steps{grid-template-columns:repeat(3,1fr)}.actions{grid-template-columns:1fr}.qrBox img{max-height:210px}}
`;