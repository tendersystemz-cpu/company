import { createClient } from '@supabase/supabase-js';

const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const key = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

// EDGE RANGE OS production tenant lock.
// Do not trust stale Coolify NEXT_PUBLIC_ORG_SLUG values from older duplicate apps.
export const ORG_SLUG = 'drukm';
export const HAS_SUPABASE_ENV = Boolean(url && key);

export function hasSupabaseEnv() {
  return HAS_SUPABASE_ENV;
}

function envError() {
  return Promise.resolve({ data: null, error: { message: 'Missing Supabase public environment variables.' } });
}

const mockClient = {
  rpc: envError,
  from: () => ({
    select: () => ({
      eq: () => ({ maybeSingle: envError, single: envError, limit: () => ({ maybeSingle: envError }) }),
      maybeSingle: envError,
      single: envError,
      limit: () => ({ maybeSingle: envError }),
    }),
    insert: () => ({ select: () => ({ single: envError }) }),
    update: () => ({ eq: envError }),
  }),
};

export const supabase = HAS_SUPABASE_ENV
  ? createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } })
  : (mockClient as any);
