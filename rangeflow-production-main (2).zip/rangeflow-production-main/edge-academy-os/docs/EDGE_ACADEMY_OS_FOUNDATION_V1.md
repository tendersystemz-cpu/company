# EDGE Academy OS Foundation V1

## Purpose

EDGE Academy OS is the coaching, student progress, lesson booking, package, attendance, and training management module under the EDGE Ecosystem.

It must be able to operate independently as a SaaS product, while remaining compatible with EDGE Core, EDGE Membership, EDGE Booking, EDGE CRM, EDGE POS, EDGE Online Proshop, and EDGE AI.

---

## Product Positioning

EDGE Academy OS is not only a golf student portal.

It is a universal sports coaching operating system for:

- Golf academies
- Driving range coaching programs
- Sports schools
- Individual coaches
- Multi-coach academies
- Franchise-style training businesses

Golf is the first vertical. The architecture must remain sport-agnostic where possible.

---

## V1 Scope

```text
EDGE Academy OS V1
├── Academy Dashboard
├── Student Management
├── Coach Management
├── Package Management
├── Syllabus Management
├── Lesson Session Management
├── Attendance Tracking
├── Progress Tracking
├── Payment Tracking
└── Bilingual BM/EN Content
```

---

## Roles

### Super Admin
Platform owner. Can manage all organizations, modules, billing, and system configuration.

### Organization Owner
Academy or range business owner. Can manage academy settings, coaches, students, packages, payments, and reports.

### Manager / Admin Staff
Operational user. Can manage students, sessions, attendance, and payment records.

### Coach
Can view assigned students, manage sessions, mark attendance, update progress, and add coach notes.

### Student
Can view own package, progress, sessions, attendance history, coach notes, and payment status.

### Parent / Guardian
Optional future role for junior students.

---

## Core Concepts

### Organization
The tenant. Every academy, range, or sports business is an organization.

### Academy
An academy profile under an organization. In simple deployments, one organization may have one academy. In enterprise deployments, one organization may own multiple academies or branches.

### Coach
A user with coaching privileges.

### Student
A user receiving training. A student may be linked to one or more packages.

### Package
A commercial training package such as Beginner, Intermediate, Advanced, Junior Program, Private Coaching, or Group Class.

### Syllabus Template
The structured training roadmap for a package or skill level.

### Lesson Session
A scheduled coaching session.

### Attendance
The check-in/completion state of a lesson session.

### Progress
A student's completion and proficiency status against syllabus items.

### Payment
A record of package payment, invoice, or manual payment proof.

---

## Operational Flow

### Student Purchase Flow

```text
Student registers
→ Selects package
→ Payment created
→ Payment confirmed
→ Subscription/package activated
→ Student can book lesson sessions
```

### Lesson Flow

```text
Student books session
→ Coach confirms or system auto-confirms
→ Student attends
→ Coach marks attendance
→ Coach updates notes
→ Coach updates syllabus progress
→ Remaining session count is reduced
```

### Progress Flow

```text
Package selected
→ Syllabus template assigned
→ Student progress rows created
→ Coach marks progress per topic
→ Student dashboard shows completion percentage
```

### Renewal Flow

```text
Remaining sessions low or package expired
→ Notification created
→ Student/parent renews
→ Payment confirmed
→ New package cycle starts
```

---

## Dashboard Requirements

### Academy Owner Dashboard

- Total students
- Active students
- Active coaches
- Today's sessions
- Upcoming sessions
- Attendance rate
- Active packages
- Revenue summary
- Outstanding payments
- Recent coach notes
- Student progress summary

### Coach Dashboard

- Today's sessions
- Assigned students
- Pending attendance updates
- Students requiring review
- Recent notes
- Progress checklist

### Student Dashboard

- Active package
- Remaining sessions
- Next lesson
- Progress percentage
- Completed syllabus items
- Coach notes
- Payment status
- Attendance history

---

## Database Blueprint V1

All tenant-owned tables must include:

```sql
organization_id uuid not null
```

### academy_profiles

```text
id uuid primary key
organization_id uuid not null
name text not null
slug text not null
sport_type text default 'golf'
logo_url text
contact_name text
contact_phone text
contact_email text
address text
timezone text default 'Asia/Kuala_Lumpur'
default_language text default 'ms'
status text default 'active'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### academy_user_profiles

This table extends core users with academy-specific profile data.

```text
id uuid primary key
organization_id uuid not null
user_id uuid not null
academy_id uuid
role_key text not null
full_name text not null
phone text
email text
avatar_url text
status text default 'active'
metadata jsonb default '{}'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### coaches

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
user_profile_id uuid not null
coach_code text
specialization text
bio_ms text
bio_en text
hourly_rate numeric default 0
status text default 'active'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### students

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
user_profile_id uuid
student_code text
full_name text not null
phone text
email text
birthdate date
skill_level text default 'beginner'
target_level text
handicap numeric
guardian_name text
guardian_phone text
medical_notes text
status text default 'active'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### training_packages

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
name_ms text not null
name_en text not null
description_ms text
description_en text
level_key text not null
sport_type text default 'golf'
session_count integer not null
validity_days integer default 90
price numeric not null default 0
currency text default 'MYR'
is_group_package boolean default false
max_students_per_session integer default 1
status text default 'active'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### syllabus_templates

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
package_id uuid
level_key text not null
sport_type text default 'golf'
title_ms text not null
title_en text not null
description_ms text
description_en text
sequence_no integer not null
status text default 'active'
created_at timestamptz default now()
updated_at timestamptz default now()
```

### student_packages

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
student_id uuid not null
package_id uuid not null
assigned_coach_id uuid
status text default 'pending_payment'
payment_status text default 'unpaid'
start_date date
end_date date
sessions_total integer not null
sessions_used integer default 0
sessions_remaining integer not null
price numeric not null default 0
created_at timestamptz default now()
updated_at timestamptz default now()
```

### lesson_sessions

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
student_package_id uuid
student_id uuid not null
coach_id uuid not null
package_id uuid
session_no integer
scheduled_start timestamptz not null
scheduled_end timestamptz not null
location_text text
bay_id uuid
status text default 'booked'
attendance_status text default 'pending'
coach_notes text
student_notes text
created_at timestamptz default now()
updated_at timestamptz default now()
```

### attendance_records

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
lesson_session_id uuid not null
student_id uuid not null
coach_id uuid
status text not null
check_in_at timestamptz
completed_at timestamptz
marked_by uuid
remarks text
created_at timestamptz default now()
updated_at timestamptz default now()
```

### student_syllabus_progress

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
student_id uuid not null
student_package_id uuid
syllabus_template_id uuid not null
status text default 'not_started'
proficiency text
coach_id uuid
coach_notes text
completed_at timestamptz
created_at timestamptz default now()
updated_at timestamptz default now()
```

### academy_payments

This table may later merge into EDGE Core billing/payment tables. For V1, it can exist as an Academy OS scoped payment tracking table.

```text
id uuid primary key
organization_id uuid not null
academy_id uuid not null
student_id uuid
student_package_id uuid
amount numeric not null default 0
currency text default 'MYR'
gateway text default 'manual'
gateway_ref text
payment_method text
status text default 'pending'
payer_name text
payer_phone text
proof_url text
paid_at timestamptz
metadata jsonb default '{}'
created_at timestamptz default now()
updated_at timestamptz default now()
```

---

## Status Values

### Lesson Status

```text
booked
confirmed
completed
cancelled
no_show
rescheduled
```

### Attendance Status

```text
pending
present
absent
late
completed
no_show
```

### Progress Status

```text
not_started
in_progress
completed
repeat_needed
excellent
```

### Package Status

```text
pending_payment
active
completed
expired
cancelled
```

---

## Bilingual Rule

System UI text should be handled by application translation files.

Business content from database should use bilingual columns:

```text
name_ms
name_en
description_ms
description_en
title_ms
title_en
```

Do not hardcode third-party brand names in default syllabus or default marketing copy.

Use generic industry terms such as:

- Launch monitor
- Video swing analysis
- Performance analysis
- Advanced radar analysis
- Official golf rules

---

## V1 Golf Package Defaults

### Beginner

- Fundamentals
- Grip
- Posture
- Alignment
- Half swing
- Full swing
- Chipping
- Putting
- Basic course etiquette

### Intermediate

- Swing audit
- Driver consistency
- Iron distance control
- Short game improvement
- Bunker basics
- Putting break reading
- Shot shaping basics
- 9-hole course management

### Advanced

- Performance analysis
- Scoring zone mastery
- Wedge distance system
- Recovery shots
- Mental strategy
- Tournament preparation
- 18-hole strategy

---

## Integration Boundaries

### With EDGE Core

Uses:

- Organizations
- Users
- Roles
- Permissions
- Billing
- Notifications
- Audit logs

### With EDGE Booking

Shares:

- Availability
- Calendar
- Booking rules
- Resource scheduling

### With EDGE Membership

Shares:

- Member profile
- Access privileges
- Subscription status
- Credits

### With EDGE CRM

Sends events:

- Student registered
- Package purchased
- Payment completed
- Session attended
- Package expiring
- Student inactive

### With EDGE Online Proshop

Possible future actions:

- Coach recommends product
- Student buys training bundle
- Academy sells merchandise
- Student purchases equipment

### With EDGE AI

Future AI insights:

- Student weakness pattern
- Recommended next lesson
- Retention risk
- Coach performance summary
- Revenue forecast

---

## Implementation Sequence

### Step 1
Create isolated Academy OS documentation and migration files under:

```text
edge-academy-os/
```

### Step 2
Create Academy OS database migration SQL for Supabase `rangeOS` project.

### Step 3
Apply migration after review.

### Step 4
Seed sample academy, coaches, students, packages, and syllabus.

### Step 5
Build first visible dashboard/admin prototype.

### Step 6
Connect payment tracking and ToyyibPay later.

---

## Non-Negotiable Rules

1. Do not break existing RangeOS production flow.
2. Do not overwrite existing RangeFlow tables without explicit migration strategy.
3. Do not mix Academy OS UI into RangeOS customer order flow yet.
4. Do not add AI, marketplace, or tournament logic into V1.
5. Keep Academy OS isolated until foundation is stable.

---

## Immediate Next Deliverable

Create:

```text
edge-academy-os/supabase/migrations/001_edge_academy_os_foundation.sql
```

This migration will create the Academy OS V1 tables safely without modifying existing RangeOS operational tables.
