# EDGE Ecosystem Master Architecture V1

## Master Structure

```text
EDGE Ecosystem
├── EDGE Core
├── EDGE RangeOS
├── EDGE Academy OS
├── EDGE POS
├── EDGE CRM
├── EDGE Membership
├── EDGE Tournament
├── EDGE Booking
├── EDGE AI
└── EDGE Online Proshop
```

## Core Principle

EDGE is not a single golf web app. EDGE is a modular sports technology ecosystem platform.

The architecture must follow these rules:

1. Core-first
2. Modular services
3. API-first
4. Tenant-safe
5. SaaS-ready
6. AI-ready
7. Mobile-ready
8. Event-driven
9. Production-oriented
10. Non-destructive scaling

---

## EDGE Core

EDGE Core is the shared backbone for every module.

### Responsibilities

- Authentication
- Organizations / Tenants
- Roles
- Permissions
- Billing
- Wallet
- Notifications
- Audit logs
- Media engine
- API gateway
- AI gateway
- Shared settings
- Module registry

### Key Rule

No module should build its own duplicated auth, billing, notification, wallet, or organization logic.

---

## EDGE RangeOS

Driving range operation module.

### Scope

- Bay QR ordering
- Ball bucket order
- F&B/product order
- Counter queue
- Runner/delivery confirmation
- Print slip
- Menu/product setup
- POS lite
- Stock tracking
- Owner dashboard
- System health

---

## EDGE Academy OS

Coaching and student learning management module.

### Scope

- Academy profile
- Coach management
- Student management
- Training packages
- Syllabus templates
- Student progress tracking
- Lesson booking
- Attendance
- Coach notes
- Payment records
- BM/EN bilingual content

---

## EDGE POS

Commercial point-of-sale and inventory module.

### Scope

- Cashier interface
- Counter sales
- Product catalog
- Barcode support
- Stock movement
- Purchase orders
- Supplier records
- Inventory valuation
- Accounting export
- Multi-location stock

---

## EDGE CRM

Customer growth and communication module.

### Scope

- Lead tracking
- Customer segmentation
- Campaigns
- WhatsApp/email follow-up
- Loyalty targeting
- Customer behavior timeline
- Reactivation workflows

---

## EDGE Membership

Subscription, access, and privileges engine.

### Scope

- Membership tiers
- Subscription plans
- Wallet/credits
- Access privileges
- Usage tracking
- Renewals
- Expiry reminders

---

## EDGE Tournament

Competition and event module.

### Scope

- Tournament registration
- Flights and pairing
- Scoring
- Leaderboard
- Handicap category
- Result publishing
- Sponsor package support

---

## EDGE Booking

Universal booking and scheduling engine.

### Scope

- Bay booking
- Lesson booking
- Room/resource booking
- Coach availability
- Group classes
- Calendar view
- Booking rules

---

## EDGE Online Proshop

Commerce and marketplace module.

### Scope

- Ecommerce catalog
- Product categories
- Brands
- Inventory
- Orders
- Payments
- Shipping
- Coupons
- Vouchers
- Digital products
- Training bundles
- Affiliate/commission

---

## EDGE AI

Intelligence and automation layer.

### Scope

- Operational alerts
- Sales prediction
- Student progress insights
- Customer segmentation
- AI recommendation
- Smart assistant
- Workflow automation

---

## Data Architecture Rule

Every operational table that belongs to a client/tenant must include:

```sql
organization_id uuid not null
```

This prevents data leakage across academies, ranges, shops, or tenants.

---

## Current Execution Priority

```text
1. EDGE Core
2. EDGE RangeOS stabilization
3. EDGE Academy OS foundation
4. EDGE Membership + Booking
5. EDGE POS
6. EDGE CRM
7. EDGE Tournament
8. EDGE Online Proshop
9. EDGE AI
```

---

## Immediate Implementation Strategy

The current GitHub repository remains RangeFlow production. EDGE Academy OS work must be isolated under:

```text
edge-academy-os/
```

This avoids breaking the existing RangeFlow production app.

A dedicated repository named `edge-academy-os` should be created later when GitHub repo creation is available.
