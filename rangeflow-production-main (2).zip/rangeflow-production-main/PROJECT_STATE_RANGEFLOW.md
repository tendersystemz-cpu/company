# RangeFlow / EDGE RangeFlow @ UKM — Source of Truth

Last updated: 2026-05-28

This file is the mandatory starting point before any future assistant, developer, or AI worker changes RangeFlow code, Supabase, Coolify, or UI.

## Active project

- Product: EDGE RangeFlow / RangeFlow Standard Package
- Client/site: Driving Range @ UKM
- Operator: PRIMAVOC SDN. BHD.
- Supabase org slug: `drukm`
- Status: serious production stabilization, not demo/pilot wording in user-facing UI

## Canonical apps for production validation

### Customer app

- Coolify app: `rangeflow-customer`
- URL: `http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io`
- Main test: `/b/07/order`

### Operations app

- Coolify app: `rangeflow-operations`
- URL: `http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io`
- Main routes: `/owner`, `/counter`, `/stock`, `/pos`, `/menu`, `/payments`, `/members`, `/access`, `/promotions`

## Current validation progress

### Customer flow visible pass — 2026-05-28

The user verified by iPhone screenshots that the canonical customer flow is visually acceptable after deployment from GitHub:

- `/b/07/order` compact premium order page is accepted.
- Sticky checkout bar is visible and usable above the iPhone/Safari bottom toolbar.
- Checkout bar is centered on wider desktop/tablet viewport.
- `/pay/[bookingId]` now clearly explains manual TNG/DuitNow QR payment using operator physical QR at counter or bay.
- Screenshot/proof upload remains optional only if staff requests it.
- `/receipt/[bookingId]` is now a compact purchase slip suitable for customer screenshot/save reference.

Latest relevant customer commits:

- `d36ac0e04b2a41cc6590c18869ef8147b857bfbb` — fix mobile checkout bar visibility.
- `8c4290bd788228ca1d160610e5a8a0a3c4929ced` — clarify manual QR payment flow.
- `17e4329e01a1d356e6daede5967723b48b112471` — convert receipt page to compact purchase slip.
- `257b33ad920993542e2b25bc242c4320eb4bdc29` — center fixed checkout bar across desktop and mobile.

Next stabilization focus after customer visible pass: continue operations validation, starting with `/counter`, `/pos?bay=07`, and `/stock`, while keeping customer flow unchanged unless a new defect is found.

## Non-canonical Coolify apps rule

Old or duplicate Coolify apps such as `thw9q52...`, `tvrtb4...`, `s8lb...` must **not** be deleted, discarded, renamed, or treated as useless without an audit.

They are non-canonical for current production validation, but they may contain previous work, route experiments, UI decisions, deployment history, or useful recovery references.

Required handling:

1. Do not use them as live production references unless the user explicitly reopens one.
2. Do not delete or overwrite them without explicit user approval.
3. If one is investigated, record its purpose, route, env, linked branch/commit, and whether it is archive/reference/active.
4. Stabilization must still be done on the two canonical apps first.

## Deployment discipline

If Coolify shows `Configuration changes are not applied`, `REBUILD REQUIRED`, or pending config changes, do not keep changing code. First force rebuild/redeploy the correct canonical app.

Required env for both customer and operations apps:

```txt
NEXT_PUBLIC_SUPABASE_URL
NEXT_PUBLIC_SUPABASE_ANON_KEY
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY
NEXT_PUBLIC_ORG_SLUG=drukm
```

## Customer operation flow

1. Customer arrives with golf bag.
2. Customer chooses available bay and places bag.
3. First purchase normally happens at counter.
4. Staff uses assisted counter order for selected bay.
5. Customer pays using TNG/DuitNow QR.
6. Staff verifies payment.
7. Customer self-picks first items or delivery is prepared if needed.
8. Later repeat orders use Bay QR `/b/[bay]/order`.
9. Customer chooses Self Pickup or Deliver to Bay.
10. Payment proof upload remains optional only if staff requests it.

Avoid heavy e-commerce friction. Customer name, phone, transaction ID, and screenshot must not be mandatory in normal flow.

## Approved customer mobile order UI direction

The approved target for `/b/07/order` is the compact premium mobile layout generated in-chat on 2026-05-28.

Required characteristics:

- Professional, compact, premium, not playful or oversized.
- Header: dark green/black, RF logo, RangeFlow @ UKM, DR UKM, Bay 07.
- Title panel: Add-on Order, Bay 07, small Need Help pill, one short instruction line only.
- Option selector: compact 2x2 grid for Walk-in RM12, UKM RM8, Self Pickup, Deliver to Bay.
- Optional contact: single subtle row/button, not a large form by default.
- Category chips: All, Ball, Drinks, Food, Snack, Equipment.
- Product menu: dense touch-to-add grid, ideally 4 columns on normal mobile width; 3 columns only on very narrow phones.
- Product tiles: small image/icon, short name, price, compact add/stepper control.
- No giant cards, no giant fonts, no large blank spaces, no clipped checkout bar.
- Sticky checkout bar: compact, fully visible, order summary left, bright green Checkout button right.
- Visual identity: deep green/black header, clean white cards, muted gray-green text, lime-green action accents, subtle shadows and rounded corners.

## Operations UI identity

Operations pages must follow Owner Dashboard visual identity:

- Light green/off-white background
- Dark green premium hero header
- White cards with soft border/shadow
- Green action buttons
- Minimal text
- Mobile/tablet friendly
- Consistent radius, spacing, typography, and nav style

## Ball inventory source of truth

Ball inventory is critical and must not be hardcoded in frontend code.

Current estimated opening values for DR UKM are stored in Supabase and editable from Stock Lite:

- `balls_per_bucket = 100`
- `current_ball_stock = 10000`
- `low_stock_qty = 2000`

Tables:

- `ball_inventory_settings`
- `ball_stock_movements`

RPC functions:

- `get_operations_ball_inventory(p_org_slug text)`
- `save_operations_ball_inventory(p_org_slug text, p_current_ball_stock integer, p_low_stock_qty integer, p_note text)`
- `add_operations_ball_stock_in(p_org_slug text, p_quantity integer, p_note text)`

Verification SQL:

```sql
select public.get_operations_ball_inventory('drukm'::text) as ball_inventory;
```

Expected key values:

```json
{
  "ok": true,
  "currentBallStock": 10000,
  "lowStockQty": 2000,
  "ballsPerBucket": 100
}
```

If `/stock` shows old fallback text while the RPC returns `ok: true`, the live app is stale or wrong container/app is being tested.

## POS Lite rule

- `/pos?bay=07` must open POS Lite for Bay 07.
- UI must allow selecting Bay 01–30.
- Assisted order must attach to selected bay.
- Do not call missing RPC `create_counter_sale` unless intentionally added and verified.
- Current intended stable path uses `create_counter_first_order`.

## Staff counter rule

`/counter` is primary staff operating screen and must remain bay-centric:

- Bay grid shows status, payment, Need Help, session, and queue signals.
- Selecting a bay shows relevant queue/items/payment.
- Add Counter Order includes Walk-in RM12 and UKM Student/Staff RM8.
- F&B/product menu should be touch-to-add grid suitable for rushed staff.
- Use full labels, not confusing abbreviations: Self Pickup / Ambil Sendiri, Deliver to Bay / Hantar ke Bay.

## Standard Package scope lock

Included:

- Customer QR Bay Order
- Ball Bucket Order
- F&B/Product Order
- Assisted Counter Order / First Counter Order
- Payment Verification
- Print Slip
- Menu/Product Management
- POS Lite
- Basic Stock Tracking / Stock Lite
- QR/Bay Management
- Payment Setup
- Owner Dashboard
- Runner/Delivery Confirmation
- Need Help
- System Health/Admin Tools
- Basic Access Protection

Do not add or distract with Telegram, Suna/OpenClaw, full POS supplier/accounting, multi-branch, payroll, or AI prediction unless explicitly reopened.

## Work rule for every future session

1. Read this file first.
2. Confirm canonical app and route.
3. Classify the issue: frontend, Supabase, env/config, stale deployment, or wrong app.
4. Make one focused change.
5. Commit to GitHub.
6. Rebuild/redeploy only the canonical app.
7. Verify live route.
8. Update this file if source-of-truth changes.

Never create new Coolify apps or duplicate routes to solve bugs without explicit approval. Never delete, discard, or call old apps useless until their function has been audited and recorded.
