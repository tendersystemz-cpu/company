/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  async redirects() {
    return [
      {
        source: '/staff',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/staff/:path*',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/staff-ops',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/staff-ops/:path*',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/staff-ops-bay',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/staff-ops-bay/:path*',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/queue',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/queue/:path*',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/pilot',
        destination: '/',
        permanent: false,
      },
      {
        source: '/pilot/:path*',
        destination: '/',
        permanent: false,
      },
      {
        source: '/trial',
        destination: '/',
        permanent: false,
      },
      {
        source: '/trial/:path*',
        destination: '/',
        permanent: false,
      },
      {
        source: '/setup',
        destination: '/access',
        permanent: false,
      },
      {
        source: '/setup/:path*',
        destination: '/access',
        permanent: false,
      },
      {
        source: '/checkpoint',
        destination: '/counter',
        permanent: false,
      },
      {
        source: '/checkpoint/:path*',
        destination: '/counter',
        permanent: false,
      },
    ];
  },
};

module.exports = nextConfig;
