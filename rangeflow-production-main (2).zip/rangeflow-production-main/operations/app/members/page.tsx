'use client';

import { useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type Member = {
  customer_id: string;
  name?: string | null;
  phone?: string | null;
  last_seen_at?: string | null;
  tier?: string;
  status?: string;
  points?: number;
  expires_at?: string | null;
};

type MemberSummary = { ok?: boolean; message?: string; total_customers?: number; active_members?: number; vip_members?: number; members?: Member[] };

function count(value?: number | string) { return Number(value || 0).toLocaleString('en-MY'); }
function date(value?: string | null) { if (!value) return '-'; try { return new Date(value).toLocaleDateString('en-MY'); } catch { return value; } }
function tierLabel(value?: string) {
  const v = String(value || 'guest').toLowerCase();
  if (v === 'vvip') return 'VVIP';
  if (v === 'vip') return 'VIP';
  if (v === 'corporate') return 'Corporate';
  if (v === 'member') return 'Member';
  if (v === 'basic') return 'Basic';
  return 'Guest';
}

export default function MembersPage() {
  const [ownerPin, setOwnerPin] = useState('');
  const [summary, setSummary] = useState<MemberSummary | null>(null);
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  async function loadMembers() {
    if (!ownerPin.trim()) { setError('Masukkan owner PIN untuk buka customer/member summary.'); return; }
    setLoading(true); setError(''); setMessage('');
    window.sessionStorage.setItem('rangeflow_member_pin', ownerPin);
    const { data, error: loadError } = await supabase.rpc('get_operations_member_summary', { p_org_slug: ORG_SLUG, p_owner_pin: ownerPin });
    setLoading(false);
    if (loadError) { setError(loadError.message || 'Gagal load membership summary. Pastikan migration V6/V7 sudah run.'); return; }
    const result = data as MemberSummary;
    if (!result?.ok) { setError(result?.message || 'Membership summary tidak berjaya dibuka.'); return; }
    setSummary(result);
    setMessage('Customer/member summary loaded.');
  }

  const members = summary?.members || [];
  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return members;
    return members.filter((member) => `${member.name || ''} ${member.phone || ''} ${member.tier || ''}`.toLowerCase().includes(q));
  }, [members, query]);

  return (
    <main className="membersShell">
      <header className="hero">
        <div><span>EDGE RANGE OS</span><h1>Customer & Membership Lite</h1><p>Basic customer directory from QR/POS activity.</p></div>
        <strong>Owner Only</strong>
      </header>

      <nav className="nav"><a href="/owner">Owner</a><a href="/pos">POS</a><a href="/promotions">Promotions</a><a href="/counter">Counter</a><button onClick={loadMembers} disabled={loading}>{loading ? 'Loading...' : 'Load Members'}</button></nav>

      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}

      <section className="accessPanel panel">
        <div><span>Owner Access</span><h2>Protected Customer Data</h2><p>Membership Lite contains customer contact and engagement data.</p></div>
        <div className="accessInputs"><input type="password" value={ownerPin} onChange={(e) => setOwnerPin(e.target.value)} placeholder="Owner PIN" /><button onClick={loadMembers} disabled={loading}>{loading ? 'Loading...' : 'Unlock'}</button></div>
      </section>

      <section className="metrics">
        <Metric label="Total Customers" value={count(summary?.total_customers)} />
        <Metric label="Active Members" value={count(summary?.active_members)} />
        <Metric label="VIP / VVIP" value={count(summary?.vip_members)} />
      </section>

      <section className="panel directory">
        <div className="directoryHead"><div><span>Directory</span><h2>Customer Records</h2></div><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search name, phone or tier" /></div>
        <div className="memberList">
          {!summary ? <p>Enter owner PIN and load members.</p> : null}
          {summary && filtered.length === 0 ? <p>No customer record matched.</p> : null}
          {filtered.map((member) => <article className="memberCard" key={member.customer_id}><div><span>{tierLabel(member.tier)}</span><h3>{member.name || 'Walk-in Customer'}</h3><p>{member.phone || 'No phone'} · Last seen {date(member.last_seen_at)}</p></div><div className="memberStats"><b>{member.status || 'inactive'}</b><strong>{count(member.points)} pts</strong><small>Expiry {date(member.expires_at)}</small></div></article>)}
        </div>
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) { return <article className="metric"><span>{label}</span><b>{value}</b></article>; }

const styles = `
.membersShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hero{max-width:1240px;margin:0 auto 12px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:28px;padding:24px;display:flex;justify-content:space-between;gap:20px;align-items:flex-start;box-shadow:0 20px 60px rgba(7,28,22,.14)}.hero span{color:var(--accent);font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:42px;line-height:1;margin:8px 0 8px;letter-spacing:-.04em}.hero p{margin:0;color:#cdebd8;font-weight:900}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:12px 16px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px;flex-wrap:wrap}.nav a,.nav button,.accessInputs button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.nav button,.accessInputs button{background:var(--green);color:#fff}.notice{max-width:1240px;margin:0 auto 12px;border-radius:16px;padding:12px 14px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.panel,.metric{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06)}.accessPanel{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:minmax(0,1fr) 380px;gap:14px;align-items:center}.accessPanel span,.directoryHead span,.metric span,.memberCard span{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.accessPanel h2,.directoryHead h2{font-size:22px;margin:6px 0}.accessPanel p,.memberList p,.memberCard p{color:var(--muted);font-weight:900;margin:0}.accessInputs{display:grid;grid-template-columns:1fr 120px;gap:8px}.accessInputs input,.directoryHead input{width:100%;box-sizing:border-box;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:12px 13px;font-weight:850}.metrics{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric b{display:block;font-size:32px;margin-top:10px}.directory{max-width:1240px;margin:0 auto}.directoryHead{display:grid;grid-template-columns:minmax(0,1fr) 320px;gap:12px;align-items:end;margin-bottom:14px}.memberList{display:grid;gap:10px}.memberCard{display:flex;justify-content:space-between;gap:14px;align-items:center;border:1px solid var(--line);background:#fbfdf9;border-radius:16px;padding:14px}.memberCard h3{font-size:20px;margin:7px 0 5px}.memberStats{text-align:right}.memberStats b{display:block;color:#b45309;text-transform:uppercase;font-size:12px}.memberStats strong{display:block;color:var(--green);font-size:20px;margin:5px 0}.memberStats small{color:var(--muted);font-weight:900}@media(max-width:900px){.accessPanel,.directoryHead{grid-template-columns:1fr}.metrics{grid-template-columns:1fr}.hero{display:block}.hero strong{display:inline-block;margin-top:16px}.accessInputs{grid-template-columns:1fr}.memberCard{display:block}.memberStats{text-align:left;margin-top:12px}.nav a,.nav button{flex:1 1 130px;text-align:center}}@media(max-width:560px){.membersShell{padding:10px}.hero{border-radius:22px;padding:18px}.hero h1{font-size:32px}.metric b{font-size:28px}}
`;