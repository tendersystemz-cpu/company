'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type PricingRule = {
  id?: string;
  location_name?: string;
  amenity_type?: string;
  slot_label?: string | null;
  pricing_unit?: string;
  walkin_price: number | string;
  active: boolean;
  effective_from?: string | null;
};

const emptyForm: PricingRule = {
  slot_label: 'Default',
  walkin_price: 0,
  active: true,
};

export default function PricingPage() {
  const [rules, setRules] = useState<PricingRule[]>([]);
  const [form, setForm] = useState<PricingRule>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function loadPricing() {
    setLoading(true);
    setError(null);
    const { data, error: loadError } = await supabase.rpc('get_operations_ball_pricing', {
      p_org_slug: ORG_SLUG,
    });
    setLoading(false);
    if (loadError) {
      setError(loadError.message || 'Gagal load pricing.');
      return;
    }
    setRules((data || []) as PricingRule[]);
  }

  useEffect(() => { loadPricing(); }, []);

  function editRule(rule: PricingRule) {
    setForm({
      id: rule.id,
      slot_label: rule.slot_label || 'Default',
      walkin_price: Number(rule.walkin_price || 0),
      active: Boolean(rule.active),
    });
    setMessage(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function saveRule() {
    setSaving(true);
    setMessage(null);
    setError(null);

    const { error: saveError } = await supabase.rpc('save_operations_ball_pricing', {
      p_org_slug: ORG_SLUG,
      p_pricing_id: form.id || null,
      p_walkin_price: Number(form.walkin_price || 0),
      p_slot_label: form.slot_label || 'Default',
      p_active: form.active,
    });

    setSaving(false);

    if (saveError) {
      setError(saveError.message || 'Gagal save pricing.');
      return;
    }

    setMessage(form.id ? 'Bucket price updated.' : 'Bucket price rule added.');
    setForm(emptyForm);
    await loadPricing();
  }

  const activeRule = rules.find((rule) => rule.active);

  return (
    <main className="shell">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Operations</div>
          <h1 className="title">Ball Pricing</h1>
          <p className="muted">Ubah harga bucket/bola. Customer QR order akan guna harga aktif dari Supabase.</p>
        </div>
        <button className="btn secondary" onClick={() => { setForm(emptyForm); setMessage(null); setError(null); }}>New Rule</button>
      </div>

      {activeRule ? (
        <section className="card" style={{marginBottom: 18}}>
          <div className="pill">Current active price</div>
          <h2 style={{margin: '10px 0 4px'}}>RM {Number(activeRule.walkin_price).toFixed(2)} / bucket</h2>
          <p className="muted">{activeRule.slot_label || 'Default'} · {activeRule.location_name || 'Driving Range'}</p>
        </section>
      ) : null}

      {message ? <div className="card" style={{borderColor: '#34d399'}}>{message}</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      <section className="card" style={{marginBottom: 18}}>
        <div className="pill">{form.id ? 'Edit price' : 'Add price rule'}</div>
        <div className="grid" style={{marginTop: 14}}>
          <label>
            <div className="muted" style={{fontSize: 13, marginBottom: 6}}>Slot label</div>
            <input className="input" value={form.slot_label || ''} onChange={(e) => setForm({...form, slot_label: e.target.value})} placeholder="Default / Morning / Night" />
          </label>

          <label>
            <div className="muted" style={{fontSize: 13, marginBottom: 6}}>Walk-in price RM / bucket</div>
            <input className="input" type="number" step="0.01" value={form.walkin_price} onChange={(e) => setForm({...form, walkin_price: e.target.value})} />
          </label>

          <label style={{display: 'flex', gap: 10, alignItems: 'center'}}>
            <input type="checkbox" checked={form.active} onChange={(e) => setForm({...form, active: e.target.checked})} />
            <span>Active price rule</span>
          </label>

          <button className="btn" disabled={saving} onClick={saveRule}>{saving ? 'Saving...' : 'Save Price'}</button>
        </div>
      </section>

      <section className="grid orders">
        {loading ? <div className="card">Loading pricing...</div> : null}
        {rules.map((rule) => (
          <article className="card" key={rule.id}>
            <div className="pill">{rule.active ? 'active' : 'inactive'}</div>
            <h2 style={{margin: '10px 0 4px'}}>RM {Number(rule.walkin_price).toFixed(2)} / bucket</h2>
            <p className="muted">{rule.slot_label || 'Default'} · {rule.pricing_unit || 'per_bucket'}</p>
            <div className="row"><span>Location</span><strong>{rule.location_name || '-'}</strong></div>
            <div className="row"><span>Active</span><strong>{rule.active ? 'Yes' : 'No'}</strong></div>
            <button className="btn secondary" onClick={() => editRule(rule)}>Edit</button>
          </article>
        ))}
      </section>
    </main>
  );
}
