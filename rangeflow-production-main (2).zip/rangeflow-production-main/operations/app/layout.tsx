import type { Metadata, Viewport } from 'next';
import './globals.css';
import GlobalReturnNav from './GlobalReturnNav';

export const metadata: Metadata = {
  title: 'EDGE RangeFlow Operations',
  description: 'Operations dashboard for counter, payment verification, queue and bay workflow.',
};

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  themeColor: '#071b16',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ms">
      <body>
        <GlobalReturnNav />
        {children}
      </body>
    </html>
  );
}
