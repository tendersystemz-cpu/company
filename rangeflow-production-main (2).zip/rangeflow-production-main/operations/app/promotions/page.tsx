'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type Promotion = {
  id: string;
  code: string;
  name: string;
  description?: string | null;
  discount_type: string;
  discount_value: number | string;
  min_order_amount: number | string;
  active: boolean;
  campaign_source?: string | null;
  used_count?: number;
  usage_limit?: number | null;
};

type SaveResult = { ok?: boolean; message?: string; promotion_id?: string };

const emptyForm = {
  code: '',
  name: '',
  description: '',
  discount_type: 'fixed',
  discount_value: '0',
  min_order_amount: '0',
  campaign_source: 'meta',
  active: true,
};

function money(value: number | string | undefined) { return `RM ${Number(value || 0).toFixed(2)}`; }
function count(value: number | string | undefined) { return Number(value || 0).toLocaleString('en-MY'); }
function discountLabel(promo: Promotion) {
  if (promo.discount_type === 'percent') return `${Number(promo.discount_value || 0)}% off`;
  if (promo.discount_type === 'free_item') return 'Free item / manual';
  if (promo.discount_type === 'bundle') return 'Bundle offer';
  return `${money(promo.discount_value)} off`;
}

export default function PromotionsPage() {
  const [promotions, setPromotions] = useState<Promotion[]>([]);
  const [form, setForm] = useState(emptyForm);
  const [accessPin, setAccessPin] = useState('');
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const activeCount = useMemo(() => promotions.filter((promo) => promo.active).length, [promotions]);
  const usedCount = useMemo(() => promotions.reduce((sum, promo) => sum + Number(promo.used_count || 0), 0), [promotions]);

  async function loadPromotions() {
    if (!accessPin.trim()) { setError('Masukkan staff / owner PIN untuk load promotions.'); return; }
    setLoading(true); setMessage(''); setError('');
    const { data, error: loadError } = await supabase.rpc('get_operations_promotions', { p_org_slug: ORG_SLUG, p_access_pin: accessPin });
    setLoading(false);
    if (loadError) { setError(loadError.message || 'Gagal load promotions. Pastikan migration V6 sudah run.'); return; }
    setPromotions((data || []) as Promotion[]);
    setMessage('Promotions loaded.');
  }

  useEffect(() => {
    const saved = window.sessionStorage.getItem('rangeflow_promo_pin') || '';
    if (saved) setAccessPin(saved);
  }, []);

  async function savePromotion() {
    if (!accessPin.trim()) { setError('Masukkan owner PIN untuk save promotion.'); return; }
    setSaving(true); setMessage(''); setError('');
    window.sessionStorage.setItem('rangeflow_promo_pin', accessPin);
    const { data, error: saveError } = await supabase.rpc('save_operations_promotion', {
      p_org_slug: ORG_SLUG,
      p_owner_pin: accessPin,
      p_code: form.code,
      p_name: form.name,
      p_description: form.description || null,
      p_discount_type: form.discount_type,
      p_discount_value: Number(form.discount_value || 0),
      p_min_order_amount: Number(form.min_order_amount || 0),
      p_active: form.active,
      p_campaign_source: form.campaign_source || null,
    });
    setSaving(false);
    if (saveError) { setError(saveError.message || 'Gagal save promotion.'); return; }
    const result = data as SaveResult;
    if (!result?.ok) { setError(result?.message || 'Promotion tidak berjaya disimpan.'); return; }
    setMessage(result.message || 'Promotion saved.');
    setForm(emptyForm);
    await loadPromotions();
  }

  function editPromotion(promo: Promotion) {
    setForm({
      code: promo.code,
      name: promo.name,
      description: promo.description || '',
      discount_type: promo.discount_type || 'fixed',
      discount_value: String(promo.discount_value || 0),
      min_order_amount: String(promo.min_order_amount || 0),
      campaign_source: promo.campaign_source || 'meta',
      active: Boolean(promo.active),
    });
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  return (
    <main className="promoShell">
      <header className="hero">
        <div>
          <span>EDGE RANGE OS</span>
          <h1>Promotions Lite</h1>
          <p>Create campaign promo codes for posters, WhatsApp, social ads and bay QR offers.</p>
        </div>
        <strong>Campaign Control</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/pos">POS</a>
        <a href="/members">Members</a>
        <a href="/counter">Counter</a>
        <button onClick={loadPromotions} disabled={loading}>{loading ? 'Loading...' : 'Load Promotions'}</button>
      </nav>

      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}

      <section className="metrics">
        <Metric label="Promotions" value={count(promotions.length)} sub="Loaded campaigns" />
        <Metric label="Active" value={count(activeCount)} sub="Currently on" />
        <Metric label="Used" value={count(usedCount)} sub="Total redemption" />
      </section>

      <section className="promoGrid">
        <section className="panel formPanel">
          <div className="panelTitle"><div><span>Campaign Setup</span><h2>Create / Update Promo</h2></div></div>
          <p className="panelNote">Owner PIN required. Keep launch offers simple: code, discount value, minimum order and source.</p>
          <label><span>Owner / Staff PIN</span><input type="password" value={accessPin} onChange={(e) => setAccessPin(e.target.value)} placeholder="Required" /></label>
          <div className="formGrid">
            <label><span>Promo Code</span><input value={form.code} onChange={(e) => setForm({...form, code: e.target.value.toUpperCase()})} placeholder="WEEKEND10" /></label>
            <label><span>Campaign Name</span><input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} placeholder="Weekend Bucket Promo" /></label>
            <label><span>Discount Type</span><select value={form.discount_type} onChange={(e) => setForm({...form, discount_type: e.target.value})}><option value="fixed">Fixed RM</option><option value="percent">Percent %</option><option value="bundle">Bundle / Manual</option><option value="free_item">Free Item / Manual</option></select></label>
            <label><span>Discount Value</span><input type="number" step="0.01" value={form.discount_value} onChange={(e) => setForm({...form, discount_value: e.target.value})} /></label>
            <label><span>Minimum Order RM</span><input type="number" step="0.01" value={form.min_order_amount} onChange={(e) => setForm({...form, min_order_amount: e.target.value})} /></label>
            <label><span>Source</span><select value={form.campaign_source} onChange={(e) => setForm({...form, campaign_source: e.target.value})}><option value="meta">Meta / Facebook / Instagram</option><option value="tiktok">TikTok</option><option value="whatsapp">WhatsApp</option><option value="poster_qr">Poster QR</option><option value="walk_in">Walk-in</option><option value="partner">Partner / Coach</option></select></label>
          </div>
          <label><span>Description</span><input value={form.description} onChange={(e) => setForm({...form, description: e.target.value})} placeholder="Short offer detail shown internally" /></label>
          <label className="check"><input type="checkbox" checked={form.active} onChange={(e) => setForm({...form, active: e.target.checked})} /> <span>Active campaign</span></label>
          <div className="actions"><button onClick={savePromotion} disabled={saving}>{saving ? 'Saving...' : 'Save Promotion'}</button><button className="secondary" onClick={loadPromotions} disabled={loading}>{loading ? 'Loading...' : 'Load Promotions'}</button></div>
        </section>

        <section className="promoList">
          {promotions.length === 0 ? <div className="panel emptyState">No promotions loaded. Enter PIN and click Load Promotions.</div> : null}
          {promotions.map((promo) => <article className={`promoCard ${promo.active ? '' : 'inactive'}`} key={promo.id}>
            <div className="promoHead"><div><span>{promo.campaign_source || 'campaign'}</span><h2>{promo.code}</h2><p>{promo.name}</p></div><strong>{promo.active ? 'ACTIVE' : 'OFF'}</strong></div>
            <Row label="Offer" value={discountLabel(promo)} />
            <Row label="Min order" value={money(promo.min_order_amount)} />
            <Row label="Used" value={`${promo.used_count || 0}${promo.usage_limit ? ` / ${promo.usage_limit}` : ''}`} />
            {promo.description ? <p className="description">{promo.description}</p> : null}
            <button className="secondary" onClick={() => editPromotion(promo)}>Edit</button>
          </article>)}
        </section>
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub: string }) { return <article className="metric"><span>{label}</span><b>{value}</b><small>{sub}</small></article>; }
function Row({ label, value }: { label: string; value: string }) { return <div className="row"><span>{label}</span><b>{value}</b></div>; }

const styles = `
.promoShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:12px}.hero{max-width:1240px;margin:0 auto 10px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:22px;padding:18px;display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.hero span{color:var(--accent);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:36px;line-height:1;margin:7px 0;letter-spacing:-.04em}.hero p{margin:0;color:#d6f3df;font-weight:900;line-height:1.35}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:9px 12px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.nav a,.nav button,.actions button,.promoCard button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px;text-decoration:none;font-weight:1000;text-align:center}.nav button,.actions button{background:var(--green);color:#fff}.nav button{grid-column:1/-1}.secondary{background:#f3f7f1!important;color:var(--ink)!important}.notice{max-width:1240px;margin:0 auto 10px;border-radius:15px;padding:11px 13px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.metrics{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.metric,.panel,.promoCard{background:var(--panel);border:1px solid var(--line);border-radius:20px;padding:16px;box-shadow:0 10px 24px rgba(7,28,22,.05)}.metric span,.panelTitle span,.formPanel label span,.promoHead span,.row span{display:block;color:var(--muted);font-size:10px;font-weight:1000;text-transform:uppercase;letter-spacing:.12em}.metric b{display:block;font-size:30px;margin:8px 0 4px}.metric small,.panelNote,.description,.emptyState,.promoHead p{color:var(--muted);font-weight:900}.promoGrid{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:380px minmax(0,1fr);gap:10px;align-items:start}.panelTitle{margin-bottom:12px}.panelTitle h2{font-size:22px;margin:5px 0 0}.formPanel label{display:block;margin-top:10px}.formPanel input,.formPanel select{width:100%;box-sizing:border-box;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:11px 12px;font-weight:850;margin-top:5px}.formGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.check{display:flex!important;gap:8px;align-items:center}.check input{width:auto;margin:0}.actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:12px}.promoList{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:10px}.promoCard.inactive{opacity:.7}.promoHead{display:flex;justify-content:space-between;gap:10px;align-items:flex-start}.promoHead h2{font-size:25px;margin:7px 0 3px}.promoHead strong{border-radius:999px;padding:7px 9px;background:#dcfce7;color:#166534;font-size:10px}.promoCard.inactive .promoHead strong{background:#e2e8f0;color:#334155}.row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line);padding:11px 0}.row:last-child{border-bottom:0}.row b{text-align:right}.promoCard button{width:100%;margin-top:9px}@media(max-width:900px){.hero{display:block}.hero strong{display:inline-block;margin-top:12px}.promoGrid{grid-template-columns:1fr}.metrics{grid-template-columns:1fr}.nav{grid-template-columns:repeat(2,1fr)}}@media(max-width:560px){.promoShell{padding:8px 10px}.hero{padding:16px}.hero h1{font-size:31px}.formGrid,.actions{grid-template-columns:1fr}.metric b{font-size:28px}}
`;