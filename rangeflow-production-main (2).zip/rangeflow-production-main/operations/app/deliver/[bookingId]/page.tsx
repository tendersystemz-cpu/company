'use client';

import { useEffect, useRef, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type PageProps = {
  params: {
    bookingId: string;
  };
  searchParams?: {
    bay?: string;
  };
};

type ConfirmStatus = 'idle' | 'scanning' | 'submitting' | 'success' | 'error';

function normalizeBayCode(value: string) {
  const raw = value.trim();
  const urlMatch = raw.match(/\/b\/(\d{1,3})/i);
  if (urlMatch) return urlMatch[1].padStart(2, '0').toUpperCase();
  const bayMatch = raw.match(/bay[\s_-]?(\d{1,3})/i);
  if (bayMatch) return bayMatch[1].padStart(2, '0').toUpperCase();
  const match = raw.match(/(\d{1,3})/);
  if (!match) return '';
  return match[1].padStart(2, '0').toUpperCase();
}

export default function DeliveryConfirmPage({ params, searchParams }: PageProps) {
  const expectedBay = normalizeBayCode(searchParams?.bay || '');
  const [manualBay, setManualBay] = useState(expectedBay);
  const [staffName, setStaffName] = useState('');
  const [staffPin, setStaffPin] = useState('');
  const [status, setStatus] = useState<ConfirmStatus>('idle');
  const [message, setMessage] = useState('');
  const [scanSupported, setScanSupported] = useState(true);
  const [cameraActive, setCameraActive] = useState(false);
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const scanningRef = useRef(false);

  useEffect(() => {
    return () => stopCamera();
  }, []);

  function stopCamera() {
    scanningRef.current = false;
    streamRef.current?.getTracks().forEach((track) => track.stop());
    streamRef.current = null;
    setCameraActive(false);
    if (status === 'scanning') setStatus('idle');
  }

  function validateBayOrError(bayCode: string) {
    if (!bayCode) {
      setStatus('error');
      setMessage('Bay code tidak sah. Scan QR bay atau masukkan nombor bay, contoh 01.');
      return false;
    }
    if (expectedBay && bayCode !== expectedBay) {
      setStatus('error');
      setMessage(`Wrong bay scanned. Order ini untuk Bay ${expectedBay}, tetapi scan Bay ${bayCode}.`);
      return false;
    }
    return true;
  }

  async function startQrScan() {
    setMessage('');
    const BarcodeDetectorCtor = (window as any).BarcodeDetector;
    if (!BarcodeDetectorCtor || !navigator.mediaDevices?.getUserMedia) {
      setScanSupported(false);
      setStatus('error');
      setMessage('Camera QR scan tidak disokong pada browser ini. Guna manual Bay Code fallback.');
      return;
    }

    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' }, audio: false });
      streamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        await videoRef.current.play();
      }

      const detector = new BarcodeDetectorCtor({ formats: ['qr_code'] });
      scanningRef.current = true;
      setCameraActive(true);
      setStatus('scanning');
      setMessage(`Scan QR physical Bay ${expectedBay || ''}.`);

      const scanLoop = async () => {
        if (!scanningRef.current || !videoRef.current) return;
        try {
          const codes = await detector.detect(videoRef.current);
          if (codes?.length) {
            const raw = String(codes[0]?.rawValue || '');
            const scannedBay = normalizeBayCode(raw);
            setManualBay(scannedBay);
            stopCamera();
            if (validateBayOrError(scannedBay)) {
              setStatus('idle');
              setMessage(`QR scan valid for Bay ${scannedBay}. Tap Confirm Delivery to complete.`);
            }
            return;
          }
        } catch {
          // Keep scanning; some browsers throw while video frame is not ready.
        }
        window.setTimeout(scanLoop, 450);
      };
      scanLoop();
    } catch (error) {
      setCameraActive(false);
      setStatus('error');
      setMessage('Camera permission gagal. Guna manual Bay Code fallback.');
    }
  }

  async function confirmDelivery() {
    const bayCode = normalizeBayCode(manualBay);
    if (!validateBayOrError(bayCode)) return;

    setStatus('submitting');
    setMessage('Confirming delivery...');

    const { data, error } = await supabase.rpc('confirm_delivery_by_bay_scan', {
      p_booking_id: params.bookingId,
      p_org_slug: ORG_SLUG,
      p_scanned_bay_code: bayCode,
      p_staff_name: staffName || null,
      p_staff_pin: staffPin || null,
      p_notes: 'Bay QR delivery confirmation by operations staff.',
    });

    if (error) {
      setStatus('error');
      setMessage(error.message || 'Delivery confirmation failed. Pastikan bay QR atau bay code betul.');
      return;
    }

    const result = data as { bay_code?: string; response_seconds?: number };
    setStatus('success');
    setMessage(`Delivery confirmed at Bay ${result?.bay_code || bayCode}. Response time: ${result?.response_seconds || 0}s.`);
  }

  return (
    <main className="shell deliveryPage">
      <div className="top deliveryTop">
        <div>
          <div className="brand">RangeFlow Delivery</div>
          <h1 className="title">Bay Delivery Confirmation</h1>
          <p className="muted">Runner wajib scan QR bay sebenar atau masukkan bay code yang sepadan sebelum delivery ditutup.</p>
        </div>
        <div className="deliveryNav">
          <a className="btn secondary" href="/hub">Return to Main Menu</a>
          <a className="btn secondary" href="/queue">Back to Queue</a>
          <a className="btn secondary" href="/health">Health</a>
        </div>
      </div>

      <section className="deliveryGrid">
        <div className="card deliveryCard">
          <div className="pill">Order Delivery</div>
          <h2>Expected Bay {expectedBay || '-'}</h2>
          <div className="row"><span>Booking</span><strong>{params.bookingId.slice(0, 8)}</strong></div>
          <div className="row"><span>Status</span><strong>{status}</strong></div>
          {message ? <div className={status === 'error' ? 'card error deliveryError' : 'card deliveryMessage'}>{message}</div> : null}

          <div className="grid staffGrid">
            <label>
              <div className="muted fieldLabel">Staff Name</div>
              <input className="input" value={staffName} onChange={(e)=>setStaffName(e.target.value)} placeholder="Nama staff penghantar" />
            </label>
            <label>
              <div className="muted fieldLabel">Staff PIN / ID</div>
              <input className="input" value={staffPin} onChange={(e)=>setStaffPin(e.target.value)} placeholder="Optional" type="password" />
            </label>
          </div>
        </div>

        <aside className="card deliveryCard confirmCard">
          <div className="pill">Bay Proof</div>
          <h2>Scan Bay QR</h2>
          <p className="muted">Runner perlu berada di bay sebenar. Scan QR pada bay, sistem akan semak bay scan sama dengan bay order.</p>

          <div className="scanBox">
            <video ref={videoRef} className={cameraActive ? 'scanVideo active' : 'scanVideo'} muted playsInline />
            {!cameraActive ? <div className="scanPlaceholder">QR Camera Standby</div> : null}
          </div>

          <div className="grid scanActions">
            <button className="btn" type="button" disabled={status === 'submitting' || status === 'success' || cameraActive} onClick={startQrScan}>
              {cameraActive ? 'Scanning...' : 'Start QR Scan'}
            </button>
            <button className="btn secondary" type="button" disabled={!cameraActive} onClick={stopCamera}>Stop</button>
          </div>

          {!scanSupported ? <p className="muted fallbackNote">Browser ini tidak support camera QR scanner. Manual fallback masih aktif.</p> : null}

          <label>
            <div className="muted fieldLabel">Manual Bay Code Fallback</div>
            <input className="input bayInput" value={manualBay} onChange={(e)=>setManualBay(e.target.value)} placeholder="01" />
          </label>
          <button className="btn confirmBtn" type="button" disabled={status === 'submitting' || status === 'success'} onClick={confirmDelivery}>
            {status === 'submitting' ? 'Confirming...' : status === 'success' ? 'Delivery Confirmed' : `Confirm Delivered at Bay ${manualBay || '-'}`}
          </button>
          <div className="safeNote">
            <strong>Wrong Bay Protection</strong>
            <p>If scanned bay does not match the order bay, delivery confirmation will be blocked.</p>
          </div>
        </aside>
      </section>

      <style>{`
        .deliveryPage{max-width:1180px;margin:0 auto}.deliveryTop{align-items:flex-start}.deliveryNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.deliveryGrid{display:grid;grid-template-columns:minmax(0,.85fr) minmax(300px,.65fr);gap:16px;align-items:start}.deliveryCard{border-radius:20px}.deliveryCard h2{margin:12px 0 10px;color:#fff;font-size:24px;line-height:1.15}.staffGrid{margin-top:16px}.fieldLabel{font-size:12px;margin-bottom:6px;text-transform:uppercase;letter-spacing:.08em}.deliveryMessage{margin-top:12px;background:rgba(6,95,70,.7);border-color:rgba(52,211,153,.35);color:#d1fae5}.deliveryError{background:#7f1d1d;color:#fecaca}.confirmCard .muted{line-height:1.5}.scanBox{position:relative;margin:14px 0;border-radius:18px;overflow:hidden;border:1px solid rgba(52,211,153,.25);background:rgba(2,21,16,.52);min-height:220px;display:flex;align-items:center;justify-content:center}.scanVideo{width:100%;min-height:220px;object-fit:cover;display:none}.scanVideo.active{display:block}.scanPlaceholder{position:absolute;inset:0;display:flex;align-items:center;justify-content:center;color:#86efac;font-weight:900;letter-spacing:.08em;text-transform:uppercase}.scanActions{grid-template-columns:1fr .45fr;margin-bottom:14px}.fallbackNote{font-size:12px;margin:8px 0 14px}.bayInput{font-size:22px;font-weight:900;text-align:center;letter-spacing:.08em}.confirmBtn{width:100%;margin-top:12px}.safeNote{margin-top:16px;border:1px solid rgba(52,211,153,.25);border-radius:18px;padding:14px;background:rgba(2,21,16,.35)}.safeNote strong{display:block;color:#86efac;margin-bottom:6px}.safeNote p{margin:0;color:#bbf7d0;line-height:1.55;font-size:13px}@media(max-width:900px){.deliveryGrid{grid-template-columns:1fr}.deliveryNav{justify-content:flex-start}.deliveryNav a{flex:1 1 150px}.deliveryCard h2{font-size:22px}}
      `}</style>
    </main>
  );
}
