'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type QueueItem = {
  booking_id: string;
  qr_token: string;
  bay_code: string;
  bay_name: string;
  customer_name?: string | null;
  booking_status: string;
  payment_status: string;
  total_amount: number | string;
};

function money(value: number | string) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

export default function CheckpointPage() {
  const [orders, setOrders] = useState<QueueItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const [error, setError] = useState('');

  async function loadOrders() {
    setLoading(true);
    setError('');
    const { data, error: queueError } = await supabase.rpc('get_operations_queue_summary', {
      p_org_slug: ORG_SLUG,
    });
    setLoading(false);
    if (queueError) {
      setError(queueError.message || 'Gagal load checkpoint queue.');
      return;
    }
    setOrders((data || []) as QueueItem[]);
  }

  useEffect(() => { loadOrders(); }, []);

  function checkpointUrl(order: QueueItem) {
    return `/deliver/${order.booking_id}?bay=${encodeURIComponent(order.bay_code)}`;
  }

  async function startAndOpen(order: QueueItem) {
    setWorking(order.booking_id);
    setError('');
    const { error: statusError } = await supabase.rpc('update_operations_booking_status', {
      p_booking_id: order.booking_id,
      p_status: 'out_for_delivery',
    });
    setWorking(null);
    if (statusError) {
      setError(statusError.message || 'Gagal start delivery checkpoint.');
      return;
    }
    window.location.href = checkpointUrl(order);
  }

  return (
    <main className="shell checkpointPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">QR Checkpoint</h1>
          <p className="muted">Start delivery dan terus buka bay QR confirmation. Ini shortcut untuk elak checkpoint cycle putus.</p>
        </div>
        <div className="checkpointNav">
          <a className="btn secondary" href="/queue">Back: Queue</a>
          <button className="btn" onClick={loadOrders}>Refresh</button>
        </div>
      </div>

      {loading ? <div className="card">Loading checkpoint orders...</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      <section className="checkpointList">
        {orders.map((order) => {
          const paid = order.payment_status === 'paid';
          const started = order.booking_status === 'out_for_delivery';
          const done = order.booking_status === 'completed' || order.booking_status === 'delivered';
          return (
            <article className="card checkpointCard" key={order.booking_id}>
              <div>
                <div className="pill">{order.bay_name || `Bay ${order.bay_code}`}</div>
                <h2>Token {order.qr_token}</h2>
                <p className="muted">{order.customer_name || 'Walk-in customer'} · {money(order.total_amount)}</p>
                <div className="row"><span>Payment</span><strong>{order.payment_status}</strong></div>
                <div className="row"><span>Status</span><strong>{order.booking_status}</strong></div>
              </div>
              <div className="checkpointActions">
                {!paid ? <button className="btn secondary" disabled>Verify payment first</button> : null}
                {paid && !started && !done ? (
                  <button className="btn" disabled={working === order.booking_id} onClick={() => startAndOpen(order)}>
                    {working === order.booking_id ? 'Starting...' : 'Start Delivery + Checkpoint'}
                  </button>
                ) : null}
                {paid && started ? <a className="btn" href={checkpointUrl(order)}>Open QR Checkpoint</a> : null}
                {done ? <button className="btn secondary" disabled>Completed</button> : null}
              </div>
            </article>
          );
        })}
      </section>

      {!loading && orders.length === 0 ? <div className="card">No active orders.</div> : null}

      <style>{`
        .checkpointPage{max-width:1080px;margin:0 auto}.checkpointNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.checkpointList{display:grid;gap:12px}.checkpointCard{display:grid;grid-template-columns:minmax(0,1fr) 240px;gap:14px;align-items:center}.checkpointCard h2{color:#fff;margin:10px 0 4px}.checkpointActions{display:grid;gap:10px}.checkpointActions a{text-align:center;text-decoration:none}@media(max-width:760px){.checkpointCard{grid-template-columns:1fr}.checkpointNav{justify-content:flex-start}.checkpointNav .btn{flex:1 1 130px}}
      `}</style>
    </main>
  );
}
