'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type BayRow = {
  bay_code: string;
  display_name?: string | null;
  operation_status: 'active' | 'pending_payment' | 'need_help' | 'empty' | 'disabled' | string;
  total_amount?: number | string | null;
  booking_id?: string | null;
  payment_status?: string | null;
  session_started_at?: string | null;
  order_channel?: string | null;
};

type PaymentRow = {
  booking_id: string;
  payment_id?: string | null;
  order_token?: string | null;
  bay_code: string;
  total_amount?: number | string | null;
  payment_amount?: number | string | null;
  payment_method?: string | null;
  fulfillment_type?: string | null;
};

type FulfillmentRow = {
  order_id: string;
  booking_id: string;
  order_token?: string | null;
  bay_code: string;
  item_name: string;
  quantity: number;
  subtotal?: number | string | null;
  fulfillment_type: 'self_pickup' | 'deliver_to_bay' | string;
  payment_status?: string | null;
};

type MenuItem = { id: string; category: string; name: string; price: number | string; available?: boolean; pos_enabled?: boolean };
type Product = { key: string; item_name: string; type: 'bucket' | 'fb' | 'drink'; unit_price: number; label: string; category: 'Popular' | 'Ball' | 'Drinks' | 'Food' | 'Rental' | 'Other'; icon: string };
type SlipType = 'ball' | 'kitchen' | 'delivery' | 'full';

const CATEGORIES: Product['category'][] = ['Popular', 'Ball', 'Drinks', 'Food', 'Rental', 'Other'];

function money(value: number | string | null | undefined) { return `RM ${Number(value || 0).toFixed(2)}`; }
function statusLabel(value?: string | null) {
  const s = String(value || 'empty');
  if (s === 'pending_payment') return 'Pending';
  if (s === 'need_help') return 'Need Help';
  if (s === 'active') return 'Active';
  if (s === 'disabled') return 'Disabled';
  return 'Empty';
}
function statusDot(value?: string | null) {
  const s = String(value || 'empty');
  if (s === 'pending_payment') return '🟡';
  if (s === 'need_help') return '🔔';
  if (s === 'active') return '🟢';
  if (s === 'disabled') return '⛔';
  return '⚪';
}
function fulfillmentLabel(value?: string | null) { return value === 'deliver_to_bay' ? 'Deliver to Bay' : 'Self Pickup'; }
function fulfillmentBm(value?: string | null) { return value === 'deliver_to_bay' ? 'Hantar ke Bay' : 'Ambil Sendiri'; }
function categoryOf(value?: string | null): Product['category'] {
  const v = String(value || '').toLowerCase();
  if (v.includes('ball') || v.includes('bola') || v.includes('bucket')) return 'Ball';
  if (v.includes('drink') || v.includes('beverage') || v.includes('minum')) return 'Drinks';
  if (v.includes('food') || v.includes('fb') || v.includes('snack') || v.includes('makan')) return 'Food';
  if (v.includes('rent') || v.includes('sewa') || v.includes('equipment') || v.includes('golf')) return 'Rental';
  return 'Other';
}
function iconOf(name: string, category: Product['category']) {
  const n = name.toLowerCase();
  if (category === 'Ball' || n.includes('ball')) return '🏌️';
  if (n.includes('water') || n.includes('air')) return '💧';
  if (n.includes('coffee') || n.includes('kopi')) return '☕';
  if (n.includes('burger')) return '🍔';
  if (category === 'Drinks') return '🥤';
  if (category === 'Food') return '🍽️';
  if (category === 'Rental') return '⛳';
  return '🧾';
}
function toProduct(item: MenuItem): Product {
  const category = categoryOf(item.category);
  return { key: `menu_${item.id}`, item_name: item.name, type: category === 'Drinks' ? 'drink' : category === 'Ball' ? 'bucket' : 'fb', unit_price: Number(item.price || 0), label: item.name, category, icon: iconOf(item.name, category) };
}

export default function CounterFlowPage() {
  const [bays, setBays] = useState<BayRow[]>([]);
  const [payments, setPayments] = useState<PaymentRow[]>([]);
  const [queue, setQueue] = useState<FulfillmentRow[]>([]);
  const [menuItems, setMenuItems] = useState<Product[]>([]);
  const [selectedBay, setSelectedBay] = useState('07');
  const [quantities, setQuantities] = useState<Record<string, number>>({});
  const [activeCategory, setActiveCategory] = useState<Product['category']>('Popular');
  const [printType, setPrintType] = useState<SlipType>('full');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const selectedBayRow = useMemo(() => bays.find((bay) => bay.bay_code === selectedBay) || null, [bays, selectedBay]);
  const needHelpBays = bays.filter((bay) => bay.operation_status === 'need_help');
  const selectedQueue = queue.filter((item) => item.bay_code === selectedBay);
  const selectedPayments = payments.filter((payment) => payment.bay_code === selectedBay);
  const visiblePayments = selectedPayments.length > 0 ? selectedPayments : payments.slice(0, 5);

  const allProducts = useMemo(() => {
    const seen = new Set<string>();
    return menuItems.filter((item) => {
      const key = `${item.item_name.toLowerCase()}-${item.unit_price}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });
  }, [menuItems]);

  const queueByBay = useMemo(() => {
    const map = new Map<string, { pickup: number; delivery: number }>();
    queue.forEach((item) => {
      const current = map.get(item.bay_code) || { pickup: 0, delivery: 0 };
      if (item.fulfillment_type === 'deliver_to_bay') current.delivery += 1; else current.pickup += 1;
      map.set(item.bay_code, current);
    });
    return map;
  }, [queue]);

  const cartLines = allProducts.map((item) => ({ ...item, quantity: quantities[item.key] || 0 })).filter((item) => item.quantity > 0);
  const cartTotal = cartLines.reduce((sum, item) => sum + item.quantity * item.unit_price, 0);
  const visibleProducts = activeCategory === 'Popular' ? allProducts.slice(0, 10) : allProducts.filter((item) => item.category === activeCategory);

  async function loadMenu() {
    const { data } = await supabase.rpc('get_operations_menu_items', { p_org_slug: ORG_SLUG });
    const list = ((data || []) as MenuItem[]).filter((item) => item.available !== false && item.pos_enabled !== false).map(toProduct);
    setMenuItems(list);
  }

  async function loadAll(options?: { silent?: boolean }) {
    if (!options?.silent) setLoading(true);
    setError('');
    const [bayResult, paymentResult, queueResult] = await Promise.all([
      supabase.from('v_rangeflow_staff_bay_grid').select('*').eq('org_slug', ORG_SLUG).order('bay_code'),
      supabase.from('v_rangeflow_payment_verification_queue').select('*').eq('org_slug', ORG_SLUG).order('created_at', { ascending: true }),
      supabase.from('v_rangeflow_fulfillment_queue').select('*').eq('org_slug', ORG_SLUG).order('created_at', { ascending: true }),
    ]);
    await loadMenu();
    if (!options?.silent) setLoading(false);
    const firstError = bayResult.error || paymentResult.error || queueResult.error;
    if (firstError) { setError(firstError.message || 'Gagal load staff dashboard.'); return; }
    setBays((bayResult.data || []) as BayRow[]);
    setPayments((paymentResult.data || []) as PaymentRow[]);
    setQueue((queueResult.data || []) as FulfillmentRow[]);
  }

  useEffect(() => {
    loadAll();
    const timer = window.setInterval(() => loadAll({ silent: true }), 15000);
    return () => window.clearInterval(timer);
  }, []);

  function changeQty(key: string, delta: number) { setQuantities((current) => ({ ...current, [key]: Math.max(0, (current[key] || 0) + delta) })); }

  async function createCounterOrder() {
    const selected = cartLines.map((item) => ({ item_name: item.item_name, type: item.type === 'drink' ? 'fb' : item.type, quantity: item.quantity, unit_price: item.unit_price }));
    if (selected.length === 0) { setError('Pilih item dahulu. Jika tiada item, setup produk dahulu di Setup Wizard / Menu Management.'); return; }
    setWorking('create-counter-order'); setMessage(''); setError('');
    const { data, error: createError } = await supabase.rpc('create_counter_first_order', {
      p_org_slug: ORG_SLUG,
      p_bay_code: selectedBay,
      p_items: selected,
      p_customer_type: 'walkin',
      p_payment_method: 'manual_qr',
      p_assisted_by: 'counter_staff',
    });
    setWorking(null);
    if (createError) { setError(createError.message || 'Gagal create counter order.'); return; }
    const token = Array.isArray(data) ? data[0]?.order_token : data?.order_token;
    setMessage(`Added to Bay ${selectedBay}${token ? ` · ${token}` : ''}.`);
    setQuantities({});
    await loadAll({ silent: true });
  }

  async function markPaid(bookingId: string) {
    setWorking(`paid-${bookingId}`); setMessage(''); setError('');
    const { error: paidError } = await supabase.rpc('mark_booking_paid', { p_booking_id: bookingId, p_verified_by: 'counter_staff' });
    setWorking(null);
    if (paidError) { setError(paidError.message || 'Gagal mark payment as paid.'); return; }
    setMessage('Payment verified.');
    await loadAll({ silent: true });
  }

  async function releaseBay(bookingId?: string | null) {
    if (!bookingId) return;
    setWorking(`release-${bookingId}`); setMessage(''); setError('');
    const { error: releaseError } = await supabase.rpc('release_bay_session', { p_booking_id: bookingId });
    setWorking(null);
    if (releaseError) { setError(releaseError.message || 'Gagal release bay.'); return; }
    setMessage(`Bay ${selectedBay} released.`);
    await loadAll({ silent: true });
  }

  function printSlip(bookingId?: string | null) { if (bookingId) window.open(`/print/${bookingId}?type=${printType}`, '_blank', 'noopener,noreferrer'); }

  return (
    <main className="counterShell">
      <header className="hero">
        <div><span>EDGE RANGE OS</span><h1>Staff Counter</h1><p>Bay board, touch order, queue and payment verification.</p></div>
        <nav><a href="/owner">Owner</a><button onClick={() => loadAll()}>Refresh</button></nav>
      </header>

      {loading ? <div className="alert">Loading counter...</div> : null}
      {message ? <div className="alert ok">{message}</div> : null}
      {error ? <div className="alert error">{error}</div> : null}

      <section className="layout">
        <div className="mainStack">
          <section className="panel bayPanel">
            <div className="panelTitle"><b>Bay Overview</b><small>{bays.length} bays</small></div>
            <div className="bayGrid">
              {bays.map((bay) => {
                const counts = queueByBay.get(bay.bay_code) || { pickup: 0, delivery: 0 };
                return <button key={bay.bay_code} className={`bayTile ${bay.operation_status} ${selectedBay === bay.bay_code ? 'selected' : ''}`} onClick={() => setSelectedBay(bay.bay_code)}>
                  <div className="bayTop"><b>Bay {bay.bay_code}</b><i>{statusDot(bay.operation_status)}</i></div>
                  <div className="bayMeta"><span>{money(bay.total_amount)}</span><span>{statusLabel(bay.operation_status)}</span></div>
                  {bay.session_started_at ? <small>Session {new Date(bay.session_started_at).toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit' })}</small> : null}
                  {bay.payment_status ? <small>{bay.payment_status}</small> : null}
                  {counts.pickup > 0 ? <em className="pickup">Self Pickup {counts.pickup}<small>Ambil Sendiri</small></em> : null}
                  {counts.delivery > 0 ? <em className="delivery">Deliver to Bay {counts.delivery}<small>Hantar ke Bay</small></em> : null}
                </button>;
              })}
            </div>
            <div className="selectedDock">
              <div><span>Selected</span><b>Bay {selectedBay}</b><small>{statusLabel(selectedBayRow?.operation_status)} · {selectedBayRow?.payment_status || 'no payment'}</small></div>
              <div className="miniQueue"><span>Bay Queue</span>{selectedQueue.length === 0 ? <small>No queue</small> : selectedQueue.slice(0, 4).map((item) => <small key={item.order_id}>{fulfillmentLabel(item.fulfillment_type)} · {item.quantity}x {item.item_name} · {money(item.subtotal)}</small>)}</div>
              <div className="bayActions"><select value={printType} onChange={(e) => setPrintType(e.target.value as SlipType)} disabled={!selectedBayRow?.booking_id}><option value="ball">Ball Slip</option><option value="kitchen">Kitchen Slip</option><option value="delivery">Delivery Slip</option><option value="full">Full Slip</option></select><button disabled={!selectedBayRow?.booking_id} onClick={() => printSlip(selectedBayRow?.booking_id)}>Print</button><button className="release" disabled={!selectedBayRow?.booking_id || working?.startsWith('release')} onClick={() => releaseBay(selectedBayRow?.booking_id)}>Release</button></div>
            </div>
          </section>

          <section className="panel menuPanel">
            <div className="panelTitle"><b>Touch to Add</b><small>Bay {selectedBay}</small></div>
            <div className="tabs">{CATEGORIES.map((cat) => <button key={cat} className={activeCategory === cat ? 'active' : ''} onClick={() => setActiveCategory(cat)}>{cat}</button>)}</div>
            <div className="menuGrid">
              {visibleProducts.length === 0 ? <div className="emptyProducts"><b>No counter product loaded.</b><span>Setup ball packages, F&amp;B and POS items in Setup Wizard / Menu Management.</span></div> : null}
              {visibleProducts.map((item) => <article className={`menuTile ${item.category.toLowerCase()}`} key={item.key}><button type="button" onClick={() => changeQty(item.key, 1)}><i>{item.icon}</i><b>{item.label}</b><span>{money(item.unit_price)}</span></button><div className="stepper"><button onClick={() => changeQty(item.key, -1)}>−</button><strong>{quantities[item.key] || 0}</strong><button onClick={() => changeQty(item.key, 1)}>+</button></div></article>)}
            </div>
          </section>
        </div>

        <aside className="sideStack">
          <section className="panel"><div className="panelTitle"><b>Queue</b><small>{queue.length}</small></div><div className="sideList">{queue.slice(0, 8).map((item) => <div className="sideCard" key={item.order_id}><b>Bay {item.bay_code}</b><span>{item.quantity}x {item.item_name}</span><small>{fulfillmentBm(item.fulfillment_type)} · {money(item.subtotal)}</small></div>)}{queue.length === 0 ? <p>No queue.</p> : null}</div></section>
          <section className="panel"><div className="panelTitle"><b>Need Help</b><small>{needHelpBays.length}</small></div><div className="sideList compact">{needHelpBays.slice(0, 5).map((bay) => <button className="helpCard" key={bay.bay_code} onClick={() => setSelectedBay(bay.bay_code)}><b>Bay {bay.bay_code}</b><span>Bantuan</span></button>)}{needHelpBays.length === 0 ? <p>No request.</p> : null}</div></section>
          <section className="panel"><div className="panelTitle"><b>Payments</b><small>{payments.length}</small></div><div className="sideList payList">{visiblePayments.map((payment) => <div className="payCard" key={`${payment.booking_id}-${payment.payment_id || payment.order_token}`}><b>Bay {payment.bay_code}</b><span>{money(payment.payment_amount || payment.total_amount)}</span><small>{fulfillmentLabel(payment.fulfillment_type)}</small><button disabled={working === `paid-${payment.booking_id}`} onClick={() => markPaid(payment.booking_id)}>Verify</button></div>)}{payments.length === 0 ? <p>No pending payment.</p> : null}</div></section>
        </aside>
      </section>

      <section className="cartBar"><div className="cartItems">{cartLines.length === 0 ? <span>No item selected</span> : cartLines.map((item) => <span key={item.key}><b>{item.quantity}x</b> {item.label}</span>)}</div><div className="cartTotal"><span>Total</span><b>{money(cartTotal)}</b></div><button disabled={working === 'create-counter-order' || cartLines.length === 0} onClick={createCounterOrder}>Add to Bay {selectedBay}</button></section>
      <style>{styles}</style>
    </main>
  );
}

const styles = `
.counterShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:12px 12px 112px}.hero{max-width:1420px;margin:0 auto 10px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:22px;padding:16px 18px;display:flex;justify-content:space-between;gap:12px;align-items:center}.hero span{color:var(--accent);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:34px;line-height:1;margin:6px 0}.hero p{margin:0;color:#d6f3df;font-weight:900;line-height:1.35}.hero nav{display:flex;gap:8px}.hero a,.hero button,.cartBar button,.payCard button,.bayActions button{border:0;border-radius:15px;background:var(--green);color:#fff;font-weight:1000;padding:10px 13px;text-decoration:none;cursor:pointer}.hero a{background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16)}button:disabled,select:disabled{opacity:.45}.alert{max-width:1420px;margin:0 auto 10px;border-radius:15px;padding:11px 13px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.alert.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.layout{max-width:1420px;margin:0 auto;display:grid;grid-template-columns:minmax(720px,1fr) 340px;gap:10px}.mainStack,.sideStack{display:grid;gap:10px;align-content:start}.panel{background:var(--panel);border:1px solid var(--line);border-radius:20px;padding:14px;box-shadow:0 10px 24px rgba(7,28,22,.05)}.panelTitle{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.panelTitle b{font-size:18px}.panelTitle small{color:var(--muted);font-weight:900}.bayGrid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px}.bayTile{border:1px solid var(--line);border-radius:16px;background:#fff;min-height:104px;padding:9px;text-align:left;color:var(--ink);cursor:pointer}.bayTile.selected{outline:3px solid var(--deep)}.bayTile.active{background:#ecfdf5}.bayTile.pending_payment{background:#fff7ed}.bayTile.need_help{background:#fff1f2}.bayTop,.bayMeta{display:flex;justify-content:space-between;gap:6px}.bayTop b{font-size:16px}.bayTop i{font-style:normal}.bayMeta{margin:7px 0 4px}.bayMeta span,.bayTile small{font-size:10px;color:var(--muted);font-weight:1000}.bayTile small{display:block;margin-top:3px}.bayTile em{display:block;font-style:normal;border-radius:10px;padding:4px 7px;font-size:10px;font-weight:1000;margin-top:5px}.bayTile em small{font-size:8px;color:inherit;opacity:.82}.pickup{background:#e0f2fe;color:#075985}.delivery{background:#ecfccb;color:#3f6212}.selectedDock{margin-top:10px;border:1px solid var(--line);background:#fbfdf9;border-radius:18px;padding:11px;display:grid;grid-template-columns:180px 1fr 235px;gap:10px;align-items:center}.selectedDock span{display:block;color:var(--muted);font-size:10px;font-weight:1000;text-transform:uppercase}.selectedDock b{display:block;font-size:26px}.selectedDock small,.miniQueue small{display:block;color:var(--muted);font-weight:900;margin-top:4px}.miniQueue{max-height:92px;overflow:auto}.bayActions{display:grid;grid-template-columns:1fr 70px 78px;gap:7px}.bayActions select{border:1px solid var(--line);border-radius:14px;background:#fff;padding:10px;font-weight:900}.bayActions .release{background:#64748b}.tabs{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:10px}.tabs button{border:1px solid var(--line);border-radius:14px;background:#f3f7f1;padding:9px 13px;font-weight:1000;cursor:pointer}.tabs button.active{background:var(--deep);color:#fff}.menuGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(135px,1fr));gap:10px}.emptyProducts{grid-column:1/-1;border:1px dashed var(--line);border-radius:18px;background:#fbfdf9;padding:18px;color:var(--ink)}.emptyProducts b{display:block;font-size:17px}.emptyProducts span{display:block;color:var(--muted);font-weight:900;margin-top:6px}.menuTile{border:1px solid var(--line);border-radius:18px;background:#fff;min-height:142px;display:flex;flex-direction:column;justify-content:space-between;overflow:hidden}.menuTile.food{background:#fff7ed}.menuTile.drinks{background:#eff6ff}.menuTile.ball{background:#ecfdf5}.menuTile.rental{background:#f5f3ff}.menuTile>button{border:0;background:transparent;color:inherit;text-align:center;padding:12px 9px 6px;display:grid;gap:6px;cursor:pointer}.menuTile i{font-size:31px;font-style:normal}.menuTile b{font-size:14px}.menuTile span{font-weight:900;color:var(--muted)}.stepper{display:grid;grid-template-columns:44px 1fr 44px;border-top:1px solid var(--line)}.stepper button{border:0;background:#fff;font-size:20px;font-weight:1000;padding:8px;cursor:pointer}.stepper strong{display:grid;place-items:center}.sideList{display:grid;gap:8px}.sideCard,.payCard,.helpCard{border:1px solid var(--line);border-radius:15px;background:#fbfdf9;padding:10px;text-align:left;color:var(--ink)}.sideCard b,.payCard b,.helpCard b{display:block}.sideCard span,.payCard span,.helpCard span{display:block;color:var(--muted);font-weight:900;margin-top:4px}.sideCard small,.payCard small{display:block;color:var(--muted);font-weight:900;margin-top:4px}.payCard button{width:100%;margin-top:8px;padding:9px}.compact{grid-template-columns:1fr 1fr}.cartBar{position:fixed;left:14px;right:14px;bottom:14px;z-index:50;max-width:1420px;margin:0 auto;background:#061c14;color:#fff;border:1px solid rgba(255,255,255,.14);box-shadow:0 20px 50px rgba(0,0,0,.28);border-radius:22px;padding:12px;display:grid;grid-template-columns:minmax(0,1fr) 140px 190px;gap:12px;align-items:center}.cartItems{display:flex;gap:8px;flex-wrap:wrap}.cartItems span{border-radius:999px;background:rgba(255,255,255,.08);padding:7px 9px;font-weight:900}.cartTotal span{display:block;color:#a7f3d0;font-size:10px;font-weight:1000;text-transform:uppercase}.cartTotal b{font-size:24px}.cartBar button{height:48px}@media(max-width:1100px){.layout{grid-template-columns:1fr}.sideStack{grid-template-columns:repeat(3,1fr)}.selectedDock{grid-template-columns:1fr}.bayGrid{grid-template-columns:repeat(4,1fr)}}@media(max-width:760px){.hero{display:block}.hero nav{margin-top:12px}.layout,.sideStack{grid-template-columns:1fr}.bayGrid{grid-template-columns:repeat(2,1fr)}.bayActions{grid-template-columns:1fr}.menuGrid{grid-template-columns:repeat(2,1fr)}.cartBar{grid-template-columns:1fr;left:10px;right:10px;bottom:10px;border-radius:18px}.counterShell{padding:8px 10px 185px}.hero{padding:15px}.hero h1{font-size:30px}.compact{grid-template-columns:1fr}}
`;