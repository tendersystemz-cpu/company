import AccessCodeForm from './AccessCodeForm';

export default function AccessSettingsPage() {
  return (
    <main className="accessShell">
      <header className="hero">
        <div>
          <span>RangeFlow @ UKM</span>
          <h1>Access Settings</h1>
          <p>Owner-controlled access codes for staff operation and owner-level settings.</p>
        </div>
        <strong>Secure Control</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/payments">Payment</a>
        <a href="/menu">Menu</a>
        <a href="/stock">Stock</a>
        <a href="/counter">Counter</a>
      </nav>

      <section className="metrics">
        <Metric label="Staff PIN" value="Operation" />
        <Metric label="Owner PIN" value="Settings" />
        <Metric label="Backend" value="Supabase" />
      </section>

      <section className="panel scopePanel">
        <div className="panelTitle"><div><span>Access Rule</span><h2>Operational Security</h2></div></div>
        <Row label="Staff/Admin PIN" value="Counter, QR, health and setup access" />
        <Row label="Owner PIN" value="Owner dashboard and main settings" />
        <p>Keep operation simple: owner controls PIN updates, staff uses one operational PIN for counter and setup pages.</p>
      </section>

      <AccessCodeForm />

      <section className="panel notePanel">
        <div className="panelTitle"><div><span>Security Note</span><h2>PIN Verification</h2></div></div>
        <p>PINs are verified through Supabase and are not hardcoded in the frontend screen.</p>
      </section>

      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) {
  return <article className="metric"><span>{label}</span><b>{value}</b></article>;
}
function Row({ label, value }: { label: string; value: string }) {
  return <div className="row"><span>{label}</span><b>{value}</b></div>;
}

const styles = `
.accessShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hero{max-width:1240px;margin:0 auto 12px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:28px;padding:24px;display:flex;justify-content:space-between;gap:20px;align-items:flex-start;box-shadow:0 20px 60px rgba(7,28,22,.14)}.hero span{color:var(--accent);font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:42px;line-height:1;margin:8px 0 8px;letter-spacing:-.04em}.hero p{margin:0;color:#cdebd8;font-weight:900}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:12px 16px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px;flex-wrap:wrap}.nav a{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.metrics{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric,.panel{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06)}.metric span,.panelTitle span,.row span{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.metric b{display:block;font-size:30px;margin-top:10px}.scopePanel,.notePanel{max-width:1240px;margin:0 auto 12px}.panelTitle{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:10px}.panelTitle h2{font-size:22px;margin:6px 0 0}.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:12px 0}.row:last-child{border-bottom:0}.row b{text-align:right}.scopePanel p,.notePanel p{color:var(--muted);font-weight:900;line-height:1.5}.accessCodeWrap{max-width:1240px;margin:0 auto 12px}.card{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06);color:var(--ink)}.grid{display:grid;gap:12px}.pill{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.muted{color:var(--muted)!important}.input{width:100%;box-sizing:border-box;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:12px 13px;font-weight:850}.btn{border:1px solid var(--line);background:var(--green);color:#fff;border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.error{background:#fff1f2!important;border-color:#fecdd3!important;color:#9f1239!important}.accessOk{background:#ecfdf5!important;border-color:#bbf7d0!important;color:#065f46!important}@media(max-width:900px){.metrics{grid-template-columns:1fr}.hero{display:block}.hero strong{display:inline-block;margin-top:16px}.nav a{flex:1 1 130px;text-align:center}.row{display:block}.row b{display:block;text-align:left;margin-top:4px}}@media(max-width:560px){.accessShell{padding:10px}.hero{border-radius:22px;padding:18px}.hero h1{font-size:32px}.metric b{font-size:26px}}
`;
