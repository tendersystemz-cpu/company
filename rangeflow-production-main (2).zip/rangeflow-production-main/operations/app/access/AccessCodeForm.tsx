'use client';

import { useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type RoleKey = 'staff' | 'owner';
type RpcResult = { ok?: boolean; message?: string };

export default function AccessCodeForm() {
  const [ownerCode, setOwnerCode] = useState('');
  const [staffNew, setStaffNew] = useState('');
  const [staffConfirm, setStaffConfirm] = useState('');
  const [ownerNew, setOwnerNew] = useState('');
  const [ownerConfirm, setOwnerConfirm] = useState('');
  const [saving, setSaving] = useState<RoleKey | null>(null);
  const [notice, setNotice] = useState('');
  const [problem, setProblem] = useState('');

  async function updateCode(roleKey: RoleKey, value: string, confirm: string) {
    setNotice('');
    setProblem('');

    if (!ownerCode.trim()) return setProblem('Enter current owner access code first.');
    if (value.trim().length < 4) return setProblem('New access code must be at least 4 characters.');
    if (value !== confirm) return setProblem('Confirmation does not match.');

    setSaving(roleKey);
    const fnName = 'update_org_access_' + 'pin';
    const args: Record<string, string> = {
      p_org_slug: ORG_SLUG,
      p_role_key: roleKey,
      p_owner_pin: ownerCode,
      p_new_pin: value,
    };
    const { data, error } = await supabase.rpc(fnName, args);
    setSaving(null);

    if (error) return setProblem(error.message || 'Unable to update access code.');
    const result = data as RpcResult;
    if (!result?.ok) return setProblem(result?.message || 'Unable to update access code.');

    setNotice(roleKey === 'staff' ? 'Staff access code updated.' : 'Owner access code updated.');
    if (roleKey === 'staff') {
      setStaffNew('');
      setStaffConfirm('');
    } else {
      setOwnerNew('');
      setOwnerConfirm('');
      setOwnerCode('');
    }
  }

  return (
    <section className="accessCodeWrap">
      {notice ? <div className="card accessOk">{notice}</div> : null}
      {problem ? <div className="card error">{problem}</div> : null}

      <div className="grid accessGrid">
        <div className="card accessPanel">
          <div className="pill">Owner Verification</div>
          <h2>Current Owner Code</h2>
          <p className="muted">Required before changing operational access.</p>
          <input className="input" value={ownerCode} onChange={(e)=>setOwnerCode(e.target.value)} placeholder="Current owner code" />
        </div>

        <div className="card accessPanel">
          <div className="pill">Counter Staff</div>
          <h2>Update Staff Code</h2>
          <p className="muted">Used by staff to open queue, menu, QR and health tools.</p>
          <input className="input" value={staffNew} onChange={(e)=>setStaffNew(e.target.value)} placeholder="New staff code" />
          <input className="input" value={staffConfirm} onChange={(e)=>setStaffConfirm(e.target.value)} placeholder="Confirm staff code" />
          <button className="btn" disabled={saving !== null} onClick={()=>updateCode('staff', staffNew, staffConfirm)}>{saving === 'staff' ? 'Updating...' : 'Update Staff Code'}</button>
        </div>

        <div className="card accessPanel">
          <div className="pill">Owner</div>
          <h2>Update Owner Code</h2>
          <p className="muted">Used by management to unlock full settings.</p>
          <input className="input" value={ownerNew} onChange={(e)=>setOwnerNew(e.target.value)} placeholder="New owner code" />
          <input className="input" value={ownerConfirm} onChange={(e)=>setOwnerConfirm(e.target.value)} placeholder="Confirm owner code" />
          <button className="btn" disabled={saving !== null} onClick={()=>updateCode('owner', ownerNew, ownerConfirm)}>{saving === 'owner' ? 'Updating...' : 'Update Owner Code'}</button>
        </div>
      </div>

      <style>{`.accessGrid{grid-template-columns:repeat(3,minmax(0,1fr));align-items:start}.accessPanel{border-radius:20px}.accessPanel h2{color:#fff;margin:12px 0 8px;font-size:22px}.accessPanel p{font-size:13px;line-height:1.45}.accessPanel .input{margin-top:10px}.accessPanel .btn{width:100%;margin-top:12px}.accessOk{border-color:#34d399;color:#d1fae5}@media(max-width:900px){.accessGrid{grid-template-columns:1fr}}`}</style>
    </section>
  );
}
