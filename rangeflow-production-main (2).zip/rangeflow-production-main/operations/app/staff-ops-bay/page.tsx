'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type QueueItem = {
  booking_id: string;
  qr_token: string;
  bay_code: string;
  bay_name: string;
  customer_name?: string | null;
  booking_status: string;
  payment_status: string;
  total_amount: number | string;
};

type AssistanceRequest = {
  id: string;
  bay_code: string;
  status: 'open' | 'acknowledged' | 'closed';
  message?: string | null;
  created_at: string;
};

function money(value: number | string) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function normBay(code: string) {
  const n = Number(code);
  return Number.isFinite(n) ? String(n).padStart(2, '0') : code;
}

function bayLabel(code: string) {
  return `Bay ${normBay(code)}`;
}

export default function StaffOpsBayPage() {
  const [orders, setOrders] = useState<QueueItem[]>([]);
  const [help, setHelp] = useState<AssistanceRequest[]>([]);
  const [selectedBay, setSelectedBay] = useState('01');
  const [working, setWorking] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const helpByBay = useMemo(() => {
    const map = new Map<string, AssistanceRequest>();
    help.filter((h) => h.status === 'open').forEach((h) => map.set(normBay(h.bay_code), h));
    return map;
  }, [help]);

  const ordersByBay = useMemo(() => {
    const map = new Map<string, QueueItem[]>();
    orders.forEach((o) => {
      const bay = normBay(o.bay_code);
      map.set(bay, [...(map.get(bay) || []), o]);
    });
    return map;
  }, [orders]);

  async function loadOrders() {
    const { data, error: queueError } = await supabase.rpc('get_operations_queue_summary', { p_org_slug: ORG_SLUG });
    if (queueError) {
      setError(queueError.message || 'Gagal load order queue.');
      return;
    }
    setOrders((data || []) as QueueItem[]);
  }

  async function loadHelp() {
    const { data, error: helpError } = await supabase
      .from('assistance_requests')
      .select('id,bay_code,status,message,created_at')
      .eq('org_slug', ORG_SLUG)
      .in('status', ['open', 'acknowledged'])
      .order('created_at', { ascending: false })
      .limit(30);
    if (helpError) {
      setError(helpError.message || 'Gagal load bantuan.');
      return;
    }
    setHelp((data || []) as AssistanceRequest[]);
  }

  async function reloadAll() {
    setError('');
    await Promise.all([loadOrders(), loadHelp()]);
  }

  useEffect(() => {
    reloadAll();
    const timer = window.setInterval(reloadAll, 10000);
    return () => window.clearInterval(timer);
  }, []);

  async function ackHelp(request: AssistanceRequest) {
    setWorking(`help-${request.id}`);
    setError('');
    setMessage('');
    const { error: ackError } = await supabase.rpc('acknowledge_assistance_request', { p_request_id: request.id });
    setWorking(null);
    if (ackError) {
      setError(ackError.message || 'Gagal acknowledge bantuan.');
      return;
    }
    setSelectedBay(normBay(request.bay_code));
    setMessage(`${bayLabel(request.bay_code)} acknowledged.`);
    await loadHelp();
  }

  async function verifyPayment(order: QueueItem) {
    setWorking(order.booking_id);
    setError('');
    setMessage('');
    const { error: verifyError } = await supabase.rpc('verify_operations_payment', {
      p_booking_id: order.booking_id,
      p_status: 'paid',
      p_note: 'Verified from bay-centric admin operations.',
    });
    setWorking(null);
    if (verifyError) {
      setError(verifyError.message || 'Gagal verify payment.');
      return;
    }
    setMessage(`Payment verified: ${order.qr_token}`);
    await loadOrders();
  }

  async function updateStatus(order: QueueItem, status: 'preparing' | 'delivered' | 'completed') {
    setWorking(order.booking_id);
    setError('');
    setMessage('');
    const { error: statusError } = await supabase.rpc('update_operations_booking_status', {
      p_booking_id: order.booking_id,
      p_status: status,
    });
    setWorking(null);
    if (statusError) {
      setError(statusError.message || 'Gagal update order.');
      return;
    }
    setMessage(`${order.qr_token} updated to ${status}.`);
    await loadOrders();
  }

  function printKitchenSlip(order: QueueItem) {
    window.open(`/print/${order.booking_id}?type=kitchen`, '_blank', 'noopener,noreferrer');
  }

  function printReceipt(order: QueueItem) {
    window.open(`/print/${order.booking_id}?type=full`, '_blank', 'noopener,noreferrer');
  }

  const selectedOrders = ordersByBay.get(selectedBay) || [];

  return (
    <main className="shell bayOpsPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Admin Operasi Bay View</h1>
          <p className="muted">Bay-centric phone/tablet dashboard for order, payment, stock and assistance.</p>
        </div>
        <div className="navActions">
          <a className="btn secondary" href="/stock">Stock</a>
          <a className="btn secondary" href="/staff-ops">Queue</a>
          <button className="btn" onClick={reloadAll}>Refresh</button>
        </div>
      </div>

      {message ? <div className="card okCard">{message}</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      {helpByBay.size > 0 ? (
        <section className="helpStrip">
          {[...helpByBay.values()].map((request) => (
            <button key={request.id} className="helpAlert" disabled={working === `help-${request.id}`} onClick={() => ackHelp(request)}>
              🔔 {bayLabel(request.bay_code)} Need Help / Perlu Bantuan
            </button>
          ))}
        </section>
      ) : null}

      <section className="card bayGridCard">
        <div className="bayHead">
          <div>
            <div className="pill">Bay Quick Action</div>
            <h2>{bayLabel(selectedBay)}</h2>
            <p className="muted">Tap bay number to view orders or add assisted order.</p>
          </div>
          <a className="btn" href={`/pos?bay=${selectedBay}`}>Add Order</a>
        </div>
        <div className="bayGrid">
          {Array.from({ length: 30 }, (_, i) => normBay(String(i + 1))).map((bay) => {
            const standby = Number(bay) > 25;
            const ordersForBay = ordersByBay.get(bay) || [];
            const hasHelp = helpByBay.has(bay);
            const pendingPay = ordersForBay.some((order) => order.payment_status !== 'paid');
            return (
              <button key={bay} disabled={standby} className={`bayBtn ${selectedBay === bay ? 'selected' : ''} ${hasHelp ? 'help' : ''} ${pendingPay ? 'pending' : ''} ${standby ? 'standby' : ''}`} onClick={() => setSelectedBay(bay)}>
                <b>{bay}</b>
                <span>{hasHelp ? 'HELP' : pendingPay ? 'PAY' : ordersForBay.length ? 'ORDER' : standby ? 'Standby' : 'OK'}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="card selectedPanel">
        <div className="bayHead">
          <div>
            <div className="pill">Selected Bay</div>
            <h2>{bayLabel(selectedBay)}</h2>
          </div>
          <div className="panelActions">
            <a className="btn secondary" href={`/pos?bay=${selectedBay}`}>Add Order For Bay</a>
            <a className="btn secondary" href="/stock">Stock Movement</a>
          </div>
        </div>

        {selectedOrders.length === 0 ? <p className="muted">No active order. If customer orders verbally, use Add Order For Bay.</p> : null}
        <div className="orderList">
          {selectedOrders.map((order) => {
            const paid = order.payment_status === 'paid';
            const done = order.booking_status === 'completed' || order.booking_status === 'delivered';
            const busy = working === order.booking_id;
            return (
              <article className="miniOrder" key={order.booking_id}>
                <div>
                  <b>{order.qr_token}</b>
                  <span>{money(order.total_amount)} · {order.booking_status}</span>
                  <small>{order.customer_name || 'Walk-in customer'} · {paid ? 'PAID' : order.payment_status}</small>
                </div>
                <div className="miniActions">
                  <button className="btn" disabled={busy || paid || done} onClick={() => verifyPayment(order)}>{paid ? 'Verified' : 'Verify'}</button>
                  <button className="btn secondary" disabled={!paid || busy || done} onClick={() => printKitchenSlip(order)}>Kitchen</button>
                  <button className="btn secondary" disabled={!paid || busy || done} onClick={() => updateStatus(order, 'preparing')}>Preparing</button>
                  <button className="btn secondary" disabled={!paid || busy || done} onClick={() => updateStatus(order, 'delivered')}>Delivered</button>
                  <button className="btn secondary" disabled={!paid || busy} onClick={() => printReceipt(order)}>Receipt</button>
                </div>
              </article>
            );
          })}
        </div>
      </section>

      <style>{`
        .bayOpsPage{max-width:1120px;margin:0 auto}.navActions,.panelActions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.helpStrip{display:grid;gap:10px;margin:12px 0}.helpAlert{border:1px solid rgba(251,191,36,.8);background:rgba(251,191,36,.18);color:#fde68a;border-radius:16px;padding:14px;font-weight:1000;text-align:left;animation:pulseHelp 1.2s infinite}.bayGridCard,.selectedPanel{margin:12px 0}.bayHead{display:flex;align-items:center;justify-content:space-between;gap:14px}.bayHead h2{color:#fff;margin:8px 0 4px}.bayGrid{display:grid;grid-template-columns:repeat(10,minmax(0,1fr));gap:8px;margin-top:14px}.bayBtn{border:1px solid rgba(52,211,153,.22);background:rgba(2,44,34,.62);color:#d1fae5;border-radius:14px;padding:10px 6px}.bayBtn b{display:block;color:#fff;font-size:18px}.bayBtn span{font-size:10px;color:#a7f3d0}.bayBtn.selected{outline:2px solid #34d399}.bayBtn.help{border-color:#fbbf24;background:rgba(251,191,36,.18);animation:pulseHelp 1.2s infinite}.bayBtn.help span{color:#fde68a;font-weight:1000}.bayBtn.pending{border-color:#fbbf24}.bayBtn.standby{opacity:.38}.orderList{display:grid;gap:10px;margin-top:14px}.miniOrder{display:grid;grid-template-columns:minmax(0,1fr) 560px;gap:12px;align-items:center;border:1px solid rgba(52,211,153,.22);background:rgba(2,44,34,.62);border-radius:16px;padding:14px}.miniOrder b,.miniOrder span,.miniOrder small{display:block}.miniOrder b{color:#fff;font-size:20px}.miniOrder span{color:#d1fae5;font-weight:900}.miniOrder small{color:#a7f3d0}.miniActions{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px}.okCard{border-color:#34d399;color:#d1fae5}@keyframes pulseHelp{0%,100%{box-shadow:0 0 0 rgba(251,191,36,0)}50%{box-shadow:0 0 24px rgba(251,191,36,.45)}}@media(max-width:900px){.navActions,.panelActions{justify-content:flex-start}.bayHead{display:block}.bayHead .btn{margin-top:10px}.bayGrid{grid-template-columns:repeat(5,minmax(0,1fr))}.miniOrder{grid-template-columns:1fr}.miniActions{grid-template-columns:1fr}}
      `}</style>
    </main>
  );
}
