'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';
import {
  TOP_NAV_ROUTES,
  accessLabel,
  canAccess,
  requiredAccessForPath,
  routePath,
  type AccessRole,
  type NavRoute,
} from '@/lib/navigation';

const ACCESS_SESSION_KEY = 'edge_range_os_ops_role';
const OLD_ACCESS_SESSION_KEY = 'rangeflow_ops_role';
const NEW_PAYMENT_NOTE = 'Sila bayar jumlah yang tepat. Simpan bukti bayaran jika diminta oleh staff. Staff akan sahkan bayaran secara manual.';

type VerifyResult = { ok?: boolean; message?: string; role_key?: string };

function readStoredRole(value: string | null): AccessRole | null {
  if (value === 'staff' || value === 'owner' || value === 'superadmin') return value;
  return null;
}

function protectedFallback(pathname: string, required: AccessRole): NavRoute {
  const isOwner = required === 'owner';
  const isSuperAdmin = required === 'superadmin';
  return {
    icon: isSuperAdmin ? '🏢' : isOwner ? '👑' : '🔒',
    label: isSuperAdmin ? 'Super Admin Area' : isOwner ? 'Owner Area' : 'Staff Area',
    href: pathname || '/',
    section: isSuperAdmin ? 'superadmin' : isOwner ? 'owner' : 'staff',
    access: required,
    status: isSuperAdmin ? 'future' : 'production',
  };
}

async function verifyRpc(roleKey: 'staff' | 'owner', pin: string) {
  const { data, error } = await supabase.rpc('verify_org_access_pin', {
    p_org_slug: ORG_SLUG,
    p_role_key: roleKey,
    p_pin: pin,
  });

  if (error) return { ok: false, message: error.message || 'Access verification failed.' };

  const result = data as VerifyResult;
  if (!result?.ok) return { ok: false, message: result?.message || 'PIN tidak sah.' };

  return { ok: true, role: roleKey as AccessRole, message: result?.message || 'Access granted.' };
}

async function verifyAccess(required: AccessRole, pin: string) {
  if (required === 'owner') return verifyRpc('owner', pin);

  if (required === 'staff') {
    const staffResult = await verifyRpc('staff', pin);
    if (staffResult.ok) return staffResult;

    // Owner PIN must also be able to unlock staff operation.
    const ownerResult = await verifyRpc('owner', pin);
    if (ownerResult.ok) return { ...ownerResult, role: 'owner' as AccessRole };

    return { ok: false, message: staffResult.message || ownerResult.message || 'PIN tidak sah.' };
  }

  if (required === 'superadmin') return { ok: false, message: 'Super Admin auth is future scope and not active yet.' };

  return { ok: true, role: 'public' as AccessRole, message: 'Open route.' };
}

export default function GlobalReturnNav() {
  const [currentPath, setCurrentPath] = useState('');
  const [accessRole, setAccessRole] = useState<AccessRole | null>(null);
  const [pending, setPending] = useState<NavRoute | null>(null);
  const [pin, setPin] = useState('');
  const [checking, setChecking] = useState(false);
  const [error, setError] = useState('');
  const [message, setMessage] = useState('');

  const activeItem = useMemo(
    () => TOP_NAV_ROUTES.find((item) => !item.external && currentPath && currentPath === routePath(item.href)),
    [currentPath]
  );

  useEffect(() => {
    const saved = readStoredRole(window.sessionStorage.getItem(ACCESS_SESSION_KEY)) || readStoredRole(window.sessionStorage.getItem(OLD_ACCESS_SESSION_KEY));
    if (saved) setAccessRole(saved);
    setCurrentPath(window.location.pathname);
  }, []);

  useEffect(() => {
    const required = requiredAccessForPath(currentPath);
    if (required === 'public' || canAccess(required, accessRole)) return;

    const matched = TOP_NAV_ROUTES.find((item) => routePath(item.href) === currentPath);
    setPending(matched || protectedFallback(currentPath, required));
  }, [accessRole, currentPath]);

  useEffect(() => {
    function patchUi() {
      const path = window.location.pathname;

      document.querySelectorAll<HTMLButtonElement>('.cartBar button').forEach((button) => {
        const bar = button.closest('.cartBar');
        const text = bar?.textContent || '';
        const empty = text.includes('No item selected') || text.includes('RM 0.00') || text.includes('RM0.00');
        button.disabled = empty;
        if (empty) button.textContent = 'Select item first';
      });

      document.querySelectorAll<HTMLButtonElement>('.bayActions .release').forEach((button) => {
        if (button.dataset.confirmPatched === '1') return;
        button.dataset.confirmPatched = '1';
        button.addEventListener('click', (event) => {
          const selected = document.querySelector('.selectedDock b')?.textContent || 'selected bay';
          if (!window.confirm(`Are you sure you want to release ${selected}? This will close the active session.`)) {
            event.preventDefault();
            event.stopImmediatePropagation();
          }
        }, true);
      });

      if (path === '/payments' || path.startsWith('/payments/')) {
        document.querySelectorAll<HTMLTextAreaElement>('textarea').forEach((textarea) => {
          if (textarea.value.includes('upload') || textarea.value.includes('proof') || textarea.value.includes('bukti')) {
            textarea.value = NEW_PAYMENT_NOTE;
            textarea.dispatchEvent(new Event('input', { bubbles: true }));
          }
        });
      }
    }

    patchUi();
    const timer = window.setInterval(patchUi, 500);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    function interceptProtectedLinks(event: MouseEvent) {
      const target = event.target as HTMLElement | null;
      const anchor = target?.closest('a[href]') as HTMLAnchorElement | null;
      if (!anchor) return;
      if (anchor.closest('.edgeIconNav') || anchor.target === '_blank') return;

      const href = anchor.getAttribute('href') || '';
      if (!href.startsWith('/')) return;

      const path = href.split('?')[0];
      const required = requiredAccessForPath(path);
      if (required === 'public' || canAccess(required, accessRole)) return;

      event.preventDefault();
      event.stopPropagation();
      setPending({
        ...protectedFallback(path, required),
        label: anchor.textContent?.trim() || protectedFallback(path, required).label,
        href,
      });
    }

    document.addEventListener('click', interceptProtectedLinks, true);
    return () => document.removeEventListener('click', interceptProtectedLinks, true);
  }, [accessRole]);

  function openNavItem(item: NavRoute) {
    setError('');
    setMessage('');

    if (item.status === 'future') {
      setPending(item);
      setPin('');
      return;
    }

    if (!canAccess(item.access, accessRole)) {
      setPending(item);
      setPin('');
      return;
    }

    window.location.href = item.href;
  }

  async function unlockAndOpen() {
    if (!pending) return;

    if (pending.access === 'superadmin') {
      setError('Super Admin auth is future scope and not active yet.');
      return;
    }

    if (!pin.trim()) {
      setError('Masukkan PIN akses.');
      return;
    }

    setChecking(true);
    setError('');
    setMessage('');

    const result = await verifyAccess(pending.access, pin);

    setChecking(false);

    if (!result.ok || !result.role) {
      setError(result.message || 'PIN tidak sah.');
      return;
    }

    setAccessRole(result.role);
    window.sessionStorage.setItem(ACCESS_SESSION_KEY, result.role);
    window.sessionStorage.setItem(OLD_ACCESS_SESSION_KEY, result.role);
    setMessage(`${accessLabel(result.role)} access granted.`);

    const nextHref = pending.href;
    setPending(null);
    setPin('');

    if (nextHref && nextHref !== window.location.pathname) window.location.href = nextHref;
  }

  function lockAccess() {
    setAccessRole(null);
    window.sessionStorage.removeItem(ACCESS_SESSION_KEY);
    window.sessionStorage.removeItem(OLD_ACCESS_SESSION_KEY);
    setMessage('Access locked.');
    setError('');
  }

  return (
    <>
      <nav className="edgeIconNav" aria-label="EDGE RANGE OS persistent operations menu">
        <button className="edgeBrand" type="button" onClick={() => window.location.href = '/'}>
          <span>DG</span>
          <b>EDGE</b>
        </button>
        <div className="iconRail">
          {TOP_NAV_ROUTES.map((item) => {
            const active = activeItem?.href === item.href;
            const locked = !canAccess(item.access, accessRole);
            return (
              <button key={`${item.section}-${item.label}`} type="button" className={`${active ? 'active' : ''} ${locked ? 'locked' : ''}`} onClick={() => openNavItem(item)} title={item.label}>
                <i>{item.icon}</i>
                <small>{item.label}</small>
                {locked ? <em>🔒</em> : null}
              </button>
            );
          })}
        </div>
        <button className="rolePill" type="button" onClick={lockAccess}>{accessLabel(accessRole)}</button>
      </nav>

      {message ? <div className="edgeToast ok">{message}</div> : null}

      {pending ? (
        <section className="edgeAccessOverlay" role="dialog" aria-modal="true" aria-label="Protected access">
          <div className="edgeAccessCard">
            <button className="closeAccess" type="button" onClick={() => setPending(null)}>×</button>
            <span>{pending.icon}</span>
            <h2>{pending.label}</h2>
            <p>{pending.access === 'owner' ? 'Owner PIN required.' : pending.access === 'staff' ? 'Staff PIN required. Owner PIN can also unlock staff operation.' : 'Protected access required.'}</p>
            <input type="password" inputMode="numeric" placeholder="PIN" value={pin} onChange={(event) => setPin(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') unlockAndOpen(); }} autoFocus />
            <button type="button" onClick={unlockAndOpen} disabled={checking}>{checking ? 'Checking...' : 'Unlock & Open'}</button>
            {error ? <strong className="edgeError">{error}</strong> : null}
          </div>
        </section>
      ) : null}

      <style jsx global>{`
        body{padding-top:62px!important}.edgeIconNav{position:fixed;top:0;left:0;right:0;z-index:9999;display:flex;align-items:center;gap:8px;height:58px;padding:6px 8px;background:rgba(3,24,16,.96);border-bottom:1px solid rgba(155,232,79,.22);box-shadow:0 12px 30px rgba(3,24,16,.24);backdrop-filter:blur(14px)}.edgeBrand,.rolePill,.edgeIconNav button{font-family:Inter,Arial,sans-serif}.edgeBrand{flex:0 0 auto;display:flex;align-items:center;gap:7px;border:0;border-radius:16px;background:rgba(255,255,255,.06);color:white;padding:6px 9px;min-height:44px}.edgeBrand span{width:30px;height:30px;border-radius:11px;background:linear-gradient(135deg,#9be84f,#17b26a);display:grid;place-items:center;color:#06110d;font-size:11px;font-weight:1000}.edgeBrand b{font-size:13px;letter-spacing:.08em}.iconRail{flex:1 1 auto;display:flex;align-items:center;gap:6px;overflow-x:auto;scrollbar-width:none}.iconRail::-webkit-scrollbar{display:none}.iconRail button{position:relative;flex:0 0 62px;height:46px;border:1px solid rgba(255,255,255,.1);border-radius:15px;background:rgba(255,255,255,.05);color:#eaffef;display:grid;place-items:center;padding:4px 5px;cursor:pointer}.iconRail button.active{background:linear-gradient(135deg,#9be84f,#17b26a);color:#06110d;border-color:transparent}.iconRail button.locked{background:rgba(255,255,255,.035)}.iconRail i{font-style:normal;font-size:17px;line-height:1}.iconRail small{display:block;margin-top:1px;font-size:9px;font-weight:950;line-height:1;white-space:nowrap}.iconRail em{position:absolute;top:3px;right:4px;font-style:normal;font-size:9px}.rolePill{flex:0 0 auto;border:1px solid rgba(255,255,255,.14);border-radius:999px;background:rgba(255,255,255,.07);color:#d6f3df;padding:0 12px;height:40px;font-size:12px;font-weight:1000}.edgeAccessOverlay{position:fixed;inset:0;z-index:10000;display:grid;place-items:center;background:rgba(2,21,16,.62);backdrop-filter:blur(6px);padding:16px}.edgeAccessCard{position:relative;width:min(380px,100%);border:1px solid rgba(255,255,255,.18);border-radius:24px;background:#fbfdf8;color:#071c16;padding:18px;box-shadow:0 28px 100px rgba(0,0,0,.38);font-family:Inter,Arial,sans-serif}.closeAccess{position:absolute;top:10px;right:10px;width:34px;height:34px;border:0;border-radius:50%;background:#eef4eb;color:#071c16;font-size:22px;font-weight:1000}.edgeAccessCard>span{display:grid;place-items:center;width:48px;height:48px;border-radius:17px;background:linear-gradient(135deg,#9be84f,#17b26a);font-size:23px}.edgeAccessCard h2{font-size:26px;line-height:1;margin:12px 42px 7px 0;letter-spacing:-.04em}.edgeAccessCard p{margin:0 0 12px;color:#607469;font-size:13px;font-weight:850;line-height:1.35}.edgeAccessCard input{width:100%;border:1px solid #dce8d5;border-radius:15px;background:white;color:#071c16;padding:13px;font-size:20px;font-weight:1000;outline:none}.edgeAccessCard>button:not(.closeAccess){width:100%;margin-top:10px;border:0;border-radius:15px;background:linear-gradient(135deg,#9be84f,#17b26a);color:#06110d;padding:13px;font-weight:1000}.edgeAccessCard>button:disabled{opacity:.58}.edgeError{display:block;margin-top:10px;color:#9f1239;font-size:13px}.edgeToast{position:fixed;top:68px;right:12px;z-index:10001;border-radius:999px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;padding:9px 12px;font-size:12px;font-weight:1000;box-shadow:0 12px 34px rgba(7,28,22,.14)}@media(max-width:760px){body{padding-top:60px!important}.edgeIconNav{height:56px}.edgeBrand b{display:none}.iconRail button{flex-basis:54px}.rolePill{display:none}}@media(max-width:420px){.edgeIconNav{padding:5px 6px}.edgeBrand{padding:5px 6px}.edgeBrand span{width:28px;height:28px}.iconRail{gap:5px}.iconRail button{flex-basis:50px;height:44px;border-radius:14px}.iconRail i{font-size:16px}.iconRail small{font-size:8px}.edgeAccessCard{border-radius:22px;padding:16px}}
      `}</style>
    </>
  );
}
