'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';
import { MODULE_ROUTES, canAccess, roleChip, type AccessRole } from '@/lib/navigation';

type VerifyResult = { ok?: boolean; message?: string; role_key?: string };
const ACCESS_SESSION_KEY = 'edge_range_os_ops_role';
const OLD_ACCESS_SESSION_KEY = 'rangeflow_ops_role';

function readStoredRole(value: string | null): AccessRole | null {
  if (value === 'staff' || value === 'owner' || value === 'superadmin') return value;
  return null;
}

export default function HubPage() {
  const [role, setRole] = useState<'staff' | 'owner'>('staff');
  const [pin, setPin] = useState('');
  const [accessRole, setAccessRole] = useState<AccessRole | null>(null);
  const [checking, setChecking] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  useEffect(() => {
    const saved = readStoredRole(window.sessionStorage.getItem(ACCESS_SESSION_KEY)) || readStoredRole(window.sessionStorage.getItem(OLD_ACCESS_SESSION_KEY));
    if (saved) setAccessRole(saved);
  }, []);

  async function unlock() {
    setError('');
    setMessage('');
    if (!pin.trim()) {
      setError('Masukkan PIN akses.');
      return;
    }

    setChecking(true);
    const { data, error: rpcError } = await supabase.rpc('verify_org_access_pin', {
      p_org_slug: ORG_SLUG,
      p_role_key: role,
      p_pin: pin,
    });
    setChecking(false);

    if (rpcError) {
      setError(rpcError.message || 'Access verification failed.');
      return;
    }

    const result = data as VerifyResult;
    if (!result?.ok) {
      setError(result?.message || 'PIN tidak sah.');
      return;
    }

    setAccessRole(role);
    window.sessionStorage.setItem(ACCESS_SESSION_KEY, role);
    window.sessionStorage.setItem(OLD_ACCESS_SESSION_KEY, role);
    setPin('');
    setMessage(role === 'owner' ? 'Owner access granted.' : 'Staff access granted.');
  }

  function lock() {
    setAccessRole(null);
    window.sessionStorage.removeItem(ACCESS_SESSION_KEY);
    window.sessionStorage.removeItem(OLD_ACCESS_SESSION_KEY);
    setMessage('Access locked.');
  }

  const visibleRoutes = MODULE_ROUTES.filter((route) => route.status === 'production');

  return (
    <main className="hubPage">
      <section className="hubHero">
        <div>
          <span>Access Hub</span>
          <h1>EDGE RANGE OS</h1>
          <p>Secure entry point for customer preview, staff operation and owner control. Legacy staff-ops links are removed from this hub.</p>
        </div>
        <a href="/" className="homeBtn">Open Icon Dashboard</a>
      </section>

      <section className="hubLayout">
        <aside className="accessCard" id="login">
          <div className="pill">Secure Access</div>
          <h2>Staff / Owner PIN</h2>
          <p>Staff PIN unlocks daily operation. Owner PIN unlocks owner control and staff operation.</p>
          <select value={role} onChange={(event) => { setRole(event.target.value as 'staff' | 'owner'); setError(''); setMessage(''); }}>
            <option value="staff">Staff Operation</option>
            <option value="owner">Owner Control</option>
          </select>
          <input type="password" placeholder="PIN" value={pin} onChange={(event) => setPin(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') unlock(); }} />
          <button type="button" onClick={unlock} disabled={checking}>{checking ? 'Checking...' : 'Unlock Access'}</button>
          {accessRole ? <button type="button" className="secondary" onClick={lock}>Lock / Logout</button> : null}
          {message ? <strong className="okMsg">{message}</strong> : null}
          {error ? <strong className="badMsg">{error}</strong> : null}
        </aside>

        <section className="routeGrid" aria-label="EDGE RANGE OS access routes">
          {visibleRoutes.map((route) => {
            const unlocked = canAccess(route.access, accessRole);
            return (
              <a key={`${route.section}-${route.label}`} href={unlocked ? route.href : '#login'} className={`routeCard ${unlocked ? '' : 'locked'}`}>
                <div className="icon">{route.icon}</div>
                <div>
                  <span>{roleChip(route)}</span>
                  <h2>{route.label}</h2>
                  <p>{route.description || 'EDGE RANGE OS module'}</p>
                </div>
                <em>{unlocked ? '›' : '🔒'}</em>
              </a>
            );
          })}
        </section>
      </section>

      <section className="flowNote">
        <b>Production flow</b>
        <span>Customer QR order → Staff counter/payment fulfilment → POS/stock update → Owner dashboard/control. Super Admin starts after route governance is stable.</span>
      </section>

      <style jsx>{styles}</style>
    </main>
  );
}

const styles = `
.hubPage{--bg:#f7faf6;--panel:#fff;--ink:#102019;--muted:#657568;--line:#dbe7d8;--green:#063f22;--green2:#17b26a;--lime:#9be84f;min-height:100vh;background:radial-gradient(circle at top left,rgba(155,232,79,.16),transparent 28%),var(--bg);color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hubHero,.hubLayout,.flowNote{max-width:1180px;margin-left:auto;margin-right:auto}.hubHero{display:flex;justify-content:space-between;align-items:center;gap:16px;border:1px solid var(--line);border-radius:24px;background:white;box-shadow:0 14px 34px rgba(7,28,22,.08);padding:18px}.hubHero span,.pill,.routeCard span{display:inline-flex;border-radius:999px;background:#ecfdf5;border:1px solid #bbf7d0;color:#0f773a;text-transform:uppercase;font-size:10px;font-weight:1000;letter-spacing:.1em;padding:5px 8px}.hubHero h1{margin:8px 0 4px;font-size:30px;letter-spacing:.08em}.hubHero p,.accessCard p,.routeCard p,.flowNote span{margin:0;color:var(--muted);font-size:13px;font-weight:850;line-height:1.35}.homeBtn{border-radius:15px;background:#061c14;color:white;text-decoration:none;font-size:13px;font-weight:1000;padding:12px 14px;white-space:nowrap}.hubLayout{display:grid;grid-template-columns:300px minmax(0,1fr);gap:14px;margin-top:14px}.accessCard{border:1px solid var(--line);border-radius:22px;background:white;box-shadow:0 12px 30px rgba(7,28,22,.07);padding:16px}.accessCard h2{margin:10px 0 7px;font-size:23px}.accessCard select,.accessCard input{width:100%;box-sizing:border-box;border:1px solid var(--line);border-radius:14px;background:#fbfdf9;color:var(--ink);font-size:15px;font-weight:900;padding:12px;margin-top:10px}.accessCard button{width:100%;border:0;border-radius:14px;background:linear-gradient(135deg,var(--lime),var(--green2));color:#06110d;font-size:13px;font-weight:1000;padding:12px;margin-top:10px}.accessCard button.secondary{background:#061c14;color:white}.okMsg,.badMsg{display:block;margin-top:10px;font-size:13px}.okMsg{color:#0f773a}.badMsg{color:#9f1239}.routeGrid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.routeCard{position:relative;display:grid;grid-template-columns:62px minmax(0,1fr) 28px;gap:12px;align-items:center;min-height:124px;border:1px solid var(--line);border-radius:20px;background:white;color:var(--ink);text-decoration:none;box-shadow:0 12px 28px rgba(7,28,22,.06);padding:14px}.routeCard.locked{background:#fbfdf9;opacity:.82}.routeCard .icon{width:58px;height:58px;border-radius:20px;background:#eef8ed;color:var(--green);display:grid;place-items:center;font-size:28px}.routeCard h2{margin:8px 0 4px;font-size:20px;letter-spacing:-.03em}.routeCard em{width:28px;height:28px;border-radius:50%;background:#f6faf3;border:1px solid var(--line);display:grid;place-items:center;font-style:normal;font-size:18px}.flowNote{display:flex;gap:12px;align-items:center;border:1px solid var(--line);border-radius:18px;background:white;box-shadow:0 10px 24px rgba(7,28,22,.05);padding:14px;margin-top:14px}.flowNote b{color:var(--green);white-space:nowrap}@media(max-width:980px){.hubHero,.flowNote{display:block}.homeBtn{display:inline-grid;margin-top:13px}.hubLayout{grid-template-columns:1fr}.routeGrid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:580px){.hubPage{padding:10px}.hubHero h1{font-size:24px}.routeGrid{grid-template-columns:1fr}.routeCard{grid-template-columns:54px minmax(0,1fr) 28px}.routeCard .icon{width:52px;height:52px;border-radius:18px}}
`;
