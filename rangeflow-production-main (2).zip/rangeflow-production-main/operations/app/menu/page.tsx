'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type MenuItem = {
  id?: string;
  category: string;
  name: string;
  description?: string | null;
  price: number | string;
  image_url?: string | null;
  available: boolean;
  position: number;
  prep_time_min: number;
  stock_tracked?: boolean;
  stock_qty?: number;
  low_stock_qty?: number;
  low_stock?: boolean;
};

const emptyForm: MenuItem = {
  category: 'bucket',
  name: '',
  description: '',
  price: 0,
  image_url: '',
  available: true,
  position: 0,
  prep_time_min: 5,
};

function categoryLabel(category: string) {
  if (category === 'bucket') return 'Ball Bucket';
  if (category === 'fb' || category === 'food') return 'Food';
  if (category === 'drink') return 'Drink';
  if (category === 'snack') return 'Snack';
  if (category === 'set' || category === 'promo') return 'Set / Combo';
  if (category === 'equipment' || category === 'golf') return 'Golf Essentials';
  if (category === 'service') return 'Service';
  return category || 'Other';
}

function money(value: number | string | undefined) { return `RM ${Number(value || 0).toFixed(2)}`; }
function count(value: number | string | undefined) { return Number(value || 0).toLocaleString('en-MY'); }

export default function MenuManagementPage() {
  const [items, setItems] = useState<MenuItem[]>([]);
  const [form, setForm] = useState<MenuItem>(emptyForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const bucketCount = useMemo(() => items.filter((item) => item.category === 'bucket').length, [items]);
  const fbCount = useMemo(() => items.filter((item) => ['fb', 'food', 'drink', 'snack', 'set', 'promo'].includes(item.category)).length, [items]);
  const stockCount = useMemo(() => items.filter((item) => item.stock_tracked).length, [items]);
  const lowStockCount = useMemo(() => items.filter((item) => item.low_stock).length, [items]);

  async function loadMenu() {
    setLoading(true);
    setError(null);
    const { data, error: loadError } = await supabase.rpc('get_operations_menu_items', { p_org_slug: ORG_SLUG });
    setLoading(false);
    if (loadError) {
      setError(loadError.message || 'Gagal load menu.');
      return;
    }
    setItems((data || []) as MenuItem[]);
  }

  useEffect(() => { loadMenu(); }, []);

  function editItem(item: MenuItem) {
    setForm({
      id: item.id,
      category: item.category || 'fb',
      name: item.name || '',
      description: item.description || '',
      price: Number(item.price || 0),
      image_url: item.image_url || '',
      available: Boolean(item.available),
      position: Number(item.position || 0),
      prep_time_min: Number(item.prep_time_min || 5),
      stock_tracked: Boolean(item.stock_tracked),
      stock_qty: Number(item.stock_qty || 0),
      low_stock_qty: Number(item.low_stock_qty || 0),
    });
    setMessage(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function saveItem() {
    setSaving(true);
    setMessage(null);
    setError(null);
    const { error: saveError } = await supabase.rpc('save_operations_menu_item', {
      p_org_slug: ORG_SLUG,
      p_item_id: form.id || null,
      p_category: form.category,
      p_name: form.name,
      p_description: form.description || null,
      p_price: Number(form.price || 0),
      p_image_url: form.image_url || null,
      p_available: form.available,
      p_position: Number(form.position || 0),
      p_prep_time_min: Number(form.prep_time_min || 5),
    });
    setSaving(false);
    if (saveError) {
      setError(saveError.message || 'Gagal save menu.');
      return;
    }
    setMessage(form.id ? 'Product updated.' : 'Product added.');
    setForm(emptyForm);
    await loadMenu();
  }

  return (
    <main className="menuShell">
      <header className="hero">
        <div>
          <span>RangeFlow @ UKM</span>
          <h1>Menu / Product Setup</h1>
          <p>Manage ball bucket, F&B, counter items and POS Lite products.</p>
        </div>
        <strong>Standard Package</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/stock">Stock</a>
        <a href="/payments">Payment</a>
        <a href="/counter">Counter</a>
        <button type="button" onClick={() => { setForm(emptyForm); setMessage(null); setError(null); }}>New Product</button>
      </nav>

      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}
      {loading ? <div className="notice">Loading products...</div> : null}

      <section className="metrics">
        <Metric label="Ball Bucket" value={count(bucketCount)} />
        <Metric label="F&B / Products" value={count(fbCount)} />
        <Metric label="Stock Tracked" value={count(stockCount)} />
        <Metric label="Low Stock" value={count(lowStockCount)} />
      </section>

      <section className="contentGrid">
        <article className="panel formPanel">
          <div className="panelTitle">
            <div><span>{form.id ? 'Edit Product' : 'Add Product'}</span><h2>{form.id ? 'Update Product' : 'Create Product'}</h2></div>
            <button type="button" disabled={saving} onClick={saveItem}>{saving ? 'Saving...' : 'Save Product'}</button>
          </div>

          <div className="formGrid">
            <label><small>Category</small><select value={form.category} onChange={(e) => setForm({...form, category: e.target.value})}>
              <option value="bucket">Ball Bucket</option>
              <option value="fb">Food</option>
              <option value="drink">Drink</option>
              <option value="snack">Snack</option>
              <option value="set">Set / Combo</option>
              <option value="equipment">Golf Essentials</option>
              <option value="service">Service / Rental</option>
              <option value="other">Other Standard Item</option>
            </select></label>
            <label><small>Name</small><input value={form.name} onChange={(e) => setForm({...form, name: e.target.value})} placeholder="100 Balls Bucket / Mineral Water" /></label>
            <label><small>Description</small><input value={form.description || ''} onChange={(e) => setForm({...form, description: e.target.value})} placeholder="Shown to customer" /></label>
            <label><small>Price RM</small><input type="number" step="0.01" value={form.price} onChange={(e) => setForm({...form, price: e.target.value})} /></label>
            <label className="wide"><small>Image URL</small><input value={form.image_url || ''} onChange={(e) => setForm({...form, image_url: e.target.value})} placeholder="https://..." /></label>
            <label><small>Position</small><input type="number" value={form.position} onChange={(e) => setForm({...form, position: Number(e.target.value)})} /></label>
            <label><small>Prep Min</small><input type="number" value={form.prep_time_min} onChange={(e) => setForm({...form, prep_time_min: Number(e.target.value)})} /></label>
            <label className="checkLine"><input type="checkbox" checked={form.available} onChange={(e) => setForm({...form, available: e.target.checked})} /><span>Available to customer</span></label>
          </div>
        </article>

        <aside className="panel scopePanel">
          <div className="panelTitle"><div><span>Package Scope</span><h2>Standard Flow</h2></div></div>
          <Row label="Ball bucket" value="Customer + Counter" />
          <Row label="F&B / Product" value="QR Order + POS Lite" />
          <Row label="Stock Lite" value="Basic tracking" />
          <p>POS Lite and basic stock are included in the standard operational flow. Full POS, supplier, purchase order and accounting valuation remain add-ons.</p>
        </aside>
      </section>

      <section className="products">
        {items.map((item) => (
          <article className={`productCard ${item.low_stock ? 'low' : ''}`} key={item.id}>
            {item.image_url ? <img src={item.image_url} alt={item.name} /> : <div className="imageFallback">{categoryLabel(item.category)}</div>}
            <div className="pill">{categoryLabel(item.category)}</div>
            <h2>{item.name}</h2>
            <p>{item.description || 'No description'}</p>
            <Row label="Price" value={money(item.price)} />
            <Row label="Available" value={item.available ? 'Yes' : 'No'} />
            <Row label="Stock" value={item.stock_tracked ? `${item.stock_qty ?? 0}` : 'Not tracked'} />
            <button onClick={() => editItem(item)}>Edit</button>
          </article>
        ))}
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) { return <article className="metric"><span>{label}</span><b>{value}</b></article>; }
function Row({ label, value }: { label: string; value: string }) { return <div className="row"><span>{label}</span><b>{value}</b></div>; }

const styles = `
.menuShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hero{max-width:1240px;margin:0 auto 12px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:28px;padding:24px;display:flex;justify-content:space-between;gap:20px;align-items:flex-start;box-shadow:0 20px 60px rgba(7,28,22,.14)}.hero span{color:var(--accent);font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:42px;line-height:1;margin:8px 0 8px;letter-spacing:-.04em}.hero p{margin:0;color:#cdebd8;font-weight:900}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:12px 16px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px;flex-wrap:wrap}.nav a,.nav button,.panelTitle button,.productCard button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.nav button,.panelTitle button,.productCard button{background:var(--green);color:#fff}.notice{max-width:1240px;margin:0 auto 12px;border-radius:16px;padding:12px 14px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.metrics{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.metric,.panel,.productCard{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06)}.metric span,.panelTitle span,.row span,label small,.pill{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.metric b{display:block;font-size:32px;margin-top:10px}.contentGrid{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:minmax(0,1fr) 390px;gap:12px;align-items:start}.panelTitle{display:flex;justify-content:space-between;gap:12px;align-items:flex-start;margin-bottom:14px}.panelTitle h2{font-size:22px;margin:6px 0 0}.formGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.formGrid label{display:block}.formGrid input,.formGrid select{width:100%;box-sizing:border-box;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:12px 13px;font-weight:850;margin-top:6px}.wide{grid-column:1/-1}.checkLine{display:flex!important;align-items:center;gap:10px;margin-top:24px}.checkLine input{width:auto;margin:0}.checkLine span{font-weight:1000}.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:12px 0}.row:last-child{border-bottom:0}.row b{text-align:right}.scopePanel p{color:var(--muted);font-weight:900;line-height:1.45}.products{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.productCard.low{border-color:#f59e0b}.productCard img,.imageFallback{width:100%;height:150px;object-fit:cover;border-radius:16px;margin-bottom:12px}.imageFallback{display:grid;place-items:center;background:#f3f7f1;color:var(--muted);font-weight:1000}.productCard h2{font-size:22px;margin:10px 0 4px}.productCard p{color:var(--muted);font-weight:900}.productCard button{width:100%;margin-top:12px}@media(max-width:980px){.metrics{grid-template-columns:repeat(2,1fr)}.contentGrid{grid-template-columns:1fr}.products{grid-template-columns:repeat(2,1fr)}.hero{display:block}.hero strong{display:inline-block;margin-top:16px}.formGrid{grid-template-columns:1fr}.nav a,.nav button{flex:1 1 130px;text-align:center}.panelTitle{display:block}.panelTitle button{width:100%;margin-top:12px}}@media(max-width:560px){.menuShell{padding:10px}.hero{border-radius:22px;padding:18px}.hero h1{font-size:32px}.metrics,.products{grid-template-columns:1fr}.metric b{font-size:28px}}
`;