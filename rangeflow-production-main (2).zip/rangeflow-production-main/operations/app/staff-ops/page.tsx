'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type QueueItem = {
  booking_id: string;
  qr_token: string;
  bay_code: string;
  bay_name: string;
  customer_name?: string | null;
  booking_status: string;
  payment_status: string;
  total_amount: number | string;
};

type AssistanceRequest = {
  id: string;
  bay_code: string;
  status: 'open' | 'acknowledged' | 'closed';
  message?: string | null;
  created_at: string;
};

function money(value: number | string) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function bayLabel(code: string) {
  const n = Number(code);
  if (Number.isFinite(n)) return `Bay ${String(n).padStart(2, '0')}`;
  return `Bay ${code}`;
}

export default function StaffOpsPage() {
  const [orders, setOrders] = useState<QueueItem[]>([]);
  const [assistance, setAssistance] = useState<AssistanceRequest[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState<string | null>(null);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const openAssistanceByBay = useMemo(() => {
    const map = new Map<string, AssistanceRequest>();
    assistance.filter((item) => item.status === 'open').forEach((item) => map.set(String(item.bay_code), item));
    return map;
  }, [assistance]);

  async function loadOrders() {
    setLoading(true);
    setError('');
    const { data, error: queueError } = await supabase.rpc('get_operations_queue_summary', { p_org_slug: ORG_SLUG });
    setLoading(false);
    if (queueError) {
      setError(queueError.message || 'Gagal load admin operation queue.');
      return;
    }
    setOrders((data || []) as QueueItem[]);
  }

  async function loadAssistance() {
    const { data, error: helpError } = await supabase
      .from('assistance_requests')
      .select('id,bay_code,status,message,created_at')
      .eq('org_slug', ORG_SLUG)
      .in('status', ['open', 'acknowledged'])
      .order('created_at', { ascending: false })
      .limit(20);

    if (helpError) {
      setError(helpError.message || 'Gagal load assistance alert.');
      return;
    }
    setAssistance((data || []) as AssistanceRequest[]);
  }

  async function reloadAll() {
    await Promise.all([loadOrders(), loadAssistance()]);
  }

  useEffect(() => {
    reloadAll();
    const timer = window.setInterval(loadAssistance, 8000);
    return () => window.clearInterval(timer);
  }, []);

  async function acknowledgeHelp(request: AssistanceRequest) {
    setWorking(`help-${request.id}`);
    setMessage('');
    setError('');
    const { error: ackError } = await supabase.rpc('acknowledge_assistance_request', { p_request_id: request.id });
    setWorking(null);
    if (ackError) {
      setError(ackError.message || 'Gagal acknowledge bantuan.');
      return;
    }
    setMessage(`${bayLabel(request.bay_code)} assistance acknowledged.`);
    await loadAssistance();
  }

  async function updateStatus(order: QueueItem, status: 'preparing' | 'delivered' | 'completed') {
    setWorking(order.booking_id);
    setMessage('');
    setError('');
    const { error: statusError } = await supabase.rpc('update_operations_booking_status', {
      p_booking_id: order.booking_id,
      p_status: status,
    });
    setWorking(null);
    if (statusError) {
      setError(statusError.message || 'Gagal update order status.');
      return;
    }
    setMessage(`Order ${order.qr_token} updated to ${status}.`);
    await loadOrders();
  }

  async function verifyPayment(order: QueueItem) {
    setWorking(order.booking_id);
    setMessage('');
    setError('');
    const { error: verifyError } = await supabase.rpc('verify_operations_payment', {
      p_booking_id: order.booking_id,
      p_status: 'paid',
      p_note: 'Verified from admin operations page.',
    });
    setWorking(null);
    if (verifyError) {
      setError(verifyError.message || 'Gagal verify payment.');
      return;
    }
    setMessage(`Payment verified for token ${order.qr_token}. Kitchen slip may be printed only if required.`);
    await loadOrders();
  }

  function printKitchenSlip(order: QueueItem) {
    window.open(`/print/${order.booking_id}?type=kitchen`, '_blank', 'noopener,noreferrer');
  }

  function printReceipt(order: QueueItem) {
    window.open(`/print/${order.booking_id}?type=full`, '_blank', 'noopener,noreferrer');
  }

  return (
    <main className="shell staffOpsPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Admin Operasi</h1>
          <p className="muted">Order in/out, payment verification, kitchen slip when required, assistance alert and daily stock inventory access.</p>
        </div>
        <div className="staffOpsNav">
          <a className="btn secondary" href="/stock">Stock Inventory</a>
          <button className="btn" onClick={reloadAll}>Refresh</button>
        </div>
      </div>

      {openAssistanceByBay.size > 0 ? (
        <section className="helpStrip">
          {[...openAssistanceByBay.values()].map((request) => (
            <button className="helpAlert" key={request.id} disabled={working === `help-${request.id}`} onClick={() => acknowledgeHelp(request)}>
              🔔 {bayLabel(request.bay_code)} Need Help / Perlu Bantuan
            </button>
          ))}
        </section>
      ) : null}

      {loading ? <div className="card">Loading active orders...</div> : null}
      {message ? <div className="card okCard">{message}</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      <section className="bayGrid card">
        <div className="pill">Bay Assistance Monitor</div>
        <div className="bayButtons">
          {Array.from({ length: 30 }, (_, i) => String(i + 1).padStart(2, '0')).map((code) => {
            const help = openAssistanceByBay.get(code) || openAssistanceByBay.get(String(Number(code)));
            const standby = Number(code) > 25;
            return (
              <button key={code} className={`bayBtn ${help ? 'needHelp' : ''} ${standby ? 'standby' : ''}`} disabled={standby} onClick={() => help && acknowledgeHelp(help)}>
                <b>{code}</b>
                <span>{help ? 'HELP' : standby ? 'Standby' : 'OK'}</span>
              </button>
            );
          })}
        </div>
      </section>

      <section className="opsList">
        {orders.map((order) => {
          const paid = order.payment_status === 'paid';
          const done = order.booking_status === 'completed' || order.booking_status === 'delivered';
          const busy = working === order.booking_id;

          return (
            <article className="card opsCard" key={order.booking_id}>
              <div className="opsHead">
                <div>
                  <div className="pill">{order.bay_name || `Bay ${order.bay_code}`}</div>
                  <h2>Token {order.qr_token}</h2>
                  <p className="muted">{order.customer_name || 'Walk-in customer'} · {money(order.total_amount)} · {order.booking_status}</p>
                </div>
                <div className={paid ? 'statusPaid' : 'statusPending'}>{paid ? 'PAID' : order.payment_status}</div>
              </div>

              <div className="opsActions">
                <button className="btn" disabled={busy || paid || done} onClick={() => verifyPayment(order)}>{paid ? 'Payment Verified' : 'Verify Payment'}</button>
                <button className="btn secondary" disabled={!paid || busy || done} onClick={() => printKitchenSlip(order)}>Kitchen Slip</button>
                <button className="btn secondary" disabled={!paid || busy || done} onClick={() => updateStatus(order, 'preparing')}>Preparing</button>
                <button className="btn secondary" disabled={!paid || busy || done} onClick={() => updateStatus(order, 'delivered')}>Delivered</button>
                <button className="btn secondary" disabled={!paid || busy} onClick={() => printReceipt(order)}>Receipt</button>
              </div>
            </article>
          );
        })}
      </section>

      {!loading && orders.length === 0 ? <div className="card">No active orders.</div> : null}

      <style>{`
        .staffOpsPage{max-width:1120px;margin:0 auto}.staffOpsNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.helpStrip{display:grid;gap:10px;margin:12px 0}.helpAlert{border:1px solid rgba(251,191,36,.8);background:rgba(251,191,36,.18);color:#fde68a;border-radius:16px;padding:14px;font-weight:1000;text-align:left;animation:pulseHelp 1.2s infinite}.bayGrid{margin:12px 0}.bayButtons{display:grid;grid-template-columns:repeat(10,minmax(0,1fr));gap:8px;margin-top:14px}.bayBtn{border:1px solid rgba(52,211,153,.22);background:rgba(2,44,34,.62);color:#d1fae5;border-radius:14px;padding:10px 6px}.bayBtn b{display:block;color:#fff;font-size:18px}.bayBtn span{font-size:10px;color:#a7f3d0}.bayBtn.needHelp{border-color:#fbbf24;background:rgba(251,191,36,.18);animation:pulseHelp 1.2s infinite}.bayBtn.needHelp span{color:#fde68a;font-weight:1000}.bayBtn.standby{opacity:.38}.opsList{display:grid;gap:12px}.opsCard h2{color:#fff;margin:10px 0 4px}.opsHead{display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.statusPaid,.statusPending{font-weight:900;border-radius:999px;padding:10px 12px}.statusPaid{background:#34d399;color:#022c22}.statusPending{background:#fbbf24;color:#422006}.opsActions{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin-top:16px}.okCard{border-color:#34d399;color:#d1fae5}@keyframes pulseHelp{0%,100%{box-shadow:0 0 0 rgba(251,191,36,0)}50%{box-shadow:0 0 24px rgba(251,191,36,.45)}}@media(max-width:900px){.staffOpsNav{justify-content:flex-start;margin-top:12px}.staffOpsNav .btn{flex:1 1 140px}.opsHead{display:block}.statusPaid,.statusPending{display:inline-block;margin-top:10px}.opsActions{grid-template-columns:1fr}.bayButtons{grid-template-columns:repeat(5,minmax(0,1fr))}}
      `}</style>
    </main>
  );
}
