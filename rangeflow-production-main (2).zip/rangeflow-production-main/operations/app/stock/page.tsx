'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type StockItem = {
  id: string;
  category: string;
  name: string;
  price: number | string;
  available: boolean;
  stock_tracked?: boolean;
  stock_qty?: number | string | null;
  low_stock_qty?: number | string | null;
  low_stock?: boolean;
};

type BallInventory = {
  ok?: boolean;
  message?: string;
  ballsPerBucket?: number | string;
  currentBallStock?: number | string;
  lowStockQty?: number | string;
  bucketSoldToday?: number | string;
  expectedBallOutToday?: number | string;
  stockInToday?: number | string;
  manualOutToday?: number | string;
};

function num(value: number | string | null | undefined) {
  return Number(value || 0).toLocaleString('en-MY');
}

function money(value: number | string | null | undefined) {
  return `RM ${Number(value || 0).toFixed(2)}`;
}

function categoryLabel(value?: string | null) {
  const v = String(value || '').toLowerCase();
  if (v === 'bucket') return 'Ball / Range';
  if (v === 'drink') return 'Drinks';
  if (v === 'fb' || v === 'food') return 'Food';
  if (v === 'snack') return 'Snack';
  if (v === 'equipment' || v === 'golf') return 'Golf Essentials';
  return value || 'Other';
}

export default function StockPage() {
  const [items, setItems] = useState<StockItem[]>([]);
  const [ball, setBall] = useState<BallInventory>({});
  const [currentBallStock, setCurrentBallStock] = useState('');
  const [lowStockQty, setLowStockQty] = useState('');
  const [stockInQty, setStockInQty] = useState('');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const trackedCount = useMemo(() => items.filter((item) => item.stock_tracked).length, [items]);
  const lowItemCount = useMemo(() => items.filter((item) => item.low_stock).length, [items]);
  const ballLow = Number(ball.lowStockQty || 0) > 0 && Number(ball.currentBallStock || 0) <= Number(ball.lowStockQty || 0);

  async function loadAll() {
    setLoading(true);
    setError('');
    setMessage('');

    const [ballResult, stockResult] = await Promise.all([
      supabase.rpc('get_operations_ball_inventory', { p_org_slug: ORG_SLUG }),
      supabase.rpc('get_operations_stock_summary', { p_org_slug: ORG_SLUG }),
    ]);

    setLoading(false);

    if (ballResult.error) {
      setError(`Ball inventory error: ${ballResult.error.message}`);
    } else {
      const data = (ballResult.data || {}) as BallInventory;
      setBall(data);
      setCurrentBallStock(String(data.currentBallStock || 0));
      setLowStockQty(String(data.lowStockQty || 0));
    }

    if (stockResult.error) {
      setError((prev) => prev || `Product stock error: ${stockResult.error.message}`);
    } else {
      setItems((stockResult.data || []) as StockItem[]);
    }
  }

  useEffect(() => { loadAll(); }, []);

  async function saveBallSettings() {
    const current = Math.max(0, Math.floor(Number(currentBallStock || 0)));
    const low = Math.max(0, Math.floor(Number(lowStockQty || 0)));
    setWorking(true);
    setError('');
    setMessage('');

    const { data, error: saveError } = await supabase.rpc('save_operations_ball_inventory', {
      p_org_slug: ORG_SLUG,
      p_current_ball_stock: current,
      p_low_stock_qty: low,
      p_note: 'Owner saved ball inventory from Stock Lite',
    });

    setWorking(false);
    if (saveError) {
      setError(saveError.message || 'Gagal save ball inventory.');
      return;
    }

    const result = (data || {}) as { ok?: boolean; message?: string };
    if (!result.ok) {
      setError(result.message || 'Gagal save ball inventory.');
      return;
    }

    setMessage(`Ball inventory saved: ${num(current)} balls · alert ${num(low)}.`);
    await loadAll();
  }

  async function addBallStockIn() {
    const qty = Math.max(0, Math.floor(Number(stockInQty || 0)));
    if (qty <= 0) {
      setError('Masukkan quantity bola lebih daripada 0.');
      return;
    }

    setWorking(true);
    setError('');
    setMessage('');

    const { data, error: addError } = await supabase.rpc('add_operations_ball_stock_in', {
      p_org_slug: ORG_SLUG,
      p_quantity: qty,
      p_note: 'Ball stock in from Stock Lite',
    });

    setWorking(false);
    if (addError) {
      setError(addError.message || 'Gagal tambah stock bola.');
      return;
    }

    const result = (data || {}) as { ok?: boolean; message?: string };
    if (!result.ok) {
      setError(result.message || 'Gagal tambah stock bola.');
      return;
    }

    setStockInQty('');
    setMessage(`Stock bola ditambah: +${num(qty)} balls.`);
    await loadAll();
  }

  return (
    <main className="stockShell">
      <header className="hero">
        <div>
          <span>EDGE RANGE OS</span>
          <h1>Stock Lite</h1>
          <p>Ball inventory, F&amp;B stock control and low-stock monitoring.</p>
        </div>
        <strong>{ballLow || lowItemCount > 0 ? 'Action Needed' : 'Stock OK'}</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/counter">Counter</a>
        <a href="/menu">Menu</a>
        <a href="/pos">POS</a>
        <button type="button" onClick={loadAll}>Refresh</button>
      </nav>

      {loading ? <div className="notice">Loading stock...</div> : null}
      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}

      <section className="metrics">
        <Metric label="Ball Stock" value={num(ball.currentBallStock)} sub="Current balance" />
        <Metric label="Buckets Today" value={num(ball.bucketSoldToday)} sub="Paid bucket sales" />
        <Metric label="Expected Out" value={num(ball.expectedBallOutToday)} sub="1 bucket = 100 balls" />
        <Metric label="Low Stock" value={num(lowItemCount + (ballLow ? 1 : 0))} sub="Alert count" />
      </section>

      <section className="grid">
        <article className={`panel ${ballLow ? 'warning' : ''}`}>
          <div className="panelTitle"><div><span>Ball Inventory Control</span><h2>Driving Range Ball Stock</h2></div><b>{ballLow ? 'LOW STOCK' : 'STOCK OK'}</b></div>
          <div className="miniGrid">
            <Mini label="Minimum Stock" value={num(ball.lowStockQty)} />
            <Mini label="Stock In Today" value={num(ball.stockInToday)} />
            <Mini label="Manual Out" value={num(ball.manualOutToday)} />
            <Mini label="Per Bucket" value={num(ball.ballsPerBucket || 100)} />
          </div>
          <div className="controlGrid">
            <div className="controlBox"><h3>Add Ball Stock</h3><p>Use this when balls are collected or reloaded into inventory.</p><input type="number" min="0" value={stockInQty} onChange={(e) => setStockInQty(e.target.value)} placeholder="Example: 2000" /><button disabled={working} onClick={addBallStockIn}>Add Ball Stock</button></div>
            <div className="controlBox"><h3>Owner Setting</h3><p>Set opening/current balance and alert minimum.</p><input type="number" min="0" value={currentBallStock} onChange={(e) => setCurrentBallStock(e.target.value)} placeholder="Current ball stock" /><input type="number" min="0" value={lowStockQty} onChange={(e) => setLowStockQty(e.target.value)} placeholder="Low stock alert" /><button disabled={working} onClick={saveBallSettings}>Save Ball Settings</button></div>
          </div>
        </article>

        <aside className="panel sidePanel">
          <div className="panelTitle"><div><span>Product Stock</span><h2>F&amp;B / Product</h2></div></div>
          <Row label="Total Products" value={num(items.length)} />
          <Row label="Stock Tracked" value={num(trackedCount)} />
          <Row label="Low Stock" value={num(lowItemCount)} />
          <p>Use product stock for water, canned drinks, food, snacks, rental and operational range items.</p>
        </aside>
      </section>

      <section className="stockList">
        {items.map((item) => <article className={`stockCard ${item.low_stock ? 'low' : ''}`} key={item.id}><div><span>{categoryLabel(item.category)}</span><h2>{item.name}</h2><p>{money(item.price)}</p></div><Mini label="Stock" value={item.stock_tracked ? num(item.stock_qty) : 'Not tracked'} /><Mini label="Low Alert" value={item.stock_tracked ? num(item.low_stock_qty) : '-'} /><Mini label="Status" value={item.low_stock ? 'LOW' : item.available ? 'OK' : 'OFF'} /></article>)}
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub: string }) { return <article className="metric"><span>{label}</span><b>{value}</b><small>{sub}</small></article>; }
function Mini({ label, value }: { label: string; value: string }) { return <div className="mini"><span>{label}</span><b>{value}</b></div>; }
function Row({ label, value }: { label: string; value: string }) { return <div className="row"><span>{label}</span><b>{value}</b></div>; }

const styles = `
.stockShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:12px}.hero{max-width:1240px;margin:0 auto 10px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:22px;padding:18px;display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.hero span{color:var(--accent);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:36px;line-height:1;margin:7px 0;letter-spacing:-.04em}.hero p{margin:0;color:#d6f3df;font-weight:900;line-height:1.35}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:9px 12px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.nav a,.nav button,.controlBox button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px;text-decoration:none;font-weight:1000;text-align:center}.nav button,.controlBox button{background:var(--green);color:#fff}.nav button{grid-column:1/-1}.notice{max-width:1240px;margin:0 auto 10px;border-radius:15px;padding:11px 13px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.metrics{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.metric,.panel,.stockCard{background:var(--panel);border:1px solid var(--line);border-radius:20px;padding:16px;box-shadow:0 10px 24px rgba(7,28,22,.05)}.metric span,.panelTitle span,.mini span,.row span,.stockCard>div>span{display:block;color:var(--muted);font-size:10px;font-weight:1000;text-transform:uppercase;letter-spacing:.12em}.metric b{display:block;font-size:30px;margin:8px 0 4px}.metric small,.controlBox p,.sidePanel p,.stockCard p{color:var(--muted);font-weight:900}.grid{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:10px;align-items:start}.panelTitle{display:flex;justify-content:space-between;gap:10px;align-items:flex-start;margin-bottom:12px}.panelTitle h2{font-size:22px;margin:5px 0 0}.panelTitle>b{border-radius:999px;background:#dcfce7;color:#166534;padding:9px 11px;font-size:11px}.warning .panelTitle>b{background:#fef3c7;color:#92400e}.miniGrid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;margin-bottom:10px}.mini{border:1px solid var(--line);background:#fbfdf9;border-radius:15px;padding:11px;text-align:center}.mini b{display:block;font-size:18px;margin-top:5px}.controlGrid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.controlBox{border:1px solid var(--line);background:#fbfdf9;border-radius:18px;padding:13px}.controlBox h3{margin:0 0 6px}.controlBox input{width:100%;border:1px solid var(--line);background:#fff;border-radius:13px;padding:11px;margin:7px 0;font-weight:900}.row{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line);padding:11px 0}.row b{text-align:right}.stockList{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}.stockCard.low{border-color:#f59e0b;background:#fffbeb}.stockCard h2{font-size:18px;margin:6px 0}@media(max-width:900px){.hero{display:block}.hero strong{display:inline-block;margin-top:12px}.metrics,.grid{grid-template-columns:1fr}.miniGrid,.controlGrid{grid-template-columns:1fr}.nav{grid-template-columns:repeat(2,1fr)}}@media(max-width:560px){.stockShell{padding:8px 10px}.hero{padding:16px}.hero h1{font-size:31px}.metric b{font-size:28px}}
`;