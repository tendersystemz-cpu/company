'use client';

import { MODULE_ROUTES, roleChip, type NavRoute } from '@/lib/navigation';

const metrics = [
  { icon: '⚑', label: 'Bays', value: 'Live', note: 'Status', href: '/counter', tone: 'staff' },
  { icon: '▤', label: 'Orders', value: 'Queue', note: 'Counter', href: '/counter', tone: 'staff' },
  { icon: '💳', label: 'Payment', value: 'Verify', note: 'QR', href: '/payments', tone: 'staff' },
  { icon: '📦', label: 'Stock', value: 'Watch', note: 'Lite', href: '/stock', tone: 'staff' },
  { icon: '🛡️', label: 'Access', value: 'PIN', note: 'Lock', href: '/access', tone: 'owner' },
];

const roleActions = [
  { icon: '🛎️', label: 'Staff Ops', note: 'Counter', href: '/counter', tone: 'staff' },
  { icon: '👑', label: 'Owner', note: 'Control', href: '/owner', tone: 'owner' },
  { icon: '🔒', label: 'Access', note: 'PIN', href: '/access', tone: 'protected' },
  { icon: '💳', label: 'Payments', note: 'Verify', href: '/payments', tone: 'payment' },
];

function sectionLabel(route: NavRoute) {
  if (route.section === 'customer') return 'Customer';
  if (route.section === 'staff') return 'Staff';
  if (route.section === 'owner') return 'Owner';
  if (route.section === 'superadmin') return 'Future';
  return 'Open';
}

function toneFor(route: NavRoute) {
  if (route.section === 'customer') return 'customer';
  if (route.section === 'owner') return 'owner';
  if (route.section === 'staff') return 'staff';
  return 'main';
}

export default function OperationsHome() {
  const primaryModules = MODULE_ROUTES.filter((route) => route.status === 'production');

  return (
    <main className="opsHome">
      <section className="statusStrip" aria-label="EDGE RANGE OS status">
        <div className="brandStatus">
          <div className="brandIcon">⚑</div>
          <div>
            <span>Operations Console</span>
            <h1>EDGE RANGE OS</h1>
            <p>Icon-first command center for customer, staff and owner operations.</p>
          </div>
        </div>
        <nav className="roleActions" aria-label="Quick operational actions">
          {roleActions.map((action) => (
            <a key={action.label} href={action.href} className={`roleAction ${action.tone}`}>
              <i>{action.icon}</i>
              <b>{action.label}</b>
              <small>{action.note}</small>
            </a>
          ))}
        </nav>
      </section>

      <section className="metricGrid" aria-label="Operational snapshot">
        {metrics.map((metric) => (
          <a key={metric.label} href={metric.href} className={`metricCard ${metric.tone}`}>
            <i>{metric.icon}</i>
            <span>{metric.label}</span>
            <b>{metric.value}</b>
            <small>{metric.note}</small>
          </a>
        ))}
      </section>

      <section className="moduleHeader">
        <div>
          <span>Module Access</span>
          <h2>Choose operation</h2>
        </div>
        <p>Protected items request Staff or Owner PIN.</p>
      </section>

      <section className="moduleGrid" aria-label="EDGE RANGE OS modules">
        {primaryModules.map((route) => (
          <a key={`${route.section}-${route.label}`} href={route.href} className={`moduleCard ${toneFor(route)}`}>
            <div className="iconBubble">{route.icon}</div>
            <div className="moduleCopy">
              <small>{route.description || sectionLabel(route)}</small>
              <h3>{route.label}</h3>
            </div>
            <div className="cardFoot">
              <span className={`chip ${route.section}`}>{roleChip(route)}</span>
              <em>›</em>
            </div>
          </a>
        ))}
      </section>

      <section className="principleBar" aria-label="Implementation principles">
        <article><b>One menu source</b><span>Routes come from operations/lib/navigation.ts</span></article>
        <article><b>Functional buttons</b><span>Every chip/card opens the related module, not decoration only.</span></article>
        <article><b>Access guard</b><span>Staff and Owner routes stay protected by PIN/RPC.</span></article>
      </section>

      <style jsx>{styles}</style>
    </main>
  );
}

const styles = `
.opsHome{--bg:#f7faf6;--panel:#fff;--ink:#102019;--muted:#657568;--line:#dbe7d8;--green:#063f22;--green2:#17b26a;--lime:#9be84f;--blue:#1d55a6;--blueBg:#eef5ff;--gold:#9a6b14;--goldBg:#fff8e6;--red:#9f1239;--redBg:#fff0f3;--pay:#5b21b6;--payBg:#f4f0ff;min-height:100vh;background:radial-gradient(circle at top left,rgba(155,232,79,.16),transparent 28%),var(--bg);color:var(--ink);font-family:Inter,Arial,sans-serif;padding:12px 14px 28px}.statusStrip,.metricGrid,.moduleHeader,.moduleGrid,.principleBar{max-width:1240px;margin-left:auto;margin-right:auto}.statusStrip{display:flex;align-items:center;justify-content:space-between;gap:12px;border:1px solid var(--line);border-radius:20px;background:rgba(255,255,255,.96);box-shadow:0 10px 24px rgba(7,28,22,.07);padding:12px}.brandStatus{display:flex;align-items:center;gap:11px;min-width:0}.brandIcon{width:46px;height:46px;flex:0 0 46px;border-radius:16px;background:linear-gradient(135deg,var(--green),#0a6938);display:grid;place-items:center;color:white;font-size:22px;box-shadow:0 10px 20px rgba(6,63,34,.18)}.brandStatus span,.moduleHeader span{display:inline-flex;border-radius:999px;background:#ecfdf5;border:1px solid #bbf7d0;color:#0f773a;text-transform:uppercase;font-size:9px;font-weight:1000;letter-spacing:.1em;padding:4px 8px}.brandStatus h1{margin:6px 0 3px;font-size:21px;letter-spacing:.08em;line-height:1}.brandStatus p,.moduleHeader p{margin:0;color:var(--muted);font-size:12px;font-weight:850;line-height:1.25}.roleActions{display:grid;grid-template-columns:repeat(4,minmax(78px,1fr));gap:7px;min-width:min(520px,52vw)}.roleAction{display:grid;grid-template-columns:26px minmax(0,1fr);grid-template-areas:'icon label' 'icon note';align-items:center;column-gap:7px;border:1px solid var(--line);border-radius:15px;background:#f4fbf1;color:var(--green);text-decoration:none;padding:8px 9px;box-shadow:0 6px 14px rgba(7,28,22,.04)}.roleAction i{grid-area:icon;display:grid;place-items:center;width:26px;height:26px;border-radius:10px;background:white;font-style:normal;font-size:14px}.roleAction b{grid-area:label;font-size:12px;font-weight:1000;line-height:1;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.roleAction small{grid-area:note;color:inherit;opacity:.72;font-size:9px;font-weight:900;line-height:1;margin-top:2px}.roleAction.staff{background:var(--blueBg);color:var(--blue);border-color:#c9dbff}.roleAction.owner{background:var(--goldBg);color:var(--gold);border-color:#f5dea6}.roleAction.protected{background:var(--redBg);color:var(--red);border-color:#ffcbd7}.roleAction.payment{background:var(--payBg);color:var(--pay);border-color:#ded2ff}.metricGrid{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:9px;margin-top:10px}.metricCard{display:grid;grid-template-columns:34px minmax(0,1fr);grid-template-areas:'icon label' 'icon value' 'icon note';align-items:center;column-gap:9px;min-height:64px;border:1px solid var(--line);border-radius:16px;background:white;color:var(--ink);text-decoration:none;box-shadow:0 8px 18px rgba(7,28,22,.055);padding:10px}.metricCard.staff{border-color:#c9dbff}.metricCard.owner{border-color:#f5dea6}.metricCard i{grid-area:icon;width:34px;height:34px;border-radius:12px;background:#eef8ed;color:var(--green);display:grid;place-items:center;font-size:17px;font-style:normal}.metricCard.staff i{background:var(--blueBg);color:var(--blue)}.metricCard.owner i{background:var(--goldBg);color:var(--gold)}.metricCard span{grid-area:label;color:var(--muted);font-size:10px;font-weight:900;line-height:1}.metricCard b{grid-area:value;color:var(--ink);font-size:16px;font-weight:1000;line-height:1.05}.metricCard small{grid-area:note;color:var(--muted);font-size:10px;font-weight:850;line-height:1}.moduleHeader{display:flex;align-items:flex-end;justify-content:space-between;gap:14px;margin-top:14px}.moduleHeader h2{margin:6px 0 0;font-size:22px;letter-spacing:-.04em}.moduleGrid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-top:10px}.moduleCard{display:flex;flex-direction:column;gap:12px;min-height:178px;border:1px solid var(--line);border-radius:22px;background:white;color:var(--ink);text-decoration:none;box-shadow:0 12px 30px rgba(7,28,22,.07);padding:16px;transition:transform .15s ease,box-shadow .15s ease,border-color .15s ease}.moduleCard:hover{transform:translateY(-2px);border-color:rgba(15,119,58,.35);box-shadow:0 18px 40px rgba(7,28,22,.11)}.moduleCard.customer{border-color:#ccefc5}.moduleCard.staff{border-color:#c9dbff}.moduleCard.owner{border-color:#f5dea6}.iconBubble{width:62px;height:62px;flex:0 0 62px;border-radius:22px;background:#eef8ed;color:var(--green);display:grid;place-items:center;font-size:30px}.moduleCard.customer .iconBubble{background:#ecfdf5;color:var(--green)}.moduleCard.staff .iconBubble{background:var(--blueBg);color:var(--blue)}.moduleCard.owner .iconBubble{background:var(--goldBg);color:var(--gold)}.moduleCopy{display:grid;gap:3px}.moduleCopy small{order:1;color:var(--muted);font-size:12px;font-weight:850;line-height:1.25}.moduleCard h3{order:2;margin:0;color:var(--ink);font-size:21px;line-height:1.05;letter-spacing:-.03em}.cardFoot{margin-top:auto;display:flex;align-items:center;justify-content:space-between;gap:10px}.chip{border-radius:999px;font-size:11px;font-weight:1000;padding:7px 9px}.chip.customer,.chip.main{background:#ecfdf5;color:#0f773a}.chip.staff{background:var(--blueBg);color:var(--blue)}.chip.owner{background:var(--goldBg);color:var(--gold);border:1px solid #f5dea6}.cardFoot em{width:30px;height:30px;flex:0 0 30px;border-radius:50%;display:grid;place-items:center;background:#f6faf3;border:1px solid var(--line);color:var(--ink);font-size:22px;font-style:normal;line-height:1}.principleBar{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin-top:14px}.principleBar article{border:1px solid var(--line);border-radius:18px;background:white;padding:14px;box-shadow:0 10px 24px rgba(7,28,22,.05)}.principleBar b{display:block;color:var(--green);font-size:14px}.principleBar span{display:block;margin-top:5px;color:var(--muted);font-size:12px;font-weight:850;line-height:1.35}@media(max-width:980px){.statusStrip,.moduleHeader{display:block}.roleActions{grid-template-columns:repeat(4,minmax(0,1fr));min-width:0;margin-top:10px}.metricGrid{grid-template-columns:repeat(3,minmax(0,1fr))}.moduleGrid{grid-template-columns:repeat(2,minmax(0,1fr))}.principleBar{grid-template-columns:1fr}}@media(max-width:540px){.opsHome{padding:9px 9px 24px}.statusStrip{padding:10px;border-radius:18px}.brandStatus{align-items:flex-start}.brandIcon{width:38px;height:38px;flex-basis:38px;border-radius:14px;font-size:18px}.brandStatus span{font-size:8px;padding:3px 7px}.brandStatus h1{font-size:17px;margin-top:5px}.brandStatus p{font-size:11px;line-height:1.22}.roleActions{grid-template-columns:repeat(4,minmax(0,1fr));gap:5px}.roleAction{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:3px;text-align:center;min-height:58px;padding:6px 4px;border-radius:14px}.roleAction i{width:24px;height:24px;font-size:13px}.roleAction b{font-size:9px;max-width:100%}.roleAction small{font-size:8px;margin-top:0}.metricGrid{grid-template-columns:repeat(3,minmax(0,1fr));gap:7px}.metricCard{display:flex;flex-direction:column;align-items:center;justify-content:center;text-align:center;gap:4px;min-height:78px;padding:8px;border-radius:15px}.metricCard i{width:30px;height:30px;font-size:15px}.metricCard span{font-size:9px}.metricCard b{font-size:13px}.metricCard small{font-size:9px}.moduleGrid{grid-template-columns:repeat(2,minmax(0,1fr));gap:8px}.moduleCard{min-height:0;gap:8px;border-radius:18px;padding:10px}.iconBubble{width:42px;height:42px;flex-basis:42px;border-radius:15px;font-size:21px}.moduleCopy small{font-size:10px}.moduleCard h3{font-size:15px}.chip{font-size:9px;padding:5px 7px}.cardFoot em{width:24px;height:24px;flex-basis:24px;font-size:17px}.moduleHeader h2{font-size:20px}}
`;
