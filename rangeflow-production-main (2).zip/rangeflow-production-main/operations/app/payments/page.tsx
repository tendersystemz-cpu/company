'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type PaymentSettings = {
  duitnow_qr_url?: string;
  tng_qr_url?: string;
  bank_name?: string;
  bank_account_name?: string;
  bank_account_no?: string;
  payment_note?: string;
  support_whatsapp?: string;
};

type SettingsResponse = { payment_settings?: PaymentSettings };

const emptySettings: PaymentSettings = {
  duitnow_qr_url: '',
  tng_qr_url: '',
  bank_name: '',
  bank_account_name: '',
  bank_account_no: '',
  payment_note: 'Bayar jumlah tepat menggunakan TNG/DuitNow QR. Tunjukkan skrin bayaran berjaya kepada staff untuk verification. Simpan bukti bayaran jika diminta oleh staff.',
  support_whatsapp: '',
};

function isImageReady(value?: string) {
  const input = (value || '').trim();
  return Boolean(input && (input.startsWith('data:image') || input.startsWith('http://') || input.startsWith('https://')));
}

async function fileToDataUrl(file: File): Promise<string> {
  const imageUrl = URL.createObjectURL(file);
  try {
    const img = await new Promise<HTMLImageElement>((resolve, reject) => {
      const image = new Image();
      image.onload = () => resolve(image);
      image.onerror = reject;
      image.src = imageUrl;
    });
    const maxSide = 1100;
    const scale = Math.min(1, maxSide / Math.max(img.width, img.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    const ctx = canvas.getContext('2d');
    if (!ctx) throw new Error('Canvas not supported');
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.82);
  } finally {
    URL.revokeObjectURL(imageUrl);
  }
}

export default function PaymentSetupPage() {
  const [form, setForm] = useState<PaymentSettings>(emptySettings);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  async function loadSettings() {
    setLoading(true);
    setError(null);
    const { data, error: loadError } = await supabase.rpc('get_payment_settings', { p_org_slug: ORG_SLUG });
    setLoading(false);
    if (loadError) {
      setError(loadError.message || 'Gagal load payment settings.');
      return;
    }
    const result = data as SettingsResponse;
    setForm({ ...emptySettings, ...(result?.payment_settings || {}) });
  }

  async function saveSettings() {
    setSaving(true);
    setMessage(null);
    setError(null);
    const { error: saveError } = await supabase.rpc('save_payment_settings', {
      p_org_slug: ORG_SLUG,
      p_duitnow_qr_url: form.duitnow_qr_url || '',
      p_tng_qr_url: form.tng_qr_url || '',
      p_bank_name: form.bank_name || '',
      p_bank_account_name: form.bank_account_name || '',
      p_bank_account_no: form.bank_account_no || '',
      p_payment_note: form.payment_note || '',
      p_support_whatsapp: form.support_whatsapp || '',
    });
    setSaving(false);
    if (saveError) {
      setError(saveError.message || 'Gagal save payment settings.');
      return;
    }
    setMessage('Payment QR settings saved.');
    await loadSettings();
  }

  async function handleQrUpload(field: 'duitnow_qr_url' | 'tng_qr_url', file?: File | null) {
    if (!file) return;
    setError(null);
    try {
      const dataUrl = await fileToDataUrl(file);
      setForm((current) => ({ ...current, [field]: dataUrl }));
      setMessage('QR image loaded. Click Save Settings to apply.');
    } catch {
      setError('Gagal baca gambar QR. Sila guna JPG/PNG yang jelas.');
    }
  }

  useEffect(() => { loadSettings(); }, []);

  return (
    <main className="paymentShell">
      <header className="hero">
        <div>
          <span>EDGE RANGE OS</span>
          <h1>Payment QR Setup</h1>
          <p>Manage merchant QR, customer payment note and manual verification settings.</p>
        </div>
        <strong>Owner Control</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/menu">Menu</a>
        <a href="/counter">Counter</a>
        <button type="button" disabled={saving} onClick={saveSettings}>{saving ? 'Saving...' : 'Save Settings'}</button>
      </nav>

      {loading ? <div className="notice">Loading payment settings...</div> : null}
      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}

      <section className="scopeGrid">
        <Metric label="Customer" value="Pay QR" />
        <Metric label="Staff" value="Verify" />
        <Metric label="Proof" value="Optional" />
      </section>

      <section className="contentGrid">
        <article className="panel formPanel">
          <div className="panelTitle"><div><span>Merchant QR Details</span><h2>Payment Setup</h2></div></div>
          <div className="formGrid">
            <label><small>Upload DuitNow QR</small><input type="file" accept="image/*" onChange={(e)=>handleQrUpload('duitnow_qr_url', e.target.files?.[0])} /></label>
            <label><small>Upload TNG QR</small><input type="file" accept="image/*" onChange={(e)=>handleQrUpload('tng_qr_url', e.target.files?.[0])} /></label>
            <label><small>DuitNow QR URL / Data</small><input value={(form.duitnow_qr_url || '').startsWith('data:image') ? 'Uploaded image loaded' : form.duitnow_qr_url || ''} onChange={(e)=>setForm({...form, duitnow_qr_url:e.target.value})} placeholder="Upload image or paste URL" /></label>
            <label><small>TNG QR URL / Data</small><input value={(form.tng_qr_url || '').startsWith('data:image') ? 'Uploaded image loaded' : form.tng_qr_url || ''} onChange={(e)=>setForm({...form, tng_qr_url:e.target.value})} placeholder="Upload image or paste URL" /></label>
            <label><small>Bank Name</small><input value={form.bank_name || ''} onChange={(e)=>setForm({...form, bank_name:e.target.value})} placeholder="Bank name" /></label>
            <label><small>Merchant Name</small><input value={form.bank_account_name || ''} onChange={(e)=>setForm({...form, bank_account_name:e.target.value})} placeholder="Operator / Merchant Name" /></label>
            <label><small>Bank Account No</small><input value={form.bank_account_no || ''} onChange={(e)=>setForm({...form, bank_account_no:e.target.value})} placeholder="Account number" /></label>
            <label><small>Support WhatsApp</small><input value={form.support_whatsapp || ''} onChange={(e)=>setForm({...form, support_whatsapp:e.target.value})} placeholder="Optional" /></label>
            <label className="wide"><small>Customer Payment Note</small><textarea rows={4} value={form.payment_note || ''} onChange={(e)=>setForm({...form, payment_note:e.target.value})} /></label>
          </div>
        </article>

        <aside className="panel previewPanel">
          <div className="panelTitle"><div><span>Preview</span><h2>Customer Display</h2></div></div>
          <Row label="DuitNow QR" value={isImageReady(form.duitnow_qr_url) ? 'Ready' : 'Not set'} />
          <Row label="TNG QR" value={isImageReady(form.tng_qr_url) ? 'Ready' : 'Not set'} />
          <Row label="Merchant" value={form.bank_account_name || '-'} />
          <p>Keep instruction short: pay exact amount, show success screen, and keep payment proof only if requested by staff.</p>
          <QrPreview label="DuitNow QR preview" value={form.duitnow_qr_url} />
          <QrPreview label="TNG QR preview" value={form.tng_qr_url} />
        </aside>
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value }: { label: string; value: string }) { return <article className="metric"><span>{label}</span><b>{value}</b></article>; }
function Row({ label, value }: { label: string; value: string }) { return <div className="row"><span>{label}</span><b>{value}</b></div>; }
function QrPreview({ label, value }: { label: string; value?: string }) {
  const src = (value || '').trim();
  if (!isImageReady(src)) return <div className="qrPreview"><span>{label}: not set</span></div>;
  return <div className="qrPreview"><img src={src} alt={label} /></div>;
}

const styles = `
.paymentShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hero{max-width:1240px;margin:0 auto 12px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:28px;padding:24px;display:flex;justify-content:space-between;gap:20px;align-items:flex-start;box-shadow:0 20px 60px rgba(7,28,22,.14)}.hero span{color:var(--accent);font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:42px;line-height:1;margin:8px 0 8px;letter-spacing:-.04em}.hero p{margin:0;color:#cdebd8;font-weight:900}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:12px 16px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px;flex-wrap:wrap}.nav a,.nav button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.nav button{background:var(--green);color:#fff}.notice{max-width:1240px;margin:0 auto 12px;border-radius:16px;padding:12px 14px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.scopeGrid{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.metric,.panel{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06)}.metric span,.panelTitle span,.row span,label small{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.metric b{display:block;font-size:30px;margin-top:10px}.contentGrid{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:minmax(0,1fr) 390px;gap:12px;align-items:start}.panelTitle{display:flex;justify-content:space-between;gap:10px;margin-bottom:14px}.panelTitle h2{font-size:22px;margin:6px 0 0}.formGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.formGrid label{display:block}.formGrid input,.formGrid textarea{width:100%;box-sizing:border-box;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:12px 13px;font-weight:850;margin-top:6px}.formGrid textarea{resize:vertical;min-height:96px}.wide{grid-column:1/-1}.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:12px 0}.row b{text-align:right}.previewPanel p{color:var(--muted);font-weight:900;line-height:1.45}.qrPreview{margin-top:12px;padding:12px;border-radius:18px;background:#fbfdf9;border:1px solid var(--line);min-height:100px;display:grid;place-items:center;text-align:center}.qrPreview img{width:100%;max-height:220px;object-fit:contain;border-radius:12px}.qrPreview span{color:var(--muted);font-weight:1000}@media(max-width:980px){.contentGrid{grid-template-columns:1fr}.scopeGrid{grid-template-columns:1fr}.hero{display:block}.hero strong{display:inline-block;margin-top:16px}.formGrid{grid-template-columns:1fr}.nav a,.nav button{flex:1 1 130px;text-align:center}}@media(max-width:560px){.paymentShell{padding:10px}.hero{border-radius:22px;padding:18px}.hero h1{font-size:32px}.metric b{font-size:25px}}
`;