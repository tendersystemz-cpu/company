'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

const CUSTOMER_BASE_URL = process.env.NEXT_PUBLIC_CUSTOMER_BASE_URL || 'http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io';

type Validation = {
  checked_at?: string;
  overall_status?: 'PASS' | 'FAIL' | string;
  core_tables?: Record<string, boolean>;
  core_counts?: Record<string, number>;
  required_functions?: Record<string, boolean>;
  customer_bay_01?: { location_name?: string; menu_count?: number };
  payment_settings?: Record<string, string>;
  delivery_performance?: { total_out_for_delivery?: number; total_delivered?: number; total_scan_mismatch?: number; avg_response_seconds?: number };
};

type RouteCheck = { route: string; label: string; status: 'checking' | 'ok' | 'manual' | 'fail'; note: string };

function BoolBadge({ value }: { value: boolean }) {
  return <span className={value ? 'ok' : 'bad'}>{value ? 'OK' : 'CHECK'}</span>;
}

export default function HealthPage() {
  const [validation, setValidation] = useState<Validation | null>(null);
  const [routes, setRoutes] = useState<RouteCheck[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkingRoutes, setCheckingRoutes] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const expectedRoutes = useMemo(() => [
    { label: 'Pilot Panel', route: '/pilot' },
    { label: 'Counter Flow', route: '/counter' },
    { label: 'QR Checkpoint', route: '/checkpoint' },
    { label: 'QR Bay Management', route: '/qr' },
    { label: 'Customer Bay 01', route: `${CUSTOMER_BASE_URL}/b/01` },
    { label: 'Customer Order 01', route: `${CUSTOMER_BASE_URL}/b/01/order` },
  ], []);

  async function runValidation() {
    setLoading(true);
    setError(null);
    const { data, error: rpcError } = await supabase.rpc('rangeflow_single_validation', { p_org_slug: ORG_SLUG });
    setLoading(false);
    if (rpcError) {
      setError(rpcError.message || 'Pilot readiness check failed.');
      return;
    }
    setValidation(data as Validation);
  }

  async function checkRoutes() {
    setCheckingRoutes(true);
    const checks: RouteCheck[] = [];
    for (const item of expectedRoutes) {
      try {
        const response = await fetch(item.route, { method: 'GET', cache: 'no-store' });
        checks.push({ ...item, status: response.ok ? 'ok' : 'fail', note: response.ok ? 'Ready' : `HTTP ${response.status}` });
      } catch (err) {
        checks.push({ ...item, status: 'fail', note: err instanceof Error ? err.message : 'Route check failed' });
      }
    }
    setRoutes(checks);
    setCheckingRoutes(false);
  }

  useEffect(() => { runValidation(); checkRoutes(); }, []);

  const pass = validation?.overall_status === 'PASS';
  const tables = validation?.core_tables || {};
  const functions = validation?.required_functions || {};
  const counts = validation?.core_counts || {};
  const payment = validation?.payment_settings || {};
  const delivery = validation?.delivery_performance || {};

  return (
    <main className="shell healthPage">
      <div className="top healthTop">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Pilot Readiness Check</h1>
          <p className="muted">Check whether the standard package is ready for trial: customer order, menu, payment, counter flow and QR checkpoint.</p>
        </div>
        <div className="healthActions">
          <a className="btn secondary" href="/pilot">Pilot Panel</a>
          <a className="btn secondary" href="/counter">Counter Flow</a>
          <a className="btn secondary" href="/owner">Owner</a>
          <button className="btn" onClick={() => { runValidation(); checkRoutes(); }}>Run Check</button>
        </div>
      </div>

      {loading ? <div className="card">Running pilot readiness check...</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      <section className="card healthHero">
        <div>
          <div className="pill">Overall Pilot Status</div>
          <h2>{pass ? 'READY' : validation ? 'CHECK REQUIRED' : 'WAITING'}</h2>
          <p className="muted">Last checked: {validation?.checked_at || '-'}</p>
        </div>
        <div className={pass ? 'bigPass' : 'bigFail'}>{pass ? '✓' : '!'}</div>
      </section>

      <section className="grid healthGrid">
        <div className="card healthCard">
          <h2>System Foundation</h2>
          {Object.entries(tables).map(([key, value]) => <div className="row" key={key}><span>{key}</span><BoolBadge value={Boolean(value)} /></div>)}
        </div>

        <div className="card healthCard">
          <h2>Operation Functions</h2>
          {Object.entries(functions).map(([key, value]) => <div className="row" key={key}><span>{key}</span><BoolBadge value={Boolean(value)} /></div>)}
        </div>

        <div className="card healthCard">
          <h2>Trial Data</h2>
          <div className="row"><span>Active Bays</span><strong>{counts.active_bays ?? '-'}</strong></div>
          <div className="row"><span>Available Menu</span><strong>{counts.available_menu_items ?? '-'}</strong></div>
          <div className="row"><span>Orders 24h</span><strong>{counts.orders_last_24h ?? '-'}</strong></div>
          <div className="row"><span>Delivery Events 24h</span><strong>{counts.delivery_events_last_24h ?? '-'}</strong></div>
          <div className="row"><span>Bay 01 Menu Count</span><strong>{validation?.customer_bay_01?.menu_count ?? '-'}</strong></div>
        </div>

        <div className="card healthCard">
          <h2>Payment Readiness</h2>
          <div className="row"><span>DuitNow QR</span><strong>{payment.duitnow_qr_url ? 'READY' : 'MISSING'}</strong></div>
          <div className="row"><span>TNG QR</span><strong>{payment.tng_qr_url ? 'READY' : 'MISSING'}</strong></div>
          <div className="row"><span>Bank Name</span><strong>{payment.bank_name || '-'}</strong></div>
          <a className="btn secondary healthBtn" href="/payments">Open Payment Setup</a>
        </div>

        <div className="card healthCard">
          <h2>QR Checkpoint</h2>
          <div className="row"><span>Out for Delivery</span><strong>{delivery.total_out_for_delivery ?? 0}</strong></div>
          <div className="row"><span>Delivered</span><strong>{delivery.total_delivered ?? 0}</strong></div>
          <div className="row"><span>Wrong Bay Scan</span><strong>{delivery.total_scan_mismatch ?? 0}</strong></div>
          <div className="row"><span>Avg Response</span><strong>{delivery.avg_response_seconds ?? 0}s</strong></div>
        </div>

        <div className="card healthCard">
          <h2>Important Pages</h2>
          {checkingRoutes ? <p className="muted">Checking pages...</p> : null}
          {routes.map((item) => (
            <div className="row" key={item.route}>
              <span><a href={item.route} target="_blank">{item.label}</a><br/><small>{item.note}</small></span>
              <strong className={item.status === 'ok' ? 'okText' : item.status === 'manual' ? 'manualText' : 'badText'}>{item.status === 'ok' ? 'READY' : item.status.toUpperCase()}</strong>
            </div>
          ))}
        </div>

        <div className="card healthCard pilotBoundaryCard">
          <h2>Pilot Boundary</h2>
          <div className="row"><span>POS stock module</span><strong className="manualText">ADD-ON LATER</strong></div>
          <div className="row"><span>Payment gateway</span><strong className="manualText">ADD-ON LATER</strong></div>
          <div className="row"><span>Manual payment proof</span><strong className="okText">STANDARD</strong></div>
          <div className="row"><span>QR checkpoint</span><strong className="okText">STANDARD</strong></div>
          <p className="muted hardeningNote">Keep the pilot focused on standard package only until the user journey is stable.</p>
        </div>
      </section>

      <style>{`
        .healthPage{max-width:1180px;margin:0 auto}.healthTop{align-items:flex-start}.healthActions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.healthActions .btn{padding:10px 12px;border-radius:12px;font-size:13px}.healthHero{display:flex;justify-content:space-between;align-items:center;margin-bottom:16px;border-radius:20px}.healthHero h2{font-size:42px;margin:10px 0;color:#86efac;line-height:1}.bigPass,.bigFail{width:78px;height:78px;border-radius:999px;display:grid;place-items:center;font-size:46px;font-weight:900}.bigPass{background:#34d399;color:#022c22}.bigFail{background:#ef4444;color:white}.healthGrid{grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.healthCard{border-radius:20px}.healthCard h2{font-size:21px;color:#fff;margin:0 0 12px}.healthCard .row{padding:8px 0;font-size:14px}.ok{color:#86efac;font-weight:900}.bad{color:#fecaca;font-weight:900}.okText{color:#86efac}.badText{color:#fecaca}.manualText{color:#fde68a}.row small{color:#a7f3d0;font-size:11px}.row a{color:#ecfdf5}.healthBtn{display:block;margin-top:12px;text-align:center}.pilotBoundaryCard{border-color:rgba(251,191,36,.55)}.hardeningNote{font-size:13px;line-height:1.5;margin-top:12px}@media(max-width:900px){.healthGrid{grid-template-columns:1fr}.healthHero{display:block}.bigPass,.bigFail{margin-top:16px}.healthActions{justify-content:flex-start;margin-top:14px}.healthActions .btn{flex:1 1 120px}}
      `}</style>
    </main>
  );
}
