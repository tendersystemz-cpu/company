export default function TrialHandoverPage() {
  return (
    <main className="shell trialPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Trial Handover Checklist</h1>
          <p className="muted">Use this page on pilot day to confirm the range can run customer orders, counter processing and delivery checkpoint.</p>
        </div>
        <div className="trialNav">
          <a className="btn" href="/pilot">Pilot Panel</a>
          <a className="btn secondary" href="/health">Readiness Check</a>
        </div>
      </div>

      <section className="trialGrid">
        <article className="card lane customerLane">
          <div className="pill">Customer Acceptance</div>
          <h2>Customer can order from bay</h2>
          <ul>
            <li>Bay QR opens correct bay page.</li>
            <li>Customer can order ball bucket.</li>
            <li>Customer can add F&B item.</li>
            <li>Total amount is clear.</li>
            <li>Payment proof instruction is clear.</li>
            <li>Order token appears after submit.</li>
          </ul>
          <a className="btn secondary" href="https://rangeflow-bucc.netlify.app/b/01/order">Test Customer Order</a>
        </article>

        <article className="card lane staffLane">
          <div className="pill">Staff Acceptance</div>
          <h2>Staff can process order</h2>
          <ul>
            <li>Counter Flow opens active orders.</li>
            <li>Staff can identify bay and token.</li>
            <li>Payment can be verified.</li>
            <li>Ball slip can be printed.</li>
            <li>Kitchen slip can be printed.</li>
            <li>Delivery slip can be printed.</li>
          </ul>
          <a className="btn secondary" href="/counter">Open Counter Flow</a>
        </article>

        <article className="card lane runnerLane">
          <div className="pill">Runner Acceptance</div>
          <h2>Delivery is confirmed at bay</h2>
          <ul>
            <li>Paid order can start delivery.</li>
            <li>Checkpoint opens for runner.</li>
            <li>Correct bay QR confirms delivery.</li>
            <li>Wrong bay scan is blocked.</li>
            <li>Order becomes delivered/completed.</li>
            <li>Delivery event is recorded.</li>
          </ul>
          <a className="btn secondary" href="/checkpoint">Open QR Checkpoint</a>
        </article>

        <article className="card lane ownerLane">
          <div className="pill">Owner Acceptance</div>
          <h2>Owner can control pilot</h2>
          <ul>
            <li>Payment instruction can be updated.</li>
            <li>Ball bucket and F&B items are available.</li>
            <li>Staff/Admin PIN can be managed.</li>
            <li>Owner dashboard shows trial orders.</li>
            <li>Pilot readiness check is understandable.</li>
            <li>Add-ons are clearly separated.</li>
          </ul>
          <a className="btn secondary" href="/owner">Open Owner Dashboard</a>
        </article>
      </section>

      <section className="card closeBox">
        <div className="pill">Pilot Close Rule</div>
        <p>Standard package is accepted when one complete order can move through: Customer Order → Counter Flow → Print Slip → QR Checkpoint → Owner Dashboard.</p>
        <p><b>Do not include POS stock or payment gateway in this acceptance test.</b></p>
      </section>

      <style>{`
        .trialPage{max-width:1180px;margin:0 auto}.trialNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.trialGrid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px}.lane h2{color:#fff;margin:10px 0}.lane ul{padding-left:20px;color:#d1fae5;line-height:1.55}.lane li{margin:6px 0}.lane a{text-decoration:none;text-align:center;width:100%;margin-top:8px}.customerLane{border-color:rgba(96,165,250,.35)}.staffLane{border-color:rgba(52,211,153,.45)}.runnerLane{border-color:rgba(167,139,250,.45)}.ownerLane{border-color:rgba(251,191,36,.45)}.closeBox{margin-top:16px;border-color:rgba(251,191,36,.55)}.closeBox p{color:#d1fae5;line-height:1.55}@media(max-width:900px){.trialGrid{grid-template-columns:1fr}.trialNav{justify-content:flex-start;margin-top:12px}.trialNav a{flex:1 1 150px;text-align:center}}
      `}</style>
    </main>
  );
}
