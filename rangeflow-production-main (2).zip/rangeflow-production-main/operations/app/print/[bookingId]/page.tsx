'use client';

import { useEffect, useMemo, useState } from 'react';
import { supabase } from '@/lib/supabase';

type PageProps = { params: { bookingId: string }; searchParams?: { type?: string } };
type SlipType = 'ball' | 'kitchen' | 'delivery' | 'full';

type Booking = {
  id: string; qr_token?: string; customer_name?: string | null; customer_phone?: string | null;
  booking_status?: string; payment_status?: string; total_amount?: number | string; created_at?: string;
  bay_code?: string; bay_name?: string; location_name?: string; payment_method?: string | null;
  payment_reference?: string | null; payer_name?: string | null; payment_verification_status?: string | null;
};

type OrderItem = { order_id: string; type: string; item_name: string; quantity: number; unit_price: number | string; subtotal: number | string; status: string };
type SlipData = { booking: Booking | null; items: OrderItem[]; generated_at?: string };

function money(value?: number | string) { return `RM ${Number(value || 0).toFixed(2)}`; }
function shortId(value?: string) { return value ? value.slice(0, 8).toUpperCase() : '-'; }
function dt(value?: string | null) { if (!value) return '-'; try { return new Date(value).toLocaleString('en-MY'); } catch { return value; } }
function isBallItem(item: OrderItem) { const value = `${item.type} ${item.item_name}`.toLowerCase(); return ['ball', 'bola', 'bucket', 'range'].some((keyword) => value.includes(keyword)); }
function cleanType(value?: string): SlipType { return value === 'ball' || value === 'kitchen' || value === 'delivery' || value === 'full' ? value : 'full'; }

export default function PrintOrderSlipPage({ params, searchParams }: PageProps) {
  const slipType = cleanType(searchParams?.type);
  const [data, setData] = useState<SlipData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const booking = data?.booking || null;
  const items = useMemo(() => data?.items || [], [data]);
  const ballItems = useMemo(() => items.filter(isBallItem), [items]);
  const kitchenItems = useMemo(() => items.filter((item) => !isBallItem(item)), [items]);

  useEffect(() => {
    async function loadSlip() {
      setLoading(true); setError(null);
      const { data: slip, error: slipError } = await supabase.rpc('get_operations_print_slip', { p_booking_id: params.bookingId });
      setLoading(false);
      if (slipError) { setError(slipError.message || 'Gagal load print slip.'); return; }
      setData((slip || null) as SlipData);
    }
    loadSlip();
  }, [params.bookingId]);

  useEffect(() => {
    if (booking && !loading && !error) {
      const timer = window.setTimeout(() => window.print(), 500);
      return () => window.clearTimeout(timer);
    }
  }, [booking, loading, error]);

  if (loading) return <main className="printPage"><Nav bookingId={params.bookingId} /><p>Loading print slip...</p><style>{css}</style></main>;
  if (error) return <main className="printPage"><Nav bookingId={params.bookingId} /><p className="err">{error}</p><style>{css}</style></main>;
  if (!booking) return <main className="printPage"><Nav bookingId={params.bookingId} /><p className="err">Booking tidak ditemui.</p><style>{css}</style></main>;

  return (
    <main className="printPage">
      <Nav bookingId={params.bookingId} />
      <section className="receipt">
        <Header booking={booking} slipType={slipType} />
        {slipType === 'full' ? <PaymentBlock booking={booking} /> : null}
        {(slipType === 'ball' || slipType === 'full') ? <><MaybeCut show={slipType === 'full'} /><StationCopy title="BALL STATION COPY" subtitle="Sediakan bucket bola sahaja" empty="Tiada order bola untuk station ini." booking={booking} items={ballItems} /></> : null}
        {(slipType === 'kitchen' || slipType === 'full') ? <><MaybeCut show={slipType === 'full'} /><StationCopy title="KITCHEN / CAFE COPY" subtitle="Sediakan makanan dan minuman sahaja" empty="Tiada order makanan atau minuman." booking={booking} items={kitchenItems} /></> : null}
        {(slipType === 'delivery' || slipType === 'full') ? <><MaybeCut show={slipType === 'full'} /><DeliveryCopy booking={booking} /></> : null}
        <div className="line" />
        <p className="center">Powered by RangeFlow Operations</p>
      </section>
      <style>{css}</style>
    </main>
  );
}

function Nav({ bookingId }: { bookingId: string }) {
  return <div className="noPrint nav"><button onClick={() => window.history.back()}>Back</button><a href="/counter">Counter</a><a href={`/print/${bookingId}?type=ball`}>Ball</a><a href={`/print/${bookingId}?type=kitchen`}>Kitchen</a><a href={`/print/${bookingId}?type=delivery`}>Delivery</a><a href={`/print/${bookingId}?type=full`}>Full</a><button onClick={() => window.print()}>Print</button></div>;
}
function Header({ booking, slipType }: { booking: Booking; slipType: SlipType }) {
  return <><h1>RANGEFLOW {slipType.toUpperCase()} SLIP</h1><p className="center">{booking.location_name || 'Golf Driving Range Operations'}</p><div className="line" /><Row label="Order" value={shortId(booking.id)} /><Row label="Token" value={booking.qr_token || '-'} /><Row label="Bay" value={booking.bay_name || `Bay ${booking.bay_code || '-'}`} /><Row label="Customer" value={booking.customer_name || 'Walk-in customer'} /><Row label="Phone" value={booking.customer_phone || '-'} /><Row label="Time" value={dt(booking.created_at)} /><div className="line" /></>;
}
function PaymentBlock({ booking }: { booking: Booking }) { return <><h2>PAYMENT STATUS</h2><Row label="Status" value={booking.payment_status === 'paid' ? 'Payment Verified' : String(booking.payment_status || '-').replaceAll('_', ' ')} strong /><Row label="Method" value={booking.payment_method || 'Manual QR Proof'} /><Row label="Reference" value={booking.payment_reference || '-'} /><Row label="Total" value={money(booking.total_amount)} strong /></>; }
function MaybeCut({ show }: { show: boolean }) { return show ? <div className="cut" /> : null; }
function StationCopy({ title, subtitle, empty, booking, items }: { title: string; subtitle: string; empty: string; booking: Booking; items: OrderItem[] }) { return <section className="station"><h2>{title}</h2><p className="center stationSub">{subtitle}</p><p className="bigBay">{booking.bay_name || `Bay ${booking.bay_code || '-'}`}</p>{items.length > 0 ? items.map((item) => <div className="prepLine" key={`${title}-${item.order_id}`}><span><b>{item.quantity}x</b> {item.item_name}</span><strong>{item.status}</strong></div>) : <p className="emptyStation">{empty}</p>}<p className="note">Prepare & Deliver</p></section>; }
function DeliveryCopy({ booking }: { booking: Booking }) { return <section><h2>DELIVERY COPY</h2><p className="bigBay">Deliver to {booking.bay_name || `Bay ${booking.bay_code || '-'}`}</p><p className="center">Scan or confirm bay after delivery.</p><p className="center">Payment verified by operations staff.</p></section>; }
function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) { return <div className="row"><span>{label}</span>{strong ? <strong>{value}</strong> : <b>{value}</b>}</div>; }

const css = `.printPage{min-height:100vh;background:#f3f4f6;color:#111827;font-family:Arial,Helvetica,sans-serif;padding:24px}.nav{max-width:760px;margin:0 auto 18px;display:flex;gap:8px;flex-wrap:wrap}.nav a,.nav button{border:0;border-radius:10px;background:#166534;color:#fff;padding:10px 12px;font-weight:800;text-decoration:none;cursor:pointer}.nav button:first-child{background:#0f172a}.receipt{width:80mm;max-width:100%;margin:auto;background:#fff;color:#111;padding:12px;box-shadow:0 10px 40px rgba(0,0,0,.15)}h1{font-size:18px;text-align:center;margin:0 0 4px}h2{font-size:14px;margin:10px 0 6px;text-align:center}.center{text-align:center}.stationSub{font-size:11px;margin:0 0 6px;color:#4b5563}.line{border-top:1px dashed #111;margin:10px 0}.cut{border-top:2px dashed #111;margin:16px 0 12px}.row{display:flex;justify-content:space-between;gap:10px;font-size:12px;margin:5px 0}.row span{color:#374151}.row b,.row strong{text-align:right}.bigBay{font-size:22px;font-weight:900;text-align:center;margin:8px 0}.prepLine{display:flex;justify-content:space-between;gap:8px;font-size:15px;font-weight:800;border-bottom:1px dotted #9ca3af;padding:6px 0}.prepLine strong{font-size:10px;text-transform:uppercase}.emptyStation{text-align:center;color:#6b7280;font-size:12px;font-weight:700}.note{text-align:center;font-weight:900;border:1px solid #111;padding:6px;margin-top:10px}.err{max-width:760px;margin:auto;color:#991b1b;font-weight:900}@media print{.noPrint{display:none!important}.printPage{background:#fff;padding:0}.receipt{width:80mm;box-shadow:none;margin:0;padding:8px}@page{size:80mm auto;margin:3mm}}`;