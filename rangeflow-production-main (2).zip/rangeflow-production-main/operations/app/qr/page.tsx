'use client';

import { useEffect, useMemo, useState } from 'react';
import QRCode from 'qrcode';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type Bay = {
  id: string;
  code: string;
  display_name: string;
  status: string;
  type?: string | null;
  position?: number | null;
  location_name?: string | null;
};

type QRRow = Bay & { url: string; orderUrl: string; qrUrl: string; dataUrl?: string };

const CUSTOMER_BASE_URL = process.env.NEXT_PUBLIC_CUSTOMER_BASE_URL || 'http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io';

function isActive(status?: string | null) {
  return String(status || '').toLowerCase() === 'active';
}

export default function QRPage() {
  const [bays, setBays] = useState<QRRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const activeCount = useMemo(() => bays.filter((bay) => isActive(bay.status)).length, [bays]);
  const inactiveCount = useMemo(() => bays.filter((bay) => !isActive(bay.status)).length, [bays]);

  async function resolveLocationId() {
    const { data: org, error: orgError } = await supabase
      .from('orgs')
      .select('id')
      .eq('slug', ORG_SLUG)
      .limit(1)
      .maybeSingle();

    if (orgError || !org?.id) throw new Error(orgError?.message || 'Organization not found.');

    const { data: location, error: locationError } = await supabase
      .from('locations')
      .select('id,name')
      .eq('org_id', org.id)
      .eq('active', true)
      .order('created_at', { ascending: true })
      .limit(1)
      .maybeSingle();

    if (locationError || !location?.id) throw new Error(locationError?.message || 'Location not found.');
    return location as { id: string; name?: string | null };
  }

  async function loadBays() {
    setLoading(true);
    setError(null);
    try {
      const location = await resolveLocationId();
      const { data, error: loadError } = await supabase
        .from('bays')
        .select('id,code,display_name,status,type,position')
        .eq('location_id', location.id)
        .order('position', { ascending: true })
        .order('code', { ascending: true });

      if (loadError) throw loadError;

      const rows = ((data || []) as Bay[])
        .filter((bay) => Boolean(bay.code))
        .map((bay) => {
          const code = encodeURIComponent(String(bay.code));
          const url = `${CUSTOMER_BASE_URL}/b/${code}`;
          const orderUrl = `${CUSTOMER_BASE_URL}/b/${code}/order`;
          return { ...bay, location_name: location.name || null, url, orderUrl, qrUrl: orderUrl } as QRRow;
        });

      setBays(rows);
      if (rows.length === 0) setMessage('No bay records found for this location. Create bay records before generating QR stickers.');
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to load bay list.');
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => { loadBays(); }, []);

  async function generateQrFor(url: string) {
    return QRCode.toDataURL(url, { width: 420, margin: 2, errorCorrectionLevel: 'M' });
  }

  async function generateAll() {
    setGenerating(true);
    setMessage(null);
    setError(null);
    try {
      const generated: QRRow[] = [];
      for (const bay of bays) generated.push({ ...bay, dataUrl: await generateQrFor(bay.qrUrl) });
      setBays(generated);
      setMessage(`QR generated for ${generated.length} bays. Scan QR opens the customer order page directly.`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to generate QR.');
    } finally {
      setGenerating(false);
    }
  }

  async function copyLink(url: string) {
    try {
      await navigator.clipboard.writeText(url);
      setMessage('Order QR link copied.');
    } catch {
      setError('Copy failed. Open the link and copy manually.');
    }
  }

  return (
    <main className="qrPage">
      <section className="top no-print">
        <div>
          <span className="eyebrow">EDGE RANGE OS</span>
          <h1>QR Bay Management</h1>
          <p>Generate customer bay QR stickers for order, reorder and assistance request.</p>
        </div>
        <div className="qrActions">
          <a className="btn ghost" href="/">Icon Dashboard</a>
          <a className="btn ghost" href="/counter">Counter</a>
          <button className="btn ghost" type="button" onClick={() => window.print()}>Print QR Sheet</button>
          <button className="btn" type="button" disabled={generating || bays.length === 0} onClick={generateAll}>{generating ? 'Generating...' : 'Generate QR'}</button>
        </div>
      </section>

      <section className="summary no-print">
        <article><small>Total Bays</small><b>{bays.length}</b></article>
        <article><small>Active</small><b>{activeCount}</b></article>
        <article><small>Inactive</small><b>{inactiveCount}</b></article>
        <article><small>QR Target</small><b>/b/[bay]/order</b></article>
      </section>

      <section className="notice no-print">
        <b>Customer base URL</b>
        <span>{CUSTOMER_BASE_URL}</span>
        <p>Use a custom domain before printing final customer-facing stickers. Current QR opens the customer order page directly.</p>
      </section>

      {loading ? <div className="state no-print">Loading bays...</div> : null}
      {message ? <div className="state ok no-print">{message}</div> : null}
      {error ? <div className="state bad no-print">{error}</div> : null}

      <section className="bayList no-print">
        {bays.map((bay) => (
          <article className="bayCard" key={`manage-${bay.id || bay.code}`}>
            <div>
              <span className={isActive(bay.status) ? 'pill active' : 'pill'}>{isActive(bay.status) ? 'Active' : bay.status}</span>
              <h2>{bay.display_name}</h2>
              <p>Code {bay.code} · {bay.type || 'standard'} · QR opens order page directly.</p>
            </div>
            <div className="bayActions">
              <a className="btn ghost" href={bay.url} target="_blank" rel="noreferrer">Preview Bay</a>
              <a className="btn ghost" href={bay.orderUrl} target="_blank" rel="noreferrer">Preview Order</a>
              <button className="btn ghost" type="button" onClick={() => copyLink(bay.orderUrl)}>Copy Link</button>
            </div>
          </article>
        ))}
      </section>

      <section className="qrSheet">
        {bays.map((bay) => (
          <article className="qrCard" key={bay.id || bay.code}>
            <div className="qrBrand">EDGE RANGE OS</div>
            <div className="qrBay">{bay.display_name}</div>
            <div className="qrSub">Order · Reorder · Need Help</div>
            <div className="qrBox">
              {bay.dataUrl ? <img src={bay.dataUrl} alt={`QR ${bay.display_name}`} /> : <div className="qrPlaceholder">Generate QR</div>}
            </div>
            <div className="stickerText"><b>SCAN TO ORDER</b><span>Order balls, drinks and food from this bay.</span></div>
            <div className="paymentNote"><b>Payment Instruction</b><span>Use the operator payment QR. Keep payment proof if requested by staff.</span></div>
            <div className="qrUrl">{bay.qrUrl}</div>
            <div className="qrDev">Powered by Expert Digital Golf Ecosystem</div>
          </article>
        ))}
      </section>

      <style>{`
        .qrPage{--bg:#f7faf6;--ink:#102019;--muted:#667568;--line:#dbe7d8;--green:#063f22;--lime:#9be84f;min-height:100vh;background:var(--bg);color:var(--ink);font-family:Inter,Arial,sans-serif;padding:16px}.top,.summary,.notice,.bayList,.qrSheet{max-width:1180px;margin-left:auto;margin-right:auto}.top{display:flex;justify-content:space-between;gap:14px;align-items:flex-start;border:1px solid var(--line);border-radius:22px;background:white;padding:16px;box-shadow:0 12px 28px rgba(7,28,22,.07)}.eyebrow{display:inline-flex;border-radius:999px;background:#ecfdf5;border:1px solid #bbf7d0;color:#0f773a;font-size:10px;font-weight:1000;letter-spacing:.12em;padding:5px 8px}.top h1{font-size:28px;margin:8px 0 4px}.top p,.notice p,.bayCard p{margin:0;color:var(--muted);font-size:13px;font-weight:800;line-height:1.35}.qrActions,.bayActions{display:flex;gap:8px;flex-wrap:wrap;justify-content:flex-end}.btn{border:0;border-radius:14px;background:linear-gradient(135deg,var(--lime),#17b26a);color:#061c14;text-decoration:none;font-size:13px;font-weight:1000;padding:11px 13px;cursor:pointer}.btn.ghost{background:#f4fbf1;color:var(--green);border:1px solid var(--line)}.btn:disabled{opacity:.45;cursor:not-allowed}.summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;margin-top:12px}.summary article,.notice,.state,.bayCard{border:1px solid var(--line);border-radius:18px;background:white;box-shadow:0 8px 20px rgba(7,28,22,.055);padding:13px}.summary small{display:block;color:var(--muted);font-size:11px;font-weight:900}.summary b{display:block;margin-top:4px;color:var(--ink);font-size:18px}.notice{margin-top:12px}.notice b,.notice span{display:block}.notice span{margin:5px 0;color:var(--green);font-size:12px;font-weight:900;word-break:break-all}.state{max-width:1180px;margin:12px auto 0;color:var(--muted);font-weight:900}.state.ok{border-color:#86efac;color:#0f773a}.state.bad{border-color:#fecdd3;color:#9f1239;background:#fff7f8}.bayList{display:grid;gap:10px;margin-top:12px}.bayCard{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center}.bayCard h2{margin:8px 0 5px;font-size:21px}.pill{display:inline-flex;border:1px solid #d5dee0;border-radius:999px;background:#f6f8fa;color:#667568;font-size:11px;font-weight:1000;padding:6px 9px}.pill.active{border-color:#bbf7d0;background:#ecfdf5;color:#0f773a}.qrSheet{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-top:14px}.qrCard{break-inside:avoid;border:1px solid #111827;border-radius:14px;background:white;color:#111827;text-align:center;padding:14px}.qrBrand{font-size:13px;font-weight:1000;letter-spacing:.12em;color:#064e3b}.qrBay{font-size:24px;font-weight:1000;margin-top:8px}.qrSub{font-size:12px;color:#475569;margin:4px 0 10px}.qrBox{height:210px;display:grid;place-items:center;border:1px solid #d1d5db;border-radius:10px;background:#f8fafc}.qrBox img{width:190px;height:190px}.qrPlaceholder{color:#64748b;font-weight:900}.stickerText,.paymentNote{display:grid;gap:3px;margin-top:9px}.stickerText b{font-size:18px;color:#064e3b}.stickerText span,.paymentNote span{font-size:11px;color:#475569}.paymentNote{border-top:1px dashed #cbd5e1;padding-top:8px}.paymentNote b{font-size:12px}.qrUrl{font-size:8px;color:#64748b;margin-top:8px;word-break:break-all}.qrDev{font-size:9px;color:#064e3b;margin-top:8px;font-weight:900}@media(max-width:900px){.top,.bayCard{display:block}.qrActions,.bayActions{justify-content:flex-start;margin-top:12px}.summary{grid-template-columns:repeat(2,minmax(0,1fr))}.qrSheet{grid-template-columns:1fr}}@media print{body{background:white}.no-print,.edgeIconNav{display:none!important}.qrPage{background:white;padding:0}.qrSheet{grid-template-columns:repeat(2,1fr);gap:10mm}.qrCard{box-shadow:none;page-break-inside:avoid}.qrBox{height:55mm}.qrBox img{width:50mm;height:50mm}}
      `}</style>
    </main>
  );
}
