'use client';

const staffSteps = [
  {
    no: '01',
    title: 'Open Counter Flow',
    detail: 'Gunakan page ringkas untuk pilot: order ikut bay/token, payment status, slip dan checkpoint.',
    href: '/counter',
    action: 'Open Counter Flow',
  },
  {
    no: '02',
    title: 'Verify Payment',
    detail: 'Counter verify payment proof atau cash payment. Order unpaid tidak boleh proceed slip/delivery.',
    href: '/counter',
    action: 'Verify Payment',
  },
  {
    no: '03',
    title: 'Print Operation Slips',
    detail: 'Print Ball Slip untuk bola, Kitchen Slip untuk F&B, Delivery Slip untuk runner, Full Slip untuk receipt.',
    href: '/counter',
    action: 'Print Slips',
  },
  {
    no: '04',
    title: 'Prepare Ball / F&B',
    detail: 'Ball station dan kitchen prepare ikut slip. Counter boleh mark preparing bila kerja bermula.',
    href: '/counter',
    action: 'Mark Preparing',
  },
  {
    no: '05',
    title: 'Start Delivery + QR Checkpoint',
    detail: 'Runner buka checkpoint, start delivery dan confirm delivered dengan scan QR bay sebenar.',
    href: '/checkpoint',
    action: 'Open Checkpoint',
  },
];

export default function StaffFlowPage() {
  return (
    <main className="shell staffPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Admin / Staff Flow</h1>
          <p className="muted">Staff flow untuk trial: counter, payment, slip, prepare dan delivery checkpoint.</p>
        </div>
        <div className="staffNav">
          <a className="btn secondary" href="/pilot">Pilot Panel</a>
          <a className="btn" href="/counter">Counter Flow</a>
        </div>
      </div>

      <section className="card staffHero">
        <div className="pill">Staff Rule</div>
        <h2>Paid order sahaja boleh masuk preparing, slip dan delivery checkpoint</h2>
        <p className="muted">Tujuan flow ini ialah elak staff tersilap: verify payment dahulu, baru print slip, prepare, dan runner confirm delivery melalui QR bay.</p>
      </section>

      <section className="staffSteps">
        {staffSteps.map((step) => (
          <article className="card staffStep" key={step.no}>
            <div className="stepNo">{step.no}</div>
            <div>
              <h2>{step.title}</h2>
              <p className="muted">{step.detail}</p>
            </div>
            <a className="btn" href={step.href}>{step.action}</a>
          </article>
        ))}
      </section>

      <section className="card warningBox">
        <div className="pill">Do Not Mix</div>
        <p><b>POS stock</b> dan <b>payment gateway</b> bukan sebahagian staff flow pilot sekarang. Fokus trial: order → verify → slip → deliver → checkpoint.</p>
      </section>

      <style>{`
        .staffPage{max-width:1080px;margin:0 auto}.staffNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.staffHero{margin-bottom:16px}.staffHero h2{color:#fff;margin:10px 0}.staffSteps{display:grid;gap:12px}.staffStep{display:grid;grid-template-columns:70px minmax(0,1fr) 180px;gap:14px;align-items:center}.stepNo{width:54px;height:54px;border-radius:999px;background:#34d399;color:#022c22;display:flex;align-items:center;justify-content:center;font-weight:900}.staffStep h2{color:#fff;margin:0 0 8px}.staffStep a{text-align:center;text-decoration:none}.warningBox{margin-top:16px;border-color:rgba(251,191,36,.45)}.warningBox p{color:#d1fae5;line-height:1.55;margin:10px 0 0}@media(max-width:820px){.staffStep{grid-template-columns:1fr}.staffStep a,.staffNav a{width:100%;text-align:center}.staffNav{justify-content:flex-start;margin-top:12px}}
      `}</style>
    </main>
  );
}
