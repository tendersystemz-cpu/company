'use client';

const customerBayUrl = 'https://rangeflow-bucc.netlify.app/b/01';
const customerOrderUrl = 'https://rangeflow-bucc.netlify.app/b/01/order';

const customerFlow = [
  ['1', 'Scan Bay QR', 'Customer scan QR di bay sebenar.', customerBayUrl, 'Open Bay'],
  ['2', 'Choose Ball / F&B', 'Customer pilih bucket bola, makanan atau minuman.', customerOrderUrl, 'Open Order'],
  ['3', 'Submit Payment Proof', 'Customer upload bukti bayaran untuk counter verify.', customerOrderUrl, 'Test Payment'],
  ['4', 'Wait at Bay', 'Customer tunggu staff prepare dan runner deliver.', customerBayUrl, 'View Bay'],
];

const staffFlow = [
  ['1', 'Staff Flow Guide', 'Staff ikut flow operasi harian yang ringkas dahulu.', '/staff', 'Open Staff Guide'],
  ['2', 'Counter Flow', 'Staff verify payment, print slip, mark preparing dan checkpoint dari satu page.', '/counter', 'Open Counter Flow'],
  ['3', 'QR Checkpoint', 'Runner start delivery dan confirm delivery dengan QR bay.', '/checkpoint', 'Open Checkpoint'],
  ['4', 'Trial Handover', 'Gunakan acceptance checklist untuk pastikan pilot boleh diterima.', '/trial', 'Open Trial Checklist'],
];

const ownerFlow = [
  ['1', 'Payment Setup', 'Owner set merchant QR, bank detail dan instruction.', '/payments', 'Payment'],
  ['2', 'Menu / Product', 'Owner/admin set bucket, food, drink, price dan availability.', '/menu', 'Menu'],
  ['3', 'Access Settings', 'Owner kawal PIN staff/admin dan owner.', '/access', 'Access'],
  ['4', 'Owner Dashboard', 'Owner lihat sales, order, bucket dan bay usage.', '/owner', 'Dashboard'],
];

function FlowLane({ title, subtitle, items, tone }: { title: string; subtitle: string; items: string[][]; tone: string }) {
  return (
    <article className={`card lane ${tone}`}>
      <div className="laneHead">
        <div className="pill">{title}</div>
        <p className="muted">{subtitle}</p>
      </div>
      <div className="laneSteps">
        {items.map(([no, name, detail, href, action]) => (
          <div className="laneStep" key={`${title}-${no}`}>
            <div className="bubble">{no}</div>
            <div>
              <h3>{name}</h3>
              <p>{detail}</p>
              <a href={href}>{action}</a>
            </div>
          </div>
        ))}
      </div>
    </article>
  );
}

export default function PilotControlPanelPage() {
  return (
    <main className="shell pilotPage">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Pilot Control Panel</h1>
          <p className="muted">Satu page untuk jelaskan perjalanan sistem: Customer order bola/F&B, Admin/Staff prepare-deliver, Owner manage operasi.</p>
        </div>
        <div className="pilotNav">
          <a className="btn secondary" href="/staff">Staff Flow</a>
          <a className="btn" href="/counter">Counter Flow</a>
          <a className="btn secondary" href="/trial">Trial Checklist</a>
        </div>
      </div>

      <section className="card pilotHero">
        <div>
          <div className="pill">Pilot Scope Locked</div>
          <h2>Standard Package sahaja untuk trial range</h2>
          <p className="muted">Fokus sekarang: QR bay order, bucket/F&B order, payment verification, slip print, delivery checkpoint, owner control. POS stock dan payment gateway ialah add-on selepas standard package stabil.</p>
        </div>
        <div className="pilotBadge">PILOT</div>
      </section>

      <section className="flowLanes">
        <FlowLane title="Customer Flow" subtitle="Apa customer nampak dan buat di bay." items={customerFlow} tone="customerLane" />
        <FlowLane title="Admin / Staff Flow" subtitle="Apa staff counter, kitchen/ball station dan runner buat." items={staffFlow} tone="staffLane" />
        <FlowLane title="Owner Flow" subtitle="Apa owner/manager urus dan semak." items={ownerFlow} tone="ownerLane" />
      </section>

      <section className="card trialScript">
        <div className="pill">Trial Script</div>
        <h2>Jalankan demo ikut urutan ini</h2>
        <ol>
          <li>Buka Customer Bay dan submit satu order bucket + satu item F&B.</li>
          <li>Buka Counter Flow, verify payment dan print slip yang berkaitan.</li>
          <li>Buka QR Checkpoint, start delivery dan confirm scan bay QR.</li>
          <li>Buka Owner Dashboard untuk tunjuk sales/order/bucket/bay usage.</li>
          <li>Buka Trial Checklist untuk tandakan acceptance test standard package.</li>
        </ol>
      </section>

      <section className="card addOnNotice">
        <div className="pill">Not In This Pilot</div>
        <p><b>POS stock</b> untuk air botol, air kotak, air tin dan makanan ialah add-on berasingan.</p>
        <p><b>Payment gateway</b> juga add-on selepas kita pilih provider murah dan standard package sudah stabil.</p>
      </section>

      <style>{`
        .pilotPage{max-width:1180px;margin:0 auto}.pilotNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.pilotHero{display:flex;align-items:center;justify-content:space-between;gap:18px;margin-bottom:16px}.pilotHero h2,.trialScript h2{color:#fff;margin:10px 0}.pilotBadge{width:96px;height:96px;border-radius:999px;background:#34d399;color:#022c22;display:flex;align-items:center;justify-content:center;font-weight:900;letter-spacing:.08em}.flowLanes{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.lane{min-height:610px}.laneHead{border-bottom:1px solid rgba(52,211,153,.2);padding-bottom:12px;margin-bottom:12px}.laneHead p{margin:10px 0 0}.customerLane{border-color:rgba(96,165,250,.35)}.staffLane{border-color:rgba(52,211,153,.4)}.ownerLane{border-color:rgba(251,191,36,.35)}.laneSteps{display:grid;gap:12px}.laneStep{display:grid;grid-template-columns:42px minmax(0,1fr);gap:12px;padding:12px;border-radius:16px;background:rgba(2,44,34,.55);border:1px solid rgba(52,211,153,.18)}.bubble{width:34px;height:34px;border-radius:999px;background:#34d399;color:#022c22;display:flex;align-items:center;justify-content:center;font-weight:900}.laneStep h3{margin:0 0 5px;color:#fff}.laneStep p{margin:0 0 10px;color:#a7f3d0;font-size:13px;line-height:1.4}.laneStep a{display:inline-flex;color:#022c22;background:#34d399;text-decoration:none;font-weight:900;padding:8px 10px;border-radius:10px;font-size:12px}.trialScript{margin-top:16px}.trialScript ol{margin:10px 0 0;padding-left:20px;color:#d1fae5}.trialScript li{margin:8px 0;line-height:1.45}.addOnNotice{margin-top:16px;border-color:rgba(251,191,36,.45)}.addOnNotice p{margin:10px 0;color:#d1fae5;line-height:1.5}@media(max-width:1000px){.flowLanes{grid-template-columns:1fr}.lane{min-height:auto}}@media(max-width:760px){.pilotHero{display:block}.pilotBadge{margin-top:16px}.pilotNav{justify-content:flex-start;margin-top:12px}.pilotNav a{flex:1 1 150px;text-align:center}}
      `}</style>
    </main>
  );
}
