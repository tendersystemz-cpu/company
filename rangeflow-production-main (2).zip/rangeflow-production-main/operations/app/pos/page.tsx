'use client';

import { useEffect, useMemo, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type MenuItem = {
  id: string;
  category: string;
  name: string;
  description?: string | null;
  price: number | string;
  available: boolean;
  stock_tracked?: boolean;
  stock_qty?: number;
  low_stock?: boolean;
  pos_enabled?: boolean;
};

type Cart = Record<string, number>;
type CounterOrderResult = { booking_id?: string; order_token?: string; qr_token?: string; total_amount?: number | string };

const BAY_OPTIONS = Array.from({ length: 30 }, (_, index) => String(index + 1).padStart(2, '0'));

function money(value: number | string | undefined) { return `RM ${Number(value || 0).toFixed(2)}`; }
function count(value: number | string | undefined) { return Number(value || 0).toLocaleString('en-MY'); }
function categoryLabel(value: string) {
  const v = String(value || '').toLowerCase();
  if (v === 'bucket') return 'Ball';
  if (v === 'drink') return 'Drink';
  if (v === 'fb' || v === 'food') return 'Food';
  if (v === 'snack') return 'Snack';
  if (v === 'set' || v === 'promo') return 'Set';
  if (v === 'equipment' || v === 'golf') return 'Golf';
  if (v === 'service') return 'Service';
  return 'Other';
}
function normalizeBay(value?: string | null) {
  const raw = String(value || '01').trim();
  const n = Number(raw);
  return Number.isFinite(n) ? String(n).padStart(2, '0') : raw.toUpperCase();
}
function orderType(category: string) {
  return String(category || '').toLowerCase() === 'bucket' ? 'bucket' : 'fb';
}

export default function PosLitePage() {
  const [selectedBay, setSelectedBay] = useState('01');
  const [items, setItems] = useState<MenuItem[]>([]);
  const [cart, setCart] = useState<Cart>({});
  const [staffPin, setStaffPin] = useState('');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('manual_qr');
  const [note, setNote] = useState('');
  const [filter, setFilter] = useState('all');
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [lastSale, setLastSale] = useState<CounterOrderResult | null>(null);

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    setSelectedBay(normalizeBay(params.get('bay')));
  }, []);

  async function loadItems() {
    setLoading(true);
    setError('');
    const { data, error: loadError } = await supabase.rpc('get_operations_menu_items', { p_org_slug: ORG_SLUG });
    setLoading(false);
    if (loadError) { setError(loadError.message || 'Gagal load POS items.'); return; }
    const list = ((data || []) as MenuItem[]).filter((item) => item.available && item.pos_enabled !== false);
    setItems(list);
  }

  useEffect(() => { loadItems(); }, []);

  const categories = useMemo(() => ['all', ...Array.from(new Set(items.map((item) => item.category || 'other')))], [items]);
  const visibleItems = useMemo(() => filter === 'all' ? items : items.filter((item) => item.category === filter), [items, filter]);
  const cartLines = useMemo(() => items.filter((item) => (cart[item.id] || 0) > 0), [items, cart]);
  const total = useMemo(() => cartLines.reduce((sum, item) => sum + Number(item.price || 0) * (cart[item.id] || 0), 0), [cartLines, cart]);
  const lowCount = useMemo(() => items.filter((item) => item.low_stock).length, [items]);

  function changeQty(id: string, delta: number) {
    setCart((current) => ({ ...current, [id]: Math.max(0, (current[id] || 0) + delta) }));
  }

  function chooseBay(bay: string) {
    setSelectedBay(bay);
    setError('');
    setMessage(`Bay ${bay} selected.`);
    const nextUrl = `${window.location.pathname}?bay=${bay}`;
    window.history.replaceState(null, '', nextUrl);
  }

  async function completeSale() {
    if (!staffPin.trim()) { setError('Masukkan staff / owner PIN untuk assisted order.'); return; }
    if (cartLines.length === 0 || total <= 0) { setError('Pilih sekurang-kurangnya satu item.'); return; }

    setSubmitting(true); setMessage(''); setError(''); setLastSale(null);
    const payload = cartLines.map((item) => ({ item_name: item.name, type: orderType(item.category), quantity: cart[item.id] || 0, unit_price: Number(item.price || 0) }));

    const { data, error: orderError } = await supabase.rpc('create_counter_first_order', {
      p_org_slug: ORG_SLUG,
      p_bay_code: selectedBay,
      p_items: payload,
      p_customer_type: 'walkin',
      p_payment_method: paymentMethod,
      p_assisted_by: 'pos_lite',
    });

    setSubmitting(false);
    if (orderError) { setError(orderError.message || 'Gagal complete assisted order.'); return; }

    const result = (Array.isArray(data) ? data[0] : data) as CounterOrderResult;
    setCart({}); setCustomerName(''); setCustomerPhone(''); setNote(''); setLastSale(result);
    setMessage(`Assisted order completed for Bay ${selectedBay}. Token ${result?.order_token || result?.qr_token || '-'}.`);
    await loadItems();
  }

  return (
    <main className="posShell">
      <header className="hero">
        <div>
          <span>EDGE RANGE OS</span>
          <h1>POS Lite</h1>
          <p>Assisted counter order for selected bay. Cashless QR flow.</p>
        </div>
        <strong>Bay {selectedBay}</strong>
      </header>

      <nav className="nav">
        <a href="/owner">Owner</a>
        <a href="/counter">Counter</a>
        <a href="/menu">Menu</a>
        <a href="/stock">Stock</a>
        <button onClick={loadItems}>Refresh</button>
      </nav>

      <section className="baySelector">
        <div>
          <span>Selected Bay</span>
          <b>Bay {selectedBay}</b>
          <small>Choose the bay before completing assisted order.</small>
        </div>
        <select value={selectedBay} onChange={(event) => chooseBay(event.target.value)}>
          {BAY_OPTIONS.map((bay) => <option value={bay} key={bay}>Bay {bay}</option>)}
        </select>
        <div className="bayButtons">
          {BAY_OPTIONS.slice(0, 12).map((bay) => <button key={bay} className={selectedBay === bay ? 'active' : ''} onClick={() => chooseBay(bay)}>Bay {bay}</button>)}
        </div>
      </section>

      {message ? <div className="notice success">{message}</div> : null}
      {error ? <div className="notice error">{error}</div> : null}
      {loading ? <div className="notice">Loading POS items...</div> : null}

      <section className="metrics">
        <Metric label="Selected Bay" value={`Bay ${selectedBay}`} sub="Assisted order" />
        <Metric label="Items" value={count(items.length)} sub="POS enabled" />
        <Metric label="Cart" value={count(cartLines.length)} sub={money(total)} />
        <Metric label="Low Stock" value={count(lowCount)} sub="Alert count" />
      </section>

      <section className="posGrid">
        <section className="panel catalog">
          <div className="panelTitle"><div><span>Touch Catalog</span><h2>Add Items</h2></div></div>
          <div className="filters">{categories.map((cat) => <button key={cat} className={filter === cat ? 'active' : ''} onClick={() => setFilter(cat)}>{cat === 'all' ? 'All' : categoryLabel(cat)}</button>)}</div>
          <div className="productGrid">
            {visibleItems.map((item) => {
              const itemCount = cart[item.id] || 0;
              return <article className={`posItem ${item.low_stock ? 'low' : ''}`} key={item.id}>
                <button type="button" className="tap" onClick={() => changeQty(item.id, 1)}>
                  <span>{categoryLabel(item.category)}</span>
                  <h2>{item.name}</h2>
                  <p>{item.description || 'Counter item'}</p>
                  <strong>{money(item.price)}</strong>
                  <small>{item.stock_tracked ? `Stock ${item.stock_qty ?? 0}` : 'Stock not tracked'}</small>
                </button>
                <div className="qtyBar"><button onClick={() => changeQty(item.id, -1)}>−</button><b>{itemCount}</b><button onClick={() => changeQty(item.id, 1)}>+</button></div>
              </article>;
            })}
          </div>
        </section>

        <aside className="panel cartPanel">
          <div className="panelTitle"><div><span>Checkout</span><h2>Bay {selectedBay}</h2></div></div>
          <div className="cartList">
            {cartLines.length === 0 ? <p>No item selected.</p> : null}
            {cartLines.map((item) => <div className="cartLine" key={item.id}><span>{cart[item.id]}x {item.name}</span><b>{money(Number(item.price) * (cart[item.id] || 0))}</b></div>)}
          </div>
          <div className="cartTotal"><span>Total</span><b>{money(total)}</b></div>
          <div className="formStack">
            <label><span>Staff / Owner PIN</span><input type="password" value={staffPin} onChange={(e) => setStaffPin(e.target.value)} placeholder="Required" /></label>
            <label><span>Customer Name</span><input value={customerName} onChange={(e) => setCustomerName(e.target.value)} placeholder={`Optional · Bay ${selectedBay}`} /></label>
            <label><span>Customer Phone</span><input value={customerPhone} onChange={(e) => setCustomerPhone(e.target.value)} placeholder="Optional" /></label>
            <label><span>Payment Method</span><select value={paymentMethod} onChange={(e) => setPaymentMethod(e.target.value)}><option value="manual_qr">TNG / DuitNow QR</option><option value="tng">TNG</option><option value="duitnow_qr">DuitNow QR</option><option value="bank_transfer">Bank Transfer</option><option value="card">Card Terminal</option></select></label>
            <label><span>Note</span><input value={note} onChange={(e) => setNote(e.target.value)} placeholder={`Optional · Assisted order for Bay ${selectedBay}`} /></label>
          </div>
          <button className="checkoutBtn" disabled={submitting} onClick={completeSale}>{submitting ? 'Completing...' : `Complete Assisted Order · Bay ${selectedBay}`}</button>
          {lastSale?.booking_id ? <a className="printBtn" href={`/print/${lastSale.booking_id}?type=full`}>Print Full Slip</a> : null}
        </aside>
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Metric({ label, value, sub }: { label: string; value: string; sub: string }) { return <article className="metric"><span>{label}</span><b>{value}</b><small>{sub}</small></article>; }

const styles = `
.posShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:12px}.hero{max-width:1240px;margin:0 auto 10px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:22px;padding:18px;display:flex;justify-content:space-between;gap:14px;align-items:flex-start}.hero span{color:var(--accent);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:36px;line-height:1;margin:7px 0;letter-spacing:-.04em}.hero p{margin:0;color:#d6f3df;font-weight:900;line-height:1.35}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:9px 12px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.nav a,.nav button,.baySelector button,.baySelector select,.qtyBar button,.checkoutBtn,.printBtn{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px;text-decoration:none;font-weight:1000;text-align:center}.nav button,.checkoutBtn{background:var(--green);color:#fff}.nav button{grid-column:1/-1}.baySelector{max-width:1240px;margin:0 auto 10px;background:var(--panel);border:1px solid var(--line);border-radius:20px;padding:12px;box-shadow:0 10px 24px rgba(7,28,22,.05);display:grid;grid-template-columns:200px 140px 1fr;gap:10px;align-items:center}.baySelector span,.baySelector small{display:block;color:var(--muted);font-size:10px;font-weight:1000;text-transform:uppercase;letter-spacing:.12em}.baySelector b{display:block;font-size:24px}.bayButtons{display:grid;grid-template-columns:repeat(6,1fr);gap:7px}.bayButtons button{padding:9px;border-radius:12px}.bayButtons button.active{background:var(--deep);color:#fff}.notice{max-width:1240px;margin:0 auto 10px;border-radius:15px;padding:11px 13px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.metrics{max-width:1240px;margin:0 auto 10px;display:grid;grid-template-columns:repeat(4,1fr);gap:10px}.metric,.panel{background:var(--panel);border:1px solid var(--line);border-radius:20px;padding:16px;box-shadow:0 10px 24px rgba(7,28,22,.05)}.metric span,.panelTitle span,.formStack span,.tap span{display:block;color:var(--muted);font-size:10px;font-weight:1000;text-transform:uppercase;letter-spacing:.12em}.metric b{display:block;font-size:30px;margin:8px 0 4px}.metric small,.tap p,.tap small,.cartList p{color:var(--muted);font-weight:900}.posGrid{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:minmax(0,1fr) 360px;gap:10px;align-items:start}.panelTitle{margin-bottom:12px}.panelTitle h2{font-size:22px;margin:5px 0 0}.filters{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.filters button{border:1px solid var(--line);background:#f3f7f1;border-radius:14px;padding:9px 12px;font-weight:1000}.filters button.active{background:var(--deep);color:#fff}.productGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(160px,1fr));gap:10px}.posItem{border:1px solid var(--line);border-radius:18px;background:#fbfdf9;overflow:hidden}.posItem.low{border-color:#f59e0b;background:#fffbeb}.tap{width:100%;border:0;background:transparent;text-align:left;color:var(--ink);padding:13px}.tap h2{font-size:17px;margin:6px 0}.tap strong{display:block;font-size:19px;color:var(--green);margin-top:8px}.qtyBar{display:grid;grid-template-columns:44px 1fr 44px;border-top:1px solid var(--line)}.qtyBar b{display:grid;place-items:center}.qtyBar button{border-radius:0;border:0;background:#fff}.cartList{display:grid;gap:8px}.cartLine,.cartTotal{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid var(--line);padding:10px 0}.cartTotal b{font-size:24px;color:var(--green)}.formStack{display:grid;gap:8px;margin-top:10px}.formStack input,.formStack select{width:100%;border:1px solid var(--line);background:#fbfdf9;color:var(--ink);border-radius:14px;padding:11px;font-weight:850;margin-top:5px}.checkoutBtn,.printBtn{display:block;width:100%;margin-top:10px}.printBtn{background:#f3f7f1}@media(max-width:900px){.hero{display:block}.hero strong{display:inline-block;margin-top:12px}.metrics,.posGrid,.baySelector{grid-template-columns:1fr}.bayButtons{grid-template-columns:repeat(4,1fr)}.nav{grid-template-columns:repeat(2,1fr)}}@media(max-width:560px){.posShell{padding:8px 10px}.hero{padding:16px}.hero h1{font-size:31px}.metric b{font-size:28px}.bayButtons{grid-template-columns:repeat(2,1fr)}.productGrid{grid-template-columns:1fr}}
`;