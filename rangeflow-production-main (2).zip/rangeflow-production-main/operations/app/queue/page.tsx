'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type QueueItem = {
  booking_id: string;
  qr_token: string;
  bay_code: string;
  bay_name: string;
  customer_name?: string | null;
  customer_phone?: string | null;
  booking_status: string;
  payment_status: string;
  payment_method?: string | null;
  payment_reference?: string | null;
  payer_name?: string | null;
  payment_note?: string | null;
  payment_submitted_at?: string | null;
  payment_verification_status?: string | null;
  total_amount: number | string;
  created_at: string;
};

type OrderLine = {
  order_id: string;
  type: string;
  item_name: string;
  quantity: number;
  unit_price: number | string;
  subtotal: number | string;
  status: string;
  metadata?: Record<string, unknown>;
};

type SlipType = 'ball' | 'kitchen' | 'delivery' | 'full';

function paymentLabel(status: string) {
  if (status === 'paid') return 'Payment Verified';
  if (status === 'authorized') return 'Awaiting Verification';
  if (status === 'failed') return 'Payment Rejected';
  return status.replaceAll('_', ' ');
}

function bookingLabel(status: string) {
  const value = String(status || '').toLowerCase();
  if (value === 'pending') return 'Pending';
  if (value === 'preparing') return 'Preparing';
  if (value === 'out_for_delivery') return 'Out for Delivery';
  if (value === 'completed') return 'Completed';
  return value.replaceAll('_', ' ');
}

export default function OperationsQueuePage() {
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [items, setItems] = useState<Record<string, OrderLine[]>>({});
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [updating, setUpdating] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<string>('');
  const [actionsOpen, setActionsOpen] = useState(false);

  async function loadQueue(options?: { silent?: boolean }) {
    const silent = Boolean(options?.silent);
    if (silent) setRefreshing(true);
    else setLoading(true);
    setError(null);

    const { data, error: queueError } = await supabase.rpc('get_operations_queue_summary', {
      p_org_slug: ORG_SLUG,
    });

    if (silent) setRefreshing(false);
    else setLoading(false);

    if (queueError) {
      setError(queueError.message || 'Gagal load operations queue.');
      return;
    }

    const rows = (data || []) as QueueItem[];
    setQueue(rows);

    const loaded: Record<string, OrderLine[]> = {};
    for (const row of rows.slice(0, 20)) {
      const { data: itemData } = await supabase.rpc('get_operations_booking_items', {
        p_booking_id: row.booking_id,
      });
      loaded[row.booking_id] = (itemData || []) as OrderLine[];
    }
    setItems(loaded);
    setLastUpdated(new Date().toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  }

  async function updateStatus(bookingId: string, status: 'preparing' | 'out_for_delivery') {
    setUpdating(`${bookingId}:${status}`);
    setError(null);

    const { error: updateError } = await supabase.rpc('update_operations_booking_status', {
      p_booking_id: bookingId,
      p_status: status,
    });

    setUpdating(null);

    if (updateError) {
      setError(updateError.message || 'Gagal update status.');
      return false;
    }

    await loadQueue({ silent: true });
    return true;
  }

  async function verifyPayment(bookingId: string, status: 'paid' | 'rejected') {
    setUpdating(`${bookingId}:payment:${status}`);
    setError(null);

    const { error: verifyError } = await supabase.rpc('verify_operations_payment', {
      p_booking_id: bookingId,
      p_status: status,
      p_note: status === 'paid' ? 'Verified by staff queue.' : 'Rejected by staff queue.',
    });

    setUpdating(null);

    if (verifyError) {
      setError(verifyError.message || 'Gagal verify payment.');
      return;
    }

    await loadQueue({ silent: true });
  }

  async function startDelivery(order: QueueItem) {
    const ok = await updateStatus(order.booking_id, 'out_for_delivery');
    if (!ok) return;
    setError(null);
  }

  function openDeliveryScan(order: QueueItem) {
    window.location.href = `/deliver/${order.booking_id}?bay=${encodeURIComponent(order.bay_code)}`;
  }

  function printSlip(order: QueueItem, type: SlipType) {
    window.open(`/print/${order.booking_id}?type=${type}`, '_blank', 'noopener,noreferrer');
  }

  useEffect(() => {
    loadQueue();
    const timer = setInterval(() => loadQueue({ silent: true }), 60000);
    return () => clearInterval(timer);
  }, []);

  return (
    <main className="shell">
      <div className="top">
        <div>
          <div className="brand">RangeFlow Operations</div>
          <h1 className="title">Counter Queue</h1>
          <p className="muted">Bay-based order queue untuk bola, makanan dan minuman.</p>
          <p className="muted" style={{fontSize: 12}}>{refreshing ? 'Refreshing quietly...' : lastUpdated ? `Last updated ${lastUpdated}` : ''}</p>
        </div>
        <div className="queueActions">
          <a className="btn secondary compactBtn" href="/hub">Main Menu</a>
          <div className="actionDropdown">
            <button className="btn secondary compactBtn" type="button" onClick={() => setActionsOpen(!actionsOpen)}>
              Actions ▾
            </button>
            {actionsOpen ? (
              <div className="actionMenu">
                <a href="/hub">Main Hub</a>
                <a href="/setup">Setup Wizard</a>
                <a href="/owner">Owner Dashboard</a>
                <a href="/menu">Menu Management</a>
                <a href="/payments">Payment Setup</a>
                <a href="/health">System Health</a>
                <a href="/qr">QR Management</a>
              </div>
            ) : null}
          </div>
          <button className="btn compactBtn" onClick={() => loadQueue({ silent: true })}>Refresh</button>
        </div>
      </div>

      {loading && queue.length === 0 ? <div className="card">Loading orders...</div> : null}
      {error ? <div className="card error">{error}</div> : null}

      <section className="grid orders">
        {queue.map((order) => {
          const orderItems = items[order.booking_id] || [];
          const paid = order.payment_status === 'paid';
          const pendingVerify = order.payment_status === 'authorized';
          const isUpdatingPreparing = updating === `${order.booking_id}:preparing`;
          const isStartingDelivery = updating === `${order.booking_id}:out_for_delivery`;
          const isVerifyingPaid = updating === `${order.booking_id}:payment:paid`;
          const isRejecting = updating === `${order.booking_id}:payment:rejected`;
          const deliveryStarted = order.booking_status === 'out_for_delivery';
          return (
            <article className="card" key={order.booking_id}>
              <div style={{display: 'flex', justifyContent: 'space-between', gap: 12, alignItems: 'start'}}>
                <div>
                  <div className="pill">{order.bay_name || `Bay ${order.bay_code}`}</div>
                  <h2 style={{margin: '10px 0 4px'}}>Token {order.qr_token}</h2>
                  <div className="muted">{order.customer_name || 'Walk-in customer'} {order.customer_phone ? `· ${order.customer_phone}` : ''}</div>
                </div>
                <div style={{textAlign: 'right'}}>
                  <div className={paid ? 'paid' : pendingVerify ? 'pending' : 'unpaid'} style={{fontWeight: 900}}>{paymentLabel(order.payment_status)}</div>
                  <div className="total">RM {Number(order.total_amount).toFixed(2)}</div>
                </div>
              </div>

              <div className="row"><span>Status</span><strong>{bookingLabel(order.booking_status)}</strong></div>
              <div className="row"><span>Booking</span><strong>{order.booking_id.slice(0, 8)}</strong></div>

              <div className="paymentPanel">
                <div className="pill">Payment Check</div>
                <div className="row"><span>Method</span><strong>{order.payment_method || '-'}</strong></div>
                <div className="row"><span>Payer</span><strong>{order.payer_name || order.customer_name || '-'}</strong></div>
                <div className="row"><span>Reference</span><strong>{order.payment_reference || '-'}</strong></div>
                <div className="row"><span>Verify Status</span><strong>{order.payment_verification_status || '-'}</strong></div>
                {order.payment_note ? <div className="row"><span>Note</span><strong>{order.payment_note}</strong></div> : null}
                <div className="grid" style={{gridTemplateColumns: '1fr 1fr', marginTop: 12}}>
                  <button className="btn" type="button" disabled={Boolean(updating) || paid} onClick={() => verifyPayment(order.booking_id, 'paid')}>
                    {isVerifyingPaid ? 'Verifying...' : paid ? 'Verified' : 'Verify Payment'}
                  </button>
                  <button className="btn danger" type="button" disabled={Boolean(updating) || paid} onClick={() => verifyPayment(order.booking_id, 'rejected')}>
                    {isRejecting ? 'Rejecting...' : 'Reject'}
                  </button>
                </div>
              </div>

              <div style={{marginTop: 12}}>
                {orderItems.map((item) => (
                  <div className="row" key={item.order_id}>
                    <span>{item.quantity}x {item.item_name}</span>
                    <strong>{item.status}</strong>
                  </div>
                ))}
                {orderItems.length === 0 ? <div className="muted">No item details loaded.</div> : null}
              </div>

              {paid ? (
                <div className="slipPanel">
                  <div className="pill">Print Slips</div>
                  <div className="slipGrid">
                    <button className="btn printBtn" type="button" onClick={() => printSlip(order, 'ball')}>Ball Slip</button>
                    <button className="btn printBtn" type="button" onClick={() => printSlip(order, 'kitchen')}>Kitchen Slip</button>
                    <button className="btn printBtn" type="button" onClick={() => printSlip(order, 'delivery')}>Delivery Slip</button>
                    <button className="btn printBtn fullSlip" type="button" onClick={() => printSlip(order, 'full')}>Full Slip</button>
                  </div>
                </div>
              ) : (
                <button className="btn printBtn disabled" type="button" disabled>
                  Verify payment before printing slips
                </button>
              )}

              <div className="grid" style={{gridTemplateColumns: '1fr 1fr', marginTop: 12}}>
                <button className="btn secondary" type="button" disabled={Boolean(updating) || !paid} onClick={() => updateStatus(order.booking_id, 'preparing')}>
                  {isUpdatingPreparing ? 'Updating...' : paid ? 'Preparing Order' : 'Verify Payment First'}
                </button>
                <button className="btn secondary" type="button" disabled={Boolean(updating) || !paid} onClick={() => deliveryStarted ? openDeliveryScan(order) : startDelivery(order)}>
                  {isStartingDelivery ? 'Starting...' : deliveryStarted ? 'Scan Bay QR' : paid ? 'Start Delivery' : 'Verify Payment First'}
                </button>
              </div>
            </article>
          );
        })}
      </section>

      {!loading && queue.length === 0 ? (
        <div className="card">Belum ada order hari ini.</div>
      ) : null}
      <style>{`
        .paymentPanel{margin-top:14px;padding:14px;border-radius:18px;background:rgba(2,21,16,.42);border:1px solid rgba(52,211,153,.18)}.pending{color:#fde68a}.danger{background:#ef4444;color:white}.slipPanel{margin-top:12px;padding:12px;border-radius:18px;background:rgba(52,211,153,.08);border:1px solid rgba(52,211,153,.2)}.slipGrid{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-top:10px}.printBtn{margin-top:0;min-height:42px}.printBtn.fullSlip{grid-column:1 / -1}.printBtn.disabled{margin-top:12px;opacity:.55;background:#475569!important;cursor:not-allowed}.queueActions{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end;align-items:flex-start}.compactBtn{width:auto;min-width:120px}.actionDropdown{position:relative}.actionMenu{position:absolute;right:0;top:calc(100% + 8px);z-index:30;width:230px;border:1px solid rgba(52,211,153,.3);border-radius:16px;background:#021510;box-shadow:0 18px 50px rgba(0,0,0,.38);overflow:hidden}.actionMenu a{display:block;padding:14px 16px;color:#d1fae5;text-decoration:none;font-weight:900;border-bottom:1px solid rgba(52,211,153,.13)}.actionMenu a:last-child{border-bottom:0}.actionMenu a:hover{background:rgba(52,211,153,.13)}@media(max-width:640px){.queueActions{justify-content:flex-start;width:100%;display:grid;grid-template-columns:1fr 1fr;gap:10px}.queueActions .compactBtn{width:100%;min-width:0}.actionDropdown{width:100%}.actionMenu{left:0;right:auto;width:min(280px,calc(100vw - 36px))}.slipGrid{grid-template-columns:1fr}}
      `}</style>
    </main>
  );
}
