'use client';

const customerBayUrl = 'https://rangeflow-bucc.netlify.app/b/01';
const customerOrderUrl = 'https://rangeflow-bucc.netlify.app/b/01/order';

const steps = [
  {
    no: '01',
    group: 'Foundation',
    title: 'System / Range Profile Check',
    detail: 'Confirm environment, system health, org setting and basic readiness before user-facing setup.',
    href: '/health',
    action: 'Check Health',
  },
  {
    no: '02',
    group: 'Bay Setup',
    title: 'QR Bay Management',
    detail: 'Confirm bay list, bay codes, fixed QR links and printable bay labels.',
    href: '/qr',
    action: 'Manage Bay QR',
  },
  {
    no: '03',
    group: 'Product Setup',
    title: 'Menu / Product Management',
    detail: 'Confirm buckets, food, drinks, prices, categories and active customer menu items.',
    href: '/menu',
    action: 'Manage Menu',
  },
  {
    no: '04',
    group: 'Payment Setup',
    title: 'Payment Setup',
    detail: 'Confirm merchant QR, bank details, payment notes and manual verification instruction.',
    href: '/payments',
    action: 'Manage Payment',
  },
  {
    no: '05',
    group: 'Access Setup',
    title: 'Staff / Owner Access',
    detail: 'Confirm owner PIN, staff PIN and protected operations access before live use.',
    href: '/access',
    action: 'Manage Access',
  },
  {
    no: '06',
    group: 'Launch Test',
    title: 'Queue / Slip / Delivery Test',
    detail: 'Run one end-to-end test: customer order, payment verify, print slip and delivery confirmation.',
    href: '/queue',
    action: 'Open Queue Test',
  },
];

export default function SetupWizardPage() {
  return (
    <main className="shell setupPage">
      <div className="top flowTop">
        <div>
          <div className="brand">RangeFlow Standard Package</div>
          <h1 className="title">Setup Wizard</h1>
          <p className="muted">Ikut turutan sahaja: satu step, satu tujuan, satu action utama.</p>
        </div>
        <div className="flowNav">
          <a className="btn secondary" href="/hub">Back</a>
          <a className="btn" href="/qr">Next: QR Bay</a>
        </div>
      </div>

      <section className="card flowIntro">
        <div className="pill">Standard Setup Cycle</div>
        <h2>Setup → QR Bay → Menu → Payment → Access → Queue</h2>
        <p className="muted">Client-facing flow mesti jelas. Preview customer link diletak di bawah, bukan bercampur dengan action setup.</p>
      </section>

      <section className="wizardList">
        {steps.map((step, index) => {
          const next = steps[index + 1];
          return (
            <article className="card wizardStep" key={step.no}>
              <div className="stepNo">{step.no}</div>
              <div className="stepBody">
                <div className="pill">{step.group}</div>
                <h2>{step.title}</h2>
                <p className="muted">{step.detail}</p>
                {next ? <p className="nextHint">Next: {next.title}</p> : <p className="nextHint">Next: monitor live operation.</p>}
              </div>
              <a className="btn" href={step.href}>{step.action}</a>
            </article>
          );
        })}
      </section>

      <section className="card launchPreview">
        <div className="pill">Customer Preview</div>
        <p className="muted">Preview links are separated from setup actions so staff do not confuse setup work with customer testing.</p>
        <div className="previewLinks">
          <a href={customerBayUrl}>Customer Bay Preview</a>
          <a href={customerOrderUrl}>Customer Order Preview</a>
        </div>
      </section>

      <style>{`
        .setupPage{max-width:1080px;margin:0 auto}.flowTop{align-items:flex-start}.flowNav{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}.flowIntro{margin-bottom:16px}.flowIntro h2{color:#fff;margin:10px 0}.wizardList{display:grid;gap:12px}.wizardStep{display:grid;grid-template-columns:64px minmax(0,1fr) 180px;gap:14px;align-items:center}.stepNo{width:52px;height:52px;border-radius:999px;background:#34d399;color:#022c22;display:flex;align-items:center;justify-content:center;font-weight:900}.stepBody h2{color:#fff;margin:10px 0 6px}.nextHint{margin:10px 0 0;color:#6ee7b7;font-weight:900;font-size:13px}.launchPreview{margin-top:16px}.previewLinks{display:flex;gap:10px;flex-wrap:wrap;margin-top:12px}.previewLinks a{display:inline-flex;padding:10px 12px;border-radius:12px;border:1px solid rgba(52,211,153,.25);background:rgba(2,44,34,.68);color:#d1fae5;text-decoration:none;font-weight:900}@media(max-width:820px){.wizardStep{grid-template-columns:1fr}.wizardStep .btn{width:100%;text-align:center}.top{display:block}.flowNav{justify-content:flex-start;margin-top:12px}.flowNav .btn{flex:1 1 130px}}
      `}</style>
    </main>
  );
}
