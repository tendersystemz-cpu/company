'use client';

import { useEffect, useState } from 'react';
import { ORG_SLUG, supabase } from '@/lib/supabase';

type OwnerSummary = {
  today?: { sales?: number | string; orders?: number; paid_orders?: number; pending_orders?: number; completed_orders?: number; bucket_qty?: number | string };
  overall?: { total_bookings?: number; paid_bookings?: number; completed_bookings?: number; total_sales?: number | string; total_bucket_qty?: number | string };
  bay?: { total_bays?: number; active_bays?: number; used_bays_today?: number };
};

function money(value: number | string | undefined) { return `RM ${Number(value || 0).toFixed(2)}`; }
function count(value: number | string | undefined) { return Number(value || 0).toLocaleString('en-MY'); }

export default function OwnerDashboardPage() {
  const [summary, setSummary] = useState<OwnerSummary | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState('');

  async function loadSummary(options?: { silent?: boolean }) {
    const silent = Boolean(options?.silent);
    if (silent) setRefreshing(true); else setLoading(true);
    setError(null);
    const { data, error: summaryError } = await supabase.rpc('get_operations_owner_summary', { p_org_slug: ORG_SLUG });
    if (silent) setRefreshing(false); else setLoading(false);
    if (summaryError) { setError(summaryError.message || 'Gagal load owner summary.'); return; }
    setSummary((data || {}) as OwnerSummary);
    setLastUpdated(new Date().toLocaleTimeString('en-MY', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
  }

  useEffect(() => {
    loadSummary();
    const timer = setInterval(() => loadSummary({ silent: true }), 60000);
    return () => clearInterval(timer);
  }, []);

  const today = summary?.today || {};
  const overall = summary?.overall || {};
  const bay = summary?.bay || {};
  const utilization = Number(bay.total_bays || 0) > 0 ? (Number(bay.used_bays_today || 0) / Number(bay.total_bays || 1)) * 100 : 0;
  const unused = Math.max(0, Number(bay.total_bays || 0) - Number(bay.used_bays_today || 0));
  const status = Number(today.pending_orders || 0) > 0 ? 'Action Needed' : Number(today.orders || 0) > 0 ? 'Live Operation' : 'Ready';

  return (
    <main className="ownerShell">
      <header className="hero">
        <div>
          <span>EDGE RANGE OS</span>
          <h1>Owner Dashboard</h1>
          <p>Revenue, bay usage and daily operation overview.</p>
          <small>{refreshing ? 'Refreshing...' : lastUpdated ? `Updated ${lastUpdated}` : 'Live view'}</small>
        </div>
        <strong>{status}</strong>
      </header>

      <nav className="nav">
        <a href="/counter">Counter</a>
        <a href="/payments">Payment</a>
        <a href="/menu">Menu</a>
        <a href="/pos">POS</a>
        <a href="/stock">Stock</a>
        <button onClick={() => loadSummary({ silent: true })}>Refresh</button>
      </nav>

      {loading ? <div className="notice">Loading owner dashboard...</div> : null}
      {error ? <div className="notice error">{error}</div> : null}

      <section className="metrics">
        <Card label="Today Sales" value={money(today.sales)} sub="Paid value" />
        <Card label="Orders" value={count(today.orders)} sub={`${count(today.paid_orders)} paid · ${count(today.pending_orders)} pending`} />
        <Card label="Buckets" value={count(today.bucket_qty)} sub="Today" />
        <Card label="Bay Usage" value={`${utilization.toFixed(0)}%`} sub={`${count(bay.used_bays_today)} / ${count(bay.total_bays)} used`} />
      </section>

      <section className="grid">
        <article className="panel"><h2>Today Operation</h2><Row label="Paid orders" value={count(today.paid_orders)} /><Row label="Pending" value={count(today.pending_orders)} /><Row label="Completed" value={count(today.completed_orders)} /><Row label="Unused bays" value={count(unused)} /></article>
        <article className="panel"><h2>Overall System</h2><Row label="Total sales" value={money(overall.total_sales)} /><Row label="Total bookings" value={count(overall.total_bookings)} /><Row label="Paid bookings" value={count(overall.paid_bookings)} /><Row label="Total buckets" value={count(overall.total_bucket_qty)} /></article>
        <article className="panel"><h2>Quick Control</h2><div className="links"><a href="/payments">Payment Setup</a><a href="/menu">Menu/Product</a><a href="/pos">POS Lite</a><a href="/stock">Stock Lite</a><a href="/counter">Counter Flow</a><a href="/members">Members</a></div></article>
      </section>
      <style>{styles}</style>
    </main>
  );
}

function Card({ label, value, sub }: { label: string; value: string; sub: string }) { return <article className="card"><span>{label}</span><b>{value}</b><small>{sub}</small></article>; }
function Row({ label, value }: { label: string; value: string }) { return <div className="row"><span>{label}</span><b>{value}</b></div>; }

const styles = `
.ownerShell{--bg:#f5f8f1;--panel:#fff;--ink:#071c16;--muted:#607469;--line:#dce8d5;--green:#0f773a;--green2:#17b26a;--deep:#061c14;--accent:#9be84f;min-height:100vh;background:linear-gradient(180deg,#f9fcf6,var(--bg));color:var(--ink);font-family:Inter,Arial,sans-serif;padding:18px}.hero{max-width:1240px;margin:0 auto 12px;background:linear-gradient(135deg,#061c14,#0b3324);color:#fff;border-radius:28px;padding:24px;display:flex;justify-content:space-between;gap:20px;align-items:flex-start;box-shadow:0 20px 60px rgba(7,28,22,.14)}.hero span{color:var(--accent);font-size:12px;font-weight:1000;text-transform:uppercase;letter-spacing:.18em}.hero h1{font-size:42px;line-height:1;margin:8px 0 8px;letter-spacing:-.04em}.hero p{margin:0;color:#cdebd8;font-weight:900}.hero small{display:block;margin-top:12px;color:#a7d7b9;font-weight:900}.hero strong{border:1px solid rgba(255,255,255,.18);border-radius:999px;padding:12px 16px;background:rgba(255,255,255,.08);white-space:nowrap}.nav{max-width:1240px;margin:0 auto 12px;display:flex;gap:8px;flex-wrap:wrap}.nav a,.nav button{border:1px solid var(--line);background:#fff;color:var(--ink);border-radius:15px;padding:11px 14px;text-decoration:none;font-weight:1000}.nav button{background:var(--green);color:#fff}.notice{max-width:1240px;margin:0 auto 12px;border-radius:16px;padding:12px 14px;background:#ecfdf5;border:1px solid #bbf7d0;color:#065f46;font-weight:900}.notice.error{background:#fff1f2;border-color:#fecdd3;color:#9f1239}.metrics{max-width:1240px;margin:0 auto 12px;display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.card,.panel{background:var(--panel);border:1px solid var(--line);border-radius:22px;padding:18px;box-shadow:0 12px 30px rgba(7,28,22,.06)}.card span,.row span{display:block;color:var(--muted);font-size:11px;font-weight:1000;text-transform:uppercase;letter-spacing:.08em}.card b{display:block;font-size:32px;margin:10px 0 6px}.card small{color:var(--muted);font-weight:900}.grid{max-width:1240px;margin:0 auto;display:grid;grid-template-columns:1fr 1fr 1fr;gap:12px}.panel h2{font-size:20px;margin:0 0 12px}.row{display:flex;justify-content:space-between;gap:12px;border-bottom:1px solid var(--line);padding:12px 0}.row:last-child{border-bottom:0}.row b{text-align:right}.links{display:grid;grid-template-columns:1fr 1fr;gap:9px}.links a{display:grid;place-items:center;min-height:52px;background:linear-gradient(135deg,var(--accent),var(--green2));color:#06110d;border-radius:15px;text-align:center;text-decoration:none;font-weight:1000;padding:10px}@media(max-width:980px){.metrics{grid-template-columns:repeat(2,1fr)}.grid{grid-template-columns:1fr}.hero{display:block}.hero strong{display:inline-block;margin-top:16px}}@media(max-width:560px){.ownerShell{padding:10px}.hero{border-radius:22px;padding:18px}.hero h1{font-size:32px}.metrics{grid-template-columns:1fr}.links{grid-template-columns:1fr}.nav a,.nav button{flex:1 1 120px;text-align:center}.card b{font-size:28px}}
`;