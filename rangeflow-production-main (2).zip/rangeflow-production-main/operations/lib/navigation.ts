export type AccessRole = 'public' | 'staff' | 'owner' | 'superadmin';
export type RouteStatus = 'production' | 'deprecated' | 'internal' | 'future';
export type NavSection = 'main' | 'customer' | 'staff' | 'owner' | 'superadmin';

export type NavRoute = {
  icon: string;
  label: string;
  href: string;
  section: NavSection;
  access: AccessRole;
  status: RouteStatus;
  external?: boolean;
  redirectTo?: string;
  showInTopNav?: boolean;
  showAsModule?: boolean;
  description?: string;
};

export const CUSTOMER_BASE_URL =
  process.env.NEXT_PUBLIC_CUSTOMER_BASE_URL ||
  'http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io';

export const NAV_ROUTES: NavRoute[] = [
  {
    icon: '⌂',
    label: 'Hub',
    href: '/',
    section: 'main',
    access: 'public',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Operations command center',
  },
  {
    icon: '🧾',
    label: 'Bay Order',
    href: `${CUSTOMER_BASE_URL}/b/07/order`,
    section: 'customer',
    access: 'public',
    status: 'production',
    external: true,
    showInTopNav: true,
    showAsModule: true,
    description: 'Customer QR order preview',
  },
  {
    icon: '🛎️',
    label: 'Counter',
    href: '/counter',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Staff counter and bay operation',
  },
  {
    icon: '👥',
    label: 'Queue',
    href: '/counter',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Queue view inside counter operation',
  },
  {
    icon: '🛒',
    label: 'POS Lite',
    href: '/pos?bay=07',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Counter sale and POS Lite flow',
  },
  {
    icon: '📦',
    label: 'Stock',
    href: '/stock',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Stock Lite control',
  },
  {
    icon: '🍽️',
    label: 'Menu',
    href: '/menu',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Menu and product management',
  },
  {
    icon: '💳',
    label: 'Payments',
    href: '/payments',
    section: 'staff',
    access: 'staff',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Payment verification and setup',
  },
  {
    icon: '👑',
    label: 'Owner',
    href: '/owner',
    section: 'owner',
    access: 'owner',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Owner dashboard and reports',
  },
  {
    icon: '▦',
    label: 'QR',
    href: '/qr',
    section: 'owner',
    access: 'owner',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'QR bay management',
  },
  {
    icon: '⚙️',
    label: 'Access',
    href: '/access',
    section: 'owner',
    access: 'owner',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'PIN and access settings',
  },
  {
    icon: '📊',
    label: 'Reports',
    href: '/owner',
    section: 'owner',
    access: 'owner',
    status: 'production',
    showInTopNav: true,
    showAsModule: true,
    description: 'Reports inside owner dashboard',
  },
  {
    icon: '🧭',
    label: 'Access Hub',
    href: '/hub',
    section: 'main',
    access: 'public',
    status: 'production',
    showInTopNav: false,
    showAsModule: false,
    description: 'Temporary access hub; clean or redirect after P0',
  },
  {
    icon: '🖨️',
    label: 'Print Slip',
    href: '/print/[bookingId]',
    section: 'staff',
    access: 'staff',
    status: 'internal',
    showInTopNav: false,
    showAsModule: false,
  },
  {
    icon: '🚚',
    label: 'Delivery',
    href: '/deliver/[bookingId]',
    section: 'staff',
    access: 'staff',
    status: 'internal',
    showInTopNav: false,
    showAsModule: false,
  },
  {
    icon: '🧍',
    label: 'Staff Legacy',
    href: '/staff',
    section: 'staff',
    access: 'staff',
    status: 'deprecated',
    redirectTo: '/counter',
    showInTopNav: false,
  },
  {
    icon: '🧍',
    label: 'Staff Ops Legacy',
    href: '/staff-ops',
    section: 'staff',
    access: 'staff',
    status: 'deprecated',
    redirectTo: '/counter',
    showInTopNav: false,
  },
  {
    icon: '⚑',
    label: 'Staff Bay Legacy',
    href: '/staff-ops-bay',
    section: 'staff',
    access: 'staff',
    status: 'deprecated',
    redirectTo: '/counter',
    showInTopNav: false,
  },
  {
    icon: '👥',
    label: 'Queue Legacy',
    href: '/queue',
    section: 'staff',
    access: 'staff',
    status: 'deprecated',
    redirectTo: '/counter',
    showInTopNav: false,
  },
  {
    icon: '🧪',
    label: 'Pilot Legacy',
    href: '/pilot',
    section: 'main',
    access: 'owner',
    status: 'deprecated',
    redirectTo: '/',
    showInTopNav: false,
  },
  {
    icon: '🧪',
    label: 'Trial Legacy',
    href: '/trial',
    section: 'main',
    access: 'owner',
    status: 'deprecated',
    redirectTo: '/',
    showInTopNav: false,
  },
  {
    icon: '🔧',
    label: 'Setup Legacy',
    href: '/setup',
    section: 'owner',
    access: 'owner',
    status: 'deprecated',
    redirectTo: '/access',
    showInTopNav: false,
  },
  {
    icon: '🧪',
    label: 'Checkpoint',
    href: '/checkpoint',
    section: 'main',
    access: 'owner',
    status: 'deprecated',
    redirectTo: '/',
    showInTopNav: false,
  },
  {
    icon: '♡',
    label: 'Health',
    href: '/health',
    section: 'main',
    access: 'owner',
    status: 'internal',
    showInTopNav: false,
  },
  {
    icon: '🏢',
    label: 'Super Admin',
    href: '/superadmin',
    section: 'superadmin',
    access: 'superadmin',
    status: 'future',
    showInTopNav: false,
    showAsModule: false,
    description: 'Future SaaS tenant and billing control',
  },
];

export const TOP_NAV_ROUTES = NAV_ROUTES.filter((route) => route.showInTopNav);
export const MODULE_ROUTES = NAV_ROUTES.filter((route) => route.showAsModule);
export const DEPRECATED_ROUTES = NAV_ROUTES.filter((route) => route.status === 'deprecated');

export function routePath(href: string) {
  if (href.startsWith('http')) return href;
  return href.split('?')[0];
}

export function routeForPath(pathname: string) {
  return NAV_ROUTES.find((route) => routePath(route.href) === pathname);
}

export function requiredAccessForPath(pathname: string): AccessRole {
  const route = routeForPath(pathname);
  if (route) return route.access;

  if (
    pathname.startsWith('/owner') ||
    pathname.startsWith('/access') ||
    pathname.startsWith('/qr') ||
    pathname.startsWith('/setup-wizard')
  ) return 'owner';

  if (
    pathname.startsWith('/counter') ||
    pathname.startsWith('/pos') ||
    pathname.startsWith('/stock') ||
    pathname.startsWith('/menu') ||
    pathname.startsWith('/payments') ||
    pathname.startsWith('/members') ||
    pathname.startsWith('/promotions') ||
    pathname.startsWith('/staff') ||
    pathname.startsWith('/staff-ops') ||
    pathname.startsWith('/staff-ops-bay') ||
    pathname.startsWith('/queue') ||
    pathname.startsWith('/print') ||
    pathname.startsWith('/deliver')
  ) return 'staff';

  return 'public';
}

export function canAccess(required: AccessRole | undefined, unlockedRole: AccessRole | null) {
  if (!required || required === 'public') return true;
  if (required === 'staff') return unlockedRole === 'staff' || unlockedRole === 'owner' || unlockedRole === 'superadmin';
  if (required === 'owner') return unlockedRole === 'owner' || unlockedRole === 'superadmin';
  if (required === 'superadmin') return unlockedRole === 'superadmin';
  return false;
}

export function roleKeyForRpc(required: AccessRole) {
  if (required === 'owner') return 'owner';
  if (required === 'staff') return 'staff';
  return required;
}

export function accessLabel(role: AccessRole | null) {
  if (role === 'owner') return 'Owner';
  if (role === 'staff') return 'Staff';
  if (role === 'superadmin') return 'Super Admin';
  return 'Locked';
}

export function roleChip(route: NavRoute) {
  if (route.access === 'owner') return 'Owner';
  if (route.access === 'staff') return 'Staff';
  if (route.access === 'superadmin') return 'Future';
  return route.section === 'customer' ? 'Customer' : 'Open';
}
