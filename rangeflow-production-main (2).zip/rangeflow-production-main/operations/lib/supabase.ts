import { createClient } from '@supabase/supabase-js';

const rawSupabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
const rawSupabaseKey = process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY || process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY || '';

export const HAS_SUPABASE_ENV = Boolean(rawSupabaseUrl && rawSupabaseKey);

// UKM production lock:
// EDGE RangeFlow @ UKM source-of-truth org slug.
export const ORG_SLUG = 'drukm';

export function hasSupabaseEnv() {
  return HAS_SUPABASE_ENV;
}

function missingEnvResponse() {
  return Promise.resolve({ data: null, error: { message: 'Supabase environment is not configured for this deployment.' } });
}

const fallbackSupabase = {
  rpc: () => missingEnvResponse(),
  from: () => ({
    select: () => ({
      eq: () => ({
        order: () => missingEnvResponse(),
        limit: () => ({ maybeSingle: () => missingEnvResponse() }),
        maybeSingle: () => missingEnvResponse(),
      }),
      order: () => missingEnvResponse(),
      limit: () => ({ maybeSingle: () => missingEnvResponse() }),
      maybeSingle: () => missingEnvResponse(),
    }),
    insert: () => ({ select: () => ({ single: () => missingEnvResponse() }) }),
    update: () => ({ eq: () => missingEnvResponse() }),
  }),
};

export const supabase = HAS_SUPABASE_ENV
  ? createClient(rawSupabaseUrl, rawSupabaseKey, { auth: { persistSession: false, autoRefreshToken: false } })
  : (fallbackSupabase as any);
