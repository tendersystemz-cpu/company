# Project Notes

This file records the current project direction.

## Rule

Check this file before changing product direction.

## Priority

- Keep the project focused.
- Keep the customer flow simple.
- Update this file when decisions change.
