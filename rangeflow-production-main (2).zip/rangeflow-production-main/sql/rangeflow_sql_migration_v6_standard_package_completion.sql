-- RangeFlow V6 Standard Package Completion
-- Adds POS Lite transaction RPC, Promotion/Campaign Lite, and Membership Lite support.
-- Apply after V1-V5 migrations have been applied.

create extension if not exists pgcrypto;

-- Align product categories used by the app with database constraint.
alter table public.menu_items drop constraint if exists menu_items_category_check;
alter table public.menu_items
  add constraint menu_items_category_check
  check (category = any (array['bucket','fb','food','equipment','snack','drink','set','promo','other','service','golf']));

-- POS Lite customer capture needs one customer record per org + phone.
-- Existing production rows should be checked for duplicates before applying this in a heavily used tenant.
create unique index if not exists customers_org_phone_uidx
  on public.customers (org_id, phone);

create table if not exists public.promotions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  code text not null,
  name text not null,
  description text,
  discount_type text not null default 'fixed' check (discount_type in ('fixed','percent','free_item','bundle')),
  discount_value numeric not null default 0,
  min_order_amount numeric not null default 0,
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean not null default true,
  campaign_source text,
  usage_limit integer,
  used_count integer not null default 0,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, code)
);

alter table public.promotions enable row level security;

create table if not exists public.campaign_events (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  promotion_id uuid references public.promotions(id) on delete set null,
  booking_id uuid references public.bookings(id) on delete set null,
  event_type text not null check (event_type in ('view','scan','lead','order','redeem','whatsapp','demo_request')),
  source text,
  medium text,
  campaign text,
  content text,
  customer_phone text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.campaign_events enable row level security;

create table if not exists public.memberships (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  customer_id uuid not null references public.customers(id) on delete cascade,
  member_no text,
  tier text not null default 'guest' check (tier in ('guest','basic','member','vip','vvip','corporate')),
  status text not null default 'active' check (status in ('active','inactive','expired','blocked')),
  points integer not null default 0,
  started_at timestamptz not null default now(),
  expires_at timestamptz,
  notes text,
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, customer_id)
);

alter table public.memberships enable row level security;

create or replace function public.rangeflow_pin_ok(
  p_org_id uuid,
  p_pin text,
  p_role_keys text[]
)
returns boolean
language sql
security definer
set search_path = public
as $$
  select exists (
    select 1
    from public.org_access_pins p
    where p.org_id = p_org_id
      and p.role_key = any(p_role_keys)
      and crypt(trim(coalesce(p_pin,'')), p.pin_hash) = p.pin_hash
  );
$$;

revoke all on function public.rangeflow_pin_ok(uuid,text,text[]) from public;
grant execute on function public.rangeflow_pin_ok(uuid,text,text[]) to anon, authenticated;

create or replace function public.get_operations_promotions(
  p_org_slug text,
  p_access_pin text
)
returns table (
  id uuid,
  code text,
  name text,
  description text,
  discount_type text,
  discount_value numeric,
  min_order_amount numeric,
  active boolean,
  campaign_source text,
  usage_limit integer,
  used_count integer,
  starts_at timestamptz,
  ends_at timestamptz
)
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
begin
  select o.id into v_org_id from public.orgs o where o.slug = p_org_slug limit 1;
  if v_org_id is null then raise exception 'Organization not found.'; end if;
  if not public.rangeflow_pin_ok(v_org_id, p_access_pin, array['staff','owner']) then
    raise exception 'Invalid staff or owner PIN.';
  end if;

  return query
  select p.id, p.code, p.name, p.description, p.discount_type, p.discount_value,
         p.min_order_amount, p.active, p.campaign_source, p.usage_limit, p.used_count,
         p.starts_at, p.ends_at
  from public.promotions p
  where p.org_id = v_org_id
  order by p.created_at desc;
end;
$$;

grant execute on function public.get_operations_promotions(text,text) to anon, authenticated;

create or replace function public.save_operations_promotion(
  p_org_slug text,
  p_owner_pin text,
  p_code text,
  p_name text,
  p_description text,
  p_discount_type text,
  p_discount_value numeric,
  p_min_order_amount numeric,
  p_active boolean,
  p_campaign_source text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_promo_id uuid;
begin
  select o.id into v_org_id from public.orgs o where o.slug = p_org_slug limit 1;
  if v_org_id is null then return jsonb_build_object('ok', false, 'message', 'Organization not found.'); end if;
  if not public.rangeflow_pin_ok(v_org_id, p_owner_pin, array['owner']) then
    return jsonb_build_object('ok', false, 'message', 'Invalid owner PIN.');
  end if;
  if trim(coalesce(p_code,'')) = '' or trim(coalesce(p_name,'')) = '' then
    return jsonb_build_object('ok', false, 'message', 'Promotion code and name are required.');
  end if;

  insert into public.promotions (
    org_id, code, name, description, discount_type, discount_value,
    min_order_amount, active, campaign_source, updated_at
  ) values (
    v_org_id, upper(trim(p_code)), trim(p_name), nullif(trim(coalesce(p_description,'')), ''),
    coalesce(p_discount_type, 'fixed'), coalesce(p_discount_value, 0),
    coalesce(p_min_order_amount, 0), coalesce(p_active, true), nullif(trim(coalesce(p_campaign_source,'')), ''), now()
  )
  on conflict (org_id, code) do update set
    name = excluded.name,
    description = excluded.description,
    discount_type = excluded.discount_type,
    discount_value = excluded.discount_value,
    min_order_amount = excluded.min_order_amount,
    active = excluded.active,
    campaign_source = excluded.campaign_source,
    updated_at = now()
  returning id into v_promo_id;

  return jsonb_build_object('ok', true, 'promotion_id', v_promo_id, 'message', 'Promotion saved.');
end;
$$;

grant execute on function public.save_operations_promotion(text,text,text,text,text,text,numeric,numeric,boolean,text) to anon, authenticated;

create or replace function public.create_counter_sale(
  p_org_slug text,
  p_staff_pin text,
  p_customer_name text,
  p_customer_phone text,
  p_payment_method text,
  p_items jsonb,
  p_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_location_id uuid;
  v_bay_id uuid;
  v_customer_id uuid;
  v_booking_id uuid;
  v_qr_token text;
  v_total numeric := 0;
  v_line jsonb;
  v_menu record;
  v_qty integer;
  v_type text;
begin
  select o.id into v_org_id from public.orgs o where o.slug = p_org_slug limit 1;
  if v_org_id is null then return jsonb_build_object('ok', false, 'message', 'Organization not found.'); end if;
  if not public.rangeflow_pin_ok(v_org_id, p_staff_pin, array['staff','owner']) then
    return jsonb_build_object('ok', false, 'message', 'Invalid staff or owner PIN.');
  end if;

  select l.id into v_location_id from public.locations l where l.org_id = v_org_id and l.active = true order by l.created_at asc limit 1;
  if v_location_id is null then return jsonb_build_object('ok', false, 'message', 'Active location not found.'); end if;

  select b.id into v_bay_id from public.bays b where b.location_id = v_location_id and b.status = 'active' order by b.position asc, b.code asc limit 1;
  if v_bay_id is null then return jsonb_build_object('ok', false, 'message', 'Active bay not found.'); end if;

  if p_items is null or jsonb_typeof(p_items) <> 'array' or jsonb_array_length(p_items) = 0 then
    return jsonb_build_object('ok', false, 'message', 'No POS items selected.');
  end if;

  if nullif(trim(coalesce(p_customer_phone,'')), '') is not null then
    insert into public.customers (org_id, phone, full_name, last_seen_at)
    values (v_org_id, trim(p_customer_phone), nullif(trim(coalesce(p_customer_name,'')), ''), now())
    on conflict (org_id, phone) do update set full_name = coalesce(excluded.full_name, public.customers.full_name), last_seen_at = now()
    returning id into v_customer_id;
  end if;

  for v_line in select * from jsonb_array_elements(p_items) loop
    v_qty := greatest(1, coalesce((v_line->>'quantity')::integer, 1));
    select m.* into v_menu
    from public.menu_items m
    where m.id = (v_line->>'menu_item_id')::uuid
      and m.location_id = v_location_id
      and m.available = true
    limit 1;
    if v_menu.id is null then
      return jsonb_build_object('ok', false, 'message', 'One selected item is not available.');
    end if;
    v_total := v_total + (v_qty * v_menu.price);
  end loop;

  insert into public.bookings (
    location_id, bay_id, customer_id, customer_phone, customer_name,
    status, payment_status, bucket_qty, unit_price, subtotal, discount_amount,
    total_amount, source, notes, paid_at
  ) values (
    v_location_id, v_bay_id, v_customer_id, nullif(trim(coalesce(p_customer_phone,'')), ''), nullif(trim(coalesce(p_customer_name,'')), ''),
    'completed', 'paid', 0, 0, v_total, 0, v_total, 'counter', p_note, now()
  ) returning id, qr_token into v_booking_id, v_qr_token;

  insert into public.payments (booking_id, amount, method, status, paid_at, gateway, gateway_ref)
  values (v_booking_id, v_total, coalesce(nullif(p_payment_method,''), 'cash'), 'paid', now(), 'pos_lite', v_qr_token);

  for v_line in select * from jsonb_array_elements(p_items) loop
    v_qty := greatest(1, coalesce((v_line->>'quantity')::integer, 1));
    select m.* into v_menu from public.menu_items m where m.id = (v_line->>'menu_item_id')::uuid limit 1;
    v_type := case when v_menu.category in ('equipment','golf') then 'merch' when v_menu.category = 'bucket' then 'bucket' else 'fb' end;

    insert into public.orders (booking_id, type, item_name, quantity, unit_price, subtotal, status, menu_item_id, completed_at)
    values (v_booking_id, v_type, v_menu.name, v_qty, v_menu.price, v_qty * v_menu.price, 'completed', v_menu.id, now());

    if coalesce(v_menu.stock_tracked, false) then
      insert into public.stock_movements (location_id, menu_item_id, booking_id, movement_type, quantity, before_qty, after_qty, note)
      values (v_location_id, v_menu.id, v_booking_id, 'sale', v_qty, v_menu.stock_qty, greatest(0, v_menu.stock_qty - v_qty), 'POS Lite sale');
      update public.menu_items set stock_qty = greatest(0, stock_qty - v_qty), updated_at = now() where id = v_menu.id;
    end if;
  end loop;

  return jsonb_build_object('ok', true, 'booking_id', v_booking_id, 'qr_token', v_qr_token, 'total_amount', v_total, 'message', 'Counter sale completed.');
end;
$$;

grant execute on function public.create_counter_sale(text,text,text,text,text,jsonb,text) to anon, authenticated;

create or replace function public.get_operations_member_summary(
  p_org_slug text,
  p_owner_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_result jsonb;
begin
  select o.id into v_org_id from public.orgs o where o.slug = p_org_slug limit 1;
  if v_org_id is null then return jsonb_build_object('ok', false, 'message', 'Organization not found.'); end if;
  if not public.rangeflow_pin_ok(v_org_id, p_owner_pin, array['owner']) then
    return jsonb_build_object('ok', false, 'message', 'Invalid owner PIN.');
  end if;

  select jsonb_build_object(
    'ok', true,
    'total_customers', count(c.id),
    'active_members', count(m.id) filter (where m.status = 'active'),
    'vip_members', count(m.id) filter (where m.tier in ('vip','vvip')),
    'members', coalesce(jsonb_agg(jsonb_build_object(
      'customer_id', c.id,
      'name', c.full_name,
      'phone', c.phone,
      'last_seen_at', c.last_seen_at,
      'tier', coalesce(m.tier, 'guest'),
      'status', coalesce(m.status, 'inactive'),
      'points', coalesce(m.points, 0),
      'expires_at', m.expires_at
    ) order by c.last_seen_at desc) filter (where c.id is not null), '[]'::jsonb)
  ) into v_result
  from public.customers c
  left join public.memberships m on m.customer_id = c.id and m.org_id = c.org_id
  where c.org_id = v_org_id;

  return v_result;
end;
$$;

grant execute on function public.get_operations_member_summary(text,text) to anon, authenticated;
