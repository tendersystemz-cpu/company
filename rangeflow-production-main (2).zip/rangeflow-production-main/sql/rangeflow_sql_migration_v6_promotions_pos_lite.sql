-- RangeFlow V6: Promotion Campaigns + POS Lite foundation
-- Review and apply through Supabase SQL Editor or migration pipeline.

create table if not exists public.campaigns (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  name text not null,
  platform text not null default 'manual' check (platform in ('facebook','instagram','tiktok','google','whatsapp','walk_in','manual','other')),
  objective text not null default 'orders' check (objective in ('awareness','leads','orders','membership','event','retention')),
  status text not null default 'draft' check (status in ('draft','active','paused','completed','archived')),
  source_code text not null,
  start_at timestamptz,
  end_at timestamptz,
  budget_amount numeric default 0,
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, source_code)
);

create table if not exists public.promotion_codes (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  code text not null,
  description text,
  discount_type text not null default 'fixed' check (discount_type in ('fixed','percent','free_item')),
  discount_value numeric not null default 0,
  min_order_amount numeric not null default 0,
  max_uses integer,
  uses_count integer not null default 0,
  active boolean not null default true,
  valid_from timestamptz,
  valid_to timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, code)
);

create table if not exists public.promotion_redemptions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  promotion_code_id uuid references public.promotion_codes(id) on delete set null,
  booking_id uuid references public.bookings(id) on delete set null,
  customer_phone text,
  discount_amount numeric not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.campaign_events (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  campaign_id uuid references public.campaigns(id) on delete set null,
  event_type text not null check (event_type in ('view','qr_scan','lead','order_created','payment_submitted','paid','redeemed')),
  booking_id uuid references public.bookings(id) on delete set null,
  bay_id uuid references public.bays(id) on delete set null,
  customer_phone text,
  metadata jsonb not null default '{}',
  created_at timestamptz not null default now()
);

create table if not exists public.pos_sales (
  id uuid primary key default gen_random_uuid(),
  location_id uuid not null references public.locations(id) on delete cascade,
  org_id uuid not null references public.orgs(id) on delete cascade,
  sale_no text not null default upper(substring(replace(gen_random_uuid()::text, '-', '') from 1 for 8)),
  customer_name text,
  customer_phone text,
  payment_method text not null default 'cash' check (payment_method in ('cash','duitnow_qr','tng','bank_transfer','card','manual_qr','other')),
  subtotal numeric not null default 0,
  discount_amount numeric not null default 0,
  total_amount numeric not null default 0,
  status text not null default 'paid' check (status in ('draft','paid','voided','refunded')),
  source text not null default 'counter',
  staff_name text,
  note text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.pos_sale_items (
  id uuid primary key default gen_random_uuid(),
  pos_sale_id uuid not null references public.pos_sales(id) on delete cascade,
  menu_item_id uuid references public.menu_items(id) on delete set null,
  item_name text not null,
  category text,
  quantity integer not null default 1,
  unit_price numeric not null default 0,
  subtotal numeric not null default 0,
  created_at timestamptz not null default now()
);

alter table public.campaigns enable row level security;
alter table public.promotion_codes enable row level security;
alter table public.promotion_redemptions enable row level security;
alter table public.campaign_events enable row level security;
alter table public.pos_sales enable row level security;
alter table public.pos_sale_items enable row level security;

-- Keep direct table access restricted. Client apps should use security definer RPCs.
revoke all on public.campaigns from anon, authenticated;
revoke all on public.promotion_codes from anon, authenticated;
revoke all on public.promotion_redemptions from anon, authenticated;
revoke all on public.campaign_events from anon, authenticated;
revoke all on public.pos_sales from anon, authenticated;
revoke all on public.pos_sale_items from anon, authenticated;

-- Critical advisory remediation review: stock_movements should have RLS enabled.
-- If existing RPCs are security definer, enabling this should be safe for direct table access.
alter table public.stock_movements enable row level security;

drop function if exists public.get_operations_promotion_summary(text);
create or replace function public.get_operations_promotion_summary(p_org_slug text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_result jsonb;
begin
  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;
  if v_org_id is null then
    return jsonb_build_object('campaigns', '[]'::jsonb, 'codes', '[]'::jsonb, 'events_today', 0);
  end if;

  select jsonb_build_object(
    'campaigns', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', c.id,
        'name', c.name,
        'platform', c.platform,
        'objective', c.objective,
        'status', c.status,
        'source_code', c.source_code,
        'budget_amount', c.budget_amount,
        'events', coalesce((select count(*) from public.campaign_events e where e.campaign_id = c.id), 0),
        'orders', coalesce((select count(*) from public.campaign_events e where e.campaign_id = c.id and e.event_type = 'order_created'), 0)
      ) order by c.created_at desc)
      from public.campaigns c where c.org_id = v_org_id
    ), '[]'::jsonb),
    'codes', coalesce((
      select jsonb_agg(jsonb_build_object(
        'id', p.id,
        'code', p.code,
        'description', p.description,
        'discount_type', p.discount_type,
        'discount_value', p.discount_value,
        'active', p.active,
        'uses_count', p.uses_count,
        'max_uses', p.max_uses
      ) order by p.created_at desc)
      from public.promotion_codes p where p.org_id = v_org_id
    ), '[]'::jsonb),
    'events_today', coalesce((select count(*) from public.campaign_events e where e.org_id = v_org_id and e.created_at::date = current_date), 0)
  ) into v_result;

  return v_result;
end;
$$;

drop function if exists public.save_operations_campaign(text,uuid,text,text,text,text,text,timestamptz,timestamptz,numeric,text);
create or replace function public.save_operations_campaign(
  p_org_slug text,
  p_campaign_id uuid,
  p_name text,
  p_platform text,
  p_objective text,
  p_status text,
  p_source_code text,
  p_start_at timestamptz,
  p_end_at timestamptz,
  p_budget_amount numeric,
  p_notes text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_id uuid;
begin
  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;
  if v_org_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization not found.');
  end if;
  if trim(coalesce(p_name,'')) = '' then
    return jsonb_build_object('ok', false, 'message', 'Campaign name is required.');
  end if;

  if p_campaign_id is null then
    insert into public.campaigns (org_id, name, platform, objective, status, source_code, start_at, end_at, budget_amount, notes)
    values (v_org_id, p_name, coalesce(p_platform,'manual'), coalesce(p_objective,'orders'), coalesce(p_status,'draft'), lower(regexp_replace(coalesce(nullif(p_source_code,''), p_name), '[^a-zA-Z0-9]+', '-', 'g')), p_start_at, p_end_at, coalesce(p_budget_amount,0), p_notes)
    returning id into v_id;
  else
    update public.campaigns set
      name = p_name,
      platform = coalesce(p_platform, platform),
      objective = coalesce(p_objective, objective),
      status = coalesce(p_status, status),
      source_code = lower(regexp_replace(coalesce(nullif(p_source_code,''), source_code), '[^a-zA-Z0-9]+', '-', 'g')),
      start_at = p_start_at,
      end_at = p_end_at,
      budget_amount = coalesce(p_budget_amount,0),
      notes = p_notes,
      updated_at = now()
    where id = p_campaign_id and org_id = v_org_id
    returning id into v_id;
  end if;

  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

drop function if exists public.save_operations_promotion_code(text,uuid,uuid,text,text,text,numeric,numeric,integer,boolean,timestamptz,timestamptz);
create or replace function public.save_operations_promotion_code(
  p_org_slug text,
  p_code_id uuid,
  p_campaign_id uuid,
  p_code text,
  p_description text,
  p_discount_type text,
  p_discount_value numeric,
  p_min_order_amount numeric,
  p_max_uses integer,
  p_active boolean,
  p_valid_from timestamptz,
  p_valid_to timestamptz
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_id uuid;
begin
  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;
  if v_org_id is null then return jsonb_build_object('ok', false, 'message', 'Organization not found.'); end if;
  if trim(coalesce(p_code,'')) = '' then return jsonb_build_object('ok', false, 'message', 'Promo code is required.'); end if;

  if p_code_id is null then
    insert into public.promotion_codes (org_id, campaign_id, code, description, discount_type, discount_value, min_order_amount, max_uses, active, valid_from, valid_to)
    values (v_org_id, p_campaign_id, upper(trim(p_code)), p_description, coalesce(p_discount_type,'fixed'), coalesce(p_discount_value,0), coalesce(p_min_order_amount,0), p_max_uses, coalesce(p_active,true), p_valid_from, p_valid_to)
    returning id into v_id;
  else
    update public.promotion_codes set
      campaign_id = p_campaign_id,
      code = upper(trim(p_code)),
      description = p_description,
      discount_type = coalesce(p_discount_type, discount_type),
      discount_value = coalesce(p_discount_value, 0),
      min_order_amount = coalesce(p_min_order_amount, 0),
      max_uses = p_max_uses,
      active = coalesce(p_active, true),
      valid_from = p_valid_from,
      valid_to = p_valid_to,
      updated_at = now()
    where id = p_code_id and org_id = v_org_id
    returning id into v_id;
  end if;

  return jsonb_build_object('ok', true, 'id', v_id);
end;
$$;

drop function if exists public.create_operations_pos_sale(text,jsonb,text,text,text,text,numeric,text);
create or replace function public.create_operations_pos_sale(
  p_org_slug text,
  p_items jsonb,
  p_customer_name text,
  p_customer_phone text,
  p_payment_method text,
  p_staff_name text,
  p_discount_amount numeric,
  p_note text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_location_id uuid;
  v_sale_id uuid;
  v_item jsonb;
  v_menu public.menu_items%rowtype;
  v_qty integer;
  v_subtotal numeric := 0;
  v_line numeric := 0;
  v_total numeric := 0;
begin
  select o.id, l.id into v_org_id, v_location_id
  from public.orgs o
  join public.locations l on l.org_id = o.id and l.active = true
  where o.slug = p_org_slug
  limit 1;

  if v_org_id is null or v_location_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization/location not found.');
  end if;
  if p_items is null or jsonb_array_length(p_items) = 0 then
    return jsonb_build_object('ok', false, 'message', 'No POS items selected.');
  end if;

  insert into public.pos_sales (location_id, org_id, customer_name, customer_phone, payment_method, subtotal, discount_amount, total_amount, staff_name, note)
  values (v_location_id, v_org_id, p_customer_name, p_customer_phone, coalesce(p_payment_method,'cash'), 0, coalesce(p_discount_amount,0), 0, p_staff_name, p_note)
  returning id into v_sale_id;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty := greatest(1, coalesce((v_item->>'quantity')::integer, 1));
    select * into v_menu from public.menu_items where id = (v_item->>'menu_item_id')::uuid and location_id = v_location_id and available = true limit 1;
    if v_menu.id is null then
      raise exception 'Menu item not found or unavailable';
    end if;
    v_line := v_qty * coalesce(v_menu.price,0);
    v_subtotal := v_subtotal + v_line;

    insert into public.pos_sale_items (pos_sale_id, menu_item_id, item_name, category, quantity, unit_price, subtotal)
    values (v_sale_id, v_menu.id, v_menu.name, v_menu.category, v_qty, v_menu.price, v_line);

    if coalesce(v_menu.stock_tracked,false) then
      insert into public.stock_movements (location_id, menu_item_id, movement_type, quantity, before_qty, after_qty, note)
      values (v_location_id, v_menu.id, 'sale', v_qty, v_menu.stock_qty, greatest(0, v_menu.stock_qty - v_qty), 'POS Lite sale');
      update public.menu_items set stock_qty = greatest(0, stock_qty - v_qty), updated_at = now() where id = v_menu.id;
    end if;
  end loop;

  v_total := greatest(0, v_subtotal - coalesce(p_discount_amount,0));
  update public.pos_sales set subtotal = v_subtotal, discount_amount = coalesce(p_discount_amount,0), total_amount = v_total, updated_at = now() where id = v_sale_id;

  return jsonb_build_object('ok', true, 'sale_id', v_sale_id, 'subtotal', v_subtotal, 'total', v_total);
end;
$$;

grant execute on function public.get_operations_promotion_summary(text) to anon, authenticated;
grant execute on function public.save_operations_campaign(text,uuid,text,text,text,text,text,timestamptz,timestamptz,numeric,text) to anon, authenticated;
grant execute on function public.save_operations_promotion_code(text,uuid,uuid,text,text,text,numeric,numeric,integer,boolean,timestamptz,timestamptz) to anon, authenticated;
grant execute on function public.create_operations_pos_sale(text,jsonb,text,text,text,text,numeric,text) to anon, authenticated;
