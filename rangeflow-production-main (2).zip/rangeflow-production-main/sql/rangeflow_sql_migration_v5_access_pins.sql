create extension if not exists pgcrypto with schema extensions;

create table if not exists public.org_access_pins (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  role_key text not null check (role_key in ('staff','owner','runner','kitchen')),
  pin_hash text not null,
  updated_at timestamptz not null default now(),
  updated_by text,
  unique (org_id, role_key)
);

alter table public.org_access_pins enable row level security;

revoke all on public.org_access_pins from anon, authenticated;

drop function if exists public.verify_org_access_pin(text,text,text);
create or replace function public.verify_org_access_pin(
  p_org_slug text,
  p_role_key text,
  p_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_org_id uuid;
  v_pin_hash text;
  v_valid boolean := false;
begin
  if p_org_slug is null or trim(p_org_slug) = '' then
    return jsonb_build_object('ok', false, 'message', 'Missing org slug.');
  end if;

  if p_role_key not in ('staff','owner','runner','kitchen') then
    return jsonb_build_object('ok', false, 'message', 'Invalid role.');
  end if;

  if p_pin is null or length(trim(p_pin)) < 4 then
    return jsonb_build_object('ok', false, 'message', 'Invalid access code.');
  end if;

  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;

  if v_org_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization not found.');
  end if;

  select pin_hash into v_pin_hash
  from public.org_access_pins
  where org_id = v_org_id and role_key = p_role_key
  limit 1;

  if v_pin_hash is null then
    return jsonb_build_object('ok', false, 'message', 'Access code not configured.');
  end if;

  v_valid := extensions.crypt(trim(p_pin), v_pin_hash) = v_pin_hash;

  if not v_valid then
    return jsonb_build_object('ok', false, 'message', 'Access code tidak sah.');
  end if;

  return jsonb_build_object('ok', true, 'role_key', p_role_key, 'message', 'Access granted.');
end;
$$;

drop function if exists public.update_org_access_pin(text,text,text,text);
create or replace function public.update_org_access_pin(
  p_org_slug text,
  p_owner_pin text,
  p_role_key text,
  p_new_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public, extensions
as $$
declare
  v_org_id uuid;
  v_owner_hash text;
  v_owner_valid boolean := false;
begin
  if p_role_key not in ('staff','owner','runner','kitchen') then
    return jsonb_build_object('ok', false, 'message', 'Invalid role.');
  end if;

  if p_new_pin is null or length(trim(p_new_pin)) < 4 or length(trim(p_new_pin)) > 12 then
    return jsonb_build_object('ok', false, 'message', 'New access code must be 4 to 12 characters.');
  end if;

  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;

  if v_org_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization not found.');
  end if;

  select pin_hash into v_owner_hash
  from public.org_access_pins
  where org_id = v_org_id and role_key = 'owner'
  limit 1;

  if v_owner_hash is null then
    return jsonb_build_object('ok', false, 'message', 'Owner access code not configured.');
  end if;

  v_owner_valid := extensions.crypt(trim(p_owner_pin), v_owner_hash) = v_owner_hash;

  if not v_owner_valid then
    return jsonb_build_object('ok', false, 'message', 'Current owner access code tidak sah.');
  end if;

  insert into public.org_access_pins (org_id, role_key, pin_hash, updated_at, updated_by)
  values (v_org_id, p_role_key, extensions.crypt(trim(p_new_pin), extensions.gen_salt('bf')), now(), 'owner')
  on conflict (org_id, role_key)
  do update set pin_hash = excluded.pin_hash, updated_at = now(), updated_by = 'owner';

  return jsonb_build_object('ok', true, 'role_key', p_role_key, 'message', 'Access code updated.');
end;
$$;

grant execute on function public.verify_org_access_pin(text,text,text) to anon, authenticated;
grant execute on function public.update_org_access_pin(text,text,text,text) to anon, authenticated;

-- Demo seed for existing technical tenant. Display branding is generalized in UI.
insert into public.org_access_pins (org_id, role_key, pin_hash, updated_by)
select o.id, seed.role_key, extensions.crypt(seed.pin, extensions.gen_salt('bf')), 'seed'
from public.orgs o
cross join (values ('staff','2026'), ('owner','210672')) as seed(role_key, pin)
where o.slug = 'bukitunggul'
on conflict (org_id, role_key) do nothing;
