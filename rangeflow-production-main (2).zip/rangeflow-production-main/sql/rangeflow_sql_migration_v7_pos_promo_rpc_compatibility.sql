-- RangeFlow V7: RPC compatibility for existing POS Lite and Promotions UI
-- This migration bridges the UI routes already present in operations/app/pos and operations/app/promotions.
-- Apply after V6.

create extension if not exists pgcrypto;

-- Compatibility table for the existing Promotions UI if the older table name does not exist yet.
create table if not exists public.promotions (
  id uuid primary key default gen_random_uuid(),
  org_id uuid not null references public.orgs(id) on delete cascade,
  code text not null,
  name text not null,
  description text,
  discount_type text not null default 'fixed' check (discount_type in ('fixed','percent','bundle','free_item')),
  discount_value numeric not null default 0,
  min_order_amount numeric not null default 0,
  active boolean not null default true,
  campaign_source text,
  used_count integer not null default 0,
  usage_limit integer,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (org_id, code)
);

alter table public.promotions enable row level security;
revoke all on public.promotions from anon, authenticated;

-- Helper: verify staff or owner PIN.
drop function if exists public.rangeflow_verify_any_ops_pin(uuid,text);
create or replace function public.rangeflow_verify_any_ops_pin(
  p_org_id uuid,
  p_pin text
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  v_ok boolean := false;
begin
  if p_org_id is null or p_pin is null or length(trim(p_pin)) < 4 then
    return false;
  end if;

  select exists(
    select 1
    from public.org_access_pins p
    where p.org_id = p_org_id
      and p.role_key in ('staff','owner')
      and crypt(trim(p_pin), p.pin_hash) = p.pin_hash
  ) into v_ok;

  return coalesce(v_ok, false);
end;
$$;

-- Existing promotions page expects get_operations_promotions(p_org_slug, p_access_pin).
drop function if exists public.get_operations_promotions(text,text);
create or replace function public.get_operations_promotions(
  p_org_slug text,
  p_access_pin text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
begin
  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;
  if v_org_id is null then
    raise exception 'Organization not found.';
  end if;

  if not public.rangeflow_verify_any_ops_pin(v_org_id, p_access_pin) then
    raise exception 'PIN tidak sah.';
  end if;

  return coalesce((
    select jsonb_agg(jsonb_build_object(
      'id', id,
      'code', code,
      'name', name,
      'description', description,
      'discount_type', discount_type,
      'discount_value', discount_value,
      'min_order_amount', min_order_amount,
      'active', active,
      'campaign_source', campaign_source,
      'used_count', used_count,
      'usage_limit', usage_limit
    ) order by created_at desc)
    from public.promotions
    where org_id = v_org_id
  ), '[]'::jsonb);
end;
$$;

-- Existing promotions page expects save_operations_promotion(...).
drop function if exists public.save_operations_promotion(text,text,text,text,text,text,numeric,numeric,boolean,text);
create or replace function public.save_operations_promotion(
  p_org_slug text,
  p_owner_pin text,
  p_code text,
  p_name text,
  p_description text,
  p_discount_type text,
  p_discount_value numeric,
  p_min_order_amount numeric,
  p_active boolean,
  p_campaign_source text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_owner_hash text;
  v_id uuid;
begin
  select id into v_org_id from public.orgs where slug = p_org_slug limit 1;
  if v_org_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization not found.');
  end if;

  select pin_hash into v_owner_hash from public.org_access_pins where org_id = v_org_id and role_key = 'owner' limit 1;
  if v_owner_hash is null or crypt(trim(coalesce(p_owner_pin,'')), v_owner_hash) <> v_owner_hash then
    return jsonb_build_object('ok', false, 'message', 'Owner PIN tidak sah.');
  end if;

  if trim(coalesce(p_code,'')) = '' or trim(coalesce(p_name,'')) = '' then
    return jsonb_build_object('ok', false, 'message', 'Code and campaign name are required.');
  end if;

  insert into public.promotions (org_id, code, name, description, discount_type, discount_value, min_order_amount, active, campaign_source)
  values (
    v_org_id,
    upper(trim(p_code)),
    trim(p_name),
    p_description,
    coalesce(nullif(p_discount_type,''),'fixed'),
    coalesce(p_discount_value,0),
    coalesce(p_min_order_amount,0),
    coalesce(p_active,true),
    p_campaign_source
  )
  on conflict (org_id, code)
  do update set
    name = excluded.name,
    description = excluded.description,
    discount_type = excluded.discount_type,
    discount_value = excluded.discount_value,
    min_order_amount = excluded.min_order_amount,
    active = excluded.active,
    campaign_source = excluded.campaign_source,
    updated_at = now()
  returning id into v_id;

  return jsonb_build_object('ok', true, 'promotion_id', v_id, 'message', 'Promotion saved.');
end;
$$;

-- Existing POS Lite page expects create_counter_sale(...), returning booking_id/qr_token.
drop function if exists public.create_counter_sale(text,text,text,text,text,jsonb,text);
create or replace function public.create_counter_sale(
  p_org_slug text,
  p_staff_pin text,
  p_customer_name text,
  p_customer_phone text,
  p_payment_method text,
  p_items jsonb,
  p_note text
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  v_org_id uuid;
  v_location_id uuid;
  v_bay_id uuid;
  v_booking_id uuid;
  v_item jsonb;
  v_menu public.menu_items%rowtype;
  v_qty integer;
  v_subtotal numeric := 0;
  v_total numeric := 0;
  v_line numeric := 0;
  v_qr_token text;
begin
  select o.id, l.id into v_org_id, v_location_id
  from public.orgs o
  join public.locations l on l.org_id = o.id and l.active = true
  where o.slug = p_org_slug
  limit 1;

  if v_org_id is null or v_location_id is null then
    return jsonb_build_object('ok', false, 'message', 'Organization/location not found.');
  end if;

  if not public.rangeflow_verify_any_ops_pin(v_org_id, p_staff_pin) then
    return jsonb_build_object('ok', false, 'message', 'Staff / owner PIN tidak sah.');
  end if;

  if p_items is null or jsonb_array_length(p_items) = 0 then
    return jsonb_build_object('ok', false, 'message', 'No POS item selected.');
  end if;

  -- Use the first active bay as the counter-sale anchor so existing booking/order/reporting/print flow can be reused.
  select id into v_bay_id from public.bays where location_id = v_location_id and status = 'active' order by position, code limit 1;
  if v_bay_id is null then
    return jsonb_build_object('ok', false, 'message', 'No active bay available for counter sale anchor.');
  end if;

  insert into public.bookings (location_id, bay_id, customer_name, customer_phone, status, payment_status, bucket_qty, unit_price, subtotal, total_amount, source, notes, paid_at)
  values (v_location_id, v_bay_id, p_customer_name, p_customer_phone, 'completed', 'paid', 0, 0, 0, 0, 'counter', p_note, now())
  returning id, qr_token into v_booking_id, v_qr_token;

  for v_item in select * from jsonb_array_elements(p_items)
  loop
    v_qty := greatest(1, coalesce((v_item->>'quantity')::integer, 1));
    select * into v_menu from public.menu_items where id = (v_item->>'menu_item_id')::uuid and location_id = v_location_id and available = true limit 1;
    if v_menu.id is null then
      raise exception 'Menu item not found or unavailable';
    end if;

    v_line := v_qty * coalesce(v_menu.price,0);
    v_subtotal := v_subtotal + v_line;

    insert into public.orders (booking_id, type, item_name, quantity, unit_price, subtotal, status, menu_item_id)
    values (v_booking_id, case when v_menu.category in ('equipment') then 'merch' else 'fb' end, v_menu.name, v_qty, v_menu.price, v_line, 'completed', v_menu.id);

    if coalesce(v_menu.stock_tracked,false) then
      insert into public.stock_movements (location_id, menu_item_id, booking_id, movement_type, quantity, before_qty, after_qty, note)
      values (v_location_id, v_menu.id, v_booking_id, 'sale', v_qty, v_menu.stock_qty, greatest(0, v_menu.stock_qty - v_qty), 'POS Lite counter sale');
      update public.menu_items set stock_qty = greatest(0, stock_qty - v_qty), updated_at = now() where id = v_menu.id;
    end if;
  end loop;

  v_total := v_subtotal;
  update public.bookings set subtotal = v_subtotal, total_amount = v_total where id = v_booking_id;

  insert into public.payments (booking_id, amount, method, status, paid_at, gateway)
  values (v_booking_id, v_total, coalesce(p_payment_method,'cash'), 'paid', now(), 'pos_lite');

  return jsonb_build_object('ok', true, 'booking_id', v_booking_id, 'qr_token', v_qr_token, 'total_amount', v_total);
end;
$$;

grant execute on function public.rangeflow_verify_any_ops_pin(uuid,text) to anon, authenticated;
grant execute on function public.get_operations_promotions(text,text) to anon, authenticated;
grant execute on function public.save_operations_promotion(text,text,text,text,text,text,numeric,numeric,boolean,text) to anon, authenticated;
grant execute on function public.create_counter_sale(text,text,text,text,text,jsonb,text) to anon, authenticated;
