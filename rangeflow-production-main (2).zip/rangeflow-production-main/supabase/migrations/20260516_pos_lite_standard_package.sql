-- RangeFlow POS Lite / Basic Stock Tracking
-- Standard Package upgrade
-- Date: 2026-05-16

begin;

alter table public.menu_items
  add column if not exists subcategory text,
  add column if not exists stock_tracked boolean default false,
  add column if not exists stock_qty integer default 0,
  add column if not exists low_stock_qty integer default 0,
  add column if not exists print_station text default 'delivery',
  add column if not exists pos_enabled boolean default true;

update public.menu_items
set subcategory = coalesce(subcategory,
  case
    when category = 'drink' then 'drink'
    when category = 'snack' then 'snack'
    when category = 'equipment' then 'golf_essential'
    when category = 'promo' then 'set_combo'
    else 'food'
  end),
  print_station = coalesce(print_station,
  case
    when category = 'bucket' then 'ball'
    when category in ('fb','food','snack','drink','promo','set') then 'kitchen'
    else 'delivery'
  end),
  stock_tracked = coalesce(stock_tracked, false),
  stock_qty = coalesce(stock_qty, 0),
  low_stock_qty = coalesce(low_stock_qty, 0),
  pos_enabled = coalesce(pos_enabled, true);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  location_id uuid not null references public.locations(id) on delete cascade,
  menu_item_id uuid not null references public.menu_items(id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  movement_type text not null check (movement_type in ('stock_in','sale','adjustment','wastage','return')),
  quantity integer not null,
  before_qty integer,
  after_qty integer,
  note text,
  created_at timestamptz default now()
);

create index if not exists idx_stock_movements_location_created on public.stock_movements(location_id, created_at desc);
create index if not exists idx_stock_movements_menu_item_created on public.stock_movements(menu_item_id, created_at desc);

commit;

create or replace function public.get_operations_menu_items(p_org_slug text default 'bukitunggul'::text)
returns jsonb
language sql
security definer
set search_path to 'public'
as $function$
  select coalesce(jsonb_agg(jsonb_build_object(
    'id', mi.id,
    'location_id', mi.location_id,
    'category', mi.category,
    'subcategory', mi.subcategory,
    'code', mi.code,
    'name', mi.name,
    'description', mi.description,
    'price', mi.price,
    'image_url', mi.image_url,
    'available', mi.available,
    'position', mi.position,
    'prep_time_min', mi.prep_time_min,
    'stock_tracked', coalesce(mi.stock_tracked, false),
    'stock_qty', coalesce(mi.stock_qty, 0),
    'low_stock_qty', coalesce(mi.low_stock_qty, 0),
    'print_station', coalesce(mi.print_station, 'delivery'),
    'pos_enabled', coalesce(mi.pos_enabled, true),
    'low_stock', case when coalesce(mi.stock_tracked, false) then coalesce(mi.stock_qty, 0) <= coalesce(mi.low_stock_qty, 0) else false end
  ) order by mi.category, mi.subcategory, mi.position, mi.name), '[]'::jsonb)
  from public.menu_items mi
  join public.locations l on l.id = mi.location_id
  join public.orgs o on o.id = l.org_id
  where o.slug = p_org_slug;
$function$;

create or replace function public.update_menu_item_pos_lite(
  p_org_slug text,
  p_item_id uuid,
  p_subcategory text default null,
  p_stock_tracked boolean default false,
  p_stock_qty integer default 0,
  p_low_stock_qty integer default 0,
  p_print_station text default 'delivery',
  p_pos_enabled boolean default true
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_location_id uuid;
  v_item public.menu_items%rowtype;
  v_print_station text;
begin
  select l.id into v_location_id
  from public.locations l
  join public.orgs o on o.id = l.org_id
  where o.slug = p_org_slug and l.active = true
  order by l.created_at asc
  limit 1;

  if v_location_id is null then
    raise exception 'LOCATION_NOT_FOUND';
  end if;

  v_print_station := lower(trim(coalesce(p_print_station, 'delivery')));
  if v_print_station not in ('ball','kitchen','delivery','counter','none') then
    v_print_station := 'delivery';
  end if;

  update public.menu_items
  set subcategory = nullif(trim(coalesce(p_subcategory, '')), ''),
      stock_tracked = coalesce(p_stock_tracked, false),
      stock_qty = greatest(coalesce(p_stock_qty, 0), 0),
      low_stock_qty = greatest(coalesce(p_low_stock_qty, 0), 0),
      print_station = v_print_station,
      pos_enabled = coalesce(p_pos_enabled, true),
      updated_at = now()
  where id = p_item_id
    and location_id = v_location_id
  returning * into v_item;

  if not found then
    raise exception 'MENU_ITEM_NOT_FOUND';
  end if;

  return to_jsonb(v_item);
end;
$function$;

create or replace function public.adjust_menu_item_stock(
  p_org_slug text,
  p_item_id uuid,
  p_quantity integer,
  p_movement_type text default 'adjustment',
  p_note text default null
)
returns jsonb
language plpgsql
security definer
set search_path to 'public'
as $function$
declare
  v_location_id uuid;
  v_before integer;
  v_after integer;
  v_type text;
begin
  select l.id into v_location_id
  from public.locations l
  join public.orgs o on o.id = l.org_id
  where o.slug = p_org_slug and l.active = true
  order by l.created_at asc
  limit 1;

  if v_location_id is null then
    raise exception 'LOCATION_NOT_FOUND';
  end if;

  v_type := lower(trim(coalesce(p_movement_type, 'adjustment')));
  if v_type not in ('stock_in','sale','adjustment','wastage','return') then
    raise exception 'INVALID_STOCK_MOVEMENT_TYPE';
  end if;

  select stock_qty into v_before
  from public.menu_items
  where id = p_item_id and location_id = v_location_id
  for update;

  if not found then
    raise exception 'MENU_ITEM_NOT_FOUND';
  end if;

  v_after := greatest(coalesce(v_before, 0) + coalesce(p_quantity, 0), 0);

  update public.menu_items
  set stock_qty = v_after,
      stock_tracked = true,
      updated_at = now()
  where id = p_item_id;

  insert into public.stock_movements(location_id, menu_item_id, movement_type, quantity, before_qty, after_qty, note)
  values (v_location_id, p_item_id, v_type, coalesce(p_quantity, 0), coalesce(v_before, 0), v_after, nullif(trim(coalesce(p_note, '')), ''));

  return jsonb_build_object('item_id', p_item_id, 'before_qty', coalesce(v_before, 0), 'after_qty', v_after, 'movement_type', v_type);
end;
$function$;
