create table if not exists public.ball_inventory_settings (
  id uuid primary key default gen_random_uuid(),
  location_id uuid not null references public.locations(id) on delete cascade,
  balls_per_bucket integer not null default 100,
  current_ball_stock integer not null default 0,
  low_stock_qty integer not null default 0,
  updated_at timestamptz not null default now(),
  unique(location_id)
);

create table if not exists public.ball_stock_movements (
  id uuid primary key default gen_random_uuid(),
  location_id uuid not null references public.locations(id) on delete cascade,
  movement_type text not null,
  quantity integer not null,
  before_qty integer not null default 0,
  after_qty integer not null default 0,
  note text,
  created_at timestamptz not null default now()
);
