-- RangeFlow BUCC public customer flow fix
-- Target route: /b/01
-- Org slug: bukitunggul

DROP POLICY IF EXISTS orgs_public_read_active ON public.orgs;
CREATE POLICY orgs_public_read_active
ON public.orgs
FOR SELECT
USING (status IN ('trial', 'active'));

DROP POLICY IF EXISTS locations_public_read_active ON public.locations;
CREATE POLICY locations_public_read_active
ON public.locations
FOR SELECT
USING (active = true);

DROP POLICY IF EXISTS bays_public_read_active ON public.bays;
CREATE POLICY bays_public_read_active
ON public.bays
FOR SELECT
USING (status = 'active');

DROP POLICY IF EXISTS pricing_public_read_active ON public.pricing_rules;
CREATE POLICY pricing_public_read_active
ON public.pricing_rules
FOR SELECT
USING (active = true);

DROP POLICY IF EXISTS menu_public_read_available ON public.menu_items;
CREATE POLICY menu_public_read_available
ON public.menu_items
FOR SELECT
USING (available = true);

-- Verification query
SELECT
  o.slug,
  o.name AS org_name,
  o.status AS org_status,
  l.name AS location_name,
  b.code AS bay_code,
  b.display_name AS bay_name,
  b.status AS bay_status
FROM public.orgs o
JOIN public.locations l ON l.org_id = o.id
JOIN public.bays b ON b.location_id = l.id
WHERE o.slug = 'bukitunggul'
  AND b.code = '01';
