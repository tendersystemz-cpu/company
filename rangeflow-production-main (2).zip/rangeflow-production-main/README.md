# EDGE RANGE OS

**Expert Digital Golf Ecosystem**

EDGE RANGE OS is a universal subscription-based operations platform for driving range operators.

It is designed as a SaaS operating system for owners/operators who want to manage customer bay ordering, staff counter workflow, payment verification, POS Lite, Stock Lite, menu/product setup, bay QR flow, owner dashboard, and protected access controls in one system.

---

## Product Position

EDGE RANGE OS is not a site-specific pilot and not a generic ecommerce order form.

The product must support many operators/tenants. Each operator configures their own:

- branding
- operating hours
- bay list and bay QR
- ball package names
- ball package pricing
- F&B / product menu
- POS Lite items
- stock thresholds
- payment QR / payment note
- staff/admin access
- owner access
- operating flow options

Operator-specific products, rates, names, and customer categories must come from Setup Wizard, Menu Management, POS Lite setup, or tenant database records. They must not be hardcoded into standard UI screens.

---

## Universal Operating Flow

A standard driving range flow should remain simple and realistic:

1. Customer arrives at the driving range.
2. Customer chooses an available bay or is assigned a bay by staff.
3. Staff may create the first counter-assisted order for that bay.
4. Customer pays using the operator's configured QR/payment instruction.
5. Staff verifies payment.
6. Customer self-picks up ready items or staff prepares fulfillment.
7. Customer starts playing.
8. Later, customer may scan the bay QR for add-on orders.
9. Bay QR order auto-detects the bay and allows `Self Pickup` or `Deliver to Bay` where enabled.
10. Payment page stays simple and should not require payer name, transaction ID, or screenshot upload as the default main flow.
11. Customer is told to keep payment proof if requested by staff.
12. Owner monitors operations through the owner dashboard.

---

## Repository Layout

```text
customer/       Next.js customer QR order/payment/receipt app
operations/     Next.js staff/admin/owner operations app
supabase/       SQL migrations and database notes
docs/           product documentation, deployment notes, pricing, legal and pitch assets
```

---

## Core Product Modules

### Customer

- Bay QR Order
- Payment page
- Receipt / Purchase Slip
- Self Pickup / Deliver to Bay option where enabled
- Need Help / Contact flow

### Admin / Staff

- Staff Counter
- Queue
- POS Lite
- Stock Lite
- Menu Management
- Payment Verification
- Print slips
- Bay release / operational handling

### Owner

- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control
- Setup Wizard for new owner/operator onboarding

---

## Branding Rule

Use the following as the main product identity:

```text
EDGE RANGE OS
Expert Digital Golf Ecosystem
```

Do not use any real venue/operator/client name as the main product identity.

The DG / EDGE monogram without crown is the master logo direction. Crown logo variants are reserved for premium/VIP/badge uses only.

---

## Important Product Rule

No standard EDGE RANGE OS module should hardcode:

- a specific driving range name
- a specific operator/client name
- ball package names
- student/staff/member rate names
- package prices
- F&B demo items
- fallback demo products

If an operator has not configured products yet, the UI should show a setup instruction that points them to Setup Wizard / Menu Management instead of showing fake fallback items.

---

## Current Source-of-Truth Docs

Read these before making further product or UI changes:

```text
docs/EDGE_RANGE_OS_INFOGRAPHIC_PACK.md
docs/EDGE_RANGE_OS_ADMIN_OWNER_COMPACT_UI_ALIGNMENT.md
docs/EDGE_RANGE_OS_KIV_WORKLOG.md
```

---

## Required Environment Variables

Customer app:

```text
NEXT_PUBLIC_SUPABASE_URL=<Supabase project URL>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<Supabase anon/publishable key>
NEXT_PUBLIC_ORG_SLUG=<operator tenant slug>
```

Operations app:

```text
NEXT_PUBLIC_SUPABASE_URL=<Supabase project URL>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<Supabase anon/publishable key>
NEXT_PUBLIC_ORG_SLUG=<operator tenant slug>
NEXT_PUBLIC_CUSTOMER_BASE_URL=<customer app base URL>
```

---

## Deployment Notes / Example Tenant

This repository may contain historical deployment references or example tenant notes from an earlier live deployment. Treat those details as deployment notes only, not as product identity.

Example tenant/deployment values may include:

```text
Supabase project ref: cgewjbfycnqbyczyuthp
Example org slug: drukm
Customer app deployment: Coolify customer QR ordering app
Operations app deployment: Coolify operations/admin app
```

These values should not be used as universal product branding.

---

## Production Acceptance Checklist

Before presenting EDGE RANGE OS as ready for an operator:

- Product identity shows EDGE RANGE OS.
- Customer pages do not expose admin/owner controls directly.
- Admin/Staff and Owner routes remain protected.
- Setup Wizard/Menu Management controls operator-specific product setup.
- Staff Counter and POS Lite use configured products only.
- Payment proof remains optional unless configured otherwise by the operator.
- Owner dashboard shows operational overview clearly on mobile.
- Universal navigation remains aligned with role-based access.
