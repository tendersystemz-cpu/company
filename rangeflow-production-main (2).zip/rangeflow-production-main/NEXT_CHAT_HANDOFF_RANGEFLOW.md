# Next Chat Handoff — RangeFlow / EDGE RangeFlow @ UKM

Last updated: 2026-05-28

Use this file when the current ChatGPT conversation becomes too full. The next chat must start from this handoff and the source-of-truth files in GitHub, not from memory.

## Required first action in next chat

Read these files first:

1. `PROJECT_STATE_RANGEFLOW.md`
2. `PROJECT_COST_LOCK.md`
3. `PROJECT_QUALITY_GATE.md`
4. `RANGEFLOW_SESSION_START_PROMPT.md`
5. `NEXT_CHAT_HANDOFF_RANGEFLOW.md`

## Project identity

- Product: EDGE RangeFlow / RangeFlow Standard Package
- Site: Driving Range @ UKM
- Operator: PRIMAVOC SDN. BHD.
- Supabase org slug: `drukm`
- Status: finishing/stabilization for serious production use, not demo/pilot wording

## Canonical apps only

Customer:

- Coolify app: `rangeflow-customer`
- URL: `http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io`
- Main test route: `/b/07/order`

Operations:

- Coolify app: `rangeflow-operations`
- URL: `http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io`
- Main routes: `/owner`, `/counter`, `/stock`, `/pos?bay=07`, `/menu`, `/payments`

Do not use or delete old duplicate Coolify apps without audit.

## Cost lock

No new paid tools, services, APIs, VPS, agents, platforms, or subscriptions.

Use existing stack only:

- GitHub repo
- existing Supabase project
- existing Coolify canonical customer/operations apps
- existing VPS/Coolify deployment

Do not drag in Netlify, Emergent, Claude/Cowork, Gemini Cloud API, OpenRouter, Vultr, OpenClaw, Hermes, or Telegram as required dependencies.

## Current emotional/business context

The user has spent too much money and time because the project has repeatedly failed to finish cleanly. The next assistant must not give long excuses, must not add complexity, and must not make the user carry technical burden. The user verifies visible behavior only.

## Current technical status from this chat

Already committed/created recently:

- `PROJECT_STATE_RANGEFLOW.md` updated with approved customer mobile order UI direction.
- `PROJECT_COST_LOCK.md` created.
- `PROJECT_QUALITY_GATE.md` created.
- `customer/lib/supabase.ts` locked `ORG_SLUG = 'drukm'`.
- Supabase legacy duplicate `create_customer_order(text,text,text,text,integer,jsonb)` overload was removed.
- Only `create_customer_order(text,text,text,text,integer,jsonb,text,text)` should remain.
- Supabase ball inventory RPC has been verified as returning `ok: true`, `currentBallStock: 10000`, `lowStockQty: 2000`, `ballsPerBucket: 100`.
- `/b/07/order` customer page was rebuilt toward compact premium UI in commit `7bcc552ea16b51ecf5f8a7180c4e6f8ab63c4d84`.

## Current next task

Finish and verify customer `/b/07/order` first.

The approved direction:

- compact premium mobile UI
- dark green/black RF header
- Add-on Order / Bay 07 title
- small Need Help pill
- compact 2x2 option selector: Walk-in RM12, UKM RM8, Self Pickup, Deliver to Bay
- optional contact as subtle single row only
- category chips
- dense product grid: 4 columns on normal mobile, 3 only on very narrow phone
- small product tiles, not giant cards
- compact sticky checkout bar, fully visible
- no childish spacing, no giant typography, no clipped elements

## Required next sequence

1. Rebuild canonical `rangeflow-customer` in Coolify.
2. Test live route: `http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io/b/07/order`.
3. User checks screenshot on iPhone.
4. If layout still fails, adjust only `customer/app/b/[bayCode]/order/page.tsx`.
5. Do not move to payment/receipt until `/b/07/order` visually passes.
6. After `/b/07/order` passes, test customer order creation, then `/pay/[bookingId]`, then `/receipt/[bookingId]`.
7. Only after customer flow passes, continue operations routes.

## Quality gate

A page is not done until:

- opens without server error
- correct app and `drukm`
- professional compact layout
- no oversized text/card/blank space
- flow works for non-technical customer/staff
- data saves to Supabase
- no old fallback/demo wording
- screenshot/user visible pass

## Starter prompt for next chat

Paste this:

```txt
Continue RangeFlow / EDGE RangeFlow @ UKM from GitHub only.
Before answering, read:
- PROJECT_STATE_RANGEFLOW.md
- PROJECT_COST_LOCK.md
- PROJECT_QUALITY_GATE.md
- RANGEFLOW_SESSION_START_PROMPT.md
- NEXT_CHAT_HANDOFF_RANGEFLOW.md

Do not continue from memory.
No new paid tools, no new app, no new deployment, no optional modules.
Canonical customer app only: rangeflow-customer.
Canonical operations app only: rangeflow-operations.
Current task: finish and verify customer /b/07/order compact premium UI.
One focused action at a time.
```
