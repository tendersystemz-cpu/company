# EDGE RANGE OS Infographic Pack

> Product documentation source for the BM and BI infographic set.
>
> This file locks the branding, positioning, page text, navigation structure, setup wizard explanation, and standard package scope for the universal SaaS product.

---

## 1. Brand Direction

### Product Name

**EDGE RANGE OS**

### Brand Meaning

**EDGE** = **Expert Digital Golf Ecosystem**

### Product Positioning

**EDGE RANGE OS** is a subscription-based operations platform for driving range operators.

It is designed as a universal SaaS product for any driving range operator who wants to digitize daily operations, simplify customer ordering, control counter workflow, manage products and stock, and monitor owner-level performance from one operating system.

The product must be positioned as a ready-to-subscribe standard platform, not as a site-specific pilot, trial identity, or custom one-off deployment.

### Product Axis Rule

Use **EDGE RANGE OS** as the main product axis across:

- Product documentation
- Infographics
- Pitch deck
- Owner onboarding
- Setup Wizard
- Customer-facing flow
- Staff/admin flow
- Owner dashboard flow
- Commercial subscription model

Avoid presenting the product identity using any real operator, venue, client name, or previous project shorthand as the main brand.

---

## 2. Logo Rule

### Master Logo

Use the **DG / EDGE monogram logo without crown** as the master product logo.

The master product logo direction:

- Clean DG / EDGE monogram
- No crown
- Premium but operational
- Suitable for SaaS, dashboard, QR, invoice, pitch deck, and product UI
- Works across customer, staff, owner, and super admin contexts

### Crown Logo Restriction

The crown version is **not** the standard master product logo.

The crown variant may only be used for:

- Premium badge
- VIP package
- Elite edition
- Special certification
- Founder/operator prestige variant
- Internal premium branding assets

It must not be used as the default logo for the standard EDGE RANGE OS product identity.

---

## 3. Infographic Pack Status

### Bahasa Malaysia Set

Completed infographic sequence:

1. Page 1 / 4 — EDGE RANGE OS introduction
2. Page 2 / 4 — Universal Header & Role-Based Navigation
3. Page 3 / 4 — Setup Wizard & Go-Live Flow
4. Page 4 / 4 — Standard Package & Subscription Model

### Bahasa English Set

Completed infographic sequence:

1. Page 1 / 4 — EDGE RANGE OS product introduction
2. Page 2 / 4 — Universal Header & Role-Based Navigation
3. Page 3 / 4 — Setup Wizard & Go-Live Flow
4. Page 4 / 4 — Standard Package & Subscription Model

---

## 4. Image References / Placeholders

Use these placeholder paths until final image assets are committed.

### BM Image Placeholders

| Page | Suggested File Path | Title |
|---|---|---|
| 1 / 4 | `docs/assets/edge-range-os-infographic-bm-01-introduction.png` | EDGE RANGE OS Introduction |
| 2 / 4 | `docs/assets/edge-range-os-infographic-bm-02-navigation.png` | Universal Header & Role-Based Navigation |
| 3 / 4 | `docs/assets/edge-range-os-infographic-bm-03-setup-wizard.png` | Setup Wizard & Go-Live Flow |
| 4 / 4 | `docs/assets/edge-range-os-infographic-bm-04-standard-package.png` | Standard Package & Subscription Model |

### BI Image Placeholders

| Page | Suggested File Path | Title |
|---|---|---|
| 1 / 4 | `docs/assets/edge-range-os-infographic-bi-01-introduction.png` | EDGE RANGE OS Product Introduction |
| 2 / 4 | `docs/assets/edge-range-os-infographic-bi-02-navigation.png` | Universal Header & Role-Based Navigation |
| 3 / 4 | `docs/assets/edge-range-os-infographic-bi-03-setup-wizard.png` | Setup Wizard & Go-Live Flow |
| 4 / 4 | `docs/assets/edge-range-os-infographic-bi-04-standard-package.png` | Standard Package & Subscription Model |

---

## 5. BM Infographic Set — Page-by-Page Text Content

### Page 1 / 4 — Pengenalan Produk

# EDGE RANGE OS

**Expert Digital Golf Ecosystem**

Platform operasi langganan untuk pengusaha driving range.

EDGE RANGE OS membantu operator menyusun operasi harian dalam satu sistem:

- Pesanan pelanggan melalui QR bay
- Kaunter dan queue staff
- POS Lite
- Menu dan produk
- Stok asas
- Semakan pembayaran
- Dashboard owner
- Report operasi
- Setup Wizard untuk onboarding operator baru

**Kedudukan produk:**

EDGE RANGE OS ialah sistem SaaS standard untuk semua pengusaha driving range yang mahu melanggan sistem operasi digital tanpa perlu membina sistem sendiri dari kosong.

**Prinsip utama:**

Satu platform. Banyak operator. Setiap operator boleh configure operasi mereka sendiri.

---

### Page 2 / 4 — Universal Header & Role-Based Navigation

# Universal Header & Role-Based Navigation

EDGE RANGE OS menggunakan satu struktur navigasi universal yang jelas, tetapi akses dikawal mengikut peranan.

Customer hanya nampak flow pelanggan.
Admin / Staff hanya masuk selepas akses sah.
Owner hanya masuk selepas akses owner sah.

## INTRODUCTION

- Home
- How It Works
- Rates / Pricing
- Contact / Help
- Share Link / QR Link
- Setup Wizard Owner 🔒

## CUSTOMER

- Bay Order
- Payment
- Receipt / Purchase Slip

## ADMIN / STAFF 🔒

- Counter
- Queue
- POS Lite
- Stock
- Menu Management
- Payment Verification

## OWNER 🔒

- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control

**Nota keselamatan:**

Customer pages tidak boleh expose admin/owner controls secara terus.
Admin/Staff dan Owner boleh kelihatan dalam navigation universal, tetapi mesti kekal protected/locked.

---

### Page 3 / 4 — Setup Wizard & Go-Live Flow

# Setup Wizard & Go-Live Flow

Setup Wizard ialah onboarding flow untuk owner/operator baru mengaktifkan EDGE RANGE OS mengikut operasi range masing-masing.

Setiap operator boleh configure:

- Branding
- Nama range
- Logo
- Warna tema
- Pricing
- Special pricing
- Access control
- Payment QR
- Menu/products
- Stock thresholds
- Bay QR
- Operating flow

## Cadangan Flow Setup Wizard

1. Create operator account / tenant
2. Set brand profile
3. Configure operating hours
4. Configure bay list and bay numbering
5. Set ball bucket pricing
6. Set F&B / product menu
7. Set POS Lite product categories
8. Set basic stock and low stock threshold
9. Upload payment QR
10. Configure staff and owner access
11. Generate range QR and bay QR
12. Test customer order
13. Test counter queue
14. Test payment verification
15. Go Live

**Matlamat Setup Wizard:**

Owner/operator boleh mula menggunakan sistem dengan konfigurasi sendiri tanpa perlu ubah kod asas produk.

---

### Page 4 / 4 — Standard Package & Subscription Model

# Standard Package & Subscription Model

EDGE RANGE OS dibina sebagai produk langganan SaaS untuk operator driving range.

## Standard Package

Standard Package perlu merangkumi operasi asas yang diperlukan untuk menjalankan driving range secara digital:

- Customer QR Bay Order
- Ball Bucket Order
- F&B / Product Order
- Payment QR instruction
- Receipt / Purchase Slip
- Staff Counter
- Queue Management
- Payment Verification
- POS Lite
- Product/Menu Management
- Basic Stock Tracking
- Low Stock Threshold
- Owner Dashboard
- Reports Control
- Setup Wizard
- Bay QR Management
- Basic Access Protection

## Subscription Model

Model komersial yang dicadangkan:

- License rental / subscription fee
- Utility usage or small platform usage component
- Minimum contract period
- Deposit / advance commitment
- Monthly, 6-month, or yearly billing option
- Subscription tied to each operator / tenant

## Add-On / Future Modules

Modul besar tidak perlu dimasukkan sebagai Standard Package awal. Ia boleh diletakkan sebagai add-on atau roadmap:

- Membership
- Advanced booking
- Coach booking
- Pro shop advanced module
- Multi-branch
- Loyalty
- Accounting export
- Payroll
- AI prediction
- CRM
- Warehouse inventory
- Full POS hardware integration

**Prinsip produk:**

Standard Package mesti cukup kuat untuk operasi harian, tetapi tidak terlalu berat sehingga onboarding operator menjadi perlahan.

---

## 6. BI Infographic Set — Page-by-Page Text Content

### Page 1 / 4 — Product Introduction

# EDGE RANGE OS

**Expert Digital Golf Ecosystem**

A subscription-based operations platform for driving range operators.

EDGE RANGE OS helps operators run daily range operations in one system:

- Customer bay QR ordering
- Staff counter and queue
- POS Lite
- Menu and products
- Basic stock control
- Payment verification
- Owner dashboard
- Operational reports
- Setup Wizard for new operator onboarding

**Product positioning:**

EDGE RANGE OS is a standard SaaS platform for driving range operators who want to subscribe to a digital operating system instead of building their own system from scratch.

**Core principle:**

One platform. Many operators. Each operator configures their own operation.

---

### Page 2 / 4 — Universal Header & Role-Based Navigation

# Universal Header & Role-Based Navigation

EDGE RANGE OS uses one clear universal navigation structure, while access remains controlled by role.

Customers only see the customer flow.
Admin / Staff access stays protected.
Owner access stays protected.

## INTRODUCTION

- Home
- How It Works
- Rates / Pricing
- Contact / Help
- Share Link / QR Link
- Setup Wizard Owner 🔒

## CUSTOMER

- Bay Order
- Payment
- Receipt / Purchase Slip

## ADMIN / STAFF 🔒

- Counter
- Queue
- POS Lite
- Stock
- Menu Management
- Payment Verification

## OWNER 🔒

- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control

**Security note:**

Customer pages must never expose admin or owner controls directly.
Admin/Staff and Owner sections may appear in the universal navigation, but they must remain protected/locked.

---

### Page 3 / 4 — Setup Wizard & Go-Live Flow

# Setup Wizard & Go-Live Flow

The Setup Wizard is the onboarding flow for a new owner/operator to activate EDGE RANGE OS according to their own range operation.

Each operator can configure:

- Branding
- Range name
- Logo
- Theme color
- Pricing
- Special pricing
- Access control
- Payment QR
- Menu/products
- Stock thresholds
- Bay QR
- Operating flow

## Suggested Setup Wizard Flow

1. Create operator account / tenant
2. Set brand profile
3. Configure operating hours
4. Configure bay list and bay numbering
5. Set ball bucket pricing
6. Set F&B / product menu
7. Set POS Lite product categories
8. Set basic stock and low stock threshold
9. Upload payment QR
10. Configure staff and owner access
11. Generate range QR and bay QR
12. Test customer order
13. Test counter queue
14. Test payment verification
15. Go Live

**Setup Wizard objective:**

The owner/operator can start using the system with their own configuration without changing the core product code.

---

### Page 4 / 4 — Standard Package & Subscription Model

# Standard Package & Subscription Model

EDGE RANGE OS is built as a SaaS subscription product for driving range operators.

## Standard Package

The Standard Package should include the core operations required to run a driving range digitally:

- Customer QR Bay Order
- Ball Bucket Order
- F&B / Product Order
- Payment QR instruction
- Receipt / Purchase Slip
- Staff Counter
- Queue Management
- Payment Verification
- POS Lite
- Product/Menu Management
- Basic Stock Tracking
- Low Stock Threshold
- Owner Dashboard
- Reports Control
- Setup Wizard
- Bay QR Management
- Basic Access Protection

## Subscription Model

Recommended commercial model:

- License rental / subscription fee
- Utility usage or small platform usage component
- Minimum contract period
- Deposit / advance commitment
- Monthly, 6-month, or yearly billing option
- Subscription tied to each operator / tenant

## Add-On / Future Modules

Large modules should not be forced into the initial Standard Package. They should remain as add-ons or roadmap items:

- Membership
- Advanced booking
- Coach booking
- Pro shop advanced module
- Multi-branch
- Loyalty
- Accounting export
- Payroll
- AI prediction
- CRM
- Warehouse inventory
- Full POS hardware integration

**Product principle:**

The Standard Package must be strong enough for daily operations, but not so heavy that operator onboarding becomes slow.

---

## 7. Universal Navigation Structure — Locked Reference

```text
INTRODUCTION
- Home
- How It Works
- Rates / Pricing
- Contact / Help
- Share Link / QR Link
- Setup Wizard Owner 🔒

CUSTOMER
- Bay Order
- Payment
- Receipt / Purchase Slip

ADMIN / STAFF 🔒
- Counter
- Queue
- POS Lite
- Stock
- Menu Management
- Payment Verification

OWNER 🔒
- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control
```

## Navigation Protection Rule

- Customer pages must remain clean and customer-only.
- Admin/Staff routes must require valid staff/admin access.
- Owner routes must require valid owner access.
- Setup Wizard Owner must be protected because it controls operator onboarding and product configuration.
- Universal navigation may show protected sections, but clicking protected sections must require access verification.

---

## 8. Setup Wizard Explanation — Product-Level Reference

The Setup Wizard is not a cosmetic form. It is the product onboarding engine for EDGE RANGE OS.

It should allow a new operator to become operational by configuring their own tenant environment:

1. **Tenant / Operator Setup**  
   Creates the operator workspace and subscription-linked operating environment.

2. **Branding Setup**  
   Allows the operator to configure logo, range name, theme, and customer-facing identity.

3. **Pricing Setup**  
   Defines bucket pricing, special pricing, customer category pricing, or time-based pricing where applicable.

4. **Bay Setup**  
   Defines bay numbers, bay labels, bay QR generation, and bay availability structure.

5. **Payment Setup**  
   Allows owner/operator to upload their own TNG/DuitNow/bank QR or payment instruction asset.

6. **Menu / Product Setup**  
   Configures ball buckets, drinks, food, rental items, and other sellable products.

7. **POS Lite / Stock Lite Setup**  
   Defines product categories, basic stock quantities, low stock thresholds, and basic counter-sale readiness.

8. **Access Setup**  
   Configures owner, admin, and staff access controls.

9. **Test Order Flow**  
   Runs a sample customer order, payment verification, queue processing, and receipt/purchase slip check.

10. **Go Live**  
    Activates the operator environment for real daily operation.

---

## 9. Standard Package Explanation — Product-Level Reference

The Standard Package is the sellable base package for EDGE RANGE OS.

It should not be framed as a limited demo. It should be framed as the core operating platform that can run a real driving range’s daily workflow.

### Included Core Layers

#### Customer Layer

- Bay QR order
- Ball bucket order
- F&B/product order
- Payment instruction
- Receipt / purchase slip
- Help/contact support entry point

#### Staff / Admin Layer

- Counter view
- Queue processing
- Payment verification
- POS Lite
- Stock Lite
- Menu management
- Pickup / delivery-to-bay operational handling where enabled

#### Owner Layer

- Owner dashboard
- Sales/revenue overview
- Reports control
- POS Lite control
- Stock Lite control
- Settings/access control

#### Setup / SaaS Layer

- Setup Wizard
- Tenant/operator configuration
- Branding configuration
- Payment QR configuration
- Bay QR generation
- Subscription-linked activation

---

## 10. Product Positioning Guardrails

Use this guardrail for all future documents, UI copy, pitch materials, and infographic revisions.

### Use

- EDGE RANGE OS
- Expert Digital Golf Ecosystem
- Universal driving range operations platform
- Subscription-based SaaS product
- Operator-configurable setup
- Role-based navigation
- Protected admin/staff and owner access
- Standard Package
- Product Add-Ons / Roadmap

### Avoid As Main Product Identity

- Any real venue name
- Any real operator name
- Any client-specific deployment name
- Any previous shorthand that makes the product look site-specific
- Any wording that makes the system look like a temporary pilot instead of a ready SaaS product

---

## 11. Next Documentation Tasks

Recommended next documentation files after this pack:

1. `docs/EDGE_RANGE_OS_STANDARD_PACKAGE_SCOPE.md`
2. `docs/EDGE_RANGE_OS_SETUP_WIZARD_SPEC.md`
3. `docs/EDGE_RANGE_OS_NAVIGATION_AND_ACCESS_RULES.md`
4. `docs/EDGE_RANGE_OS_SUBSCRIPTION_MODEL.md`
5. `docs/EDGE_RANGE_OS_BRAND_GUIDELINES.md`

These should extend this file without changing the locked product direction.
