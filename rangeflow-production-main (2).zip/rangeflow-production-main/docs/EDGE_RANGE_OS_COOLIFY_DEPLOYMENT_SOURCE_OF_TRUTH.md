# EDGE RANGE OS — Coolify Deployment Source of Truth

Last locked: 2026-05-29

This document exists to stop future assistants, Codex sessions, or operators from confusing duplicate Coolify applications with the live EDGE RANGE OS production deployment.

---

## 1. Product identity lock

Use this product identity everywhere as the platform brand:

- Product name: **EDGE RANGE OS**
- Meaning: **Expert Digital Golf Ecosystem**
- Product type: universal SaaS operations platform for driving range operators
- Do not position the platform as UKM, Prima Voc, RF, or RangeFlow as the main product identity.
- DG / EDGE monogram without crown is the master logo direction.
- Crown version is reserved only for premium, VIP, or badge variants.

Tenant/location names such as **Driving Range @ UKM** may appear as operator/location labels only. They must not replace the EDGE RANGE OS product brand.

---

## 2. GitHub source of truth

Repository:

```txt
duniabiz2udotcom/rangeflow-production
```

Branch:

```txt
main
```

Main app directories:

```txt
customer/     = customer QR/order/payment/receipt app
operations/   = owner/staff/counter/POS/admin operations app
docs/         = project source-of-truth documentation
```

Permanent fixes must be made in GitHub source first, then deployed through Coolify.

Do not treat `/root` on the VPS as the app source.
Do not treat `/app` inside a running Docker container as permanent source.
A container patch can disappear on the next redeploy.

Source-of-truth priority order:

```txt
1. GitHub source and docs
2. Coolify live production app configured from GitHub
3. Running Docker container inspection
4. Chat memory / assistant memory
```

---

## 3. Coolify project map

There are currently two visible Coolify project groups. This is the main cause of confusion.

### A. LIVE PRODUCTION — use this for real deployment

Coolify project:

```txt
My first project
```

Environment:

```txt
production
```

Live production applications:

```txt
rangeflow-customer
rangeflow-operations
```

Use these for the active live system unless explicitly changed by the owner.

Known live/customer URL pattern seen during verification:

```txt
http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io
```

Known operations/owner URL pattern seen during verification:

```txt
http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io/owner
```

Important: these generated hostnames may change after redeployment. Always check the application card / container labels in Coolify after deploy.

### B. DUPLICATE / STAGING / CODEX GENERATED — do not use as live source by default

Coolify project:

```txt
rangeOS
```

Environment:

```txt
production
```

Applications seen there are named like:

```txt
rangeflow-production:codex/complete-rangeflow-standard-pa...
```

Treat these as staging, duplicate, or generated Codex builds unless the owner explicitly promotes one of them.

Do not deploy, delete, or replace the live system using these cards without explicit confirmation.

---

## 4. Correct deployment workflow

When changing EDGE RANGE OS production:

1. Identify whether the change is for `customer/` or `operations/`.
2. Patch GitHub source on `main`.
3. Commit with a clear message.
4. Open Coolify.
5. Go to:

```txt
My first project → production
```

6. Redeploy only the matching app:

```txt
customer/ changes    → redeploy rangeflow-customer only
operations/ changes  → redeploy rangeflow-operations only
```

7. Do not press redeploy repeatedly.
8. Verify the new commit SHA in Coolify deployment history.
9. Open the live URL and verify the affected route.

Never redeploy all cards just because one app changed.

---

## 5. Current customer branding cleanup target

The live customer app was confirmed running, but old product wording still appeared in source and UI.

Source files requiring customer branding cleanup:

```txt
customer/app/page.tsx
customer/app/layout.tsx
customer/app/b/[bayCode]/order/page.tsx
customer/app/b/[bayCode]/page.tsx
customer/app/pay/[bookingId]/page.tsx
customer/app/receipt/[bookingId]/page.tsx
customer/lib/supabase.ts
customer/app/globals.css
```

Required branding direction:

```txt
Product/header brand: EDGE RANGE OS
Tenant/location label: Driving Range @ UKM, where context requires tenant display
Footer: Customer QR Order · EDGE RANGE OS
Metadata title: EDGE RANGE OS | QR Bay Ordering System
```

Avoid using these as product identity:

```txt
EDGE RangeFlow
RangeFlow @ UKM
RangeFlow | QR Bay Ordering System
RangeFlow home
```

---

## 6. Coolify queue incident recovery record

A Coolify deployment queue incident happened where many deployments were stuck/queued.

Observed issue:

```txt
Deployment queue full
27 deployments queued / in progress
```

`docker compose` inside `/data/coolify/source` failed because of an invalid `soketi` service entry:

```txt
service "soketi" has neither an image nor a build context specified: invalid compose project
```

Do not rely on this command in that condition:

```bash
cd /data/coolify/source && docker compose restart
```

Use direct Docker restart instead:

```bash
docker restart coolify coolify-redis coolify-realtime
```

Then check logs:

```bash
docker logs --tail=120 coolify
```

Successful cleanup messages seen:

```txt
Redis cleanup: deleted 196 items
Marked 27 stuck deployments as failed
Horizon started successfully.
```

After this, refresh Coolify UI and run only one redeploy.

---

## 7. VPS inspection commands

To identify active app containers without relying on friendly names:

```bash
docker ps --format "table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}" | grep -vE "coolify|postgres|redis|traefik|sentinel"
```

To inspect an application container's Coolify labels and route:

```bash
docker inspect <container_name> --format '{{range $k,$v := .Config.Labels}}{{println $k "=" $v}}{{end}}' | grep -Ei "traefik|fqdn|domain|url|coolify|host|rule"
```

Do not assume a container name contains `rangeflow`, `edge`, `customer`, or `operations`. Coolify may generate random container names.

---

## 8. Super Admin next priority

After production deployment/source confusion is resolved, the next product build priority remains:

```txt
Super Admin module
```

Scope:

- Tenant list
- Tenant/operator profile
- Package control
- Monthly fee
- Setup fee
- Deposit record
- Contract start/end
- Billing cycle
- Usage band or usage percentage
- Monthly billing statement
- Invoice/statement generation
- Payment received marking
- Overdue status
- Suspend tenant
- Reactivate tenant
- Owner read-only subscription visibility
- Super Admin audit log

Super Admin must be separate from the normal Owner Dashboard.
Owner must not control subscription status.
Super Admin controls activation, suspension, package, and billing.

---

## 9. Golden rule for future assistants

Before touching code or Coolify, read this document first.

If screenshots show multiple Coolify projects, use this rule:

```txt
Live production = My first project → production → rangeflow-customer / rangeflow-operations
rangeOS project = staging/duplicate unless explicitly promoted
```

If source and container disagree, patch GitHub source first.

If deployment queue is full, stop pressing deploy and clear the queue before redeploying.
