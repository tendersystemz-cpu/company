# RangeFlow Pilot Trial SOP

Updated: 2026-05-15

## Scope lock

This pilot is for the Standard Package only.

Included:

- Customer QR bay order
- Ball bucket order
- F&B order
- Payment proof submission
- Counter payment verification
- Print slip operation
- QR checkpoint delivery confirmation
- Owner payment/menu/access/dashboard flow

Not included in this pilot:

- POS stock for bottled drinks, boxed drinks, canned drinks, food stock
- Payment gateway integration
- Membership
- Advance booking
- Coach booking
- Pro shop
- Multi-branch
- Accounting or payroll

These are add-ons or later roadmap items.

## Main trial pages

Recommended entry:

```text
operations-site-url/
```

Pilot explanation page:

```text
operations-site-url/pilot
```

Staff pilot operation page:

```text
operations-site-url/counter
```

Delivery checkpoint page:

```text
operations-site-url/checkpoint
```

Use `/counter` for pilot staff operation. Keep `/queue` as the full/advanced queue page.

## Demo sequence

### 1. Customer Flow

Goal: prove customer can order from bay QR.

Steps:

1. Open Customer Bay.
2. Open Customer Order.
3. Select ball bucket and one F&B item.
4. Submit customer details.
5. Submit payment proof or payment reference.
6. Record order token.

Pass condition:

- Order appears in Counter Flow or Queue.
- Bay number is clear.
- Amount is correct.

### 2. Admin / Staff Flow

Goal: prove staff can process order securely.

Steps:

1. Open Counter Flow at `/counter`.
2. Find order by bay/token.
3. Verify payment.
4. Print required slips:
   - Ball Slip
   - Kitchen Slip
   - Delivery Slip
   - Full Slip if needed
5. Mark preparing if needed.
6. Open QR Checkpoint.

Pass condition:

- Staff can verify payment.
- Staff can print slip.
- Staff can open checkpoint route.

### 3. QR Checkpoint Flow

Goal: prove runner delivery is confirmed at the correct bay.

Steps:

1. Open QR Checkpoint.
2. Select paid order.
3. Press Start Delivery + Checkpoint.
4. Scan physical bay QR or use manual bay fallback.
5. Confirm delivery.

Pass condition:

- Wrong bay is blocked.
- Correct bay can confirm delivery.
- Booking/order status becomes delivered/completed.
- Delivery event is stored.

### 4. Owner Flow

Goal: prove owner can manage and monitor operation.

Steps:

1. Open Payment Setup.
2. Confirm payment instruction.
3. Open Menu / Product.
4. Confirm bucket/F&B item availability.
5. Open Access Settings.
6. Confirm owner/staff PIN.
7. Open Owner Dashboard.

Pass condition:

- Owner sees sales/order/bucket/bay usage.
- Owner can identify pending/completed order state.

## Feedback capture

Record only these fields during pilot:

- Bay number
- Order token
- What user tried to do
- What page they were on
- Screenshot if available
- Expected result
- Actual result

Do not discuss add-ons during bug triage.

## Client-facing message

RangeFlow Standard Package is focused on stabilizing the core driving range operation first:

Customer scans bay QR, orders ball bucket and F&B, submits payment proof, counter verifies payment, staff prints slips, runner delivers to bay, and owner monitors the operation.

POS stock and payment gateway are valid add-ons, but will be handled after Standard Package flow is stable.
