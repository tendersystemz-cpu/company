# Future Note: Customer Page Operator Message / Ad Space

## Purpose

The customer QR page should have space for operator messages, announcements, promotions, and upcoming activities.

This is especially useful during first launch so the customer page does not feel empty and can communicate real club/range activities.

## Use cases

Operator can display messages such as:

```text
Today promotion
Upcoming golf clinic
Driving range maintenance notice
New food and drink menu
Tournament announcement
Membership campaign
VVIP bay promotion
Coach availability
Rain/weather operation notice
Special bundle: bucket + drink
```

## Suggested placement

Customer route:

```text
/b/{bay_code}
```

Recommended placements:

```text
Top banner below club name
Promo card before order button
Rotating announcement section
Small footer notice
```

## Example customer page message

```text
Weekend Promo
Buy 2 buckets and get 1 mineral water at RM1.
Valid Saturday and Sunday, 7am - 12pm.
```

Another example:

```text
Upcoming Activity
Junior Golf Clinic this Sunday, 9:00am.
Register at the counter.
```

## Data model idea

Future table:

```text
announcements
```

Suggested fields:

```text
id
org_id
location_id
title
message
type
image_url
cta_label
cta_url
active
start_at
end_at
position
created_at
updated_at
```

Supported types:

```text
notice
promo
event
maintenance
membership
food_drink
coach
```

## Operations requirement

Operations/admin app should include:

```text
Operations -> Customer Messages / Announcements
```

Admin can:

1. Add announcement.
2. Edit title/message.
3. Add optional image.
4. Set start/end date.
5. Activate/deactivate.
6. Choose display type.
7. Choose position/order.
8. Preview how it looks on customer QR page.

## Customer behavior

Customer page should load only active announcements:

```text
active = true
start_at <= now or null
end_at >= now or null
```

The message must not block ordering. It should support promotion and communication, but customer can still proceed to order balls, food, and drinks quickly.

## Launch priority

Not required for the immediate transaction engine, but valuable before client-facing soft launch.

Recommended sequence:

1. Stabilize customer order + operations queue.
2. Menu management DIY.
3. Ball pricing DIY.
4. QR generator per bay.
5. Customer announcement/ad space.
6. Membership/VVIP campaign banners.
