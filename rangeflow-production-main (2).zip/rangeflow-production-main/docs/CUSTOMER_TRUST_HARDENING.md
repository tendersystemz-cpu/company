# Customer Trust Hardening Standard

## Purpose

This document locks the customer-facing trust layer for EDGE RangeFlow before live use.

The customer must feel:

- the page is official for the range operation
- the QR flow is simple
- payment instruction is clear
- receipt/status is reliable
- help is easy to request
- no confusing admin/owner functions are visible

## Customer Mindset

Customer does not care about system architecture.
Customer only needs to know:

1. I am at the correct bay.
2. I can order easily.
3. I can pay the correct amount.
4. Staff can verify my payment.
5. I can see receipt/status.
6. I can ask for help.

## Customer-Facing Wording Rules

Use simple BM/BI wording.

Preferred labels:

- Order / Pesan
- 100 Balls Bucket / Bucket 100 Bola
- Drinks / Minuman
- Food / Makanan
- Self Pickup / Ambil Sendiri
- Deliver to Bay / Hantar ke Bay
- Pay Exact Amount / Bayar Jumlah Tepat
- Show Payment Screen to Staff / Tunjuk Skrin Bayaran Kepada Staff
- Check Status / Semak Status
- Need Help / Perlu Bantuan

Avoid:

- demo
- pilot
- testing
- proof required
- upload proof before processing
- technical terms
- backend terms
- admin terms

## Customer Page Trust Elements

Customer order page should show:

- EDGE RangeFlow branding
- Bay number clearly
- 100-ball bucket wording
- clean item cards
- clear total amount
- Need Help floating button
- no admin/owner link

## Payment Page Trust Elements

Payment page should show:

- Bay number
- Order token
- Total amount
- TNG/DuitNow QR
- Pay exact amount instruction
- Show successful payment screen to staff instruction
- Proof upload only as optional fallback
- Check Status / Semak Status button

Payment page should not force proof upload as the main flow.

## Receipt / Status Trust Elements

Receipt page should show:

- Order token large and clear
- Bay number
- Payment status
- Order status
- Total amount
- Ordered items
- guidance based on status

If unpaid/unverified:

- Tell customer to show payment screen to staff.

If paid:

- Tell customer to collect item or wait for bay delivery.

Receipt/status should auto refresh.

## Need Help Trust Elements

Need Help button should:

- be visible without scrolling
- be easy to tap
- say Need Help / Perlu Bantuan
- notify Admin Operasi without WhatsApp dependency
- show success message after pressed

Admin must see:

- blinking bay
- help alert
- acknowledge action

## QR Sticker Trust Elements

Bay sticker should show:

- bay number
- EDGE RangeFlow
- Scan to Order / Imbas untuk Pesan
- Need Help / Perlu Bantuan
- TNG/DuitNow payment note
- PRIMAVOC SDN BHD where relevant
- Powered by EDGE Ecosystem

Do not print final QR sticker using sslip.io after custom domain is ready.

## Final Customer Trust Test

Test with a non-technical person.

Ask them to do this without explanation:

1. Open bay QR.
2. Order 1 bucket.
3. Find how to pay.
4. Find order status.
5. Request help.

Pass if they can complete it without asking more than one question.

## Pre-Live Customer Trust Checklist

- Customer page loads fast on phone.
- Bay number is obvious.
- 100 balls wording is visible.
- Total amount is obvious.
- Payment QR is clear.
- Payment instruction is short.
- Receipt/status is readable.
- Need Help is visible.
- No demo/testing/pilot wording.
- No admin/owner controls visible.
- No forced proof upload.
