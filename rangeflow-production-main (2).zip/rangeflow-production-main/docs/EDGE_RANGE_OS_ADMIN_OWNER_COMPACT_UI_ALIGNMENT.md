# EDGE RANGE OS — Admin / Owner Compact UI Alignment Spec

> Locked implementation reference for aligning Admin, Staff, Owner, POS Lite, Stock Lite, Customer/Membership Lite, Promotions Lite, Payment QR Setup, and Assisted Counter Order screens with the professional compact customer-view standard.

---

## 1. Purpose

Admin, Staff, and Owner screens must use the same compact, professional product language as the customer-facing pages.

The current direction is **EDGE RANGE OS** as a universal SaaS product for driving range operators. Internal dashboards must not look like disconnected demo modules. They must feel like one operating system with consistent header, spacing, navigation, cards, labels, and protected access behaviour.

---

## 2. Product Branding Rule

### Use as master product identity

```text
EDGE RANGE OS
Expert Digital Golf Ecosystem
```

### Do not use as main dashboard/product identity

- Site-specific range name
- Client/operator-specific name
- Pilot/deployment-specific label
- Legacy shorthand product name
- Any wording that makes the product look custom-only instead of universal SaaS

### Header brand treatment

Every Admin/Owner/Staff module should show:

```text
EDGE RANGE OS
```

or, where space is tight:

```text
EDGE OS
```

The range/operator name may appear only as tenant context, not product identity.

Example:

```text
EDGE RANGE OS
Operator Workspace
```

or:

```text
EDGE RANGE OS
Tenant: [Operator Name]
```

---

## 3. Visual Problem Seen From Current Admin / Owner Screens

The uploaded dashboard screenshots show these correction points:

1. Hero/header area is too tall for admin operations.
2. Admin/Owner pages still feel like large landing pages, not compact operational screens.
3. Protected owner/admin sections need clearer role-based access treatment.
4. Header copy is not yet aligned with the universal EDGE RANGE OS product axis.
5. Navigation buttons are inconsistent between modules.
6. Cards have too much vertical dead space on mobile.
7. Some text labels contain typos and must be corrected before production.
8. Operations pages must be easier to scan from mobile while staff are working at counter.

---

## 4. Compact UI Direction

### Required design feel

- Mobile-first
- Compact viewing
- Professional SaaS dashboard
- Same visual quality as customer order pages
- Fast operational scanning
- Clear role distinction
- Minimal wasted vertical space
- No oversized hero block on operational pages

### Header height rule

Admin/Owner operational pages should use a compact header, not a landing-page hero.

Recommended mobile header structure:

```text
[EDGE RANGE OS]
[Module Title]
[Short one-line description]
[Role badge / status badge]
```

The header should fit within the first mobile screen without pushing all useful data too far down.

### Avoid

- Very tall dark hero block on every operations screen
- Repeating large marketing copy inside operational modules
- Oversized card spacing that forces staff to scroll too much
- Module screens that look visually unrelated to customer pages

---

## 5. Universal Header Menu Structure With Route Mapping

This is the locked navigation reference for EDGE RANGE OS.

```text
INTRODUCTION
- Home                         → /
- How It Works                 → /#how-it-works
- Rates / Pricing              → /#rates
- Contact / Help               → /#help
- Share Link / QR Link         → /share or /qr
- Setup Wizard for New Owner 🔒 → operations /setup-wizard or /wizard

CUSTOMER
- Bay Order                    → /b/07/order
- Payment                      → /pay/[bookingId]
- Receipt / Purchase Slip      → /receipt/[bookingId]

ADMIN / STAFF 🔒
- Counter                      → operations /counter
- Queue                        → operations /counter or /queue
- POS Lite                     → operations /pos?bay=07
- Stock                        → operations /stock
- Menu Management              → operations /menu
- Payment Verification         → operations /payments

OWNER 🔒
- Owner Dashboard              → operations /owner
- POS Lite Control             → operations /pos
- Stock Lite Control           → operations /stock
- Reports Control              → operations /owner or /reports
- Settings / Access Control    → operations /access
```

---

## 6. Navigation Behaviour Rules

### Customer area

Customer pages must remain clean.

Customer pages must not directly expose:

- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control
- Payment Verification admin tools
- Staff counter tools

### Admin / Staff area

Admin/Staff routes must require valid staff/admin access before use.

Admin/Staff should see operational shortcuts relevant to work:

- Counter
- Queue
- POS Lite
- Stock
- Menu Management
- Payment Verification

### Owner area

Owner routes must require valid owner access before use.

Owner should see control and reporting tools:

- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access Control
- Setup Wizard where applicable

### Locked menu behaviour

Protected items may appear in the universal menu, but must show lock status and trigger access verification before opening.

---

## 7. Module-Specific UI Alignment

### 7.1 Promotions Lite

Purpose:

```text
Create campaign promo codes for posters, WhatsApp, social ads, and bay QR offers.
```

Required compact treatment:

- Header must use EDGE RANGE OS branding.
- Keep module title as `Promotions Lite`.
- Use compact stats cards: Loaded Campaigns, Active Campaigns, Expired/Inactive, Usage Today.
- Main CTA should be `Load Promotions` or `Create Promotion`, depending on actual function.
- Navigation buttons should align with universal menu: Owner, POS, Members, Counter.

### 7.2 Customer & Membership Lite

Purpose:

```text
Basic customer directory from QR/POS activity.
```

Required compact treatment:

- Header must use EDGE RANGE OS branding.
- Keep module title as `Customer & Membership Lite`.
- Owner-only access panel must be compact and clear.
- Correct typo: `Protected Customer Data`, not `Protetcted Customer Data`.
- Use simple stats cards: Total Customers, Active Members, Repeat Customers, Last Activity.
- Owner PIN unlock should be visually smaller and not dominate the page.

### 7.3 Stock Lite

Purpose:

```text
Ball inventory, F&B stock control, and low-stock monitoring.
```

Required compact treatment:

- Header must use EDGE RANGE OS branding.
- Correct typo: `inventory`, not `iventory`.
- Correct button label: `Refresh`, not `Refrsh`.
- Use compact stats cards: Ball Stock, Buckets Today, Expected Out, Low Stock Items.
- Keep operation shortcuts: Counter, Menu, POS, Refresh.
- Prioritize stock status above decorative content.

### 7.4 Assisted Counter Order / Bay Selection

Purpose:

```text
Staff-assisted first counter order or assisted add-on order by bay.
```

Required compact treatment:

- Bay selector should be clear and fast.
- Bay buttons should use compact 2-column grid on mobile.
- Selected bay card should show selected bay and order context.
- Cart should appear higher on mobile when items are added.
- POS item list should remain easy to tap from counter phone/tablet.

### 7.5 Payment QR Setup

Purpose:

```text
Manage merchant QR, customer payment note, and manual verification settings.
```

Required compact treatment:

- Header must use EDGE RANGE OS branding.
- Owner Control badge can remain, but should not become a huge hero element.
- Show payment configuration as simple cards:
  - Customer: Pay QR
  - Staff: Verify
  - Proof: Optional
  - QR Status: Uploaded / Missing
- Keep actions: Owner, Menu, Counter, Save Settings.
- Make clear that proof upload is optional unless operator requires it.

---

## 8. Typo and Copy Fix List

Before production, fix these text issues:

| Current / Problem | Correct Text |
|---|---|
| `Protetcted Customer Data` | `Protected Customer Data` |
| `Ball iventory` | `Ball inventory` |
| `Refrsh` | `Refresh` |
| `PROMOTIONS` card label can stay, but title should be visually aligned | `Promotions` |
| Overly large module intro copy | Short one-line operational description |

---

## 9. Compact Layout Specification

### Mobile container

Recommended:

```text
max-width: 430px
margin: 0 auto
padding: 14px to 18px
```

### Compact header

Recommended:

```text
border-radius: 22px to 28px
padding: 22px to 28px
margin-bottom: 14px to 18px
```

Do not use a very tall hero header for staff/owner operations.

### Module title

Recommended:

```text
font-size: 32px to 42px on mobile
line-height: 1.0 to 1.1
```

Use smaller size if title wraps too aggressively.

### Description

Recommended:

```text
font-size: 15px to 18px
line-height: 1.35
max 1 to 2 lines
```

### Action grid

Recommended:

```text
2 columns on mobile
button height: 52px to 62px
border-radius: 16px to 20px
gap: 10px to 12px
```

### Stat cards

Recommended:

```text
padding: 18px to 22px
border-radius: 18px to 24px
margin-bottom: 12px to 16px
```

Cards should show:

```text
Label
Main value
Short supporting note
```

---

## 10. Shared Admin / Owner Shell Requirement

All operations pages should use one shared shell instead of manually recreating inconsistent headers.

Suggested component names:

```text
OperationsShell
CompactModuleHeader
RoleNavGrid
StatCard
ProtectedAccessCard
```

### OperationsShell should handle

- EDGE RANGE OS brand label
- Tenant context if needed
- Compact page width
- Background color
- Safe mobile spacing
- Shared navigation section

### CompactModuleHeader should handle

- Product brand
- Module title
- One-line description
- Role/status badge
- Optional primary action

### RoleNavGrid should handle

- Universal route mapping
- Locked state
- Active module state
- Customer/Admin/Owner separation

---

## 11. Implementation Acceptance Criteria

The Admin/Owner UI patch is accepted only when all points below are true:

1. Admin/Owner/Staff pages show EDGE RANGE OS branding as product identity.
2. Site-specific/operator-specific label is not used as main product identity.
3. Header is compact and professional on mobile.
4. Operations content appears within the first mobile screen without excessive hero space.
5. Universal menu route mapping is implemented or documented in the shared route config.
6. Customer pages do not expose admin/owner controls directly.
7. Admin/Staff protected routes require staff/admin access.
8. Owner protected routes require owner access.
9. Payment proof remains optional unless configured otherwise by operator.
10. Typos listed in this document are fixed.
11. POS Lite, Stock Lite, Promotions Lite, Customer/Membership Lite, Payment QR Setup, and Assisted Counter Order visually align with the customer-view standard.

---

## 12. Next Coding Priority

Patch in this order:

1. Create shared compact operations shell.
2. Replace old oversized operations headers with compact module headers.
3. Replace legacy product label with EDGE RANGE OS.
4. Add universal navigation route mapping.
5. Fix typo/copy issues.
6. Apply compact stat card spacing.
7. Verify mobile screenshots for:
   - Promotions Lite
   - Customer & Membership Lite
   - Stock Lite
   - Assisted Counter Order
   - Payment QR Setup
   - Owner Dashboard
   - Counter / Queue

This spec should be followed before adding any new large module.
