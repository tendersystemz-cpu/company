# RangeFlow Production Readiness Checklist

## Purpose

This checklist tracks the final polish needed before EDGE RangeFlow is treated as commercial-ready for real operation.

## Locked Product Positioning

- Product name: EDGE RangeFlow
- Package: Standard Package
- Brand layer: Powered by EDGE Ecosystem
- Legal/operator context: Dunia Bizz Resources / PRIMAVOC where required
- Avoid customer-facing wording: pilot, demo, testing, temporary
- Do not claim official UKM system unless formal approval exists
- Acceptable wording: Driving Range @ UKM

## Customer Flow

Status: in progress / mostly aligned

Required:
- Customer sees only order, payment instruction, receipt/status and Need Help
- BM/BI key labels
- 1 bucket = 100 balls
- Walk-in RM12 / 100 balls
- UKM student/staff RM8 / 100 balls
- Need Help floating button
- Payment flow: Pay TNG/DuitNow exact amount, show successful screen, staff verify
- Proof upload optional fallback only
- Receipt/status auto-refresh
- No admin/owner function visible to customer

## Admin Operasi

Status: in progress / bay-centric page added

Required:
- Primary route: /staff-ops-bay
- Bay grid first
- Active bay 01-25
- Standby bay 26-30
- Need Help blinking alert
- Payment pending indicator
- Active order indicator
- Selected bay panel
- Add Order For Bay action
- Verify payment
- Preparing / delivered status
- Kitchen slip only when required
- Receipt optional
- Stock movement link

## Owner Master Control

Status: pending UI cleanup

Required:
- Report summary
- Pricing/menu control
- Payment QR upload
- QR bay management
- Inventory verification
- Access PIN
- Admin Ops monitor link
- Remove or de-emphasize advanced add-on clutter from Standard Package view
- Remove pilot/demo wording

## Payment Setup

Status: updated

Required:
- Owner can upload TNG QR image
- Owner can upload DuitNow QR image
- Owner can optionally paste QR image URL
- Customer payment note should say pay exact amount and show successful payment screen to staff
- Proof upload described as optional fallback only
- Merchant/payment name can show PRIMAVOC SDN BHD where relevant

## QR Bay Management

Status: updated

Required:
- Generate QR for each bay order page
- Sticker shows bay number
- Sticker shows Order / Pesan
- Sticker shows Need Help / Perlu Bantuan
- Sticker mentions bucket 100 balls
- Sticker includes TNG/DuitNow payment QR area/note
- Sticker includes EDGE RangeFlow / Powered by EDGE Ecosystem
- Regenerate QR after custom domain migration
- Avoid final customer sticker using sslip.io

## Inventory / Stock

Status: core available / wording polish pending

Required:
- 1 bucket = 100 balls
- Bucket sold today
- Expected ball out today
- Current ball stock
- Stock in today
- Low stock alert
- Admin stock movement
- Owner inventory verification
- Product/F&B stock tracking

## Deployment

Status: Coolify track

Required:
- Continue using Coolify for live track
- Custom domain later
- Add custom domain to Coolify
- Enable HTTPS/SSL
- Regenerate customer QR stickers after domain is active
- No Netlify for this live track

## Final UX Review

Required before live:
- Test customer order from phone
- Test payment page from phone
- Test receipt/status refresh
- Test Need Help from customer page
- Confirm Admin Ops sees blinking bay
- Confirm staff can acknowledge help
- Confirm payment verify updates receipt
- Confirm 100-ball wording everywhere customer-facing
- Confirm no admin links on customer page
- Confirm owner can upload payment QR
- Confirm QR sticker print layout

## Current Execution Priority

1. Patch remaining owner dashboard wording and module links.
2. Patch stock page wording if safe.
3. Add assisted order page or wire /pos?bay=XX properly.
4. Final mobile UI pass.
5. Coolify deployment check.
6. Domain migration later.
