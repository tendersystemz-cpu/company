# EDGE RANGE OS — Malaysia Pricing Model

> Commercial pricing reference for selling EDGE RANGE OS in the Malaysian driving range market.
>
> This document separates Malaysia-market pricing from the higher international / premium pricing model.

---

## 1. Why Malaysia Needs A Separate Pricing Model

The earlier pricing model is suitable as an international / premium pricing reference.

For Malaysia, pricing must account for the reality that many driving ranges sell ball buckets around a lower local price range and may not be ready for a high monthly SaaS commitment at the start.

The Malaysia model should therefore focus on:

- lower entry barrier
- clear monthly commitment
- simple setup cost
- realistic deposit
- minimum contract protection
- optional or light usage component
- upsell path to higher packages later

---

## 2. Malaysia Pricing Principle

Recommended structure:

```text
Setup Fee + Monthly License + Light Usage Component + Minimum Contract + Deposit
```

Malaysia pricing should not make EDGE RANGE OS look like a cheap website.

It should still be positioned as:

```text
Driving Range Operations System
Customer QR Ordering Layer
Staff Counter Workflow
Owner Monitoring Dashboard
POS Lite + Stock Lite Platform
```

But the entry price must be realistic enough for local operators to start.

---

## 3. Recommended Malaysia Public Pricing Display

For website, infographic, proposal, and WhatsApp pitch:

```text
Starter: From RM299/month
Standard: From RM499/month
Pro: From RM999/month
```

Small note:

```text
Setup fee, deposit, contract term and usage component apply.
Final pricing depends on bay count, operation size, setup scope and support requirement.
```

---

## 4. Malaysia Package Tiers

## Package 1 — Malaysia Starter

For small driving ranges or early operators.

```text
Setup Fee: RM1,000
Monthly License: RM299/month
Usage Component: Optional or RM50/month after 500 completed orders
Minimum Contract: 6 months
Deposit: 1 month
```

Initial payment example:

```text
Setup Fee: RM1,000
Deposit: RM299
First Month: RM299
Initial Payment: RM1,598
```

Included:

- Customer Bay QR Order
- Basic Payment Instruction
- Receipt / Purchase Slip
- Basic Staff Counter
- Basic Owner View
- Basic Menu/Product Setup
- Up to 10 bays

Best fit:

```text
Small range, low traffic, early adoption, proof-of-use stage.
```

---

## Package 2 — Malaysia Standard

Recommended main Malaysia package.

```text
Setup Fee: RM1,500
Monthly License: RM399/month or RM499/month
Usage Component: RM100/month after 1,000 completed orders or 0.5% of recorded paid sales
Minimum Contract: 6 months
Deposit: 1 month
```

Preferred starting version:

```text
Setup Fee: RM1,500
Monthly License: RM399/month
Usage Component: RM100/month after 1,000 completed orders
Minimum Contract: 6 months
Deposit: 1 month
```

Initial payment example:

```text
Setup Fee: RM1,500
Deposit: RM399
First Month: RM399
Initial Payment: RM2,298
```

Included:

- Customer QR Bay Order
- Ball Package / Product Order
- F&B / Product Order
- Payment QR Instruction
- Receipt / Purchase Slip
- Staff Counter
- Queue Management
- Payment Verification
- POS Lite
- Product/Menu Management
- Basic Stock Tracking
- Low Stock Threshold
- Owner Dashboard
- Reports Control
- Setup Wizard
- Bay QR Management
- Basic Access Protection
- Up to 30 bays

Best fit:

```text
Normal Malaysian commercial driving range operator.
```

---

## Package 3 — Malaysia Pro

For stronger operators, busier ranges, or owners who want better reporting and support.

```text
Setup Fee: RM2,500 – RM5,000
Monthly License: RM999/month
Usage Component: 0.5% of recorded paid sales or fixed usage band
Minimum Contract: 12 months
Deposit: 2 months
```

Initial payment example using RM2,500 setup:

```text
Setup Fee: RM2,500
Deposit: RM1,998
First Month: RM999
Initial Payment: RM5,497
```

Included:

- Everything in Malaysia Standard
- Higher bay capacity
- Enhanced owner dashboard
- More detailed reporting
- More staff role control
- Priority support
- Monthly performance review

Best fit:

```text
High-traffic range, serious operator, bigger staff operation, or premium venue.
```

---

## 5. Alternative Usage Component Options

### Option A — Percentage Based

```text
0.5% of recorded paid sales
```

Pros:

- Scales with operator revenue.
- Lower fixed burden.

Cons:

- Operator may feel sensitive about sales sharing.
- Needs strong reporting and trust.

---

### Option B — Fixed Usage Band

Recommended for Malaysia.

```text
0 – 500 completed orders/month: RM0
501 – 1,000 completed orders/month: RM50
1,001 – 2,000 completed orders/month: RM100
2,001 – 3,500 completed orders/month: RM200
3,501+ completed orders/month: RM300
```

Pros:

- Easier to explain.
- More predictable for operator.
- Less sensitive than revenue share.

Cons:

- Does not scale perfectly with revenue value.

Best Malaysia recommendation:

```text
Use fixed usage band first.
```

---

## 6. Best First Offer For Malaysian Market

Recommended first real-world offer:

```text
EDGE RANGE OS Malaysia Standard
Setup Fee: RM1,500
Monthly License: RM399/month
Usage Component: RM100/month after 1,000 completed orders
Minimum Contract: 6 months
Deposit: 1 month
Initial Payment: RM2,298
```

Why this works:

- Not too expensive for local range operators.
- Still protects developer/operator setup effort.
- Gives clear minimum contract.
- Uses deposit for payment security.
- Allows upgrade later to Pro.

---

## 7. Sales Script For Malaysia

Simple pitch:

```text
EDGE RANGE OS bukan sekadar QR order page.
Ia sistem operasi untuk driving range: customer order, staff counter, payment verification, POS Lite, stock lite, owner dashboard dan report operasi.
```

Price framing:

```text
Untuk pasaran Malaysia, pakej permulaan kami bermula dari RM299 sebulan.
Pakej Standard yang paling sesuai untuk kebanyakan range ialah RM399 sebulan dengan setup RM1,500 dan deposit satu bulan.
```

Value framing:

```text
Sistem ini bantu operator kawal order, bay, payment, queue, produk, stok asas dan laporan owner tanpa perlu bina sistem sendiri dari kosong.
```

---

## 8. What Not To Sell

Do not position EDGE RANGE OS as:

```text
cheap website
simple QR form
one-time HTML page
basic POS clone
free trial project
```

Position it as:

```text
Driving range operations platform
Subscription-based operator system
Customer QR + staff counter workflow
Owner monitoring and reporting layer
POS Lite and Stock Lite for range operations
```

---

## 9. International / Premium Pricing Reference

The higher pricing model should remain available for:

- international markets
- premium operators
- larger venues
- multi-branch customers
- operators requiring heavier support
- operators requiring custom modules

Reference file:

```text
docs/EDGE_RANGE_OS_PRICING_MODEL.md
```

Malaysia pricing should be treated as the local market entry model.

---

## 10. Super Admin Billing Note

A working Super Admin Billing Control module is still needed before fully enforcing monthly billing and usage claims.

Required future module:

```text
Super Admin Billing Control
```

Minimum functions:

- Tenant list
- Package control
- Monthly fee
- Usage band or usage percentage
- Deposit record
- Contract start/end
- Billing status
- Invoice / statement generation
- Payment received marking
- Overdue reminder
- Suspend / reactivate tenant

Until this module is built, billing can be tracked manually using exported monthly reports and invoice records.
