# RangeFlow Pilot Trial Task Tracker

## Purpose

This tracker records the remaining tasks required to make RangeFlow ready for a pilot trial as a Standard Package.

RangeFlow direction:

- Universal driving range system
- Not BUCC-specific
- UKM or any range can be used as pilot client
- Landing page is the main hub
- Manual QR payment remains V1.0 method
- ToyyibPay is KIV as optional V1.1 add-on

## Status Legend

- PENDING = not started
- IN_PROGRESS = being worked on
- DONE_SOURCE = code or document committed to GitHub
- NEEDS_DEPLOY = needs Netlify deploy
- NEEDS_LIVE_VERIFY = needs live browser test
- VERIFIED = tested live and accepted
- KIV = keep for future version

---

## Task 1: Landing Page / Hub Polish

Status: IN_PROGRESS

Goal:

- Make `/hub` the main system center.
- Keep visual identity clean and professional.
- Show customer, staff, owner and guide sections in one page.
- Staff and owner modules must remain locked before login.

Required sections:

- Customer order entry
- Staff operation login
- Owner operation login
- QR usage guide
- Promo or advertising space
- Membership teaser
- Support contact

Success check:

- `/hub` looks like RangeFlow Standard Package, not a BUCC-only system.
- Public user cannot directly open internal operation cards from the landing display.
- Staff and owner menu appear only after correct access.

Live URL:

- https://rangeflow-bucc-ops.netlify.app/hub

Note:

- Large `/hub` patch was temporarily blocked because current file still contains hardcoded PIN values. Future cleanup should move staff/owner PIN into config or database before bigger hub refactor.

---

## Task 2: Return to Main Menu Navigation

Status: DONE_SOURCE / NEEDS_DEPLOY / NEEDS_LIVE_VERIFY

Goal:

Every module must be able to return to the main hub.

Required pages:

- `/queue`
- `/menu`
- `/qr`
- `/owner`
- `/payments`
- `/health`
- `/deliver/[bookingId]`

Success check:

- Each page has a visible `Return to Main Menu` or equivalent path back to `/hub`.
- No module feels disconnected from the landing page.

Note:

- `/menu` and `/qr` have source updates.
- Live site still needs deployment and verification.

---

## Task 3: Customer QR-at-Bay Screen

Status: DONE_SOURCE / NEEDS_DEPLOY / NEEDS_LIVE_VERIFY

Goal:

After customer scans bay QR, show a compact customer dashboard instead of a long menu page.

Required customer tiles:

- Order Bola
- Makanan dan Minuman
- Putting Green
- Upgrade VIP / Aircond Room
- Kupon dan Membership
- Call Staff
- Mula Order

Success check:

- `/b/01` shows compact QR-at-Bay dashboard.
- `Mula Order` goes to `/b/01/order`.
- Customer order flow still works.

Live URL:

- https://rangeflow-bucc.netlify.app/b/01

---

## Task 4: Manual Payment Setup and Proof Upload

Status: IN_PROGRESS / NEEDS_FULL_TEST

Goal:

Keep V1.0 payment method simple and low cost.

Payment method:

- Operator QR Pay
- Bank transfer
- Customer upload payment proof
- Staff verify paid

Required checks:

- Payment Setup can upload QR images.
- Customer can see QR or bank details.
- Customer can upload payment proof.
- Queue can show proof.
- Staff can verify payment.
- Staff can reject or keep order pending if proof is not valid.

Success check:

- Full payment proof workflow works without ToyyibPay.

Note:

- RYT or any personal/sample bank details are demo data only. Production/operator data must come from Payment Setup.

---

## Task 5: Print Order Slip

Status: DONE_SOURCE / NEEDS_DEPLOY / NEEDS_LIVE_VERIFY

Reference document:

- `docs/RANGEFLOW_PRINTOUT_GUIDE.md`

Goal:

After staff verifies payment, system can generate a printout for operations.

Completed source work:

- Supabase RPC added: `get_operations_print_slip(p_booking_id)`
- Print page added: `/print/[bookingId]`
- Queue button added: `Print Order Slip`
- Print button is active only when `payment_status = paid`
- Thermal-friendly 80mm receipt layout created
- Slip includes counter, kitchen/station and delivery sections

Required wording:

- Payment Verified by Staff
- Manual Payment Proof Verified

Do not use:

- Payment Approved by Bank
- Payment Approved by Gateway

Success check:

- Staff can print a readable order slip after Verify Paid.

Live test target:

- Open `/queue`
- Verify an order as paid
- Click `Print Order Slip`
- Confirm `/print/[bookingId]` loads and browser print dialog appears

---

## Task 6: Delivery QR Confirmation

Status: IN_PROGRESS / NEEDS_FULL_TEST

Goal:

Runner must confirm delivery by scanning the actual bay QR.

Flow:

- Staff verifies paid.
- Staff marks Preparing.
- Staff marks Out for Delivery.
- Runner delivers to bay.
- Runner scans bay QR.
- System marks order as Delivered.

Success check:

- Correct bay scan confirms delivery.
- Wrong bay scan should not confirm delivery.
- Response time is recorded.

---

## Task 7: System Health Check

Status: NEEDS_DEPLOY / NEEDS_LIVE_VERIFY

Goal:

`/health` must validate the core system before pilot trial.

Required checks:

- Supabase connection
- Org and location data
- Bay data
- Menu data
- Payment settings
- Queue functions
- Delivery functions
- QR route
- Print slip RPC

Success check:

- `/health` shows PASS before pilot trial.

Live URL:

- https://rangeflow-bucc-ops.netlify.app/health

---

## Task 8: Remove BUCC-Specific Positioning

Status: IN_PROGRESS

Goal:

RangeFlow must be presented as a universal Standard Package.

Preferred wording:

- RangeFlow
- Golf Range Ordering System
- Standard Package
- Demo Range
- Bay 01

Avoid public UI overuse of:

- Bukit Unggul
- BUCC
- bukitunggul

Note:

- Backend/env may still use BUCC demo data temporarily.
- UI and pitch must not feel BUCC-only.

---

## Task 9: ToyyibPay Gateway

Status: KIV

Sandbox test result:

- Manual ToyyibPay sandbox bill created.
- Sandbox payment simulator success.
- Receipt generated.

Reason KIV:

- Fixed RM1 transaction fee can be too expensive for small orders.
- Consider only if QR/payment fee is commercially acceptable, such as around 1 percent.

V1.0 direction remains:

- Manual QR payment proof plus staff verification.

---

## Task 10: UKM / New Operator Pilot Trial Script

Status: PENDING

Goal:

Prepare simple pilot walkthrough for new operator.

Demo flow:

1. Open landing page.
2. Show customer QR flow.
3. Customer orders from Bay 01.
4. Customer uploads payment proof.
5. Staff verifies paid.
6. Staff prints order slip.
7. Staff prepares order.
8. Runner delivers.
9. Runner scans bay QR.
10. Owner checks dashboard and audit trail.

Success check:

- Operator can understand RangeFlow in less than 10 minutes.

---

## Current Priority Order

1. Deploy latest source to Netlify.
2. Verify live navigation buttons.
3. Verify customer QR-at-Bay page live.
4. Test full order and payment proof workflow.
5. Test Print Order Slip.
6. Test delivery QR confirmation.
7. Run `/health` final check.
8. Prepare pilot script.

---

## Update Rule

After each task:

1. Update this tracker.
2. Commit to GitHub.
3. Inform Sapuan what changed.
4. Provide live URL to test.
5. Mark whether it is source-done or live-verified.
