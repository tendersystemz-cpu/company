# RangeFlow Standard Package Completion

This document records the Standard Package completion scope added in branch `codex/complete-rangeflow-standard-package`.

## Goal

Complete RangeFlow as a deployable standard driving range operations package with clear customer, staff, owner, POS Lite, promotion and customer/member flows.

## Existing confirmed foundation

- Customer app exists under `customer/`.
- Operations app exists under `operations/`.
- README production target remains `rangeflow-bucc`, Supabase project ref `cgewjbfycnqbyczyuthp`, org slug `bukitunggul`.
- Customer journey already supports bay landing, customer ordering, payment proof and receipt.
- Operations already supports hub, counter flow, payment setup, menu/product setup, stock lite, owner dashboard, QR management, print slips and access PIN hardening.

## Added in this completion branch

### 1. V6 SQL migration

File: `sql/rangeflow_sql_migration_v6_standard_package_completion.sql`

Adds:

- Product category alignment for `bucket`, F&B, drink, snack, equipment, service and promo items.
- `promotions` table for campaign offers and discount codes.
- `campaign_events` table for campaign source/event tracking.
- `memberships` table for customer/member tier foundation.
- `rangeflow_pin_ok` helper for PIN-gated RPC access.
- `get_operations_promotions` RPC.
- `save_operations_promotion` RPC.
- `create_counter_sale` RPC for POS Lite sales.
- `get_operations_member_summary` RPC.

### 2. POS Lite UI

Route: `/pos`

Supports:

- Counter sale item selection.
- Category filter.
- Staff/owner PIN requirement.
- Cash, DuitNow QR, TNG, bank transfer and card/manual terminal payment method.
- Customer name/phone capture.
- Stock deduction for tracked items through `create_counter_sale`.
- Full slip/receipt print link after successful sale.

### 3. Promotions / Campaigns Lite UI

Route: `/promotions`

Supports:

- Campaign promo code setup.
- Fixed discount, percentage, free-item/manual and bundle/manual offer type.
- Minimum order rule.
- Campaign source tag such as Meta, TikTok, WhatsApp, poster QR and partner/coach.
- Owner PIN gated save.
- Staff/owner PIN gated listing.

### 4. Customer / Membership Lite UI

Route: `/members`

Supports:

- Owner PIN gated customer/member directory.
- Total customer count.
- Active member count.
- VIP/VVIP count.
- Search by name, phone or tier.
- Basic display of tier, status, points, expiry and last seen date.

### 5. Hub and Owner navigation wiring

Updated:

- `operations/app/hub/page.tsx`
- `operations/app/owner/page.tsx`

Adds visible links for:

- POS Lite
- Promotions / Campaigns
- Customer / Membership
- Stock Lite

## Deployment sequence

1. Review and merge the branch.
2. Run `sql/rangeflow_sql_migration_v6_standard_package_completion.sql` in Supabase SQL editor.
3. Confirm Netlify environment variables for both apps:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_ORG_SLUG`
   - customer/operations base URLs where used.
4. Deploy operations app.
5. Test routes:
   - `/hub`
   - `/owner`
   - `/menu`
   - `/stock`
   - `/pos`
   - `/promotions`
   - `/members`
   - `/counter`
   - `/print/[bookingId]?type=full`
6. Run one live end-to-end test:
   - Customer QR order from `/b/01/order`.
   - Payment proof submit.
   - Staff payment verification.
   - Print ball/kitchen/delivery/full slip.
   - POS Lite counter sale.
   - Owner dashboard refresh.

## Known security action before production hardening

Supabase reports `public.stock_movements` currently has RLS disabled. Do not enable blindly without policies because stock pages and RPCs may require controlled access. Recommended next action is to add RLS policies or move all stock writes through security-definer RPCs only, then enable RLS.

Minimum SQL to enable RLS after policies are ready:

```sql
ALTER TABLE public.stock_movements ENABLE ROW LEVEL SECURITY;
```

## Scope boundary

The current branch completes the standard package path. These remain add-ons or future roadmap:

- Full accounting inventory valuation.
- Supplier and purchase order module.
- Barcode scanner and cash drawer integration.
- Advanced loyalty engine.
- Coach booking.
- Membership subscription billing.
- Multi-branch rollup dashboard.
- AI sales prediction.
