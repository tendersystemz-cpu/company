# RangeFlow UI Flow Uniformity Audit

Updated: 2026-05-15

## Direction

The operations app must feel like one RangeFlow system, not a collection of disconnected pages.

Use this standard flow:

1. Hub
2. Setup Wizard
3. QR Bay Management
4. Menu Management
5. Payment Setup
6. Access Settings
7. Counter Queue
8. Owner Dashboard / System Health
9. Back to Hub

## Navigation rule

Every operations page should show only:

- Back to previous major step
- Current page title
- Next main step

Do not place too many same-level buttons in the top header.

## Page categories

### Setup

- Setup Wizard
- QR Bay Management
- Menu Management
- Payment Setup
- Access Settings

### Operate

- Customer Bay Preview
- Customer Order Preview
- Counter Queue
- Print Slip
- Delivery Confirmation

### Monitor

- Owner Dashboard
- System Health

## Branding rule

User-facing labels should use RangeFlow only.

Avoid BUCC or Bukit Unggul wording in generic product UI. BUCC can remain only as a deployment URL or backend org slug while this repo is serving that live deployment.

## Issues to clean next

- Menu page header has too many same-level buttons.
- Payment page header has too many same-level buttons.
- Owner page header has too many same-level buttons.
- Health page exposes org slug in header and should show generic system profile instead.
- QR page should be upgraded from QR generator wording to QR Bay Management wording.
- Global return nav label should use the same phrase as the hub flow.
