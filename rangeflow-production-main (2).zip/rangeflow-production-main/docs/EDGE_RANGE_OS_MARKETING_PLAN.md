# EDGE RANGE OS — Marketing Plan

> Marketing and advertising playbook for launching EDGE RANGE OS as a universal SaaS product for driving range operators.
>
> This plan uses AI as a marketing execution assistant, not as a product module inside EDGE RANGE OS.

---

## 1. Marketing Position

EDGE RANGE OS should be marketed as:

```text
A Web + Mobile subscription-based operations platform for driving range operators.
```

Core positioning:

```text
Customer QR Order + Staff Counter + Payment Verification + POS Lite + Stock Lite + Owner Dashboard + Mobile App Access
```

Do not market it as:

```text
Simple website
Basic QR form
Cheap POS clone
One-off HTML system
AI product
```

AI is used internally to help create campaigns, write ads, generate visuals, qualify leads, prepare proposals, and analyze feedback.

---

## 2. Product Message

Primary message:

```text
EDGE RANGE OS helps driving range operators control daily operations from customer bay orders to staff counter workflow, payment verification, product setup, stock monitoring, mobile access and owner reporting.
```

Bahasa Malaysia message:

```text
EDGE RANGE OS membantu operator driving range mengawal operasi harian daripada pesanan QR pelanggan, urusan kaunter staff, semakan bayaran, produk, stok asas, akses mobile dan laporan owner.
```

English message:

```text
EDGE RANGE OS helps driving range operators manage customer QR ordering, staff counter workflow, payment verification, products, basic stock, mobile access and owner reporting in one operating platform.
```

Important rule:

```text
BM campaign and English campaign must be created separately. Do not mix languages in one poster, ad or sales asset.
```

---

## 3. Mobile App Positioning

The mobile app should be treated as a major marketing advantage.

EDGE RANGE OS should be presented as:

```text
Web App + Mobile App + QR Bay Ordering + Owner Dashboard
```

Mobile app value:

- More premium than a simple web form.
- Easier for owner to understand as a serious product.
- Stronger perception for App Store / Play Store presence.
- Useful for owner monitoring.
- Useful for staff mobile operations.
- Useful for customer QR-first/mobile-first experience.

Do not sell the mobile app as a separate subscription in the first version unless commercial strategy changes.

Recommended positioning:

```text
One EDGE RANGE OS subscription includes Web App and Mobile App access for the subscribed operator.
```

---

## 4. Mobile App Role By User Type

### Customer

Customer should be mobile-first / QR-first.

Marketing message:

```text
Customers can order from the bay using QR and mobile-friendly order screens.
```

BM:

```text
Customer boleh order dari bay menggunakan QR dan paparan mobile yang mudah.
```

English:

```text
Customers can order from the bay through QR and a mobile-friendly ordering screen.
```

---

### Staff

Staff can use web or mobile depending on counter setup.

Marketing message:

```text
Staff can manage counter orders, queue, payment verification and fulfillment from web or mobile.
```

BM:

```text
Staff boleh urus counter order, queue, payment verification dan fulfillment melalui web atau mobile.
```

English:

```text
Staff can manage counter orders, queue, payment verification and fulfillment through web or mobile.
```

---

### Owner

Owner dashboard should be promoted strongly for mobile.

Marketing message:

```text
Owner can monitor sales, orders, bay activity and operation status from phone.
```

BM:

```text
Owner boleh pantau sales, order, aktiviti bay dan status operasi dari telefon.
```

English:

```text
Owner can monitor sales, orders, bay activity and operation status from their phone.
```

---

### Super Admin

Super Admin remains web-first in V1.

Marketing message is internal only:

```text
Super Admin controls tenants, packages, subscription status, billing records and activation.
```

---

## 5. Mobile App Marketing Angles

### Angle 1 — App Store / Play Store Credibility

Message:

```text
Not just a web page. EDGE RANGE OS is planned as a Web + Mobile platform for range operations.
```

BM hook:

```text
Bukan sekadar web page. EDGE RANGE OS disediakan sebagai platform Web + Mobile untuk operasi driving range.
```

English hook:

```text
Not just a web page. EDGE RANGE OS is built as a Web + Mobile platform for range operations.
```

---

### Angle 2 — Owner Mobile Monitoring

BM hook:

```text
Owner boleh pantau operasi range dari telefon — sales, bay, order dan payment status.
```

English hook:

```text
Owners can monitor range operations from their phone — sales, bays, orders and payment status.
```

---

### Angle 3 — Staff Mobile Counter

BM hook:

```text
Staff boleh urus order, queue dan payment verification dari mobile atau kaunter.
```

English hook:

```text
Staff can manage orders, queue and payment verification from mobile or counter.
```

---

### Angle 4 — Customer QR Mobile Flow

BM hook:

```text
Customer scan QR di bay, pilih item, ikut arahan bayaran dan terima slip pembelian.
```

English hook:

```text
Customer scans the bay QR, selects items, follows payment instructions and receives a purchase slip.
```

---

## 6. Target Audience

Primary target:

- Driving range owner
- Driving range operator
- Golf club manager
- Golf academy owner
- Golf facility manager

Secondary target:

- Proshop owner
- Golf coach with range access
- F&B operator inside golf range
- Sports facility operator
- Club operations manager

---

## 7. Customer Segments

### Segment A — Small Range Operator

Profile:

- Small bay count
- Manual order handling
- Uses cash/QR payment manually
- Low to medium traffic
- Price sensitive

Best offer:

```text
Malaysia Starter or Malaysia Standard
```

BM message:

```text
Mula digitalkan operasi range tanpa perlu bina sistem sendiri dari kosong.
```

English message:

```text
Start digitizing daily range operations without building a system from zero.
```

---

### Segment B — Normal Commercial Driving Range

Profile:

- Regular customer traffic
- Staff counter operation
- Ball bucket sales
- F&B/product sales
- Owner wants better visibility

Best offer:

```text
Malaysia Standard
```

BM message:

```text
Kawal order bay, semakan bayaran, kaunter staff dan laporan owner dalam satu sistem.
```

English message:

```text
Control bay orders, payment verification, staff counter and owner reporting in one system.
```

---

### Segment C — Premium / High Traffic Operator

Profile:

- Busy range
- More staff
- F&B/proshop activity
- Needs reporting and control
- Can pay higher monthly fee

Best offer:

```text
Malaysia Pro or International / Premium Package
```

BM message:

```text
Urus range dengan laporan lebih jelas, kawalan workflow dan visibility owner yang lebih kuat.
```

English message:

```text
Run the range with stronger reporting, workflow control and management visibility.
```

---

## 8. Main Advertising Angles

Use these as campaign angles. AI can generate multiple ad copies and visuals for each angle.

### Angle 1 — Owner Control

Problem:

```text
Owner does not clearly see daily sales, orders and bay activity.
```

BM ad hook:

```text
Owner masih susah nak pantau sales, order dan penggunaan bay setiap hari?
```

English ad hook:

```text
Still hard to monitor daily sales, orders and bay usage?
```

---

### Angle 2 — Staff Counter Workflow

Problem:

```text
Staff handles orders, payments and queue manually.
```

BM ad hook:

```text
Kaunter range masih kelam-kabut urus order, bay dan bayaran?
```

English ad hook:

```text
Is your range counter still struggling with orders, bays and payment checks?
```

---

### Angle 3 — Customer QR Bay Order

Problem:

```text
Customer has to walk back to counter for add-on orders.
```

BM ad hook:

```text
Customer tak perlu ulang-alik ke kaunter untuk tambah order.
```

English ad hook:

```text
Let customers add orders from their bay using QR.
```

---

### Angle 4 — Payment Verification

Problem:

```text
Staff may be unsure which order is paid or pending.
```

BM ad hook:

```text
Kurangkan kekeliruan order sudah bayar atau belum.
```

English ad hook:

```text
Reduce confusion between paid and pending orders.
```

---

### Angle 5 — POS Lite + Stock Lite

Problem:

```text
Products and stock are tracked manually or not tracked at all.
```

BM ad hook:

```text
Produk, stok bola dan F&B lebih mudah dipantau.
```

English ad hook:

```text
Track products, ball stock and F&B items more clearly.
```

---

### Angle 6 — Malaysia Pricing

Problem:

```text
Operators think digital systems are too expensive.
```

BM ad hook:

```text
Sistem operasi driving range bermula dari RM299 sebulan.
```

English ad hook:

```text
Driving range operations system from RM299/month.
```

---

### Angle 7 — Web + Mobile Platform

Problem:

```text
Operator does not want a system that feels like a temporary web page.
```

BM ad hook:

```text
Bukan sekadar web page — EDGE RANGE OS disediakan untuk Web App dan Mobile App.
```

English ad hook:

```text
Not just a web page — EDGE RANGE OS is prepared for Web App and Mobile App access.
```

---

## 9. Channel Strategy

### Facebook / Instagram Ads

Purpose:

- Awareness
- Lead generation
- WhatsApp inquiries
- Demo bookings

Best content type:

- Infographic pricing
- Problem/solution poster
- Short demo clips
- Before/after workflow carousel
- Mobile app screenshot mockup
- Owner dashboard phone mockup

Recommended test budget:

```text
RM10 – RM30/day initially
```

---

### TikTok / Reels

Purpose:

- Fast awareness
- Show operational pain points visually
- Short demo storytelling

Best content type:

- 15–30 second problem/solution videos
- Screen recording + voiceover
- Counter chaos vs EDGE workflow
- Customer scan QR from bay
- Owner checking dashboard from phone

---

### LinkedIn

Purpose:

- Corporate positioning
- Golf club manager reach
- Facility management audience

Best content type:

- English campaign
- SaaS product positioning
- Web + Mobile platform message
- Owner dashboard benefits
- Professional case-study style posts

---

### Google Search Ads

Purpose:

- Capture high-intent users searching for systems or POS.

Possible keyword themes:

```text
driving range management system
golf range booking system
golf club POS system
golf facility management software
QR ordering system for sports facility
POS system for driving range
golf range mobile app
```

For Malaysia BM search:

```text
sistem driving range
sistem tempahan golf
sistem QR order
sistem POS golf
sistem pengurusan golf
aplikasi driving range
aplikasi golf range
```

---

### App Store / Play Store Marketing Assets

When the mobile app is ready, prepare store assets carefully.

Required marketing assets:

- App icon using EDGE / DG master logo without crown
- App screenshots for customer, staff and owner view
- Short app description
- Long app description
- Support contact
- Privacy policy page
- Demo account or review access if required
- Product website / landing page

Do not use client/operator-specific names as the app identity unless creating a white-label tenant-specific app.

Recommended app positioning:

```text
EDGE RANGE OS — Driving Range Operations Platform
```

---

### WhatsApp Sales Follow-Up

Purpose:

- Qualify leads
- Send proposal
- Book demo
- Close introductory package

Use AI to prepare message variations, but final sending should be manual and personalized.

---

## 10. AI Marketing Workflow

AI should be used as an internal marketing assistant.

Workflow:

```text
1. Generate campaign angle
2. Generate BM ad copy
3. Generate English ad copy
4. Generate image/poster concept
5. Generate mobile app screenshot caption
6. Generate short video script
7. Generate WhatsApp reply script
8. Generate lead qualification questions
9. Generate proposal summary
10. Analyze campaign feedback
11. Improve the next campaign batch
```

Important rule:

```text
AI output must be reviewed before publishing. Do not publish AI-generated text or visuals without checking branding, spelling, language purity and pricing accuracy.
```

---

## 11. Campaign Asset List

Prepare these assets before launching ads.

### Bahasa Malaysia Assets

- BM pricing infographic
- BM problem/solution poster
- BM WhatsApp pitch
- BM demo invitation poster
- BM mobile app preview poster
- BM owner dashboard mobile poster
- BM follow-up script
- BM objection handling sheet

### English Assets

- English pricing infographic
- English problem/solution poster
- English LinkedIn post
- English demo invitation poster
- English mobile app preview poster
- English owner dashboard mobile poster
- English proposal summary
- English follow-up script

Language rule:

```text
Do not mix BM and English in the same asset unless it is intentionally bilingual. Standard marketing assets should be separate.
```

---

## 12. Lead Qualification Script

Use these questions when a prospect responds.

BM version:

```text
1. Range tuan ada berapa bay?
2. Harga bucket bola sekarang sekitar berapa?
3. Ada jual F&B atau produk lain?
4. Staff kaunter berapa orang?
5. Payment sekarang guna cash, QR atau POS?
6. Masalah operasi paling besar sekarang apa?
7. Owner perlukan laporan harian atau bulanan?
8. Tuan mahu sistem untuk customer QR order sahaja atau sekali staff counter dan owner dashboard?
9. Owner mahu akses melalui telefon juga?
10. Staff perlu guna tablet/phone atau cukup di kaunter sahaja?
```

English version:

```text
1. How many bays does your range have?
2. What is your current ball bucket price?
3. Do you also sell F&B or other products?
4. How many counter staff do you have?
5. Do you currently use cash, QR payment or POS?
6. What is your biggest operational problem now?
7. Does the owner need daily or monthly reports?
8. Do you need customer QR ordering only, or staff counter and owner dashboard as well?
9. Does the owner need mobile access from phone?
10. Will staff use tablet/phone or only counter screen?
```

---

## 13. Package Recommendation Logic

Use this to recommend a package after qualification.

```text
Small range, below 10 bays, low traffic → Malaysia Starter
Normal range, 10–30 bays, staff counter, F&B/products → Malaysia Standard
Busy range, more staff, stronger reporting needs → Malaysia Pro
Needs mobile owner dashboard and staff mobile operation → Standard or Pro
Premium operator, multi-branch, custom requirements → Premium / Custom Quote
```

---

## 14. WhatsApp Follow-Up Sequence

### Day 0 — First Response

BM:

```text
Terima kasih tuan. EDGE RANGE OS ialah sistem operasi untuk driving range — customer QR order, staff counter, payment verification, POS Lite, Stock Lite, owner dashboard dan akses mobile dalam satu platform.
```

English:

```text
Thank you. EDGE RANGE OS is an operations platform for driving ranges — covering customer QR ordering, staff counter, payment verification, POS Lite, Stock Lite, owner dashboard and mobile access in one platform.
```

---

### Day 1 — Send Pricing / Infographic

BM:

```text
Saya share ringkasan pakej Malaysia. Pakej Standard yang paling sesuai untuk kebanyakan range bermula RM399 sebulan, dengan setup dan deposit satu bulan.
```

English:

```text
I am sharing the Malaysia package summary. The Standard package, suitable for most ranges, starts from RM399/month with setup and one-month deposit.
```

---

### Day 3 — Demo Invitation

BM:

```text
Kalau tuan mahu, saya boleh tunjuk demo ringkas 10–15 minit: customer scan QR, staff verify payment, queue masuk, owner nampak report dan akses mobile.
```

English:

```text
I can show a quick 10–15 minute demo: customer scans QR, staff verifies payment, queue updates, owner sees the report and mobile access.
```

---

### Day 7 — Quotation Push

BM:

```text
Jika sesuai, saya boleh sediakan quotation untuk pakej yang paling ngam berdasarkan jumlah bay, flow operasi dan keperluan mobile access range tuan.
```

English:

```text
If suitable, I can prepare a quotation based on your bay count, operating flow and mobile access needs.
```

---

## 15. Objection Handling

### Objection: Mahal

BM response:

```text
Faham tuan. Untuk Malaysia, kita sediakan pakej bermula RM299 sebulan. Pakej Standard RM399 sebulan biasanya bersamaan lebih kurang 25–40 bucket sahaja, bergantung harga bucket range tuan. Kalau sistem bantu elak missed order atau lambat verify payment 1–2 bucket sehari, kos bulanan sudah boleh cover.
```

English response:

```text
I understand. For Malaysia, we have packages from RM299/month. The Standard package at RM399/month is roughly equivalent to about 25–40 buckets, depending on your bucket price. If the system helps recover even 1–2 missed orders per day, the monthly cost can already be covered.
```

---

### Objection: Staff tak pandai guna sistem

BM response:

```text
Sistem ini memang disusun untuk staff kaunter guna secara mudah: pilih bay, pilih item, verify payment dan print slip. Kita tidak paksa flow yang berat seperti sistem enterprise besar.
```

English response:

```text
The system is designed for simple counter use: select bay, select item, verify payment and print slip. It is not a heavy enterprise system.
```

---

### Objection: Kami sudah ada POS

BM response:

```text
EDGE RANGE OS bukan semata-mata ganti POS. Ia fokus kepada operasi driving range: bay, bucket order, QR add-on order, payment verification, queue, stock lite, mobile access dan owner dashboard. POS Lite hanya satu layer untuk bantu operasi harian.
```

English response:

```text
EDGE RANGE OS is not just a POS replacement. It focuses on driving range operations: bays, bucket orders, QR add-on orders, payment verification, queue, stock lite, mobile access and owner dashboard. POS Lite is only one supporting layer.
```

---

### Objection: Customer biasa order di counter sahaja

BM response:

```text
Itu boleh kekal. Sistem ini support counter-first flow. Bay QR digunakan untuk repeat order selepas customer sudah mula bermain, supaya mereka tidak perlu ulang-alik ke kaunter.
```

English response:

```text
That can remain. The system supports counter-first operation. Bay QR is mainly for repeat orders after the customer has started playing, so they do not need to walk back to the counter.
```

---

### Objection: Kenapa perlu mobile app?

BM response:

```text
Mobile app bukan untuk memaksa customer install app. Customer tetap boleh guna QR. Mobile app lebih penting untuk owner dan staff supaya operasi boleh dipantau dan diurus dengan lebih mudah melalui telefon atau tablet.
```

English response:

```text
The mobile app is not meant to force customers to install an app. Customers can still use QR. The mobile app is more important for owner and staff access, so operations can be monitored and managed more easily from phone or tablet.
```

---

## 16. Demo Storyline

Recommended demo order:

```text
1. Open Operations Console
2. Show Setup Wizard concept
3. Show Customer Bay QR Order
4. Create sample order
5. Show Payment Instruction
6. Show Staff Counter
7. Verify Payment
8. Show Queue / Self Pickup / Deliver to Bay
9. Show Owner Dashboard
10. Show POS Lite / Stock Lite
11. Show mobile app positioning
12. End with Malaysia Pricing Package
```

Do not show all modules randomly. Follow the real operation story.

---

## 17. Campaign Testing Plan

Start with 6 campaign variants:

```text
Campaign A: Owner Dashboard / owner control
Campaign B: Staff Counter / payment verification
Campaign C: Customer QR Bay Order
Campaign D: POS Lite + Stock Lite
Campaign E: Malaysia pricing from RM299/month
Campaign F: Web + Mobile platform
```

Test small budget first:

```text
RM10 – RM30/day
```

Track:

```text
Reach
Clicks
WhatsApp leads
Demo requests
Cost per lead
Package interest
Mobile app interest
Common objections
```

After 7–14 days, review and improve.

---

## 18. Monthly Marketing Review

At the end of each month, AI can help summarize:

```text
Which ad angle performed best?
Which language performed better?
Which package got the most interest?
Did mobile app positioning increase lead quality?
What objections appeared most often?
What price point felt acceptable?
Which prospects should be followed up?
What content should be created next?
```

The result should improve the next campaign batch.

---

## 19. Next Asset Priorities

Create these next:

```text
1. BM Malaysia Pricing Infographic
2. English Pricing Infographic
3. BM Problem/Solution Carousel
4. English LinkedIn Product Sheet
5. WhatsApp Demo Invitation Image
6. Mobile App Preview Poster
7. Owner Dashboard Mobile Mockup
8. Staff Mobile Counter Mockup
9. 10-second vertical video script
10. 30-second demo walkthrough script
11. One-page quotation template
```

---

## 20. Final Rule

Use AI aggressively for marketing production speed, but keep human approval for:

```text
pricing
brand wording
language purity
mobile app positioning
operator-specific proposal
final quotation
published ads
store listing copy
```
