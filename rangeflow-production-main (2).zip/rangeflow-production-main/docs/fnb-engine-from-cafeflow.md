# RangeFlow F&B Engine Derived From CafeFlow

## Decision

RangeFlow food and drink ordering should reuse the CafeFlow / Mama Kitchen ordering logic instead of being built from zero.

The RangeFlow F&B module is essentially a bay-based adaptation of the CafeFlow ordering engine.

## Why

CafeFlow/Mama Kitchen already has the relevant business logic patterns:

```text
menu items
categories
customer order
cart
payment proof / manual QR payment
receipt
audit/order status
admin order management
```

RangeFlow needs the same order engine, but with a different context:

```text
CafeFlow context: office/table/customer delivery point
RangeFlow context: golf bay/customer bay
```

## RangeFlow adaptation

The F&B flow must attach every order to a bay.

Correct customer flow:

```text
Scan QR at Bay 01
-> /b/01
-> choose balls
-> choose food
-> choose drinks
-> one combined cart
-> one payment
-> one receipt/token
-> staff sees Bay 01 order queue
```

## Shared order model

RangeFlow orders should support item types:

```text
ball
food
drink
service
promo
```

This allows the same order table/queue to show combined items:

```text
Bay 01
- 1 bucket balls
- 1 nasi lemak
- 2 mineral water
- payment pending/paid
- preparation/fulfilment status
```

## What to reuse from CafeFlow/Mama Kitchen

Reuse these concepts:

1. Menu category management.
2. Product/menu item management.
3. Customer-facing cart.
4. QR/manual payment flow.
5. Receipt page.
6. Admin/operations order view.
7. Order status lifecycle.
8. Optional proof upload later if needed.

## What must change for RangeFlow

Do not copy CafeFlow blindly. RangeFlow requires these changes:

1. Every customer order must be bay-aware.
2. QR route must be `/b/{bay_code}`.
3. Ball order and F&B order must share one cart.
4. Operations queue must group by bay first, not by customer/table only.
5. Staff view must support both ball fulfilment and F&B fulfilment.
6. Receipt/token must identify bay clearly.

## Launch requirement

Customer-facing launch is not complete until RangeFlow supports:

```text
balls + food + drinks + one cart + one receipt + one bay queue
```

Ball-only flow is acceptable only as a technical checkpoint, not as real customer launch scope.

## Development priority

1. Implement real booking/order/payment write for ball order.
2. Extend order page into combined cart.
3. Pull menu items from Supabase `menu_items`.
4. Add food/drink quantities to the same cart.
5. Insert all cart items into `orders` with item type.
6. Update receipt to show combined items.
7. Update operations app to show bay-based combined queue.
