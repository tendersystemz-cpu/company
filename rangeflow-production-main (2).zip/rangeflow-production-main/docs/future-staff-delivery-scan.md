# Future Improvement: Staff Delivery Confirmation by Bay QR Scan

## Idea

Staff can scan the bay QR code to confirm that ordered items have been delivered to the correct bay.

This is a future improvement for operational control, not a launch blocker.

## Why it matters

In real range operations, the same counter/team may handle:

```text
balls
food
drinks
equipment
service requests
```

A delivery confirmation scan reduces the risk of:

```text
wrong bay delivery
missed delivery
customer dispute
staff forgetting to update status
manual status mismatch
```

## Proposed flow

```text
Staff prepares order
-> Staff brings item to Bay 01
-> Staff scans Bay 01 QR
-> Operations app detects matching bay
-> Staff confirms delivery
-> booking/order item status updates to delivered/completed
```

## Matching rule

The scanned bay QR must match the booking bay.

Example:

```text
Order belongs to Bay 01
Staff scans Bay 01 QR -> allow confirm delivered
Staff scans Bay 02 QR -> show warning, do not auto-confirm
```

## Possible implementation

Use existing bay QR route:

```text
/b/{bay_code}
```

Or create staff-only scan route later:

```text
/ops/scan/{bay_code}
```

The operations app can compare:

```text
booking.bay_id
scanned bay code
active pending/delivering orders
```

## Status mapping

When delivery scan is confirmed:

```text
orders.status = delivered
bookings.status = completed
```

## Priority

This should be considered after:

1. Operations queue is stable.
2. Menu management DIY is working.
3. Ball pricing DIY is working.
4. QR generator per bay is ready.

It is not required for first internal testing, but it is useful before larger-scale real customer rollout.
