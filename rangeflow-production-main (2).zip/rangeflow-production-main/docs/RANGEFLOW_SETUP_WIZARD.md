# RangeFlow Setup Wizard Direction

## Product Direction

RangeFlow must become a universal standard package, not a system hardcoded for one driving range.

The product should support self setup by any golf driving range operator.

## Current Product Rule

Do not hardcode operator identity such as:

- Bukit Unggul
- BUCC
- UKM only
- Any single range name

All tenant identity should come from setup/config.

## Default Demo Branding

When no setup has been completed, use generic demo naming:

- RangeFlow Demo Range
- RangeFlow Standard Package
- Your Golf Range

Avoid showing a real client name unless that operator has completed setup.

## Setup Wizard Fields

Minimum setup wizard fields:

1. Range / business name
2. Location name
3. Logo URL or logo upload
4. Brand color / theme preset
5. Support WhatsApp number
6. Number of bays
7. Bay naming format
8. Staff PIN
9. Owner PIN
10. QR Pay settings
11. Bank account settings
12. Menu categories
13. Promo slots
14. Membership teaser on/off
15. Delivery confirmation mode

## Payment Setup Fields

Required payment setup:

- DuitNow QR image
- TNG QR image
- Bank name
- Bank account name
- Bank account number
- Payment note
- Support WhatsApp

Future gateway add-on:

- ToyyibPay enable/disable
- Gateway category code
- Callback URL
- Return URL
- Gateway fee policy

## Page Branding Sources

All pages should use setup/config for:

- Range name
- Location name
- Logo
- Support WhatsApp
- Payment details
- Bay count
- Theme color
- Promo content

## Pages That Must Not Use Hardcoded Client Name

- Customer Bay page
- Customer Order page
- Hub / Landing page
- QR Generator
- Payment Setup preview
- Owner Dashboard
- Queue page
- Print Order Slip

## Setup Wizard Flow

Recommended flow:

1. Welcome to RangeFlow Setup
2. Business profile
3. Bay configuration
4. Payment setup
5. Menu starter setup
6. Staff/owner access PIN
7. Promo and landing content
8. Review and publish

## Standard Package Positioning

RangeFlow should be sold as:

A QR bay ordering and operations system for golf driving ranges that can be configured by each operator with their own bay setup, QR payment, menu, promotions, staff workflow and delivery confirmation.

## Immediate Productization Tasks

1. Replace hardcoded client display names with generic fallback.
2. Keep existing database slug for technical compatibility until setup wizard exists.
3. Polish customer bay UI so it looks like a standard product.
4. Polish operations hub and queue layout.
5. Add setup wizard later after current pages are stable.
