# EDGE RangeFlow Live QA Test Script

## Purpose

This script is used before real live operation. Test on phone/tablet exactly like staff and customers will use it.

## Test Environment

- Deployment: Coolify
- Product: EDGE RangeFlow Standard Package
- Bucket rule: 1 bucket = 100 balls
- Payment: cashless only
- Active bays: 01-25
- Standby bays: 26-30

## QA 1 — Customer Order Page

Open:

```text
/b/01/order
```

Pass criteria:

- Bay 01 appears correctly.
- Customer page is mobile friendly.
- Customer does not see admin/owner links.
- 100 Balls Bucket / Bucket 100 Bola appears.
- BM/BI labels are visible.
- Customer can select bucket quantity.
- Customer can select F&B/menu items.
- Need Help / Perlu Bantuan button is visible.
- Checkout button works.

Fail if:

- Any wording says 50 balls.
- Customer sees admin/owner controls.
- Page still looks like demo/testing/pilot.

## QA 2 — Customer Need Help

From customer order page:

1. Tap Need Help / Perlu Bantuan.
2. Wait for success message.

Open operations:

```text
/staff-ops-bay
```

Pass criteria:

- Bay 01 blinks/highlights.
- Alert strip appears.
- Staff can acknowledge.
- Alert disappears or changes after acknowledge.

Fail if:

- No alert appears in admin.
- Bay does not highlight.
- WhatsApp is required for help alert.

## QA 3 — Customer Checkout & Payment

From customer order page:

1. Select 1 bucket.
2. Checkout.

Pass criteria:

- Payment page opens.
- Total amount is correct.
- TNG/DuitNow payment instruction appears.
- Payment proof upload is optional fallback only.
- Customer can proceed to receipt/status.

Fail if:

- Proof upload is mandatory.
- Payment page still says pilot/demo/testing.
- Cash is shown as customer payment option.

## QA 4 — Admin Payment Verify

Open:

```text
/staff-ops-bay
```

Pass criteria:

- Pending order appears under the correct bay.
- Payment pending indicator appears.
- Staff can press Verify Payment.
- Order becomes paid.
- Customer receipt/status updates.

Fail if:

- Order does not appear.
- Payment verify fails.
- Receipt/status remains unchanged.

## QA 5 — Receipt / Status Page

Open receipt after order.

Pass criteria:

- Token appears clearly.
- Bay appears correctly.
- Payment status is clear.
- Order status is clear.
- BM/BI wording appears.
- Page auto-refreshes.
- Customer can order again.

Fail if:

- Customer has to fill information again.
- Receipt page is confusing.
- Status labels are unclear.

## QA 6 — Assisted Order By Staff

Open:

```text
/pos?bay=07
```

Pass criteria:

- Bay 07 appears.
- Page says assisted order.
- Cash is not available.
- TNG/DuitNow/bank/card options appear.
- Staff can select items.
- Staff can complete order with PIN.
- Receipt can be opened/printed.

Fail if:

- Cash option appears.
- Bay is not shown.
- Order is not tied to the bay context.

## QA 7 — Admin Bay Grid

Open:

```text
/staff-ops-bay
```

Pass criteria:

- Bay 01-25 active.
- Bay 26-30 standby/disabled.
- Bay button can be selected.
- Selected bay panel appears.
- Active order appears under selected bay.
- Add Order For Bay link opens `/pos?bay=XX`.

Fail if:

- Bay 26-30 appears active by mistake.
- Add Order button opens wrong bay.
- Staff must use long queue only.

## QA 8 — Owner Dashboard

Open:

```text
/owner
```

Pass criteria:

- Owner dashboard loads.
- Today sales appears.
- Today orders appears.
- Bucket count appears.
- Bay usage appears.
- Links to pricing/menu, payment, QR, stock and access are visible.

Fail if:

- Owner page feels like daily counter screen.
- Too many add-on modules clutter the standard view.
- Pilot/demo wording appears.

## QA 9 — Payment QR Setup

Open:

```text
/payments
```

Pass criteria:

- Owner can upload TNG QR image.
- Owner can upload DuitNow QR image.
- QR preview appears.
- Save settings works.
- Customer payment page shows saved QR.

Fail if:

- Only URL input is possible.
- Upload does not preview.
- QR does not appear on customer payment page.

## QA 10 — QR Bay Management

Open:

```text
/qr
```

Pass criteria:

- Bay list loads.
- Generate QR works.
- QR target is `/b/[bay]/order`.
- Sticker includes EDGE RangeFlow.
- Sticker includes Order / Pesan.
- Sticker includes Need Help / Perlu Bantuan.
- Sticker includes TNG/DuitNow/PRIMAVOC note.

Fail if:

- QR opens wrong page.
- Sticker has temporary/testing wording.
- Final sticker is printed with sslip.io after custom domain is ready.

## QA 11 — Stock / Inventory

Open:

```text
/stock
```

Pass criteria:

- 1 bucket = 100 balls formula appears.
- Current ball stock appears.
- Bucket sold today appears.
- Expected ball out appears.
- Stock in can be recorded.
- Low stock alert works.
- Product stock list appears.

Fail if:

- Formula shows 50 balls.
- Stock update fails.
- Product stock cannot be tracked.

## QA 12 — Mobile Real Device Test

Test with actual phone:

- iPhone Safari
- Android Chrome if available
- Staff tablet/phone browser

Pass criteria:

- Buttons are large enough.
- Need Help button is visible.
- Payment QR image fits screen.
- Receipt/status is readable.
- Admin bay grid is usable on phone.

## QA Result Format

Use this format while testing:

```text
QA item:
Result: PASS / FAIL
Problem:
Screenshot:
Fix needed:
```

## Live Decision

System can proceed to controlled live use only when:

- QA 1-7 pass for daily operation.
- QA 9 payment QR works.
- No customer-facing demo/testing/pilot wording remains.
- Staff can complete one real paid order from start to finish.
