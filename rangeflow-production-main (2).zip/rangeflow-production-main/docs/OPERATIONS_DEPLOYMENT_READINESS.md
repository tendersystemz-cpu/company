# RangeFlow Operations Deployment Readiness

Updated: 2026-05-15

## Target operations site

Netlify project:

```text
rangeflow-ops
```

Site ID:

```text
8dd21dbe-82ca-48e9-9a8d-15c8185b7f92
```

Primary URL:

```text
https://rangeflow-ops.netlify.app
```

## Current deploy gap

Netlify current deploy is still on commit:

```text
13b8902513e355a26f7e6eaa16102365cb14e3a0
```

That deploy predates the latest pilot pages and polish work.

Latest code after cleanup includes:

- `/pilot`
- `/staff`
- `/counter`
- `/checkpoint`
- pilot-first `/`
- improved `/qr`
- improved `/menu`
- improved `/payments`
- improved `/access`
- improved `/owner`
- improved `/health`

## Pilot routes that must be live

These routes are required for the trial pilot:

```text
/
/pilot
/staff
/counter
/checkpoint
/qr
/menu
/payments
/access
/owner
/health
```

## Standard pilot route order

Use this order during trial:

1. `/` - Operations Start
2. `/pilot` - Customer / Admin-Staff / Owner flow explanation
3. Customer order page from bay QR
4. `/counter` - Staff verify payment, print slips, prepare and start checkpoint
5. `/checkpoint` - Runner starts delivery and confirms bay QR checkpoint
6. `/owner` - Owner dashboard and control view
7. `/health` - Pilot readiness check

## Manual deployment path

If Git auto-deploy does not pick up the latest commits, run deployment from the repo/source directory.

Recommended local path:

```bash
cd rangeflow-production/operations
npm install
npm run build
```

Then deploy the operations app to Netlify site ID:

```text
8dd21dbe-82ca-48e9-9a8d-15c8185b7f92
```

The Netlify connector generated a deploy command for this site ID. Run it from the source/repo directory if required by the connected Netlify MCP deploy workflow.

## Post-deploy smoke test

Do not mark the pilot live until the following routes open successfully on the operations site:

- `https://rangeflow-ops.netlify.app/`
- `https://rangeflow-ops.netlify.app/pilot`
- `https://rangeflow-ops.netlify.app/staff`
- `https://rangeflow-ops.netlify.app/counter`
- `https://rangeflow-ops.netlify.app/checkpoint`
- `https://rangeflow-ops.netlify.app/qr`
- `https://rangeflow-ops.netlify.app/menu`
- `https://rangeflow-ops.netlify.app/payments`
- `https://rangeflow-ops.netlify.app/access`
- `https://rangeflow-ops.netlify.app/owner`
- `https://rangeflow-ops.netlify.app/health`

## Scope boundary

Do not add these into the current deployment scope:

- POS stock module
- Payment gateway integration
- Membership
- Advance booking
- Coach booking
- Pro shop

They are add-ons after the Standard Package pilot is stable.

## Current pilot package focus

Customer:

- Scan bay QR
- Order ball bucket and F&B
- Upload payment proof
- Wait at bay

Admin / Staff:

- Counter Flow
- Verify payment
- Print ball, kitchen and delivery slips
- Mark preparing
- Start QR checkpoint

Owner:

- Payment setup
- Menu / product setup
- Access settings
- Owner dashboard
- Pilot readiness check
