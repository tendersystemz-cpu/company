# EDGE RANGE OS — Pricing Model

> Draft commercial pricing structure for EDGE RANGE OS as a universal SaaS product for driving range operators.

---

## 1. Pricing Direction

EDGE RANGE OS should not be sold as a cheap one-off website or simple QR ordering page.

It should be positioned as an operating system subscription for driving range operators.

Recommended commercial model:

```text
License Rental + Utility Usage + Minimum Contract + Deposit
```

This protects development cost, support cost, onboarding time, and long-term platform sustainability.

---

## 2. Main Pricing Components

### A. Setup / Onboarding Fee

One-time fee to configure operator workspace, branding, payment QR, bay QR, menu/products, POS Lite, stock thresholds, staff access, owner dashboard, and go-live support.

Suggested range:

```text
RM 1,500 – RM 5,000 one-time
```

Recommended starting offer:

```text
RM 2,500 setup fee
```

---

### B. Monthly License Rental

Recurring monthly platform subscription for access to EDGE RANGE OS.

Suggested range:

```text
RM 399 – RM 1,499 / month
```

Recommended standard starting price:

```text
RM 799 / month
```

---

### C. Utility Usage / Platform Usage

Small variable charge based on system usage or recorded order value.

Purpose:

- Covers growth usage.
- Aligns fee with operator activity.
- Allows lower fixed monthly entry while still sharing upside.

Recommended options:

```text
Option 1: 1% of monthly recorded sales through EDGE RANGE OS
Option 2: RM 0.10 – RM 0.30 per completed transaction
Option 3: Fixed monthly utility band based on order count
```

Best practical option for early operator onboarding:

```text
1% of monthly recorded sales, capped or reviewed monthly
```

---

### D. Minimum Contract

Recommended minimum contract:

```text
6 months minimum
```

Preferred contract for serious operators:

```text
12 months minimum
```

Reason:

- Operator onboarding takes time.
- Staff need training.
- QR/bay/menu/payment setup needs stabilization.
- System value becomes clearer after real monthly usage.

---

### E. Deposit / Advance Commitment

Recommended:

```text
2 months deposit + first month advance
```

Example:

```text
Monthly license: RM 799
Deposit: RM 1,598
First month: RM 799
Initial payment before go-live: RM 2,397 + setup fee
```

---

## 3. Suggested Package Tiers

### Package 1 — Starter Range OS

For small driving ranges or early adopters.

```text
Setup Fee: RM 1,500
Monthly License: RM 399 / month
Utility Usage: 1.5% of recorded sales or RM 0.30 per transaction
Minimum Contract: 6 months
Deposit: 2 months
```

Included:

- Customer Bay QR Order
- Basic Payment Instruction
- Receipt / Purchase Slip
- Basic Staff Counter
- Basic Owner View
- Basic Menu/Product Setup
- Up to 10 bays

Best use:

```text
Small operator, low traffic, proof-of-adoption stage.
```

---

### Package 2 — Standard Range OS

Recommended main package.

```text
Setup Fee: RM 2,500
Monthly License: RM 799 / month
Utility Usage: 1% of recorded sales
Minimum Contract: 12 months
Deposit: 2 months
```

Included:

- Customer QR Bay Order
- Ball Package / Product Order
- F&B / Product Order
- Payment QR Instruction
- Receipt / Purchase Slip
- Staff Counter
- Queue Management
- Payment Verification
- POS Lite
- Product/Menu Management
- Basic Stock Tracking
- Low Stock Threshold
- Owner Dashboard
- Reports Control
- Setup Wizard
- Bay QR Management
- Basic Access Protection
- Up to 30 bays

Best use:

```text
Normal commercial driving range operator.
```

---

### Package 3 — Pro Range OS

For serious or high-traffic operators.

```text
Setup Fee: RM 5,000
Monthly License: RM 1,499 / month
Utility Usage: 0.75% of recorded sales
Minimum Contract: 12 months
Deposit: 2 months
```

Included:

- Everything in Standard
- More advanced reports
- More staff roles
- More detailed stock reporting
- Enhanced owner dashboard
- Extended bay capacity
- Priority support
- Monthly performance review

Best use:

```text
High-traffic range, multi-team operation, or operator who wants stronger management reporting.
```

---

## 4. Pilot / Trial Commercial Structure

Avoid using the word `pilot` as public product identity. Use:

```text
Introductory Go-Live Package
```

Recommended introductory offer:

```text
Setup Fee: RM 1,500
Monthly License: RM 499 / month
Utility Usage: 1% of recorded sales
Minimum Contract: 6 months
Deposit: 2 months
```

This lets the operator start with lower risk while still respecting the product as a real SaaS system.

---

## 5. Add-On Pricing

Add-ons should not be bundled into the first Standard Package unless commercially justified.

Suggested add-ons:

```text
Membership Module: RM 199 – RM 499 / month
Advanced Booking: RM 299 – RM 699 / month
Coach Booking: RM 299 – RM 699 / month
Pro Shop Advanced: RM 299 – RM 899 / month
Multi-Branch: RM 500 – RM 1,500 / month per extra branch
Accounting Export: RM 199 – RM 499 / month
Loyalty / Promo Engine: RM 199 – RM 499 / month
Advanced Inventory: RM 299 – RM 799 / month
Priority Support: RM 300 – RM 1,000 / month
Custom Feature Development: Quoted separately
```

---

## 6. Recommended First Market Offer

For first real operator sale, recommended offer:

```text
EDGE RANGE OS Standard
Setup Fee: RM 2,500
Monthly License: RM 799 / month
Utility Usage: 1% of monthly recorded sales
Minimum Contract: 12 months
Deposit: 2 months
Initial Payment: RM 2,500 + RM 1,598 + RM 799 = RM 4,897
```

If operator resists initial payment, fallback offer:

```text
Introductory Go-Live Package
Setup Fee: RM 1,500
Monthly License: RM 499 / month
Utility Usage: 1% of monthly recorded sales
Minimum Contract: 6 months
Deposit: 2 months
Initial Payment: RM 1,500 + RM 998 + RM 499 = RM 2,997
```

---

## 7. Sales Positioning

Do not sell as:

```text
QR order page
Simple website
One-time app
Cheap POS replacement
```

Sell as:

```text
Driving range operating system
Owner monitoring platform
Staff counter workflow system
Customer QR ordering layer
POS Lite + Stock Lite operations platform
Subscription-based digital operations system
```

---

## 8. Recommended Public Pricing Display

For website/pitch material, keep pricing simple:

```text
Starter: From RM 399/month
Standard: From RM 799/month
Pro: From RM 1,499/month
```

Then mention:

```text
Setup, deposit, contract term and usage component apply.
Final pricing depends on bay count, operation size, setup scope and support requirement.
```

---

## 9. Internal Pricing Guardrail

Do not offer unlimited custom work inside monthly subscription.

Monthly subscription covers platform access, normal support and standard updates.

Custom development, special integration, heavy data migration, multi-branch logic, or unique operator workflow should be quoted separately.
