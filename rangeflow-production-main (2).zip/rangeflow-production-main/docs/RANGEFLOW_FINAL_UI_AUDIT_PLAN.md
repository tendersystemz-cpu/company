# RangeFlow Final UI Audit Plan

## Purpose

This document locks the final UI polish direction for RangeFlow.

The goal is to review each important page one by one, fix layout, spacing, typography, branding and usability, then stop repeated fine tuning.

## Product Rule

RangeFlow is now treated as a universal standard package.

Do not present the product as a Bukit Unggul-only custom system.

Use generic fallback branding until setup wizard is implemented:

- RangeFlow Demo Range
- RangeFlow Standard Package
- Your Golf Range

## No New Feature Rule

During final UI pass, do not add new major features.

Allowed:

- Layout polish
- Font size cleanup
- Spacing cleanup
- Button hierarchy cleanup
- Broken link fix
- Branding generalization
- Better card compactness
- Mobile responsiveness
- Clear navigation and return buttons

Not allowed during this pass:

- New payment gateway
- New membership engine
- New booking module
- New AI automation
- New kitchen display system
- New complex auth system

## Page Review Order

### Phase 1: Critical customer and landing pages

1. Customer Bay Page
   - `/b/01`
   - Must be clean, compact, premium and generic.
   - Remove Bukit Unggul hardcoded display.
   - Remove default blue browser link style.
   - Improve tile spacing and coming soon badges.

2. Operations Hub / Landing Page
   - `/hub`
   - Must look like the main product command center.
   - Main menu dropdown must be clean and readable.
   - Staff/owner tools must stay locked before login.
   - Product must look universal, not BUCC-only.

3. Customer Order Page
   - `/b/01/order`
   - Must show order flow clearly.
   - Payment proof section must be easy to understand.
   - Cart/checkout must be compact.

### Phase 2: Core operations pages

4. Counter Queue
   - `/queue`
   - Must be compact enough for real staff operation.
   - Payment verification must be visually clear.
   - Status/action buttons must be clean.
   - Print Order Slip must appear only after payment verified.

5. Delivery Confirmation
   - `/deliver/[bookingId]`
   - Safe mode must be clear.
   - Return to Main Menu and Back to Queue must be visible.
   - Manual bay confirmation must not look temporary/confusing.

6. Menu Management
   - `/menu`
   - Form should be compact and professional.
   - Existing menu cards/images should not waste too much space.
   - Save button should be clear.

### Phase 3: Admin and configuration pages

7. QR Management
   - `/qr`
   - QR cards should be printable and compact.
   - Header information should be concise.
   - Customer base URL should be accurate.

8. Payment Setup
   - `/payments`
   - QR image upload/URL instruction must be clear.
   - Preview must look professional.
   - Broken image states should not look ugly.

9. Owner Dashboard
   - `/owner`
   - Metrics should be compact and readable.
   - Cards should use consistent height.
   - Dashboard should look like management view, not raw debug.

10. System Health
    - `/health`
    - Keep internal but readable.
    - PASS status should be compact.
    - Validation result cards should be easy to scan.

## Final UI Design Rules

### Typography

- Page title: 28-36px desktop, 24-30px mobile.
- Section title: 18-24px.
- Body text: 14-16px.
- Labels: 11-13px uppercase where needed.
- Avoid oversized text on operational pages.

### Spacing

- Reduce excessive vertical whitespace.
- Use consistent card padding.
- Keep mobile pages scroll-friendly.
- Important actions should remain above fold where possible.

### Color

- Keep RangeFlow dark green identity.
- Use mint green for primary actions.
- Use red only for reject/error/destructive action.
- Remove default blue link styling.

### Navigation

Every operations page should have:

- Return to Main Menu
- Relevant shortcut buttons

Customer page should not show staff/admin internal actions.

### Branding

All pages should avoid hardcoded real range names unless loaded from setup config.

Fallback names:

- RangeFlow Demo Range
- Your Golf Range
- RangeFlow Standard Package

### Operational Clarity

Operations pages must answer immediately:

- What bay?
- What order?
- Paid or unpaid?
- What action next?
- Who needs to prepare/deliver?

## Completion Criteria

The final UI pass is complete only when:

1. All critical pages open without 404 or runtime errors.
2. Customer page no longer looks like broken/default browser styling.
3. Internal pages have clear return navigation.
4. Main hub links to all important pages correctly.
5. Branding is generic and product-ready.
6. Queue, menu, QR, payment, owner and health pages are compact enough for real use.
7. No new optional modules are added during the final pass.

## Freeze Rule

After the final UI pass is approved, only bug fixes are allowed unless a new paid/operator requirement is confirmed.
