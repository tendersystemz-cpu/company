# EDGE RangeFlow Mobile Final Pass Standard

## Purpose

EDGE RangeFlow must feel mobile-first because:

- customers scan QR using phone
- staff uses phone/tablet at the range
- owner monitors remotely

Desktop view is secondary.

## Customer Mobile Requirements

Customer page must be usable with one hand.

Required:

- large bay number
- clear order cards
- clear plus/minus buttons
- sticky/floating Need Help button
- clear checkout total
- no cluttered navigation
- no admin/owner links
- BM/BI labels readable
- payment QR fits screen
- receipt/status readable without zooming

Minimum tap target:

```text
44px height or larger
```

## Admin Operasi Mobile Requirements

Admin Operasi page should be usable on phone/tablet.

Required:

- bay grid visible and tappable
- bay 01-25 active
- bay 26-30 standby/disabled
- HELP/PAY/ORDER/OK label readable
- selected bay panel easy to find
- verify payment button easy to tap
- preparing/delivered buttons not too small
- Add Order For Bay visible
- Stock link visible

Admin should not need desktop to run daily operation.

## Owner Mobile Requirements

Owner page should support remote monitoring.

Required:

- today sales visible quickly
- today orders visible quickly
- bucket quantity visible quickly
- bay usage visible quickly
- master control buttons easy to tap
- payment QR upload page usable on phone
- access PIN page usable on phone

Owner does not need daily queue clutter.

## Payment Mobile Requirements

Payment page must be extremely clear.

Required:

- total amount large
- QR image large enough
- order token visible
- instruction short
- Check Status button visible
- optional proof hidden/collapsed unless needed

## Receipt Mobile Requirements

Receipt/status page must show:

- token large
- payment status clear
- order status clear
- total amount clear
- ordered item list readable
- refresh/status behavior
- Order Again button

## QR Sticker Scan Requirements

When customer scans bay sticker:

- order page must open directly
- no login
- no admin menu
- no confusing landing page
- no unnecessary extra clicks

## Mobile Test Devices

Minimum test:

- iPhone Safari
- Android Chrome if available
- staff tablet/phone browser

## Mobile Pass Checklist

Customer:

- [ ] Scan QR opens order page
- [ ] Order page readable on phone
- [ ] Need Help visible
- [ ] Checkout total visible
- [ ] Payment QR fits screen
- [ ] Receipt/status readable

Admin:

- [ ] Bay grid usable on phone
- [ ] Need Help alert visible
- [ ] Payment verify button usable
- [ ] Add Order For Bay usable
- [ ] Stock page usable

Owner:

- [ ] Owner dashboard readable
- [ ] Payment QR upload works on phone
- [ ] QR Bay Management usable enough for owner/admin
- [ ] Access PIN page usable

## Fail Conditions

Fail mobile pass if:

- customer must zoom
- customer sees admin link
- payment QR is too small
- Need Help is hidden
- admin bay buttons are too small
- staff cannot verify payment quickly
- owner cannot upload payment QR from phone
