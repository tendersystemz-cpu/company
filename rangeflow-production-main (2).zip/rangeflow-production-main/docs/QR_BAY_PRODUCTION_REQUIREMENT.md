# RangeFlow QR Per Bay Production Requirement

## Objective

Every driving range bay must have its own QR code so customers can scan from their bay and order balls, food, drinks, and future services without staff needing to ask which bay they are using.

## Locked customer URL format

```text
https://rangeflow-bucc.netlify.app/b/{bayCode}
```

Examples:

```text
https://rangeflow-bucc.netlify.app/b/01
https://rangeflow-bucc.netlify.app/b/02
https://rangeflow-bucc.netlify.app/b/03
```

## Production behavior

When customer scans a bay QR:

1. App opens the exact bay page.
2. App detects org slug `bukitunggul`.
3. App detects location Bukit Unggul Driving Range.
4. App detects the scanned bay code.
5. Customer can order range balls.
6. Customer can later order food and drinks from the same bay.
7. Booking/order/payment records must store bay_id and bay code.
8. Operations app must show incoming orders grouped by bay.

## QR generation requirement

Operations/admin app must support:

- Generate QR for all active bays.
- Generate QR for a selected bay.
- Print-ready QR label layout.
- QR label should show bay display name and short instruction.
- QR should point to `/b/{bayCode}`.

## Recommended QR label text

```text
Scan to Order
Bay 01
Balls • Food • Drinks
RangeFlow BUCC
```

## Data dependency

QR codes should be generated from the `bays` table:

- bays.code
- bays.display_name
- bays.status
- locations.org_id
- orgs.slug

Only active bays should be included by default.

## Production priority

1. Stabilize `/b/01` customer flow.
2. Enable real booking/order/payment write.
3. Add QR generator for all bays.
4. Add food and beverage menu ordering by bay.
5. Add operations dashboard to manage bay-based orders.
