# EDGE RANGE OS — KIV Worklog

> This file records postponed or partially completed work so the next assistant/developer can continue without losing context.

---

## Current Product Direction

Product name:

```text
EDGE RANGE OS
```

Meaning:

```text
EDGE = Expert Digital Golf Ecosystem
```

Branding rule:

- Use **EDGE RANGE OS** as the universal SaaS product brand.
- Do not use any specific venue/operator/client as the main product identity.
- DG / EDGE monogram without crown is the master logo direction.
- Crown version is not the standard master product logo.

---

## Universal Product Setup Rule — Important

EDGE RANGE OS must not hardcode operator-specific products, packages, customer categories, ball package names, or pricing into standard UI screens.

### Correct direction

All operator-specific setup must come from:

- Setup Wizard
- Menu Management
- POS Lite setup
- Owner configuration
- Tenant/operator database records

### Applies to

- Ball package names
- Ball package prices
- F&B products
- Rental products
- Special pricing names
- Member/student/staff/corporate pricing labels
- Payment QR setup
- Operating flow labels

### Counter/POS rule

Staff Counter and POS Lite must show products configured by the operator. If no products are configured, show an instruction to configure products through Setup Wizard / Menu Management instead of showing fallback demo items.

---

## Completed Documentation

1. `docs/EDGE_RANGE_OS_INFOGRAPHIC_PACK.md`
   - BM + BI infographic pack source
   - brand direction
   - logo rule
   - universal navigation
   - setup wizard explanation
   - standard package explanation

2. `docs/EDGE_RANGE_OS_ADMIN_OWNER_COMPACT_UI_ALIGNMENT.md`
   - compact UI alignment spec for Admin/Owner/Staff pages
   - universal menu route mapping
   - protected access rules
   - typo/copy fix list

---

## Completed UI Source Patches

### 1. Global Compact Override

File:

```text
operations/app/globals.css
```

Commit:

```text
fdcd8acc78d01711181b5165f7e46e2a7a6cf5a4
```

Completed:

- Compact mobile-first UI override for Admin/Owner/Staff pages.
- Forces visible header branding to EDGE RANGE OS.
- Reduces oversized hero areas.
- Tightens navigation and cards.

### 2. Owner Dashboard Source Patch

File:

```text
operations/app/owner/page.tsx
```

Commit:

```text
76a838ff01cdcd45dbbaea061e8df2c252717366
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Owner dashboard no longer relies only on CSS override for product branding.

### 3. Stock Lite Source Patch

File:

```text
operations/app/stock/page.tsx
```

Commit:

```text
0b9eb4b4446b61333c0b1dfacb3fdd047defd164
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Compact mobile-first source styling applied.
- `inventory` wording corrected.
- `Refresh` label confirmed.

### 4. Promotions Lite Source Patch

File:

```text
operations/app/promotions/page.tsx
```

Commit:

```text
3c6509b59a0ef360fb87beb13aebd911d66ca916
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Compact mobile-first source styling applied.
- Navigation aligned: Owner, POS, Members, Counter, Load Promotions.

### 5. Customer & Membership Lite Source Patch

File:

```text
operations/app/members/page.tsx
```

Commit:

```text
562a46c357a990778bf483c347de41f4716b72ba
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Correct wording confirmed: `Protected Customer Data`.
- Owner PIN access remains protected.
- Navigation aligned: Owner, POS, Promotions, Counter, Load Members.

### 6. POS Lite Source Patch

File:

```text
operations/app/pos/page.tsx
```

Commit:

```text
beeec539ceefda49f5d537d2f6bd2f537db43c5f
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Compact mobile-first source styling applied.
- Bay selector made more compact.
- Customer name and phone remain optional.
- Assisted order logic preserved.

### 7. Staff Counter Source Patch

File:

```text
operations/app/counter/page.tsx
```

Initial branding/compact commit:

```text
5390201bdcba7359f0abf9784a0dda6505d19223
```

Universal product correction commit:

```text
5322d26c7c29170e137e264ba29b8e0ca864ede3
```

Completed:

- Source branding changed to EDGE RANGE OS.
- Compact staff counter layout applied.
- Hardcoded product packages removed.
- Hardcoded fallback products removed.
- Staff Counter now relies on Setup Wizard / Menu Management / POS setup products.
- If no products are configured, staff sees setup instruction instead of demo/fallback products.
- Operational functions preserved:
  - Bay overview
  - Need Help
  - Payment verification
  - Self Pickup
  - Deliver to Bay
  - Print slip type selector
  - Release Bay
  - Add to Bay

---

## KIV / Pending Work

### KIV-001 — Payment QR Setup Source Patch

File:

```text
operations/app/payments/page.tsx
```

Status:

```text
KIV / not completed
```

Reason:

A full-file GitHub update was blocked by connector safety checks because the file contains payment/bank/account-related fields and QR payment configuration text.

Important:

The page is still visually improved by the global CSS override in `operations/app/globals.css`, but the source code itself may still contain old branding text and old placeholder copy.

Required next action:

Patch this file using a smaller/diff-style method instead of full-file replacement.

Minimum required edits:

1. Change visible header label:

```tsx
<span>RangeFlow @ UKM</span>
```

to:

```tsx
<span>EDGE RANGE OS</span>
```

2. Change merchant placeholder from a real/specific operator name to neutral wording:

```tsx
placeholder="Operator / Merchant Name"
```

3. Ensure customer payment note stays universal and proof remains optional:

```text
Please keep payment proof if requested by staff.
```

or BM equivalent:

```text
Simpan bukti bayaran jika diminta oleh staff.
```

4. Keep route/navigation alignment:

```text
Owner → /owner
Menu → /menu
Counter → /counter
Save Settings action
```

Do not expose payment setup to customer pages.

---

### KIV-002 — Operations Home Branding Cleanup

File:

```text
operations/app/page.tsx
```

Status:

```text
Pending
```

Required next action:

Current source may still use legacy wording such as:

```text
RangeFlow Standard Package
Operations Start
Pilot Control Panel
```

Update to EDGE RANGE OS product direction:

```text
EDGE RANGE OS
Operations Console
```

Remove wording that makes the product feel like a temporary pilot unless it is inside internal-only development/debug context.

---

### KIV-003 — README Product Direction Cleanup

File:

```text
README.md
```

Status:

```text
Pending
```

Required next action:

README still contains older site-specific deployment context. Preserve technical deployment notes if still needed, but add or update the top section so universal product direction is clear:

```text
EDGE RANGE OS
Universal subscription-based operations platform for driving range operators.
```

Specific deployment/operator details should be moved under deployment notes, not main product identity.

---

## Priority Order For Next Assistant / Developer

Continue in this order:

1. `operations/app/page.tsx`
2. `operations/app/payments/page.tsx` using a safer smaller patch method
3. `README.md`
4. Rebuild/deploy operations app
5. Capture screenshots for:
   - Owner Dashboard
   - Stock Lite
   - Promotions Lite
   - Members Lite
   - POS Lite
   - Staff Counter
   - Payment QR Setup

---

## Acceptance Rule

Work is only considered complete when:

- Admin/Owner/Staff pages show EDGE RANGE OS as product identity.
- No standard dashboard page uses a real/specific operator as main identity.
- No standard module hardcodes operator-specific products, package names, or pricing.
- Compact mobile-first view matches customer-page professionalism.
- Customer pages do not expose admin/owner controls directly.
- Protected admin/owner routes remain locked.
- Payment proof remains optional unless configured by operator.
