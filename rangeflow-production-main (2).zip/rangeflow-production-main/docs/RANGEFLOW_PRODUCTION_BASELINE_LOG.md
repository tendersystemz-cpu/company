# RangeFlow Production Baseline Log

**Project:** RangeFlow Golf Driving Range System  
**Repository:** `duniabiz2udotcom/rangeflow-production`  
**Customer site:** `https://rangeflow-bucc.netlify.app`  
**Operations site:** `https://rangeflow-ops.netlify.app`  
**Supabase project ref:** `cgewjbfycnqbyczyuthp`  
**Org slug:** `bukitunggul`  
**Log created:** 2026-05-14  
**Current phase:** Production baseline lock / defect cleanup only

---

## 1. Recording Rule

From this baseline onward, every movement must be recorded in this Markdown file.

Each future entry must include:

1. Date/time.
2. Reason for action.
3. Scope: bug fix, UI polish, database migration, deploy, security fix, or test.
4. Files changed.
5. Supabase SQL / migration name if any.
6. GitHub commit SHA if any.
7. Netlify deploy ID if any.
8. Test steps performed.
9. Test result: pass, fail, or pending.
10. Rollback note if the action could affect production flow.

No silent changes after this point.

---

## 2. Baseline Scope

RangeFlow is currently treated as a production-ready baseline for pilot/demo operation.

### Completed UI final pass pages

- Hub
- Customer Bay
- Customer Order
- Counter Queue
- Menu Management
- QR Management
- Payment Setup
- Owner Dashboard
- System Health
- Delivery Confirmation

### Feature freeze rule

Allowed now:

- bug fixes
- broken link fixes
- security hardening
- deployment fixes
- production smoke tests
- documentation and handover material

Not allowed without a new confirmed requirement:

- membership expansion
- loyalty module
- Telegram automation
- WhatsApp automation
- AI automation
- new dashboard module
- payment gateway integration
- major report module

---

## 3. Production URLs

| Area | URL | Status |
|---|---|---|
| Customer landing | `https://rangeflow-bucc.netlify.app/` | Active pilot/customer site |
| Customer Bay 01 | `https://rangeflow-bucc.netlify.app/b/01` | Active |
| Customer Order Bay 01 | `https://rangeflow-bucc.netlify.app/b/01/order` | Active |
| Operations Hub | `https://rangeflow-ops.netlify.app/hub` | Active |
| Counter Queue | `https://rangeflow-ops.netlify.app/queue` | Active |
| Menu Management | `https://rangeflow-ops.netlify.app/menu` | Active |
| Owner Dashboard | `https://rangeflow-ops.netlify.app/owner` | Active |
| QR Management | `https://rangeflow-ops.netlify.app/qr` | Active |
| Payment Setup | `https://rangeflow-ops.netlify.app/payments` | Active |
| System Health | `https://rangeflow-ops.netlify.app/health` | Active |

Note: `rangeflow-bucc` remains the customer pilot site name. Operations branding/linking has been cleaned to `rangeflow-ops` to avoid BUCC-specific operations branding.

---

## 4. Access Hardening Completed Before This Log

### Completed items

- `org_access_pins` table prepared in Supabase.
- `verify_org_access_pin` function prepared.
- `update_org_access_pin` function prepared.
- `/hub` verifies access code through Supabase.
- `/access` owner form can update access code.

### Required regression test

- `/hub` blocks wrong access code.
- `/hub` allows correct access code.
- `/access` can update owner code.
- Old access code fails after update.
- New access code works after update.

Status at time of log creation: completed before baseline log, but not retested in this log session.

---

## 5. Action Log

### 2026-05-14 — Production defect cleanup declared

**Reason:** User clarified that current work is not new feature development; it is necessary defect cleanup before sale/demo.

**Scope:** Production defect cleanup.

**Locked defect list:**

1. RM16 overcharge / bucket default issue.
2. Menu Management not reflecting correctly in customer order page.
3. Counter Queue missing station-specific print slip buttons.
4. Operations URL should use `rangeflow-ops`, not `rangeflow-bucc-ops`.
5. Supabase `payments` RLS security defect.

**Result:** Feature freeze reaffirmed.

---

### 2026-05-14 — Queue print slip buttons patched

**Reason:** Print route already supports station-specific slip types, but Counter Queue only exposed one generic print button.

**Scope:** Operations UI defect fix.

**File changed:**

- `operations/app/queue/page.tsx`

**Behavior before:**

- One button only: `Print Order Slip`
- Opened `/print/[bookingId]`

**Behavior after:**

Four buttons are shown after payment is verified:

- `Ball Slip` → `/print/[bookingId]?type=ball`
- `Kitchen Slip` → `/print/[bookingId]?type=kitchen`
- `Delivery Slip` → `/print/[bookingId]?type=delivery`
- `Full Slip` → `/print/[bookingId]?type=full`

**GitHub commit:**

- `ce56461d389f2b7d0975cb291d9035ee0189d8b9`

**Netlify operations deploy:**

- Site: `rangeflow-ops`
- Deploy ID: `6a04c86434157d000831f3ae`
- Status: ready
- Commit: `ce56461d389f2b7d0975cb291d9035ee0189d8b9`

**Test result:**

- User later confirmed flow passed.

**Rollback note:**

- Revert `operations/app/queue/page.tsx` to prior generic `printSlip(order)` if station-specific button layout causes issue.

---

### 2026-05-14 — Menu Management category options fixed

**Reason:** Menu Management UI had category option `promo`, but database constraint does not allow `promo` in `menu_items.category`.

**Scope:** Operations UI / database constraint alignment.

**File changed:**

- `operations/app/menu/page.tsx`

**Behavior before:**

Category dropdown included:

- `fb`
- `snack`
- `drink`
- `equipment`
- `promo`

`promo` could fail because database category constraint does not accept it.

**Behavior after:**

Category dropdown uses database-valid values:

- `fb` / Food
- `snack` / Snack
- `drink` / Drink
- `equipment` / Equipment
- `set` / Set / Combo
- `other` / Other

**GitHub commit:**

- `5a7633392f146ac99070c3862d6a68e0f796ea47`

**Netlify operations deploy:**

- Site: `rangeflow-ops`
- Deploy ID: `6a04cf1e664d77000894b0dd`
- Status: ready
- Commit: `5a7633392f146ac99070c3862d6a68e0f796ea47`

**Test result:**

- User later confirmed flow passed.

**Rollback note:**

- Do not reintroduce `promo` unless database constraint is also intentionally extended.

---

### 2026-05-14 — Customer order page menu sections expanded

**Reason:** Admin menu had valid available categories that were not clearly exposed on customer order page.

**Scope:** Customer UI menu sync defect fix.

**File changed:**

- `customer/app/b/[bayCode]/order/page.tsx`

**Behavior before:**

Customer order page mainly displayed:

- `Makanan`
- `Minuman`

Some active categories could be hidden or mixed.

**Behavior after:**

Customer order page displays sections:

- `Makanan`
- `Snack`
- `Minuman`
- `Equipment`
- `Set / Lain-lain`

**GitHub commit:**

- `b22951bbdcd26839a4f4263ae8e5979e8d250875`

**Test result:**

- User later confirmed customer flow passed.

**Rollback note:**

- If the customer page becomes too crowded, hide categories using UI grouping, not by removing database categories from RPC.

---

### 2026-05-14 — Supabase customer menu RPC fixed

**Reason:** `get_customer_order_options` returned only a subset of active menu categories. Customer order page needed to receive the same valid categories that admin can manage.

**Scope:** Supabase database function migration.

**Migration name:**

- `fix_customer_order_menu_category_sync`

**Function changed:**

- `public.get_customer_order_options(p_org_slug text, p_bay_code text)`

**Behavior after migration:**

The RPC now exposes available menu items in these valid categories:

- `fb`
- `snack`
- `drink`
- `equipment`
- `set`
- `other`

**Verification query result:**

- `customer_menu_count = 14`
- `expected_available_count = 14`

**Result:**

Customer menu count matched the active expected BUCC available menu count.

**Test result:**

- User later confirmed flow passed.

**Rollback note:**

- Roll back to prior function only if customer order page fails to load after migration.

---

### 2026-05-14 — Operations domain link cleaned on customer landing page

**Reason:** User clarified that the operations URL was intentionally edited to `rangeflow-ops.netlify.app` to remove BUCC-specific naming from operations access.

**Scope:** Customer landing link cleanup / product branding alignment.

**File changed:**

- `customer/app/page.tsx`

**Behavior before:**

Customer landing page had hardcoded operations links pointing to:

- `https://rangeflow-bucc-ops.netlify.app`

**Behavior after:**

A single constant controls operations base URL:

```ts
const OPS_BASE_URL = 'https://rangeflow-ops.netlify.app';
```

Operations links now point to:

- `https://rangeflow-ops.netlify.app/hub`
- `https://rangeflow-ops.netlify.app/queue`
- `https://rangeflow-ops.netlify.app/menu`
- `https://rangeflow-ops.netlify.app/owner`
- `https://rangeflow-ops.netlify.app/qr`

**GitHub commit:**

- `80bdd2ce26031eef21e5c029150e49f18ed2009a`

**Netlify customer deploy:**

- Site: `rangeflow-bucc`
- Deploy ID: `6a04d4aa6d73090008235ffb`
- Status: ready
- Commit: `80bdd2ce26031eef21e5c029150e49f18ed2009a`

**Test result:**

- User confirmed landing link passed.

**Rollback note:**

- Do not restore `rangeflow-bucc-ops` unless a separate BUCC-specific operations site is intentionally created again.

---

### 2026-05-14 — RM16 overcharge fix verified as already deployed

**Reason:** Previous defect caused automatic RM16 charge because `bucketQty` defaulted to `1`.

**Scope:** Customer order pricing defect.

**File verified:**

- `customer/app/b/[bayCode]/order/page.tsx`

**Current behavior:**

- `bucketQty` initializes at `0`.
- Customer can order food/drink/menu item without automatically adding bucket charge.

**Netlify customer deploy before latest branding patch:**

- Site: `rangeflow-bucc`
- Deploy ID: `6a04b61432b7c20008a6f3ee`
- Status: ready
- Commit: `9bf911da2c25c4cbb2fd447a52669d4cfab31edb`
- Title: `Fix order page default bucket quantity to prevent add-on overcharge`

**Test result:**

- User confirmed RM16 flow passed.

**Rollback note:**

- Never set bucket quantity default back to `1` unless product requirement explicitly changes.

---

### 2026-05-14 — Post-deploy smoke tests passed by user

**Reason:** Confirm production baseline behavior after deployment.

**Scope:** Live smoke test.

**Test checklist passed by user:**

1. Landing links from customer site go to `rangeflow-ops`.
2. Customer order page no longer auto-adds RM16.
3. Menu sync is working.
4. Operations queue flow is working.
5. Station-specific print slip buttons are working.

**User confirmation:**

- `done pass semuanya dah ok`

**Result:**

Production flow baseline accepted before security RLS hardening.

---

### 2026-05-14 — Supabase payments RLS hardening applied

**Reason:** Supabase advisory showed `public.payments` had Row Level Security disabled.

**Scope:** Database security hardening.

**Risk:** Payment table is sensitive. Direct anonymous access should be blocked.

**Pre-check:**

Payment page and operations pages use RPC functions instead of direct browser table access. Important payment-related RPC functions were verified as `SECURITY DEFINER = true`, including:

- `create_customer_order`
- `get_customer_receipt`
- `submit_customer_payment_proof`
- `verify_operations_payment`
- `get_operations_queue_summary`
- `get_operations_print_slip`

**Migration name:**

- `enable_payments_rls_deny_direct_anon_access`

**SQL applied:**

```sql
alter table public.payments enable row level security;

drop policy if exists payments_no_direct_anon_access on public.payments;

create policy payments_no_direct_anon_access
on public.payments
for all
to anon
using (false)
with check (false);
```

**Verification result:**

- `payments.rls_enabled = true`
- Policy exists: `payments_no_direct_anon_access`
- Policy role: `anon`
- Policy command: `ALL`
- Policy `USING`: `false`
- Policy `WITH CHECK`: `false`

**Current status:**

- RLS hardening applied and database verification passed.
- Full live app retest after RLS hardening is still recommended.

**Required post-RLS smoke test:**

1. Create one small customer order.
2. Submit payment proof.
3. Confirm order appears in Queue.
4. Verify Paid.
5. Open all slip types.

**Rollback note:**

If payment proof submission or queue payment verification fails after this migration, rollback using:

```sql
alter table public.payments disable row level security;
```

Then investigate whether any client-side direct table access still exists.

---

## 6. Current Baseline Status

### Accepted as working before RLS hardening

- Customer landing link to operations site.
- Customer order flow.
- RM16 overcharge fix.
- Menu sync.
- Queue verification.
- Station print slips.

### Applied after accepted baseline

- `payments` RLS security hardening.

### Still recommended after this log

- One full post-RLS smoke test.

---

## 7. Controlled Next Actions

### Immediate next action

Run post-RLS smoke test:

1. `https://rangeflow-bucc.netlify.app/b/01/order`
2. Create small order.
3. Submit dummy payment reference/proof.
4. `https://rangeflow-ops.netlify.app/queue`
5. Verify Paid.
6. Open Ball Slip, Kitchen Slip, Delivery Slip, Full Slip.

### If pass

Mark baseline as:

```text
RangeFlow Production Baseline v1.0
```

### If fail

Record failure in this file before making any fix.

---

## 8. Future Log Template

Copy this template for every future movement:

```md
### YYYY-MM-DD HH:mm MYT — Short action title

**Reason:**

**Scope:**

**Files changed:**

- `path/to/file`

**Supabase migration:**

- `migration_name` or `None`

**GitHub commit:**

- `commit_sha` or `None`

**Netlify deploy:**

- Site:
- Deploy ID:
- Status:

**Test steps:**

1.
2.
3.

**Test result:**

- Pass / Fail / Pending

**Rollback note:**

-
```

---

## 9. Hard Rule

If a change is not recorded here, it is not considered part of the official RangeFlow production baseline.
