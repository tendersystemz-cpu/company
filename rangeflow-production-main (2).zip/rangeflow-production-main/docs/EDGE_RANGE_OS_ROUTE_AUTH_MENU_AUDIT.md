# EDGE RANGE OS — Route / Auth / Menu Audit

Last locked: 2026-05-30

This file is the execution baseline for the next cleanup sprint. It exists to stop route confusion, old fallback pages, mixed buttons, inconsistent navigation, and repeated GPT hallucination before Super Admin is built.

Read together with:

- `docs/EDGE_RANGE_OS_NEXT_DEVELOPER_HANDOFF.md`
- `docs/EDGE_RANGE_OS_ICON_FIRST_UI_DIRECTION.md`
- `docs/EDGE_RANGE_OS_COOLIFY_DEPLOYMENT_SOURCE_OF_TRUTH.md`

---

## 1. Immediate sprint decision

The immediate sprint is:

```txt
P0 — Route / Auth / Menu Cleanup
```

Do **not** build Super Admin until P0 is completed.

Reason:

```txt
Super Admin must not be added into an operations app where routes, buttons, menu, and access locks are still mixed.
```

---

## 2. Product role model

| Area | User | Access | Purpose |
|---|---|---|---|
| Customer | Customer / player | Public | QR-first order, payment instruction, receipt/status. |
| Staff | Counter / runner / ops staff | Staff PIN or Owner PIN | Counter, queue, payment verification, fulfilment, stock. |
| Owner | Range owner/operator | Owner PIN only | Dashboard, reports, setup, products, payment QR, access control. |
| Super Admin | EDGE SaaS operator | Future separate auth | Tenant, billing, package, suspend/reactivate, audit. |

Existing backend/RPC direction:

```txt
verify_org_access_pin(p_org_slug, p_role_key, p_pin)
update_org_access_pin(p_org_slug, p_owner_pin, p_role_key, p_new_pin)
```

Do not hardcode PINs in frontend.

---

## 3. Customer app routes — KEEP PUBLIC

| Route | Status | Role | Final label | Notes |
|---|---|---|---|---|
| `customer/` | Keep | Public | Customer Home | Customer-facing landing. |
| `customer/b/[bayCode]` | Keep | Public | Bay Landing | Redirect/entry to bay order. |
| `customer/b/[bayCode]/order` | Keep | Public | Bay Order | Main QR-first order page. |
| `customer/pay/[bookingId]` | Keep | Public after order | Payment | Manual QR payment instruction. |
| `customer/receipt/[bookingId]` | Keep | Public after order | Receipt / Slip | Receipt/status page. |

Customer routes must not expose owner/staff controls.

---

## 4. Operations routes — PRODUCTION KEEP

| Route | Status | Role | Final menu label | Action |
|---|---|---|---|---|
| `operations/` | Keep | Public shell with protected actions | Hub | Make this the icon-first dashboard home. |
| `operations/hub` | Keep temporarily | Staff/Owner access hub | Access Hub | Clean old wording/legacy links, or later redirect to `/`. |
| `operations/counter` | Keep | Staff | Counter | Main staff operation route. |
| `operations/pos` | Keep | Staff / Owner context | POS Lite | Staff usable, owner controllable. |
| `operations/stock` | Keep | Staff / Owner context | Stock Lite | Stock operation and monitoring. |
| `operations/menu` | Keep | Staff / Owner context | Menu | Product/menu setup and availability. |
| `operations/payments` | Keep | Staff / Owner context | Payments | Payment verification/setup. Audit internal buttons. |
| `operations/owner` | Keep | Owner | Owner | Owner dashboard/control/reporting. |
| `operations/access` | Keep | Owner | Access | PIN/access settings. |
| `operations/qr` | Keep | Owner | QR | QR Bay Management. |
| `operations/members` | Keep but not P0 critical | Owner/Staff if stable | Members | Optional/future; hide from main P0 nav unless stable. |
| `operations/promotions` | Keep but not P0 critical | Owner | Promotions | Optional/future; hide from main P0 nav unless stable. |
| `operations/print/[bookingId]` | Keep internal | Staff | Print Slip | Utility route, not main nav. |
| `operations/deliver/[bookingId]` | Keep internal | Staff | Delivery | Utility route, not main nav. |

---

## 5. Legacy / fallback / confusing routes

These routes may contain useful code, but must not appear randomly in production navigation.

| Route | Problem | Required action |
|---|---|---|
| `operations/staff` | Generic old staff page / overlap. | Audit; likely redirect to `/counter`. |
| `operations/staff-ops` | Legacy staff operations route. | Redirect to `/counter` unless still required. |
| `operations/staff-ops-bay` | Legacy bay-centric route. | Merge useful logic into `/counter` or redirect to `/counter`. |
| `operations/queue` | Duplicates queue/counter. | Redirect to `/counter` or integrate as counter tab. |
| `operations/pilot` | Pilot wording conflicts with product identity. | Hide or redirect. |
| `operations/trial` | Trial wording conflicts with product identity. | Hide or redirect. |
| `operations/setup` | May duplicate setup wizard. | Redirect to final setup route after decision. |
| `operations/setup-wizard` | Linked by newer nav; existence must be verified. | Keep if implemented; otherwise create/redirect carefully. |
| `operations/checkpoint` | Internal/debug style route. | Hide from main nav; redirect if not needed. |
| `operations/health` | System health utility. | Keep internal/admin utility only, not main nav. |

---

## 6. Final P0 navigation model

Use compact icon-first navigation, not large text-heavy pages.

| Icon | Label | Route | Role | Section |
|---|---|---|---|---|
| `⌂` | Hub | `/` | Public shell | Main |
| `🧾` | Bay Order | customer `/b/07/order` | Public external | Customer |
| `🛎️` | Counter | `/counter` | Staff | Staff |
| `👥` | Queue | `/counter` | Staff | Staff |
| `🛒` | POS | `/pos?bay=07` | Staff | Staff |
| `📦` | Stock | `/stock` | Staff | Staff |
| `🍽️` | Menu | `/menu` | Staff/Owner | Staff |
| `💳` | Payments | `/payments` | Staff/Owner | Staff |
| `👑` | Owner | `/owner` | Owner | Owner |
| `▦` | QR | `/qr` | Owner | Owner |
| `⚙️` | Access | `/access` | Owner | Owner |
| `📊` | Reports | `/owner` | Owner | Owner |

Future Super Admin items must not be added to the main menu until Super Admin module starts.

---

## 7. P0 code execution plan

### P0-A — Central route config

Create:

```txt
operations/lib/navigation.ts
```

It must define:

```txt
route path
label
icon
section
role requirement
status: production / deprecated / internal / future
redirect target if deprecated
```

### P0-B — Persistent icon nav

Update:

```txt
operations/app/GlobalReturnNav.tsx
```

It must import and use `operations/lib/navigation.ts`.

It must not maintain its own separate hardcoded route list.

### P0-C — Operations home cleanup

Update:

```txt
operations/app/page.tsx
```

Target: icon-first dashboard following:

```txt
docs/EDGE_RANGE_OS_ICON_FIRST_UI_DIRECTION.md
```

It should not contain independent navigation logic.

### P0-D — Hub cleanup

Update or redirect:

```txt
operations/app/hub/page.tsx
```

Current issue:

```txt
Hub still contains old wording and links to staff-ops/staff-ops-bay/fallback pages.
```

Target:

```txt
Simplify as Access Hub only, or redirect to `/` after persistent nav is stable.
```

### P0-E — Legacy route redirects

Redirect/hide routes listed in section 5.

### P0-F — Button/link cleanup

Patch all buttons/anchors based on this audit. Do not guess.

---

## 8. Main files to inspect before patching

| File | Reason |
|---|---|
| `operations/app/GlobalReturnNav.tsx` | Persistent navigation and access modal attempt. |
| `operations/app/page.tsx` | Operations home currently contains duplicated menu logic. |
| `operations/app/hub/page.tsx` | Known old links and older wording. |
| `operations/app/owner/page.tsx` | Owner dashboard links/actions. |
| `operations/app/counter/page.tsx` | Staff daily operation route. |
| `operations/app/pos/page.tsx` | POS Lite route. |
| `operations/app/stock/page.tsx` | Stock Lite route. |
| `operations/app/menu/page.tsx` | Menu/product management. |
| `operations/app/payments/page.tsx` | Payment setup/verification. |
| `operations/app/access/page.tsx` | Owner access/PIN settings. |
| `operations/app/qr/page.tsx` | QR Bay Management. |

---

## 9. Test checklist after P0 patch

Test live routes after deployment:

```txt
operations/
operations/hub
operations/counter
operations/pos
operations/stock
operations/menu
operations/payments
operations/owner
operations/access
operations/qr
```

Customer smoke test:

```txt
customer/b/07/order
customer/pay/[bookingId]
customer/receipt/[bookingId]
```

Access test:

```txt
Staff route without PIN -> must request PIN
Owner route without owner PIN -> must request owner PIN
Owner PIN can open staff route
Staff PIN must not open owner route
```

---

## 10. Progress target

Current SaaS production readiness before this audit:

```txt
~63%
```

After this audit doc is committed:

```txt
~66%
```

After P0 code cleanup and test:

```txt
75–80%
```

Super Admin starts only after the P0 code cleanup is accepted.
