# EDGE RangeFlow Coolify Production Deployment Guide

## Purpose

This guide records the production deployment direction for EDGE RangeFlow using Coolify.

The live track is Coolify, not Netlify.

## Deployment Principle

- Keep customer, admin operation and owner routes separated.
- Use Coolify now with temporary URL.
- Add custom domain later.
- Do not print final customer QR stickers while using sslip.io temporary domain.
- After custom domain is active, regenerate all QR bay stickers.

## Current Product Positioning

- Product: EDGE RangeFlow
- Package: Standard Package
- Brand layer: Powered by EDGE Ecosystem
- Commercial status: operational product, not demo/testing/pilot

## Required Environment Variables

Set these in Coolify application environment.

### Customer app

```env
NEXT_PUBLIC_SUPABASE_URL=<supabase-url>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<supabase-anon-key>
NEXT_PUBLIC_ORG_SLUG=ukm
NEXT_PUBLIC_CUSTOMER_BASE_URL=<customer-app-url>
NEXT_PUBLIC_OPERATIONS_BASE_URL=<operations-app-url>
```

### Operations app

```env
NEXT_PUBLIC_SUPABASE_URL=<supabase-url>
NEXT_PUBLIC_SUPABASE_ANON_KEY=<supabase-anon-key>
NEXT_PUBLIC_ORG_SLUG=ukm
NEXT_PUBLIC_CUSTOMER_BASE_URL=<customer-app-url>
NEXT_PUBLIC_OPERATIONS_BASE_URL=<operations-app-url>
```

## Important URL Rules

### Customer app routes

- `/` customer landing
- `/b/01/order` customer order page
- `/pay/[bookingId]` payment instruction
- `/receipt/[bookingId]` receipt/status

### Operations app routes

- `/hub` secure access hub
- `/staff-ops-bay` primary Admin Operasi page
- `/staff-ops` fallback queue page
- `/pos?bay=07` assisted order for selected bay
- `/stock` inventory/stock control
- `/owner` owner dashboard
- `/menu` pricing/menu control
- `/payments` payment QR setup
- `/qr` QR bay management
- `/access` PIN access control

## Supabase Requirements

The following must exist before live operation:

- `orgs` row for active org slug
- active `locations` row
- bay records for 01-25 active
- optional bay records 26-30 standby/disabled
- payment settings function/table
- customer order functions
- operations queue functions
- owner summary functions
- stock functions/tables
- assistance request table/functions

Recent assistance layer added:

- `assistance_requests`
- `create_assistance_request`
- `acknowledge_assistance_request`

## Final Pre-Live Test Flow

### 1. Customer order test

Open customer app:

```text
/b/01/order
```

Confirm:
- Bay 01 appears
- 100 Balls Bucket / Bucket 100 Bola appears
- BM/BI labels appear
- Need Help / Perlu Bantuan floating button appears
- Order can be submitted
- Payment page opens

### 2. Payment test

Confirm:
- TNG/DuitNow payment instruction appears
- Payment proof upload is optional fallback only
- Customer can open receipt/status

### 3. Admin Operasi test

Open operations app:

```text
/staff-ops-bay
```

Confirm:
- Bay grid appears
- Bay 01-25 active
- Bay 26-30 standby
- Active order appears under selected bay
- Verify payment works
- Preparing/delivered works
- Kitchen slip opens only if needed

### 4. Need Help test

From customer order page:
- Tap Need Help / Perlu Bantuan

From admin page:
- Confirm Bay 01 blinks/highlights
- Acknowledge assistance
- Alert disappears/updates

### 5. Assisted order test

Open:

```text
/pos?bay=07
```

Confirm:
- Bay 07 appears
- Cash is not available
- TNG/DuitNow available
- Staff can complete assisted order
- Receipt can print/open

### 6. Owner test

Open:

```text
/owner
```

Confirm:
- Report summary loads
- Bucket count uses 100-ball wording where shown
- Master control links are clear

### 7. Payment QR setup test

Open:

```text
/payments
```

Confirm:
- Owner can upload TNG QR image
- Owner can upload DuitNow QR image
- QR preview appears
- Save settings works
- Customer payment page shows QR

### 8. QR bay test

Open:

```text
/qr
```

Confirm:
- Generate QR works
- QR target is `/b/[bay]/order`
- Sticker includes EDGE RangeFlow wording
- Sticker includes Scan to Order / Pesan
- Sticker includes Need Help / Perlu Bantuan
- Sticker includes PRIMAVOC/TNG/DuitNow payment note

## Custom Domain Migration Later

When domain is purchased:

1. Point DNS A record or CNAME to Coolify server according to Coolify instructions.
2. Add custom domain in Coolify for customer app.
3. Add custom domain/subdomain in Coolify for operations app if separated.
4. Enable HTTPS/SSL.
5. Update `NEXT_PUBLIC_CUSTOMER_BASE_URL`.
6. Update `NEXT_PUBLIC_OPERATIONS_BASE_URL`.
7. Rebuild/redeploy apps.
8. Regenerate bay QR stickers from `/qr`.
9. Print new stickers.
10. Stop sharing temporary sslip.io customer links.

## Recommended Domain Structure

Example future structure:

```text
edgegolf.my
ukm.edgegolf.my
ops-ukm.edgegolf.my
shop.edgegolf.my
academy.edgegolf.my
```

Avoid using UKM as a primary brand/domain unless there is written permission.
Use “Driving Range @ UKM” only as location reference.

## Live Readiness Decision

The system can be considered ready for controlled live operation only after:

- customer order works on phone
- payment QR appears
- admin payment verify works
- Need Help alert works
- assisted order works
- owner can update payment QR
- QR stickers are generated using the correct domain
- no customer-facing demo/testing/pilot wording remains
