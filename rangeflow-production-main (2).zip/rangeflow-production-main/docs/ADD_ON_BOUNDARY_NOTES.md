# RangeFlow Add-On Boundary Notes

Updated: 2026-05-15

## Standard Package focus

The current work must stay focused on the RangeFlow Standard Package:

- Customer bay QR order
- Ball bucket and F&B ordering
- Payment proof upload
- Counter payment verification
- Print slips
- Staff preparing flow
- Runner delivery confirmation
- QR bay checkpoint
- Owner payment setup
- Owner menu/product setup
- Owner access settings
- Owner dashboard

## Add-ons requested by range operator

The operator requested these future modules:

1. POS stock module for bottled drinks, boxed drinks, canned drinks and food items.
2. Payment gateway integration, preferably cheaper than ToyyibPay.

## Decision

Both items are valid add-ons, but they are not part of the current Standard Package pilot.

They must not be mixed into current cleanup work until the Standard Package flow is stable and easy for users to understand.

## Current challenge

The priority is to clean the user journey:

1. Customer: scan bay QR, order ball/F&B, submit payment proof, wait at bay.
2. Admin/Staff: verify payment, print slips, prepare, deliver, QR checkpoint.
3. Owner: manage payment, menu/product, access, dashboard.

## Rule for future development

Do not introduce POS stock, payment gateway, membership, booking, coach, pro shop or other expansion modules inside the Standard Package cleanup.

Use separate add-on planning only after pilot issues are resolved.
