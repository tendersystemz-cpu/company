# RangeFlow Project Memory

Last updated: 2026-05-14

## Current product direction

RangeFlow is positioned as a Driving Range Operation OS for Bukit Unggul Golf Club / BUCC-style range operations.

The immediate objective is not to add large new modules. The current work should complete and polish the Standard Package so the product is ready to show, sell, deploy, and operate.

## Standard Package lock

The Standard Package should include:

1. Customer QR Order
2. Staff Counter Queue
3. Payment Verification
4. Print Slip
5. Menu / Product Management
6. Setup Wizard
7. QR / Bay Management
8. Payment Setup
9. Owner Dashboard
10. Runner / Delivery Confirmation
11. System Health / Admin Tools
12. Basic Access Protection

## Clarified decision: wizard and QR bay management

The user clarified that the current discussion is only about:

1. Setup Wizard
2. QR Bay Management

These are not large add-on modules. They are part of the Standard Package.

### Setup Wizard scope

The setup wizard should help an operator configure the system without developer intervention.

Recommended wizard steps:

1. Range Profile
   - range name
   - address
   - phone number
   - logo
   - operating hours

2. Bay Setup
   - total bays
   - bay names / bay numbers
   - active / inactive bay status
   - bay remarks

3. QR Bay Generator
   - generate QR per bay
   - download QR
   - print QR
   - copy bay customer link
   - preview customer order page by bay

4. Payment Setup
   - merchant QR image
   - account name
   - account / reference instructions
   - enable or disable cash / QR payment methods

5. Menu / Product Setup
   - bucket item
   - food item
   - drink item
   - prices
   - active / inactive item
   - category

6. Staff Access
   - owner code
   - counter code
   - runner access
   - basic role access

7. Launch Check
   - test customer link
   - test payment proof
   - test queue
   - test print slip
   - confirm system ready

### QR Bay Management scope

QR Bay Management should include:

- list all bays
- QR link for every bay
- active / inactive bay control
- generate QR
- download QR
- print QR
- replace QR
- preview customer order page by bay
- bay labels such as Bay 01, Bay 02, Bay VIP, Bay Coach
- disable bay temporarily if faulty
- staff can identify which bay each order came from

## Add-on catalogue decision

The following should remain Product Add-Ons or roadmap items, not part of the current Standard Package execution:

- Membership
- Advance Booking
- Coach Booking
- Pro Shop
- Multi-Branch
- Loyalty
- Accounting Export
- Payroll
- AI Prediction
- Corporate CRM
- Inventory Warehouse

These can be used later as upsell modules, but must not distract from completing the Standard Package.

## Lifecycle intelligence layer decision

The Operational Lifecycle Intelligence Layer is useful as a hardening layer, not as a reason to rebuild the product from scratch.

Use it to strengthen:

- active bay session tracking
- bucket / ball movement audit
- staff accountability
- daily closing
- owner visibility
- emergency recovery tools

Do not break existing flows:

- customer QR bay order
- payment proof upload
- payment verification
- counter queue
- print slip
- runner / delivery confirmation

## Wizard file decision

The uploaded wizard file can be used as a base UI and flow reference.

Important production notes:

- Do not use it as final production if it only saves to localStorage.
- Convert the useful wizard flow into the real Next.js / Supabase production structure.
- Connect wizard save actions to Supabase tables or RPC functions.
- Keep localStorage only for standalone demo mode.
- Profit-sharing / stealth billing settings must not be shown in the normal client-facing wizard UI.
- If billing/revenue-share logic is needed, keep it as owner/developer internal configuration, not standard operator setup.

## Current production priority

1. Stabilize current customer flow.
2. Confirm `/b/01/order` works after bucketQty default fix.
3. Keep Customer QR Order, Payment Verification, Queue, Print Slip, and Delivery Confirmation stable.
4. Patch operations UI for QR Bay Management and Setup Wizard only after current flow remains stable.
5. Keep membership / VVIP / booking modules after production flow is reliable.

## Product positioning

Use this product message:

RangeFlow is not just a booking app. It is a driving range operation system that connects QR bay order, payment verification, staff queue, print slip, bay management, setup wizard, admin tools, and owner dashboard in one operational flow.

## Workstyle note

For future work, avoid broad module expansion unless explicitly requested. Keep the user focused on finishing, deploying, and showing a working Standard Package first.
