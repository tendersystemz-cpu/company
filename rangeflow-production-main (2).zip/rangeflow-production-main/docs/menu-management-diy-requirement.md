# RangeFlow DIY Menu Management Requirement

## Purpose

Food and drink menu items must be manageable by the range/cafe operator without developer involvement.

The QR customer app must not depend on hardcoded menu names, prices, or images.

## Required admin capabilities

Operations/admin users must be able to manage menu items themselves:

1. Add new food item.
2. Add new drink item.
3. Add snack item.
4. Edit item name.
5. Edit item category.
6. Edit item description.
7. Edit item price.
8. Upload or paste item image URL.
9. Turn item availability on/off.
10. Reorder menu display position.
11. Save changes and reflect immediately in customer QR order page.

## Customer QR behavior

Customer scans bay QR:

```text
/b/{bay_code}
```

Then the order page loads available menu items from Supabase:

```text
menu_items
```

Customer should see:

```text
item image
item name
item description
price
quantity control
availability state
```

## Data model

Current table used:

```text
menu_items
```

Important fields:

```text
location_id
category
code
name
description
price
image_url
available
position
prep_time_min
```

## Image requirement

Menu image support must be DIY-friendly.

Acceptable phase 1 approach:

```text
image_url text field
```

Admin can paste image link or use uploaded image URL later.

Future phase 2 approach:

```text
Supabase Storage upload
image_url auto-filled after upload
```

## Pricing requirement

Prices must be editable by admin from operations app.

Changes must be saved to Supabase and used immediately by:

```text
customer combined cart
payment total
receipt total
operations queue
```

No hardcoded price should be used in customer-facing order logic.

## Availability requirement

When item is unavailable:

```text
available = false
```

It must disappear from the customer order page but remain manageable in operations/admin.

## Category requirement

Initial supported categories:

```text
fb
snack
drink
equipment
promo
```

Customer QR launch should show at minimum:

```text
food/snack
drink
```

Equipment and promo may be enabled later.

## Production priority

1. Customer combined cart reads live menu from Supabase.
2. Operations/admin menu management screen.
3. DIY edit price/name/availability.
4. DIY image URL field.
5. Supabase Storage upload later.
6. Menu category and display ordering polish.
