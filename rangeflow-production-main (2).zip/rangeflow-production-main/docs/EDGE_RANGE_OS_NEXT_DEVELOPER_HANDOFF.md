# EDGE RANGE OS — Next Developer / Next GPT Handoff

Last locked: 2026-05-29

This file is the continuation guide for any next developer, GPT, Codex agent, or assistant that works on this repository.

Read this before touching code, routes, Coolify, Supabase, or branding.

---

## 1. Why this document exists

EDGE RANGE OS has a clear product architecture, but the repository currently contains mixed old routes, fallback pages, trial/pilot pages, and partially patched navigation from earlier work.

The owner did not change the product direction randomly. The confusion came from previous patch-by-patch implementation where pages were added without removing or redirecting older routes, and buttons were allowed to continue pointing to legacy pages.

The next person must not continue this pattern.

The immediate job is not to add more modules. The immediate job is to restore structure.

---

## 2. Product mission lock

Product name:

```txt
EDGE RANGE OS
```

Meaning:

```txt
Expert Digital Golf Ecosystem
```

Product category:

```txt
Universal SaaS operations platform for driving range operators
```

Do not position the system as:

```txt
UKM-only
Prima Voc-only
RangeFlow-only
trial-only
pilot-only
custom one-off project
```

Correct positioning:

```txt
EDGE RANGE OS is a Web + Mobile subscription-based operations platform for driving range operators.
```

Core product roles:

```txt
Customer    = QR-first / mobile-first ordering and receipt flow
Staff       = daily counter, bay, payment and fulfilment operation
Owner       = dashboard, reporting, setup, products, payment QR and access control
Super Admin = SaaS billing, tenant, package, subscription, suspend/reactivate and audit control
```

Super Admin must remain separate from normal Owner Dashboard.
Owner must not control subscription status.
Super Admin controls activation, suspension, package, billing and tenant status.

---

## 3. Current deployment source of truth

GitHub repository:

```txt
duniabiz2udotcom/rangeflow-production
```

Branch:

```txt
main
```

Main directories:

```txt
customer/     = customer QR order/payment/receipt app
operations/   = owner/staff/counter/POS/admin operations app
docs/         = source-of-truth documentation
sql/          = Supabase migrations and database support files
```

Coolify source-of-truth:

```txt
Live production project = My first project → production
Live production apps    = rangeflow-customer, rangeflow-operations
```

Do not treat the `rangeOS` Coolify project as live production unless the owner explicitly promotes it.

Do not patch `/root` on the VPS.
Do not patch `/app` inside a running Docker container for permanent work.
Permanent work must be committed to GitHub source.

Related deployment document:

```txt
docs/EDGE_RANGE_OS_COOLIFY_DEPLOYMENT_SOURCE_OF_TRUTH.md
```

---

## 4. Current state at handoff

### Completed and accepted

Customer branding cleanup is accepted and tested.

Customer-facing pages now use:

```txt
EDGE RANGE OS
```

The customer flow tested successfully:

```txt
/b/07/order
/pay/[bookingId]
/receipt/[bookingId]
```

Payment proof wording has been simplified:

```txt
Please keep payment proof if requested by staff.
Screenshot upload is optional only.
```

Minor typo known on payment page:

```txt
Sereenshot → Screenshot
```

### Not accepted / still under governance cleanup

Operations navigation is not yet accepted as final.

Recent attempts were made to add:

```txt
compact operations console
persistent icon nav
PIN modal access guard
```

However, the owner identified that the structure still feels mixed because:

```txt
- some buttons still point to old pages
- older route names still exist
- old fallback pages remain visible
- menu/header is not yet governed from a single source
- access lock is not yet consistently active across all routes
- route structure is confusing for future developers
```

Therefore, do not continue coding blindly from the current navigation implementation. Treat it as draft material to be reorganized.

---

## 5. Immediate priority

Do not build Super Admin yet.

The next priority is:

```txt
EDGE RANGE OS Route, Auth and Navigation Governance Cleanup
```

This must be done before Super Admin is added.

Reason:

```txt
Super Admin should not be added into an operations house where rooms, doors, route names, buttons and access locks are still inconsistent.
```

The cleanup goal is to turn the current mixed route/page structure into a clear house plan:

```txt
Customer area = clean public QR-first flow
Staff area    = protected daily operation flow
Owner area    = protected monitor/control flow
Super Admin   = future protected SaaS billing/control flow
Old routes    = redirected, deprecated, or hidden from production navigation
```

---

## 6. Golden rules for the next developer / GPT

### Do not

```txt
Do not add Super Admin before route/menu/access cleanup.
Do not add new pages without updating route governance docs.
Do not create another dashboard/home/menu route unless an old one is retired.
Do not leave buttons pointing to fallback or legacy pages.
Do not use RangeFlow, UKM, Prima Voc, pilot or trial as product identity.
Do not commit many small patches if Coolify auto-deploy is active.
Do not rely on chat memory over repository docs.
Do not assume every existing route is valid just because it exists.
```

### Must do

```txt
Audit routes first.
Classify every route as Production, Deprecated, Redirect, Internal Utility or Future.
Centralize navigation/menu config.
Centralize role/access rules.
Patch buttons from the audit list, not by guessing.
Commit in controlled batch commits.
After each deploy, test route + access + customer flow.
Update this handoff if product direction changes.
```

---

## 7. Required audit before further coding

Create or update:

```txt
docs/EDGE_RANGE_OS_ROUTE_AUTH_MENU_AUDIT.md
```

The audit must include:

```txt
1. All customer routes
2. All operations routes
3. All legacy/fallback routes
4. Every visible menu button and where it links
5. Every protected route and required role
6. Which routes should be redirected
7. Which routes should be hidden from navigation
8. Which route becomes the official operations entry point
9. Which route becomes the official access/login route
10. Which route later becomes Super Admin entry
```

Suggested audit table columns:

```txt
Route | Current Purpose | Keep? | New Purpose | Access Role | Menu Label | Redirect Target | Notes
```

---

## 8. Preliminary route classification

This list is a starting point. Verify by inspecting actual files before coding.

### Customer app routes

Keep clean and public:

```txt
customer/
customer/b/[bayCode]
customer/b/[bayCode]/order
customer/pay/[bookingId]
customer/receipt/[bookingId]
```

Customer routes must not expose internal owner/staff controls directly.

### Operations production candidates

Likely keep:

```txt
operations/
operations/hub
operations/owner
operations/counter
operations/pos
operations/stock
operations/menu
operations/payments
operations/qr
operations/access
operations/members
operations/promotions
operations/print/[bookingId]
operations/deliver/[bookingId]
```

But do not assume all current button links are correct. Audit first.

### Operations legacy / fallback / confusing candidates

Must audit and likely redirect, hide, or deprecate:

```txt
operations/staff
operations/staff-ops
operations/staff-ops-bay
operations/queue
operations/pilot
operations/trial
operations/setup
operations/checkpoint
operations/health
```

These may still contain useful code or logic, but they must not remain exposed randomly in production navigation.

### Future candidate

Create only after cleanup:

```txt
operations/superadmin
```

or:

```txt
operations/admin/superadmin
```

Do not decide this route until route governance is completed.

---

## 9. Navigation architecture target

The final navigation should be persistent across operations pages.

It should not be a large page-level menu that consumes too much vertical space.

Preferred style:

```txt
Compact icon-based persistent top bar
+ dropdown / grouped menu when needed
+ PIN modal for protected route access
```

Navigation groups:

```txt
INTRODUCTION
- Home
- Setup Wizard
- QR / Share Link
- Access Control

CUSTOMER
- Bay Order
- Payment / Receipt only after order context

ADMIN / STAFF
- Counter
- Queue / Counter Queue
- POS Lite
- Stock
- Menu Management
- Payment Verification

OWNER
- Owner Dashboard
- POS Lite Control
- Stock Lite Control
- Reports Control
- Settings / Access

SUPER ADMIN (future)
- Tenants
- Packages
- Subscription
- Billing
- Usage
- Statements / Invoices
- Suspend / Reactivate
- Audit Log
```

The visual direction should borrow from the previous infographic style:

```txt
small icons
clear labels
minimal text
compact layout
fast scanning
consistent across pages
```

---

## 10. Access control target

Existing backend direction:

```txt
verify_org_access_pin(p_org_slug, p_role_key, p_pin)
update_org_access_pin(p_org_slug, p_owner_pin, p_role_key, p_new_pin)
```

Required behavior:

```txt
Public/customer route        = no staff/owner PIN
Staff route                  = staff PIN or owner PIN
Owner route                  = owner PIN only
Super Admin route future     = super admin auth, separate from owner
```

Use `sessionStorage` only as short-lived UI unlock state after Supabase RPC verification.

Do not hardcode PINs in frontend.
Do not expose PIN values in JavaScript bundle.
Do not treat visual lock icons as real access protection.

---

## 11. Route cleanup implementation plan

After audit is written, implement in this sequence:

### Step 1 — Central route config

Create one shared source for operations route metadata, for example:

```txt
operations/lib/navigation.ts
```

It should define:

```txt
route path
label
icon
section
auth role
production/deprecated/future status
redirect target if deprecated
```

### Step 2 — Persistent operations nav

Update:

```txt
operations/app/GlobalReturnNav.tsx
```

Use the central route config.

It should:

```txt
- render compact persistent icon navigation
- show grouped dropdown menu
- show locked state for staff/owner routes
- trigger PIN modal before opening protected route
- stay visible across operations pages
```

### Step 3 — Route guard

Use one route guard strategy for operations pages.

At minimum, guard via persistent nav + link interception.
Better, create a route-level guard wrapper later.

### Step 4 — Button/link patch

Patch all buttons/anchors according to the audit.
Do not guess links.

### Step 5 — Legacy route redirects

Deprecated routes should either:

```txt
- redirect to the correct production route
- show a clear deprecated page
- be removed only when safe
```

Do not leave old routes discoverable in normal navigation.

### Step 6 — Test

Test at least:

```txt
operations/
operations/hub
operations/counter
operations/owner
operations/pos
operations/stock
operations/menu
operations/payments
operations/qr
operations/access
```

Customer smoke test:

```txt
customer/b/07/order
customer/pay/[bookingId]
customer/receipt/[bookingId]
```

---

## 12. Super Admin module should wait

Super Admin scope remains important but is not the immediate next coding task.

Super Admin scope:

```txt
Tenant list
Tenant/operator profile
Package control
Monthly fee
Setup fee
Deposit record
Contract start/end
Billing cycle
Usage band or usage percentage
Monthly billing statement
Invoice/statement generation
Payment received marking
Overdue status
Suspend tenant
Reactivate tenant
Owner read-only subscription visibility
Super Admin audit log
```

Do not build this until navigation and route governance is stable.

When ready, start with:

```txt
docs/EDGE_RANGE_OS_SUPERADMIN_MODULE_SPEC.md
```

Then SQL migration, then route/UI.

---

## 13. Current known risk: Coolify auto-deploy

Coolify appears to auto-deploy on GitHub commits.

Therefore:

```txt
Do not create many small commits for code changes.
Prefer one audit doc commit, then one controlled implementation commit or small controlled batch.
After commit, check Coolify deployment queue.
Do not press redeploy repeatedly.
```

If Coolify queue gets stuck:

```bash
docker restart coolify coolify-redis coolify-realtime
docker logs --tail=120 coolify
```

Expected healthy messages:

```txt
Redis cleanup: deleted ... items
Horizon started successfully.
```

---

## 14. Final instruction to next GPT/developer

Before writing code, answer these questions from repo inspection:

```txt
1. What route is the official operations home?
2. What route is the official access/login hub?
3. Which staff route replaces old staff-ops / staff-ops-bay / queue?
4. Which owner routes are production-ready?
5. Which routes must be redirected?
6. Which buttons still point to old routes?
7. Which menu component is the single source of persistent navigation?
8. What role is required for each route?
```

If you cannot answer these, do not code yet.

The mission is to preserve the owner’s architecture, not to invent a new one.

The house plan is:

```txt
Customer QR-first flow
Staff protected operations flow
Owner protected control/reporting flow
Super Admin future SaaS billing/control flow
One persistent navigation system
One route governance source
No legacy-route confusion
```

Proceed only in that direction.
