# RangeFlow Customer UX Standard

## Locked Operational Rule

- 1 bucket = 100 golf balls.
- Customer page, receipt, sticker, inventory, admin dashboard and infographic must never describe the standard bucket as 50 balls.
- Current bucket pricing structure:
  - Walk-in customer: RM12 / 100 balls
  - UKM student/staff: RM8 / 100 balls
- Pricing must remain editable by owner later.

## Customer Experience Goal

The customer page must be simple, mobile-first and friendly.

Customer should only understand:

1. Order
2. Pay
3. Receipt/status
4. Need help if required

Customer must not see owner/admin operations.

## Customer Flow

### Normal existing range behavior

1. Customer arrives at range.
2. Customer chooses bay naturally.
3. Customer may buy first bucket at counter according to current physical operation.
4. Customer sees bay QR sticker.
5. Customer scans QR later for reorder, F&B, assistance or convenience ordering.

### Digital order/reorder flow

1. Scan bay QR.
2. Order bucket and/or F&B.
3. Choose self pickup or deliver to bay.
4. See total amount and order token.
5. Pay using TNG/DuitNow QR.
6. Show successful payment screen if staff needs confirmation.
7. Staff verifies payment in Admin Operasi.
8. Customer sees status/receipt.
9. Customer self-picks up or receives delivery to bay.

## Page Structure

Customer page should be one clean order page with the following sections:

1. Header
   - RangeFlow / EDGE RangeFlow branding
   - Bay number
   - Language-friendly wording BM/BI

2. Quick instruction card
   - BM: Pesan dari bay anda
   - BI: Order from your bay

3. Bucket section
   - 100 Balls / 100 Biji Bola
   - Walk-in RM12
   - UKM Student/Staff RM8

4. F&B section
   - Drinks / Minuman
   - Food / Makanan
   - Snacks / Snek

5. Fulfilment option
   - Self Pickup / Ambil Sendiri
   - Deliver to Bay / Hantar ke Bay

6. Payment summary
   - Bay
   - Order token
   - Total
   - Payment instruction

7. Receipt/status
   - Order received
   - Waiting verification
   - Paid
   - Preparing
   - Ready
   - Delivered

8. Need Assistance button
   - Floating/sticky button near bottom right or lower safe area
   - Label:
     - Need Help
     - Perlu Bantuan
   - Pressing it should create an assistance request for the current bay.
   - Admin Operasi dashboard should show a temporary notification and blinking/highlighted bay.

## BM/BI Requirement

All customer-facing key labels must be bilingual BM/BI.

Examples:

- Order / Pesan
- Need Help / Perlu Bantuan
- Self Pickup / Ambil Sendiri
- Deliver to Bay / Hantar ke Bay
- Pay / Bayar
- Receipt / Resit
- Waiting Verification / Menunggu Semakan Bayaran
- Paid / Telah Dibayar
- Ready / Sedia
- Preparing / Sedang Disediakan

## Payment Proof Direction

Do not force upload proof as the main flow.

Main flow:
- Customer pays with TNG/DuitNow QR.
- TNG soundbox/Blue Tap confirms payment occurred.
- Staff verifies correct amount/order where needed.
- Staff presses Verify Payment.
- Customer receipt/status appears.

Optional fallback:
- Upload payment proof can exist only for dispute, delay or manual checking.

## Need Assistance Placement

Recommended UI:

- Floating button at bottom right:
  - Bell icon
  - Need Help
  - Perlu Bantuan

Reason:
- Always visible
- Does not clutter order form
- Mobile-friendly
- Premium app-like behavior

## What Customer Must Not See

Customer page must not show:
- Admin dashboard
- Owner dashboard
- Pricing management
- Inventory control
- QR management
- PIN settings
- Operation reset

## Visual Direction

The customer UI should follow the approved infographic direction:
- Clean
- Mobile-first
- Dark/green golf-tech aesthetic
- Simple cards
- Large readable labels
- Minimal navigation
- No unnecessary home/menu buttons

## Implementation Priority

1. Confirm customer order route.
2. Ensure bucket wording is 100 balls.
3. Add BM/BI labels.
4. Add floating Need Help / Perlu Bantuan button.
5. Ensure customer flow does not force proof upload as main path.
6. Keep admin/owner routes separate.
