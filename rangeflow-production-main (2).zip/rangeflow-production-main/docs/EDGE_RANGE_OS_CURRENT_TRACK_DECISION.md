# EDGE RANGE OS — Current Track Decision

Last locked: 2026-05-31

## Decision

Customer order page wording cleanup is parked temporarily.

Reason:

```txt
The customer order page is stable again.
The order flow is more important than cosmetic wording.
Recent attempts to change public labels through layout/global approaches caused deployment risk.
```

## Current status

```txt
Customer /b/[bay]/order page: stable
Known issue: some tenant-specific wording still appears
Priority: not an operational blocker
Decision: do not touch customer order page until safer component-level patch is ready
```

## Do not repeat

```txt
Do not use global text sanitizer.
Do not use MutationObserver for label replacement.
Do not add dynamic route layout override for this page.
Do not patch customer order page with broad UI changes during operations cleanup.
```

## Next active track

Focus on lower-risk operational cleanup:

```txt
1. Operations dashboard route/action verification
2. Hub/navigation consistency
3. QR Management cleanup
4. Staff Counter/Queue workflow cleanup
5. Payment/Receipt wording cleanup
6. Access PIN verification when SQL access is available
```

## Core operating principle

```txt
Protect working customer order flow first.
Improve universal wording later with a small code-level component patch only.
```

## Next GPT / developer instruction

When continuing work:

```txt
Do not restart the UKM label issue first.
Start with operational pages that are safer to patch.
Report each page using:
- Page reviewed
- Problem found
- Change made
- Commit SHA
- Remaining risk
- Next page
```
