# Hub Polish Specification

## Page

Operations Hub / Landing Page

URL:

- `/hub`

## Purpose

This page is the main command center for RangeFlow operations. It must look like a polished standard product page, not a custom one-off page for a single range.

## Final Direction

- Use RangeFlow universal branding.
- Do not show Bukit Unggul or BUCC as product identity.
- Keep staff and owner tools locked until access is unlocked.
- Main Menu dropdown must remain visible and readable.
- Customer buttons should link to customer bay/order pages.
- Staff tools should only become active after staff/owner access.

## Layout Improvements

1. Make navigation height more compact.
2. Reduce oversized hero height.
3. Reduce hero title size on desktop and mobile.
4. Make Secure Access card more compact.
5. Compact menu cards and reduce empty vertical space.
6. Improve dropdown spacing and readability.
7. Keep QR guide readable but less bulky.

## Text Improvements

Replace generic one-off wording with product wording:

- RangeFlow Standard Package
- QR Bay Ordering Operations Hub
- Universal golf range ordering system

Avoid:

- Bukit Unggul
- BUCC
- Any specific range name unless loaded from setup wizard

## Navigation Requirements

Main Menu dropdown should include:

Customer:
- Customer Bay Dashboard
- Customer Order Page

Staff:
- Counter Queue
- Menu Management
- QR Management

Owner / System:
- Owner Dashboard
- Payment Setup
- System Health

Locked links should show as locked text before login.

## Completion Criteria

- `/hub` opens without 404.
- Main Menu dropdown appears.
- Layout looks compact on mobile.
- Staff/owner unlock still works.
- No default blue link styling.
- No client-specific hardcoded branding.
