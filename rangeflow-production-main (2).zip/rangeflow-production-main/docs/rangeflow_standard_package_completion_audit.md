# RangeFlow Standard Package Completion Audit

Date: 2026-05-17
Repository: `duniabiz2udotcom/rangeflow-production`

## 1. Objective

This document converts the current RangeFlow repository into a clear completion track for the Standard Package. The target is a deployable driving range operating system with:

- Customer QR bay ordering
- Manual payment proof and receipt
- Staff order verification and fulfilment queue
- Split print slips for ball, kitchen, delivery and full order
- POS Lite product/menu and basic stock flow
- Owner dashboard and reporting
- Setup/payment/access controls
- Future-ready promotion, membership and advertising modules

The scope intentionally avoids large add-on modules until the core production flow is stable.

## 2. Current Repository Structure Confirmed

The repository is already structured as two separate Next.js applications:

```text
customer/       Public customer QR ordering, payment and receipt app
operations/     Staff, owner and admin operations app
sql/            Database migration files
supabase/       Database notes and production references, where applicable
docs/           Planning, audit and handover documents
```

The README identifies the production target as:

- Netlify customer site: `rangeflow-bucc`
- Supabase project ref: `cgewjbfycnqbyczyuthp`
- Production org slug: `bukitunggul`
- Main customer QR route: `/b/01`

## 3. Modules Already Present

### 3.1 Customer App

The customer app already contains the main production customer journey:

1. Landing page with RangeFlow positioning and customer CTA.
2. Bay landing page at `/b/[bayCode]`.
3. Customer order page at `/b/[bayCode]/order`.
4. Payment proof page at `/pay/[bookingId]`.
5. Receipt/status page at `/receipt/[bookingId]`.

The customer order page currently calls:

- `get_customer_order_options`
- `create_customer_order`

The payment/receipt pages currently call:

- `get_customer_receipt`
- `submit_customer_payment_proof`

This means the QR ordering, cart, payment proof and receipt loop is already materially implemented.

### 3.2 Operations App

The operations app already contains the main staff and owner workflow:

1. Operations start page.
2. Secure hub with staff/owner PIN verification.
3. Counter flow for payment verification and fulfilment.
4. Owner dashboard for sales/order/bay activity.
5. Menu/Product setup.
6. Stock Lite page.
7. Print slip page for `ball`, `kitchen`, `delivery` and `full` slip types.
8. Access PIN management via hardened access PIN migration.

The counter flow already supports the correct operating sequence:

```text
Verify payment -> Print slip -> Mark preparing -> QR checkpoint/delivery
```

## 4. Important Production Alignment Issue

The README production target uses:

```text
NEXT_PUBLIC_ORG_SLUG=bukitunggul
```

However, both app libraries currently default to:

```ts
process.env.NEXT_PUBLIC_ORG_SLUG || 'rangeflow'
```

This is acceptable only if Netlify production env is correctly set to `bukitunggul`. For production safety, do not rely on the fallback slug. The deployment guide must clearly require `NEXT_PUBLIC_ORG_SLUG=bukitunggul` for the BUCC production tenant.

Recommended decision:

- Keep the code fallback as `rangeflow` for reusable demo/product packaging.
- Enforce `bukitunggul` in Netlify production environment for BUCC.
- Add a visible System Health warning if the runtime org slug does not match the intended deployment tenant.

## 5. Supabase Schema Audit Summary

The live Supabase project already contains the required operational foundation:

- `orgs`
- `locations`
- `floors`
- `bays`
- `customers`
- `bookings`
- `orders`
- `payments`
- `menu_items`
- `delivery_events`
- `audit_logs`
- `org_access_pins`
- `stock_movements`

The database already has real operational data, including bays, bookings, orders, payments and menu items. This confirms the system is no longer just a static prototype.

## 6. Critical Security Finding

Supabase reported that `public.stock_movements` has Row Level Security disabled.

This is critical because Supabase public clients use anon/authenticated roles. If a table is exposed without RLS, direct access risk increases.

Do not blindly enable RLS without checking the existing stock RPC functions, because enabling RLS without compatible policies may break Stock Lite.

Recommended remediation file:

```sql
-- Review before applying in production
alter table public.stock_movements enable row level security;

-- Prefer keeping direct client access blocked.
-- Stock changes should go through security definer RPC functions such as adjust_operations_item_stock.
```

## 7. Missing or Incomplete Standard Package Pieces

### 7.1 Setup Wizard

Current status: Concept exists, but a complete owner-facing setup wizard is not yet consolidated as a single flow.

Required wizard steps:

1. Company / range name
2. Location details
3. Bay count and bay labels
4. Payment QR / bank setup
5. Product/menu starting list
6. Staff and owner access PIN
7. Preview customer QR page
8. Go-live checklist

Recommended route:

```text
operations/app/setup/page.tsx
```

### 7.2 POS Lite Counter Sale

Current status: Menu/Product and Stock Lite exist, but a dedicated POS counter sale page should be added.

Required POS Lite functions:

- Select product
- Add quantity
- Apply simple discount or promo code
- Choose payment method
- Complete counter sale
- Reduce stock when applicable
- Print or show receipt
- Include transaction in owner dashboard

Recommended route:

```text
operations/app/pos/page.tsx
```

### 7.3 Promotion and Advertising Module

Current status: Customer landing contains promotion space, but no structured campaign management module was confirmed in database.

Required tables:

- `campaigns`
- `promotion_codes`
- `promotion_redemptions`
- `campaign_events`

Required functions:

- Create/edit campaign
- Create promo code
- Validate promo code during checkout
- Track QR source/campaign source
- Report revenue by campaign

Recommended route:

```text
operations/app/promotions/page.tsx
```

### 7.4 Membership Module

Current status: `customers` table exists but full membership package is not part of the current Standard Package completion. It should remain a future add-on unless a light member profile is needed.

Recommended Standard Package minimum:

- Customer phone/name capture
- Order history by phone
- Optional member flag/tier later

Do not overbuild membership before customer order + POS Lite + reporting are stable.

### 7.5 Reporting Upgrade

Current status: Owner dashboard exists and shows main metrics.

Recommended next reporting additions:

- Product category sales
- Payment method breakdown
- Promo code usage
- F&B attach rate
- Low stock and wastage summary
- Export CSV/PDF later

## 8. Recommended Completion Sequence

### Phase 1 — Production Stabilization

1. Confirm Netlify env for customer and operations apps.
2. Confirm `NEXT_PUBLIC_ORG_SLUG=bukitunggul` for BUCC production.
3. Test `/b/01` and `/b/01/order` end-to-end.
4. Test payment proof upload and receipt.
5. Test counter payment verification and slip printing.
6. Test owner dashboard refresh.
7. Review `stock_movements` RLS remediation.

### Phase 2 — Standard Package Completion

1. Add setup wizard route.
2. Add POS Lite route.
3. Add promotions route and database migration.
4. Add campaign source tracking to customer order flow.
5. Add reporting cards for POS/category/promo performance.

### Phase 3 — Product Packaging

1. Update README to separate BUCC deployment from generic RangeFlow deployment.
2. Add client handover guide.
3. Add go-live checklist.
4. Add sales/demo documentation.
5. Keep membership, coach booking, multi-branch, loyalty, accounting export and full inventory as add-ons.

## 9. Definition of Done

RangeFlow Standard Package can be considered complete when:

- Customer can scan bay QR and submit order.
- Customer can submit payment proof and view receipt.
- Staff can verify payment, print slips and manage fulfilment.
- Owner can manage menu/payment/access and view dashboard.
- POS Lite counter sale works for walk-in sales.
- Stock Lite is protected and operational.
- Setup wizard can onboard a new range without developer hand-editing core settings.
- Promotions/campaign tracking can attribute orders to ads or offers.
- README and handover docs match the actual deployed system.

## 10. Immediate Next Engineering Actions

1. Add SQL migration for promotion/campaign tables.
2. Add POS Lite page and RPC for counter sale creation.
3. Add setup wizard page using existing owner setup modules.
4. Add RLS review migration for `stock_movements`.
5. Update System Health page to warn when env slug, Supabase URL or required RPCs are missing.

This audit should be treated as the working completion map for the next implementation pass.
