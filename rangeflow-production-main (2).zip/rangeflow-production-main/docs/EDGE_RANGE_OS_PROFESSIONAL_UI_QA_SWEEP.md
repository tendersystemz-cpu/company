# EDGE RANGE OS — Professional UI QA Sweep

Last locked: 2026-05-31

This document defines the proactive UI/UX quality sweep for EDGE RANGE OS.

The owner should not be forced to inspect every page manually and report one issue at a time. The system should be reviewed professionally using a repeatable audit method.

---

## 1. Objective

Raise EDGE RANGE OS from a working prototype into a professional SaaS product interface.

Target outcome:

```txt
Cleaner visual hierarchy
Consistent button behavior
Universal product wording
Mobile-first operational usability
Clear customer/staff/owner separation
No legacy mixed routes
No decorative buttons without function
```

---

## 2. Review method

Every page must be reviewed using 6 layers:

```txt
1. Product identity
2. Navigation and route behavior
3. Button/action behavior
4. Role and access clarity
5. Mobile layout and visual hierarchy
6. Data/state/empty/error handling
```

No page should be accepted only because it loads successfully.

---

## 3. Page categories

### 3.1 Customer pages

Review pages:

```txt
customer/
customer/b/[bayCode]
customer/b/[bayCode]/order
customer/pay/[bookingId]
customer/receipt/[bookingId]
```

Quality rules:

```txt
Universal EDGE RANGE OS branding
No unnecessary UKM/pilot/trial identity in product UI
Simple customer language
No forced transaction ID
No mandatory proof upload as main path
Self Pickup / Deliver to Bay clear
Payment proof instruction simple
Cart and checkout obvious
Need Help visible but not distracting
```

### 3.2 Staff operation pages

Review pages:

```txt
operations/counter
operations/pos
operations/stock
operations/menu
operations/payments
operations/print/[bookingId]
operations/deliver/[bookingId]
```

Quality rules:

```txt
Staff action buttons must be obvious
Queue status must be readable
Payment verification must not be hidden
Print slip actions must be grouped
Bay/session state must be clear
POS and stock actions must not look decorative
Danger actions need confirmation
```

### 3.3 Owner pages

Review pages:

```txt
operations/owner
operations/access
operations/qr
operations/hub
```

Quality rules:

```txt
Owner control must look premium and trustworthy
Reports/settings/access must be separated from staff operation
Owner PIN route must be protected
QR page must avoid legacy staff-ops links
Setup/access/QR/payment setup must be easy to find
```

### 3.4 Future Super Admin pages

Do not build until P0 cleanup is stable.

Planned pages:

```txt
operations/superadmin
operations/superadmin/tenants
operations/superadmin/packages
operations/superadmin/subscriptions
operations/superadmin/billing
operations/superadmin/invoices
operations/superadmin/audit
```

Quality rules:

```txt
Separate EDGE SaaS operator access
Tenant/package/subscription controls
Suspend/reactivate with audit log
Invoice and billing clarity
No mixing with owner dashboard
```

---

## 4. UI quality checklist per page

For each page, check:

```txt
[ ] Is the page title short and role-appropriate?
[ ] Is the route production or deprecated?
[ ] Is every visible button functional?
[ ] Are decorative chips clearly non-clickable?
[ ] Are role colors consistent?
[ ] Does protected action trigger PIN guard?
[ ] Is mobile layout compact and readable?
[ ] Is the main action obvious?
[ ] Are secondary actions visually weaker than primary action?
[ ] Are destructive actions confirmed?
[ ] Is text universal, not tenant-specific unless intentional?
[ ] Are old words removed: pilot, trial, staff-ops, fallback, UKM as product identity?
[ ] Are empty/loading/error states handled?
[ ] Does page link only to production routes?
```

---

## 5. Button quality checklist

Every button must be classified:

```txt
Primary Action
Module Card
Quick Action
Filter Chip
Status Chip
Protected Action
Danger Action
Disabled Action
```

Rules:

```txt
Clickable = must navigate, submit, filter, open modal, or run an action.
Status only = must not look like primary button.
Protected = must show lock/PIN flow.
Danger = must be red/confirmed.
Disabled = must show why it is disabled.
```

Refer also:

```txt
docs/EDGE_RANGE_OS_BUTTON_UX_GOVERNANCE.md
```

---

## 6. Professional improvement backlog

### P1-A — Customer universalization

```txt
Remove visible UKM-specific product labels unless tenant display is intentional.
Replace Walk-in / UKM special pricing with Standard / Preferred.
Replace BM-only microcopy where an international product needs English-first wording.
Keep BM support only where operationally useful.
```

### P1-B — Operations dashboard refinement

```txt
Make top quick actions functional.
Color-code role/function buttons.
Keep metric cards compact.
Avoid giant hero/status blocks.
Keep 3-column metrics and 2-column modules on mobile.
```

### P1-C — Staff operation sweep

```txt
Counter page action hierarchy.
Queue/payment/status readability.
Assisted order clarity.
Print slip grouping.
Bay session release confirmation.
```

### P1-D — Owner control sweep

```txt
Owner dashboard information hierarchy.
Reports and setting separation.
QR management cleanup.
Access control clarity.
Subscription read-only placeholder for future Super Admin billing.
```

### P1-E — Error/empty/loading states

```txt
No blank pages.
No silent failure.
No confusing technical error shown to customer.
Operator-facing error can be technical but readable.
```

---

## 7. Testing matrix

### Mobile first

Primary test viewport:

```txt
iPhone Safari / Chrome mobile width
```

Must check:

```txt
No text overlap
No oversized hero
Bottom bars not covering important actions
Horizontal nav scroll usable
Button tap target large enough
Cards readable at glance
```

### Desktop second

Must check:

```txt
Grid uses space well
No overly stretched cards
Owner/staff controls readable
Reports/dashboard look professional
```

---

## 8. Definition of done

A page is considered professionally acceptable when:

```txt
It looks like one EDGE RANGE OS product.
It is mobile-readable.
Every button has a clear purpose.
Role and access are obvious.
No old route or pilot wording appears unexpectedly.
Primary action is obvious.
The page can be understood by owner, staff, developer, or system analyst without explanation.
```

---

## 9. Operating principle for future GPT / developer

Do not wait for the owner to find every visual defect.

Do a proactive sweep.

When patching, explain:

```txt
Page reviewed
Problem found
Change made
Commit SHA
Remaining risk
Next page to review
```

Never claim a page is clean unless it has been reviewed against this checklist.
