# RangeFlow POS Lite + Basic Stock — Standard Package Scope

**Status:** Scope locked / documentation record only  
**Date:** 2026-05-16  
**Repository:** `duniabiz2udotcom/rangeflow-production`  
**Implementation status:** Not yet integrated into production code  

---

## 1. Final Decision

RangeFlow Standard Package must include:

- Product/Menu Control
- POS Lite
- Basic Stock Tracking

Ball Bucket Order and F&B/Product Order must remain inside the standard Customer QR Bay Order flow.

They must **not** be separated into an external POS system at this stage.

---

## 2. Core Principle

RangeFlow is positioned as an operational flow system, not just a QR ordering demo.

The standard flow should remain unified:

```text
Customer scan QR Bay
→ select ball bucket
→ select F&B/product
→ upload manual payment proof
→ staff verify payment
→ print slip
→ prepare ball/F&B/product
→ runner delivery confirmation
→ owner monitor sales, stock, and operations
```

POS Lite acts as the backend engine for:

- product setup
- item availability
- stock quantity
- counter sale
- stock movement
- basic sales summary

It should support the RangeFlow operational flow without creating a separate system for staff.

---

## 3. Standard Package Modules

The RangeFlow Standard Package should include the following modules:

1. Customer QR Bay Order
2. Ball Bucket Order
3. F&B/Product Order
4. Manual Payment Proof
5. Counter Queue / Payment Verification
6. Print Slip
7. Runner / Delivery Confirmation
8. Owner Dashboard
9. Product / Menu Setup
10. POS Lite / Basic Stock
11. Basic Access Protection
12. QR Bay Management
13. Setup Wizard
14. System Health / Admin Tools

---

## 4. POS Lite Placement

POS Lite should sit under **Product / Menu Setup**, not as a separate system.

Suggested navigation structure:

```text
Owner
├─ Dashboard
├─ Payment Setup
├─ Product / Menu Setup
│  ├─ Ball Bucket
│  ├─ Drinks
│  ├─ Food
│  ├─ Golf Essentials
│  ├─ Services
│  └─ Basic Stock
├─ Counter Flow
├─ QR / Bay Management
├─ Setup Wizard
└─ Access Settings
```

---

## 5. POS Lite Standard Features

These features are included in the Standard Package:

### Product / Menu Control

- Product category
- Product subcategory
- Product name
- SKU / item code
- Item price
- Item availability
- Active / inactive item status
- Track stock / do not track stock flag

### Basic Stock

- Opening stock quantity
- Current stock quantity
- Low stock threshold
- Out-of-stock status
- Restock entry
- Wastage entry
- Stock correction entry
- Stock movement log

### Counter Sale Basic

- Select item
- Add to cart
- Adjust quantity
- Select payment method
- Complete counter sale
- Auto reduce stock after sale
- Generate basic receipt / slip

### Order Integration

- Reduce stock after customer QR order is confirmed
- Reduce stock after counter sale is completed
- Prevent sale/order when tracked item is out of stock
- Show low stock warning to staff/owner

### Owner Summary

- Sales by item
- Sales by category
- Ball bucket sales
- F&B/product sales
- Counter sales
- QR bay order sales
- Low stock list
- Top selling products

---

## 6. Customer Flow

Customer does not need to know or see POS logic.

Customer-facing flow remains simple:

```text
Scan QR Bay
→ select bucket ball
→ select F&B/product
→ submit order
→ upload payment proof
→ wait at bay
```

Customer-side modules affected:

- Customer Bay page
- Customer Order page
- Product/menu display
- Payment proof upload
- Order receipt/summary

---

## 7. Staff Flow

Staff should continue using a single operational flow.

Staff-facing flow:

```text
Counter Queue
→ review order
→ verify payment
→ print ball slip / kitchen slip / delivery slip / full slip
→ prepare items
→ confirm delivery
```

POS Lite should quietly support the staff flow by:

- reducing stock
- logging item movement
- showing out-of-stock warning
- showing low-stock warning
- recording counter sales

Staff should not need to open a separate POS system for normal RangeFlow operations.

---

## 8. Owner Flow

Owner/admin should be able to manage:

- product/menu setup
- item price
- stock quantity
- low stock threshold
- item availability
- counter sale view
- product sales summary
- stock balance summary
- top selling item report

Owner Dashboard should eventually show:

- total daily sales
- ball bucket sales
- F&B/product sales
- counter sale amount
- QR bay order amount
- low stock count
- out-of-stock item count
- top selling items

---

## 9. Add-On / Future Modules

The following should **not** be included in the Standard Package at this stage.

They remain as add-ons or roadmap modules:

- Full POS
- Barcode scanner
- Cash drawer
- Supplier management
- Purchase order
- Full stock audit
- Inventory valuation
- Accounting inventory integration
- Payment gateway reconciliation
- Multi-branch inventory
- Advanced warehouse management
- Loyalty program
- Membership wallet
- CRM
- Payroll
- AI prediction
- Accounting export

---

## 10. Suggested Supabase Data Areas

Future implementation may require or extend these data areas:

```text
products
product_categories
product_subcategories
stock_movements
counter_sales
counter_sale_items
order_items
orders
orgs
bays
payments
```

This document records scope only. Actual table design and migration should be confirmed before production deployment.

---

## 11. Current Implementation Note

A standalone POS Lite HTML prototype and Supabase migration draft were prepared separately, but this GitHub update records only the agreed `.md` scope first.

Files not yet committed as production code:

```text
rangeflow_pos_lite_module.html
rangeflow_pos_lite_supabase_migration.sql
rangeflow_pos_lite_module_pack.zip
```

---

## 12. Final Positioning Statement

English:

> RangeFlow Standard Package includes Product/Menu Control with POS Lite and Basic Stock Tracking. Full POS and advanced inventory are available as optional add-ons.

Malay:

> Pakej Standard RangeFlow sudah termasuk kawalan produk/menu, POS Lite dan stok asas. POS penuh dan inventori lanjutan boleh ditambah sebagai modul Add-On.

---

## 13. Next Recommended Work

Next implementation step should be:

```text
1. Review current production repo structure
2. Map existing product/menu/order tables
3. Decide whether to extend existing tables or add new POS Lite tables
4. Add Supabase migration
5. Integrate Product/Menu Setup screen
6. Integrate stock reduction into QR order and counter sale
7. Add dashboard summary widgets
```

This should be done only after the Standard Package scope remains confirmed.
