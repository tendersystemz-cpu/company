# EDGE RANGE OS — Button / Action UX Governance

Last locked: 2026-05-31

This document defines how buttons, chips, cards, quick actions and navigation controls must be handled across EDGE RANGE OS.

It exists because the system has many modules and roles. If every page creates buttons differently, the product becomes confusing and starts to look like disconnected pages.

---

## 1. Main principle

Every visible button must answer four questions:

```txt
1. What does this do?
2. Who is allowed to use it?
3. Is it a real action or only a status label?
4. What happens after the user taps it?
```

If a control is clickable, it must look clickable.

If it is only information, it must look like a status chip, not a button.

---

## 2. Button categories

| Category | Purpose | Example | Behavior |
|---|---|---|---|
| Primary Action | Main next step on a page | Checkout, Verify Payment, Save Setup | Strong button, one per section where possible. |
| Module Card | Open a module | Counter, POS Lite, Owner, QR | Icon + short title + role chip + arrow. |
| Quick Action | Shortcut to important operation | Staff Ops, Owner, Access, Payments | Must link to real route/module. |
| Filter Chip | Change current view only | All, Ball, Drinks, Food | Stays on same page and updates list. |
| Status Chip | Information only | Operational, Paid, Pending | Not clickable unless clearly styled as action. |
| Protected Action | Requires PIN/auth | Owner, Access, QR, Payment Setup | Shows lock/access modal before opening. |
| Destructive Action | Risky operation | Delete, Suspend, Release Bay | Red tone + confirmation. |
| Disabled Action | Not ready / unavailable | Checkout with 0 item | Disabled state + clear reason. |

---

## 3. Color governance

Use color to show organizational structure, not decoration.

| Function / Role | Color Direction | Meaning |
|---|---|---|
| Main / Open | Green | General EDGE RANGE OS action. |
| Customer | Green / light green | Public QR/customer flow. |
| Staff / Operations | Blue | Counter, queue, fulfilment, stock operation. |
| Owner / Control | Gold | Owner dashboard, reports, configuration. |
| Payment | Purple | Payment verification, payment setup, transaction control. |
| Access / Security | Red soft | PIN, protected access, lock, suspend warning. |
| System / Neutral | Grey | Read-only system information. |
| Success | Green | Completed, active, verified. |
| Warning | Amber | Attention needed, low stock, pending. |
| Danger | Red | Delete, suspend, release, irreversible action. |

Do not use many random colors. Each color must explain function/role.

---

## 4. Standard button anatomy

### 4.1 Module card

Use this pattern:

```txt
[Icon]
Short description
Module title
[Role chip]        [Arrow]
```

Example:

```txt
🛎️
Staff counter and bay operation
Counter
[Staff]            [›]
```

### 4.2 Quick action button

Use this pattern:

```txt
[Icon]  Main label
        Small note
```

Example:

```txt
🛎️ Staff Ops
    Counter
```

### 4.3 Status chip

Use this pattern only for non-clickable status:

```txt
Operational
Paid
Pending
Locked
```

Status chip must not look stronger than real buttons.

---

## 5. Functional rule

A button must not be cosmetic.

Every clickable item must have one of these behaviors:

```txt
href to production route
onClick action
modal open
filter state change
confirmation flow
submit/save operation
```

If it does none of the above, convert it into a status chip or remove it.

---

## 6. Access rule

Visual lock icon is not security.

Protected buttons must still be guarded by logic.

```txt
Customer route    = public
Staff route       = Staff PIN or Owner PIN
Owner route       = Owner PIN only
Super Admin route = future separate auth
```

Owner PIN may unlock staff operation.

Staff PIN must not unlock owner route.

---

## 7. Navigation grouping

Buttons should be grouped by workflow, not by random page history.

Recommended groups:

```txt
Customer Flow
- Bay Order
- Payment
- Receipt
- Need Help

Staff Operation
- Counter
- Queue
- Payment Verification
- POS Lite
- Stock Lite
- Print Slip

Owner Control
- Owner Dashboard
- Reports
- Menu/Product Setup
- QR Management
- Payment Setup
- Access Control

Super Admin SaaS Control
- Tenant List
- Package Control
- Billing
- Invoice
- Suspend / Reactivate
- Audit Log
```

---

## 8. Mobile layout rule

Mobile screen is the main operational screen.

Use compact layout:

```txt
Top persistent icon nav
Compact status / quick action row
3-column metric cards where possible
2-column module cards
Short labels only
No oversized hero block
No long paragraph inside module card
```

Avoid:

```txt
Large decorative header
Long text block
Cosmetic badges that do nothing
One huge card per function when a compact grid works better
```

---

## 9. Customer page rule

Customer UI must be universal.

Avoid tenant-specific wording in product identity:

```txt
Do not hardcode UKM / pilot / trial / PRIMAVOC as product identity.
Do not expose special tenant pricing label as default product identity.
Do not make EDGE RANGE OS look like one-location custom software.
```

Preferred universal labels:

```txt
Standard
Preferred
Regular rate
Member rate
Self Pickup
Deliver to Bay
Collect at counter
Send to bay
Driving Range
```

Tenant names may appear only where intentionally configured as operator/location data.

---

## 10. Button implementation checklist

Before committing any new UI button, verify:

```txt
[ ] Does it open a real route or run a real action?
[ ] Is the role clear? Customer / Staff / Owner / Super Admin?
[ ] Does color match role/function?
[ ] Does protected action trigger access guard?
[ ] Does disabled action explain why it is disabled?
[ ] Is the label short enough for mobile?
[ ] Does it avoid old/deprecated routes?
[ ] Does it follow operations/lib/navigation.ts where applicable?
```

---

## 11. Current implementation direction

The operations dashboard should use:

```txt
Quick action panel
Clickable metric cards
Role-colored module cards
Persistent icon nav
Central navigation config
```

Important current source:

```txt
operations/lib/navigation.ts
operations/app/GlobalReturnNav.tsx
operations/app/page.tsx
```

---

## 12. Summary for next GPT / developer

Do not add decorative buttons.

Do not add random route buttons.

Do not create separate button systems per page.

Use button hierarchy:

```txt
Primary action
Quick action
Module card
Filter chip
Status chip
Protected action
Danger action
Disabled action
```

Use color by role/function:

```txt
Green = Customer / Open / Main
Blue = Staff Operation
Gold = Owner Control
Purple = Payment
Red soft = Access / Security / Danger
Grey = Read-only / Neutral
```

Every button must be understandable, functional, and aligned with EDGE RANGE OS as a universal SaaS product.
