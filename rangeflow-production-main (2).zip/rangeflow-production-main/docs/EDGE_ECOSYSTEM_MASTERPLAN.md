# EDGE Ecosystem Masterplan

## Purpose

This document records the strategic direction for EDGE Ecosystem and EDGE RangeFlow so product, deployment, branding and commercial decisions stay aligned.

EDGE is the master ecosystem brand. It is not currently the legal company name. The current operating entity is Dunia Bizz Resources. EDGE is the future-facing golf ecosystem brand that can sit above digital products, physical retail, academy, booking and golf lifestyle services.

## Legal / Brand Structure

- Legal / operating entity: Dunia Bizz Resources
- Ecosystem brand: EDGE Ecosystem
- First operational digital product: EDGE RangeFlow
- Physical expansion layer: EDGE Proshop
- Future digital/physical layers: EDGE Academy, EDGE Store, EDGE Booking, EDGE Clubhouse

EDGE should be presented as an ecosystem brand, while legal agreements, quotations, invoices and formal documents can continue to use the correct operating entity where required.

## Current UKM Relationship Context

- UKM is the institution/location owner.
- PRIMAVOC SDN BHD is the operator/tenant relationship layer with UKM.
- EDGE / Dunia Bizz Resources is positioned as a technology, ecosystem and possible proshop/sub-operation layer through the relationship with PRIMAVOC.
- Do not claim EDGE or RangeFlow as an official UKM system unless formal permission exists.
- Acceptable wording: Driving Range @ UKM, Powered by EDGE Ecosystem, operated with/through the relevant operator context.

## EDGE Ecosystem Product Layers

### 1. EDGE RangeFlow
Driving range operations system focused on:
- Bay-centric operations
- Customer QR reorder flow
- Admin operation dashboard
- Owner monitoring and master control
- Inventory and bucket cycle tracking
- Cashless TNG/DuitNow-supported operation
- Customer assistance alerts

### 2. EDGE Proshop
Physical golf retail layer planned for Driving Range @ UKM around early/mid July.
Potential categories:
- Golf gloves
- Balls
- Tees
- Apparel
- Caps
- Training aids
- Accessories

### 3. EDGE Store / Ecommerce
Online ecommerce layer for EDGE Proshop and golf lifestyle products.
Possible future domain/subdomain:
- shop.edgegolf.my

### 4. EDGE Academy
Coach and player development layer.
Future modules may include:
- Coach booking
- Lessons
- Junior development
- Player pathway
- Training packages

### 5. EDGE Booking / Clubhouse
Future layer for:
- Golf booking
- Clubhouse booking
- Coach booking
- Event booking

## Domain Strategy

Use one main EDGE domain and create subdomains for each deployment/product.

Example structure:

- edgegolf.my — master ecosystem website
- ukm.edgegolf.my — Driving Range @ UKM deployment
- bukitunggul.edgegolf.my — future Bukit Unggul deployment
- shop.edgegolf.my — EDGE Proshop / ecommerce
- academy.edgegolf.my — EDGE Academy
- admin.edgegolf.my — future ecosystem admin/master console

Avoid using UKM as a main brand/domain. UKM can be used only as a location reference such as “Driving Range @ UKM”.

## Commercial Positioning

RangeFlow is not a demo, pilot app, or testing system. It must be positioned as a commercial operational product.

Preferred wording:
- EDGE RangeFlow
- RangeFlow Standard Package
- Driving Range Operations System
- Powered by EDGE Ecosystem

Avoid wording:
- pilot app
- trial system
- demo system
- testing page

Internal validation or early deployment can exist, but customer-facing language should remain commercial and operational.

## Core Operational Rule

- 1 bucket = 100 golf balls.
- Do not show 50 balls as the standard bucket quantity.
- Bucket count, inventory calculation, customer label, receipt and infographic wording must all follow 1 bucket = 100 balls unless owner changes the operating rule later.

## RangeFlow Standard Package Direction

The Standard Package should be simple, safe, practical and commercially usable for one driving range operation.

### Customer
Customer should only see the customer order experience.

Flow:
- Arrive at range
- Choose bay naturally as current operation allows
- First bucket may still be paid at counter according to existing behavior
- Customer sees bay QR and uses it for reorder, F&B, assistance or convenience ordering
- Order
- Pay through TNG/DuitNow QR
- Show successful payment screen if required
- Receive receipt/status
- Self pickup or delivery to bay

Customer-facing page should stay simple:
- Order
- Payment instruction
- Receipt/status
- Need assistance button

Customer UI requirements:
- Must be mobile-first.
- Must be clean and similar in spirit to the approved infographic style.
- Must support bilingual BM/BI labels to help customers who do not understand one language.
- The Need Assistance / Perlu Bantuan button should be visible on the customer order/status page, preferably as a clear sticky/floating action near the lower area of the screen so it is always easy to find without cluttering the order form.
- Customer should not see admin or owner functions.

### Admin Operasi
Admin Operasi handles daily operation.

Responsibilities:
- Order in/out
- View active bay/order queue
- Verify payment
- Add order for customer when customer orders verbally
- Bay quick action grid
- Kitchen slip if required
- Status update: preparing, ready, delivered
- Stock movement and inventory operations
- Handle need assistance notification from bay

Admin operation should be bay-centric, mobile/tablet friendly, and not overloaded with owner controls.

### Owner
Owner is master control and monitoring.

Responsibilities:
- Sales/report monitoring
- Pricing structure
- Menu/product add/edit/delete
- Payment QR upload and payment settings
- QR Bay Management
- Inventory verification
- Access PIN for owner and admin operation
- Operation reset/start fresh

Owner may rarely be physically at the range, so the owner dashboard should support remote monitoring and control.

## Customer/Admin Interaction Model

The key system interaction should be bay-centric.

Important features:
- Bay QR sticker
- Customer reorder from bay
- Customer need assistance button
- Admin dashboard receives temporary notification
- Bay button blinks/highlights when assistance is requested
- Admin acknowledges and responds

This avoids WhatsApp dependency and keeps the operation inside RangeFlow.

## Payment Flow Direction

Current physical operation uses cashless payment and TNG/DuitNow style QR.

Standard flow should be low-friction:
- Customer orders
- Customer pays using TNG/DuitNow QR
- TNG soundbox/Blue Tap may confirm payment occurred
- Staff still verifies correct amount/order where needed
- Staff presses verify
- System generates receipt/status

Do not force payment proof upload as the main flow. Payment proof upload may remain as optional fallback for dispute/delay/manual cases.

## Bay Sticker Concept

Each bay sticker can show:

- Bay number
- Order QR
- TNG/DuitNow payment QR under PRIMAVOC/payment merchant context
- Simple instruction

Example:

BAY 07

[ORDER QR]
Scan to Order

[TNG PAYMENT QR]
Scan to Pay

PRIMAVOC SDN BHD / relevant payment merchant name
Powered by EDGE RangeFlow

## Current Commercial Deal Note

Current proposed commercial arrangement:
- First month / initial deployment: RM500
- Live monthly license/rental: RM800 per month
- Contract target: 3 years

Strategic value is not only the RM800/month revenue. The first deployment provides:
- Live case study
- Operational validation
- Customer behavior proof
- Owner/operator trust
- Sales proof for future ranges

Future pricing for other sites may be adjusted based on bay count, modules, support level and commercial maturity.

## Website Masterplan

Once a domain is obtained, EDGE should have its own ecosystem website.

The website should explain:
- EDGE Ecosystem vision
- EDGE RangeFlow
- EDGE Proshop
- EDGE Store/ecommerce
- EDGE Academy
- Future booking/clubhouse ecosystem
- Driving Range @ UKM as a living deployment/reference site, with careful wording and no unauthorized official UKM claim

Purpose of website:
- Build trust
- Explain digital and physical products
- Show ecosystem vision
- Support sales to other ranges
- Prepare audience for EDGE Proshop and ecommerce

## Long-Term Mobile App Vision

EDGE should eventually become mobile-first.

Possible future apps:
- EDGE Golf App for customers
- EDGE Ops for staff/admin/owner

However, current priority is to stabilize the web/mobile-responsive operational flow first before wrapping or rebuilding as native mobile apps.

## Execution Priority

Immediate priority:
1. Stabilize RangeFlow Standard Package
2. Simplify customer experience
3. Build admin operation bay-centric dashboard
4. Separate owner master control
5. Fix payment QR upload instead of URL-only setup
6. Stabilize inventory and stock movement
7. Fix custom domain/SSL trust issue through Coolify custom domain
8. Prepare EDGE Ecosystem website after domain purchase

Do not over-expand into advanced features before the first live range operation is stable.
