# QR Permanent Asset Rule

## Purpose

Bay QR codes are operational assets. Once generated and printed for Bay 01–30, they must not be changed casually.

## Rule

After QR codes for active bays are generated:

```text
Bay 01 -> /b/01
Bay 02 -> /b/02
...
Bay 30 -> /b/30
```

The QR image files should be stored and treated as permanent assets.

## Storage recommendation

Store generated QR images in Supabase Storage:

```text
Bucket: bay-qrcodes
Folder: bukitunggul/
```

Suggested paths:

```text
bay-qrcodes/bukitunggul/bay-01.png
bay-qrcodes/bukitunggul/bay-02.png
...
bay-qrcodes/bukitunggul/bay-30.png
```

## Do not regenerate unless necessary

Do not regenerate or replace QR images unless one of these changes occurs:

```text
Production domain changes
Bay code changes
QR design/template changes approved for reprint
Printed QR is damaged and needs exact replacement
System is migrated to a new final customer URL
```

## Important stability principle

The QR should encode a stable customer URL only:

```text
https://rangeflow-bucc.netlify.app/b/{bay_code}
```

Do not encode temporary booking IDs, customer data, payment links, or short-lived tokens in the printed bay QR.

## Operations app requirement

Operations QR page should support:

1. Generate QR image for Bay 01–30.
2. Save QR image to Supabase Storage.
3. Reuse existing saved QR if already generated.
4. Show public QR image URL.
5. Download individual QR.
6. Print all bay QR labels.
7. Prevent accidental overwrite unless user explicitly confirms regenerate.

## Trial rule

For Monday/full-bay trial, generate and save the QR images once. Use the saved QR assets for printing and bay placement.

## Branding on QR label

QR label should highlight RangeFlow as the system:

```text
RangeFlow
Bay 01
Scan to order balls, food & drinks
Operating at Bukit Unggul Driving Range
Developed by Duniabiz2u.com
WhatsApp Support: +6013-229 9066
```
