# RangeFlow Owner Configurable Access PIN Requirement

## Reason

RangeFlow is moving from a one-off custom demo into a universal standard package.

Therefore staff and owner PINs must not remain hardcoded in frontend source code.

Current temporary state:

- Staff PIN: hardcoded in hub page
- Owner PIN: hardcoded in hub page

This is acceptable only for early demo/testing, not for production or standard package rollout.

## Required Capability

Owner must be able to update access PINs from the system.

Minimum required PIN settings:

1. Staff Counter PIN
2. Owner / Management PIN
3. Optional Runner PIN later
4. Optional Kitchen / Station PIN later

## Recommended UI Location

Add Access Settings inside either:

- Owner Dashboard `/owner`
- Setup Wizard
- System Settings page later

Recommended first version:

- `/owner` includes an Access Settings card

Fields:

- Current Owner PIN
- New Staff PIN
- Confirm New Staff PIN
- New Owner PIN
- Confirm New Owner PIN

## Recommended Flow

1. Owner logs in using current owner PIN.
2. Owner opens Owner Dashboard.
3. Owner goes to Access Settings.
4. Owner enters current owner PIN for verification.
5. Owner changes staff or owner PIN.
6. System saves new PIN securely.
7. Hub login immediately uses new PIN.

## Security Rule

Do not store PINs directly in frontend code.

Do not expose PIN values in public JavaScript bundle.

Recommended backend approach:

- Store hashed PIN values in Supabase.
- Verify PIN through Supabase RPC.
- Update PIN through owner-only Supabase RPC.

## Suggested Database Design

Table:

`org_access_pins`

Columns:

- id
- org_id
- role_key: staff, owner, runner, kitchen
- pin_hash
- updated_at
- updated_by

RPC functions:

- verify_org_access_pin(p_org_slug, p_role_key, p_pin)
- update_org_access_pin(p_org_slug, p_owner_pin, p_role_key, p_new_pin)

## Frontend Changes Required

Hub `/hub`:

- Remove hardcoded STAFF_PIN and OWNER_PIN.
- On unlock, call verify_org_access_pin.
- If valid, set session storage role.

Owner Dashboard `/owner`:

- Add Access Settings section.
- Owner can update Staff PIN and Owner PIN.

Setup Wizard:

- During initial setup, owner sets default Staff PIN and Owner PIN.

## Temporary Demo Position

Until this is implemented, current hardcoded PINs can remain only as demo defaults.

Before selling as standard package, configurable owner-managed PIN must be implemented.

## Priority

Priority: High

Reason:

- Required for self-setup product
- Required for multi-operator deployment
- Required to avoid every installation sharing the same PIN
- Required before calling the package production-ready
