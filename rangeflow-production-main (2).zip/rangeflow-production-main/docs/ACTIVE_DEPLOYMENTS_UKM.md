# ACTIVE DEPLOYMENTS — EDGE RangeFlow @ UKM

This file is the deployment source-of-truth to avoid creating or using duplicate Coolify applications.

## Production source of truth

- Supabase project ref: `cgewjbfycnqbyczyuthp`
- Supabase URL: `https://cgewjbfycnqbyczyuthp.supabase.co`
- Active org slug: `drukm`
- Do not use `bukitunggul` for UKM.

## Active live apps to use

### 1. Customer QR App — LIVE

Use this for customer bay QR/order/payment/receipt flow:

```text
http://thw9q52xl3357l1a8iwiqgus.5.223.94.81.sslip.io
```

Routes:

```text
/
/b/07
/b/07/order
/pay/[bookingId]
/receipt/[bookingId]
```

Coolify notes:

```text
Project: rangeos
Application: rangeflow-production:codex/complete-rangeflow-standard-package-thw9q52xl3357l1a8iwiqgus
Base directory: customer
```

Required env:

```text
NEXT_PUBLIC_SUPABASE_URL=https://cgewjbfycnqbyczyuthp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<Supabase anon key>
NEXT_PUBLIC_ORG_SLUG=drukm
NEXT_PUBLIC_OPERATIONS_BASE_URL=http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io
```

### 2. Operations App — LIVE

Use this for staff/admin/owner flow:

```text
http://ldf1c0363m6zfr4exdvvgebj.5.223.94.81.sslip.io
```

Routes:

```text
/
/counter
/owner
/menu
/payments
/stock
/pos
```

Coolify notes:

```text
Project: My first project
Application: rangeflow-operations
Base directory: operations
```

Required env:

```text
NEXT_PUBLIC_SUPABASE_URL=https://cgewjbfycnqbyczyuthp.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=<Supabase anon key>
NEXT_PUBLIC_ORG_SLUG=drukm
NEXT_PUBLIC_CUSTOMER_BASE_URL=http://thw9q52xl3357l1a8iwiqgus.5.223.94.81.sslip.io
```

## Legacy / duplicate apps — do not use for UKM live flow

Do not use these unless explicitly migrating or archiving:

```text
http://pywzxs74za3tmaxfz6mefzlo.5.223.94.81.sslip.io
http://s8lbafk5vhuorm1itoaclixb.5.223.94.81.sslip.io
http://tvrtb4qixifs3a411r1jqez3.5.223.94.81.sslip.io
```

## Current completion priority

1. Redeploy Operations App `ldf1c0363m6zfr4exdvvgebj` from latest `main`.
2. Confirm `/counter` shows `Staff Counter Dashboard`.
3. Test bay grid, Add Counter Order, Mark as Paid, Need Help, Self Pickup Queue, Deliver to Bay Queue.
4. Do not create new Coolify apps unless replacing an existing one intentionally.
