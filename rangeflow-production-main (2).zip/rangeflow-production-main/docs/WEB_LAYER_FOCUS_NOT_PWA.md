# RangeFlow Web Layer Focus

Status: Immediate scope
Date: 2026-05-11

---

# Instruction

Do not shift current work toward PWA or future mobile ecosystem yet.

The immediate priority is the current web layer only.

---

# Current Focus

RangeFlow standard commercial package must focus on polishing the existing web experience:

1. Customer web homepage
2. Customer bay/order/payment/receipt flow
3. Operations web hub
4. Staff queue page
5. Owner dashboard page
6. Menu management page
7. QR management page

---

# Main Problem To Solve Now

The system is already operational, but the web layer still feels too plain and internal-tool-like.

Current improvement target:

- better graphics
- better golf visuals
- less empty space
- clearer buttons
- clearer page purpose
- better user navigation
- more commercial visual feel
- more premium sports-tech atmosphere

---

# Specific Web Layer Improvements Required

## Customer Homepage

Required:

- strong hero section with golf/range image
- clear commercial headline
- clear customer call-to-action
- explain how customer flow works
- show standard package features
- avoid empty/plain developer-page feel

## Bay Page

Required:

- better bay presentation
- clearer customer instruction
- visible order button
- more visual/premium layout
- avoid overly blank card layout

## Order Page

Required:

- clearer product/order layout
- better item grouping
- better quantity controls
- stronger total/cart section
- better visual hierarchy
- make it obvious what customer should do next

## Payment Page

Required:

- clearer QR/payment instruction
- stronger payment success path
- avoid confusing manual confirmation wording
- show next action clearly

## Receipt Page

Required:

- better receipt design
- clear success message
- buttons for:
  - back to bay
  - order more
  - return to homepage/menu
- reduce dead-end flow after payment

## Operations Hub

Required:

- role-based button visibility
- customer/public should not see owner/staff modules
- staff should only see staff-relevant modules
- owner/admin should see management modules
- make it feel like normal commercial app navigation

## Operations Dashboard

Required:

- clearer status colors
- less empty space
- better KPI/queue card layout
- more visual hierarchy

---

# Explicitly Not In Scope Now

Do not prioritize the following yet:

- PWA installable app
- mobile app ecosystem
- events/community module
- advanced loyalty
- wallet
- AI analytics
- franchise/multi-branch expansion

These are future roadmap items only.

---

# Current Principle

Build the web layer to look and feel like a standard commercial web application first.

The future PWA/mobile ecosystem can come later only after the current web package is visually and operationally mature.
