# EDGE RangeFlow Staff & Owner Live Operation Guide

## Purpose

This guide is for live operation at the driving range. It explains what Customer, Admin Operasi and Owner should do during daily use.

## Product Positioning

- Product: EDGE RangeFlow
- Package: Standard Package
- Brand: Powered by EDGE Ecosystem
- Operation style: cashless driving range operation
- Bucket rule: 1 bucket = 100 balls

## Customer Flow

Customer should only need to understand:

1. Choose bay.
2. Scan bay QR.
3. Order bucket/menu.
4. Pay using TNG/DuitNow QR.
5. Show successful payment screen to staff if requested.
6. Wait for verification/status.
7. Self pickup or wait for delivery to bay.
8. Press Need Help / Perlu Bantuan if assistance is needed.

Customer page must stay simple.
Customer must not see admin or owner controls.

## Admin Operasi Daily Work

Primary route:

```text
/staff-ops-bay
```

Admin Operasi handles:

- monitor bay grid
- respond to Need Help alert
- add assisted order for customer
- verify payment
- update order status
- print kitchen slip if required
- print receipt if requested
- record stock movement

## Admin Operasi Bay Alert

When customer presses Need Help:

1. Admin sees alert on dashboard.
2. Bay number blinks/highlights.
3. Admin taps the alert/bay.
4. Admin attends customer.
5. Alert becomes acknowledged.

No WhatsApp dependency is required for this flow.

## Assisted Order Flow

Use assisted order when:

- customer orders verbally
- customer is elderly
- VIP/customer needs help
- customer does not want to scan QR
- customer wants add-on order at counter

Route:

```text
/pos?bay=07
```

Steps:

1. Select bay from Admin Ops.
2. Tap Add Order For Bay.
3. Select items.
4. Choose payment method.
5. Payment must be cashless.
6. Customer pays by TNG/DuitNow/bank/card terminal.
7. Staff completes order.
8. Print receipt if requested.

Important:

- Cash is not part of the standard live flow.
- Assisted order should still be tied to bay.

## Payment Verification

Standard flow:

1. Customer pays exact amount using TNG/DuitNow QR.
2. Customer shows successful payment screen if requested.
3. Staff verifies correct amount.
4. Staff taps Verify Payment.
5. Receipt/status updates.

Payment proof upload:

- optional fallback only
- use for dispute, delay or staff request
- not the main flow

## Kitchen Slip

Kitchen slip should be used only for items that require preparation:

- hot drinks
- prepared cold drinks
- cooked food
- items requiring kitchen/preparation time

Kitchen slip is not required for:

- ball bucket
- bottled water
- mineral water
- canned drinks
- boxed drinks
- snacks that can be handed directly

## Receipt

Receipt is optional unless customer asks.

Customer can also view receipt/status on phone.

## Stock / Inventory

Route:

```text
/stock
```

Admin Operasi records:

- stock in
- product stock movement
- wastage
- basic operational adjustment

Owner verifies:

- current stock
- low stock level
- ball stock summary
- bucket cycle summary

Locked formula:

```text
1 bucket = 100 balls
```

## Owner Work

Primary route:

```text
/owner
```

Owner handles:

- report monitoring
- pricing/menu control
- payment QR setup
- QR bay management
- inventory verification
- admin/owner access PIN

Owner is not expected to do daily counter operation unless necessary.

## Payment QR Setup

Route:

```text
/payments
```

Owner can:

- upload TNG QR image
- upload DuitNow QR image
- paste QR image URL if needed
- set merchant/account name
- set customer payment note

Recommended payment note:

```text
Bayar jumlah tepat menggunakan TNG/DuitNow QR. Tunjukkan skrin bayaran berjaya kepada staff untuk verification.
```

## QR Bay Management

Route:

```text
/qr
```

Use this to:

- generate bay QR
- preview order QR
- print bay stickers

Important:

- QR target should be `/b/[bay]/order`
- regenerate all QR after custom domain migration
- do not print final customer stickers using temporary sslip.io domain

## Daily Opening Routine

1. Open Admin Ops dashboard.
2. Check payment QR is correct.
3. Check bay grid loads.
4. Check stock/ball count if required.
5. Confirm TNG/DuitNow terminal/soundbox is working.
6. Ensure staff knows PIN.
7. Test one Need Help request if needed.

## Daily Closing Routine

1. Review paid orders.
2. Review bucket sold today.
3. Review expected ball out.
4. Record stock in/adjustment if needed.
5. Check pending orders.
6. Owner reviews report if needed.

## Live Rule Summary

- Customer page stays simple.
- Admin Operasi works by bay.
- Owner controls master settings.
- Payment is cashless.
- 1 bucket = 100 balls.
- Proof upload is fallback only.
- QR stickers must use final custom domain after domain is ready.
