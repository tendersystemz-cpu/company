# RangeOS Mobile ↔ Web App Synchronization Requirements

**Project:** RangeOS Mobile / RangeFlow  
**Purpose:** Mandatory implementation rules for Emergent so the RangeOS Mobile App can synchronize correctly with the existing RangeOS / RangeFlow Web App.

This document is the source-of-truth for mobile ↔ web synchronization, one-subscription SaaS control, role separation, and next-phase delivery.

---

## 1. Core Direction

RangeOS is not two separate products.

It is:

```text
One SaaS subscription
Two connected platforms
One shared operating system for driving ranges
```

Platforms:

```text
1. RangeOS Web App
2. RangeOS Mobile App
```

Both platforms must synchronize through one shared backend/source-of-truth.

Do not create separate business logic, subscription states, or operational data silos for web and mobile.

---

## 2. One Subscription Per Tenant

Each operator/range pays for **one SaaS subscription per tenant**.

Subscription must be tied to:

```text
tenant_id
```

Do not create separate states such as:

```text
web_subscription_status
mobile_subscription_status
```

Use one shared tenant-level subscription state:

```text
tenant.subscription_status
tenant.billing_status
tenant.package_name
tenant.billing_cycle
tenant.subscription_start_date
tenant.subscription_end_date
tenant.next_due_date
```

If a tenant is active, both web and mobile access should work.

If a tenant is suspended, both web and mobile access must be restricted.

---

## 3. Billing Cycles

Subscription must support:

```text
monthly = 1 month
6_months = 6 months
yearly = 12 months
```

Super Admin must be able to configure billing cycle per tenant.

Required fields:

```text
tenant_id
package_name
monthly_license_fee
billing_cycle
billing_period_months
deposit_amount
minimum_contract_months
utility_usage_percentage
subscription_start_date
subscription_end_date
next_due_date
last_payment_date
grace_until
subscription_status
billing_status
last_email_reminder_at
email_reminder_count
```

Super Admin may manually override invoice amount, due date, or billing record.

---

## 4. Role Hierarchy

The same role hierarchy must apply to both Web App and Mobile App.

```text
Super Admin
↓ creates / approves / controls
Owner
↓ creates / manages
Staff
↓ serves
Customer
```

Access rule:

```text
Customer = guest / QR-first / no login
Staff = operation login created by Owner
Owner = business login created or activated by Super Admin
Super Admin = SaaS control
```

Use role names consistently:

```text
super_admin
owner
staff
customer_guest
```

Do not mix Staff, Owner, and Super Admin into one generic admin role.

---

## 5. V1 Platform Coverage

Recommended V1 coverage:

```text
Customer = mobile-first / QR-first
Staff Operation = web + mobile
Owner Dashboard = web + mobile
Super Admin = web-first
```

Super Admin mobile support can come later, but Super Admin actions must affect both web and mobile because subscription is tenant-level.

---

## 6. Shared Source-of-Truth

Both Web App and Mobile App must read/write the same operational data.

Shared data must include:

```text
tenants
owners
staff users
bays
bay sessions
menu/products
orders
payment QR
customer categories
Need Help requests
revenue reports
billing records
subscription status
tenant activation/suspension status
audit logs
```

Expected sync behavior:

```text
Staff creates order on web → mobile sees it
Staff creates order on mobile → web sees it
Owner updates menu/payment QR/staff on mobile → web reflects it
Owner updates menu/payment QR/staff on web → mobile reflects it
Super Admin suspends tenant → both web and mobile restrict access
```

---

## 7. Backend Architecture Rule

Preferred architecture:

```text
Web Frontend
Mobile App
↓
Shared API / Backend
↓
Shared Database
```

Do not duplicate backend logic separately for web and mobile.

If existing Web App and Mobile App use different backend/database implementations, do not blindly connect them.

First decide one source-of-truth:

```text
Option A: Mobile and Web both use the same backend/database.
Option B: Existing Web App is migrated into the new shared backend.
Option C: Build an API bridge carefully, but avoid duplicated data.
```

Preferred option:

```text
One backend source-of-truth for both Web App and Mobile App.
```

---

## 8. Tenant Isolation

Every query and mutation must enforce `tenant_id`.

This applies to:

```text
orders
bays
bay_sessions
menu/products
staff users
owner settings
payment QR
pricing
reports
billing records
help requests
stock/inventory
print slips
```

Staff and Owner must never access data from another tenant.

Super Admin is the only role that may view/manage all tenants.

---

## 9. Customer Flow

Customer remains guest access.

Entry methods:

```text
Public Range List
Range Code
Range QR
Bay QR
QR Scanner
```

Routes may include:

```text
/customer
/customer/scan
/customer/range/[slug]
/customer/order/[slug]/[bay]
/customer/pay/[order_id]
/customer/receipt/[order_id]
```

Customer can:

```text
View selected range
Scan Bay QR
Order balls/F&B/products
Choose Self Pickup or Deliver to Bay
View operator payment QR
View receipt/status
Tap Need Help
Contact range if contact is configured
```

Customer must not access Staff, Owner, or Super Admin data.

---

## 10. Staff Operation Flow

Staff Operation must exist in both Web App and Mobile App.

Routes may include:

```text
/staff
/staff/dashboard
/staff/orders
/staff/counter-order
/staff/bays
/staff/payments
/staff/need-help
/staff/stock-lite
```

Staff can:

```text
View live bay status
Create Assisted Counter Order
Select bay
Add ball bucket / F&B / products
Mark payment as paid
Choose payment method
Update order status
Handle Self Pickup / Deliver to Bay
Respond to Need Help
Close / clear bay session
```

Staff must not control:

```text
Tenant activation
Subscription
Package
License fee
Deposit
Contract period
Billing status
Owner account
```

---

## 11. Owner Dashboard Flow

Owner Dashboard must exist in both Web App and Mobile App.

Owner can:

```text
Manage range profile
Manage bays
Manage operating hours
Manage menu/products
Manage pricing/customer categories
Upload/change TNG/DuitNow/bank QR
Manage WhatsApp/contact number
Generate/view/share/print Range QR and Bay QR
Create/manage Staff accounts
View revenue
View reports
View bay usage
View stock movement
View subscription/package information as read-only
```

Owner must not edit Super Admin-controlled fields:

```text
tenant status
package/tier assignment
monthly license fee
deposit amount
minimum contract period
utility usage percentage
billing status
subscription start/end date
activation/suspension status
```

---

## 12. Super Admin Flow

Super Admin is the platform control layer and should be web-first for V1.

Super Admin can:

```text
Create tenant/range
Approve operator signup request
Create/activate Owner login
Activate/suspend tenant
Assign package/tier
Set monthly license rental
Set billing cycle: monthly / 6 months / yearly
Set deposit
Set minimum contract period
Set utility usage percentage
Control billing status
Upgrade/downgrade tenant package
View all tenants
View all owner accounts
View all tenant operational status
Reactivate suspended tenants after payment
```

Super Admin subscription control must apply to both web and mobile.

---

## 13. QR Rules

Printed QR codes must use HTTPS-first payloads.

Range QR:

```text
https://<production-domain>/customer/range/[slug]
```

Bay QR:

```text
https://<production-domain>/customer/order/[slug]/[bay]
```

QR scanner may also support:

```text
rangeflow://range/[slug]
rangeflow://bay/[slug]/[bay]
[SLUG]
[SLUG]:[BAY]
short URLs
```

HTTPS-first is required so any customer can scan using the normal phone camera.

---

## 14. Payment Rule

For V1, payment remains operator-owned QR payment.

Do not integrate regulated payment gateway unless explicitly requested later.

Owner uploads their own payment QR:

```text
TNG
DuitNow
Bank transfer QR
```

Customer payment page shows:

```text
Range name
Order number
Total amount
Operator payment QR
Payment instruction
Receipt/status
```

---

## 15. No WhatsApp API for V1

Do not use WhatsApp API or WhatsApp Cloud API for subscription reminders in V1.

Use instead:

```text
Dashboard reminder
Email reminder
Super Admin manual billing control
Optional manual wa.me deep link only
```

Manual WhatsApp link only:

```text
https://wa.me/<owner_phone>?text=<auto_generated_message>
```

This must not require API key, paid provider, or webhook.

---

## 16. Subscription Reminder / Billing Lifecycle

Subscription statuses:

```text
active
due_soon
overdue
grace_period
suspended
cancelled
```

Reminder timeline:

```text
14 days before due date = early reminder
7 days before due date = reminder
3 days before due date = final reminder
Due date = payment due today
3 days after due date = grace period warning
7 days after due date = suspension warning
After grace period = tenant suspended
```

Owner Dashboard should show:

```text
Package
Billing cycle
License fee
Due date
Days remaining
Billing status
Subscription status
Outstanding amount
```

Email reminders should be sent to Owner email.

Suggested email subject:

```text
RangeOS Subscription Reminder — [Range Name]
```

Suggested body:

```text
Hi [Owner Name],

Your RangeOS subscription for [Range Name] is due on [Due Date].

Package: [Package Name]
Billing Cycle: [Monthly / 6 Months / Yearly]
Amount Due: RM[Amount]
Billing Status: [Billing Status]

Please make payment before the due date to avoid service interruption.

Thank you,
RangeOS Team
```

---

## 17. Billing / Invoice Records

Add billing records/invoices.

Suggested fields:

```text
id
tenant_id
invoice_no
owner_email
billing_cycle
billing_period_months
billing_period_start
billing_period_end
due_date
amount_due
amount_paid
payment_status
paid_at
payment_method
reference_no
email_reminder_count
last_email_reminder_at
created_by_super_admin_id
created_at
updated_at
```

Payment status:

```text
unpaid
pending
paid
overdue
cancelled
```

Super Admin Billing panel can:

```text
View all tenant billing status
Filter due soon / overdue / suspended
Create invoice
Send email reminder manually
Mark invoice as paid
Record payment method
Record payment reference number
Update due date
Suspend tenant
Reactivate tenant
```

---

## 18. P0-C Required Before P1

Accepted milestones:

```text
P0-A = Real QR Generation + Native QR Scanner
P0-B = Payment QR Upload + Owner Settings Tabbed Page
SaaS Structure Patch = Customer / Staff / Owner / Super Admin separation
```

Next required milestone:

```text
P0-C = Staff Assisted Counter Order + Bay Session States + Need Help Workflow
```

P0-C acceptance criteria:

```text
1. Staff can create Assisted Counter Order.
2. Staff can select bay, items, customer category, pickup/delivery option, payment method and payment status.
3. Creating a paid counter order opens/activates the bay session.
4. Creating unpaid/pending order marks bay as pending payment.
5. Customer Bay QR add-on orders attach to the active bay session.
6. Staff bay grid shows Empty / Active / Pending Payment / Need Help / Closed states.
7. Staff can close and clear bay session.
8. Customer can tap Need Help.
9. Staff receives Need Help alert and can mark it resolved.
10. Order status flow works for Self Pickup and Deliver to Bay.
11. Owner can see active bay/session overview.
12. Tenant isolation remains intact.
13. Existing QR, scanner, Owner Settings, Payment QR, and Super Admin functions remain working.
14. Backend tests pass.
15. Frontend lint remains clean.
```

---

## 19. P1 After P0-C

Only after P0-C is accepted, proceed to P1:

```text
POS Lite
Basic Inventory
Stock in / stock out
Low stock alert
Auto stock deduction after confirmed sale
Per-category pricing matrix
Print slips
Receipt/status polish
Basic audit log
Production native app testing
```

Do not start P1 before P0-C is audited.

---

## 20. GitHub Branch Workflow

Emergent may work from a different branch, but must preserve the shared product direction.

Recommended branch rules:

```text
main = stable / approved
develop = integration
feature/rangeos-mobile-p0c = P0-C implementation
feature/billing-reminder = subscription reminder / billing lifecycle
feature/mobile-web-sync = web/mobile sync work
```

Before merging to main:

```text
Backend tests must pass
Frontend lint must pass
Tenant isolation must be verified
Role access must be verified
No Super Admin control regression
No Owner/Staff access leakage
No duplicate subscription state
No separate mobile/web data silo
```

Every PR should mention:

```text
Affected routes/screens
API changes
Database/model changes
Role/access changes
Tests run
Known limitations
Screenshots if available
```

---

## 21. Preview / Development Data Reset

Provide a safe reset for preview/development only.

Reset must:

```text
Require Super Admin authentication
Be disabled in production
Show confirmation
Clear demo/test data
Preserve or recreate Super Admin
```

Clear:

```text
tenants
owners
staff users
bays
menu items
orders
payment QR data
customer categories
bay sessions
help requests
billing records
test wizard data
```

Preserve/recreate:

```text
superadmin@rangeflow.com / super123
```

---

## 22. Audit / Approval Process

Each completed milestone must be audited before moving to the next phase.

Approval statuses:

```text
ACCEPTED
ACCEPTED WITH CORRECTION
REJECTED / MUST PATCH
DEFERRED TO NEXT PHASE
```

Every completed phase must provide:

```text
1. Summary of completed work
2. Updated routes/screens
3. Backend API changes
4. Database/model changes
5. Role/access control changes
6. Test result
7. Frontend lint result
8. Known limitations
9. Screenshots if available
10. What is recommended next
```

---

## 23. Sellable V1 Readiness

RangeOS can be considered Sellable V1 only when these are ready:

```text
Multi-tenant SaaS structure
Web + Mobile shared backend/source-of-truth
One subscription per tenant covering both platforms
Super Admin subscription control
Owner Settings
Payment QR upload
QR generation and scanner
Customer ordering
Staff assisted counter order
Bay session management
Need Help workflow
Subscription reminder and billing control
Basic POS Lite
Basic inventory
Pricing matrix
Print slips
Native app real device testing
Tenant suspension rules
Basic audit log
```

Until then, it should be called:

```text
Production Foundation / Sellable Beta
```

---

## 24. Final Non-Negotiable Rules

Emergent must always preserve:

```text
One tenant = one subscription = web + mobile access
One shared backend/source-of-truth
Tenant isolation
Role separation
Super Admin subscription control
Owner business control
Staff operational simplicity
Customer guest ordering simplicity
HTTPS-first QR flow
Payment directly to operator account
No WhatsApp API cost in V1
Email/dashboard subscription reminder
Audit before next phase
```

This document must be followed before implementing any new RangeOS module.
