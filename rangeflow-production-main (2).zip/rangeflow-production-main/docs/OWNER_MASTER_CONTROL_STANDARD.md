# Owner Master Control Standard

## Purpose

Owner page is not for daily counter operation. Owner page is the master control and monitoring layer.

## Owner Role

Owner is usually not physically at the range. Owner needs remote visibility and control.

Owner controls:
- sales/report monitoring
- 100-ball bucket cycle summary
- pricing structure
- menu/product add edit delete
- payment QR setup
- QR bay management
- inventory verification
- admin/owner PIN access
- operation reset/start fresh when required

Admin Operasi handles:
- bay operation
- order in/out
- assisted order
- payment verify
- stock movement
- Need Help alert
- kitchen slip
- ready/delivered status

## Owner Dashboard Sections

### 1. Report Summary

Show:
- Today sales
- Today orders
- Paid orders
- Pending orders
- Completed orders
- 100-ball bucket quantity
- Bay usage

### 2. Business Control

Owner controls:
- Walk-in bucket price
- UKM student/staff bucket price
- menu pricing
- product availability
- add/edit/delete products

Current locked pricing:
- Walk-in customer: RM12 / 100 balls
- UKM student/staff: RM8 / 100 balls

### 3. Payment Control

Owner controls payment QR.
Important requirement:
- Owner must be able to upload JPG/PNG/PDF or image file.
- Owner should not be forced to paste image URL.
- Payment setup must support TNG/DuitNow QR.
- PRIMAVOC/payment merchant name should be visible where relevant.

### 4. QR Bay Management

Owner controls:
- bay QR generation
- bay QR print
- active/disabled bay
- standby bay 26-30

Actual active bay count: 25.
Prepared bay slots: 30.
Bay 26-30 standby unless enabled later.

### 5. Inventory Verification

Owner does not do daily stock movement unless needed.
Owner verifies:
- ball stock movement
- bucket cycle count
- low stock alert
- product stock summary

Admin Operasi records daily stock movement.
Owner verifies stock summary.

### 6. Access Control

Owner controls:
- owner PIN
- admin operation PIN

Owner has master access.
Admin only has delegated operation access.

## UI Principle

Owner dashboard must feel like a master control panel, not a cluttered admin menu.

Preferred main buttons:
- Report
- Pricing/Menu
- Payment QR
- QR Bay
- Inventory
- Access PIN
- Admin Ops Monitor

Remove or de-emphasize:
- pilot wording
- demo wording
- unnecessary advanced modules
- member/promotions unless intentionally activated later

## Commercial Positioning

Use:
- EDGE RangeFlow
- Owner Master Control
- Standard Package
- Powered by EDGE Ecosystem

Avoid:
- Pilot
- Demo
- Testing
- Temporary
