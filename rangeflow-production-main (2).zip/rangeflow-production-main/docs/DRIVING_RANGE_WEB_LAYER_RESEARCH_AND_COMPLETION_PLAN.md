# RangeFlow Web Layer Research & Completion Plan

Status: Active refinement scope
Date: 2026-05-11

---

# Objective

Complete the current RangeFlow web layer into a cleaner, more professional standard commercial package before considering PWA, mobile app, membership ecosystem, or other chargeable add-on modules.

This plan is based on current RangeFlow implementation plus quick reference review of public GitHub golf-related systems such as:

- BrandJaws/Golf-Club-Management — Laravel golf club management project
- samlance/GolfBookingSystem — golf booking system project
- related tee-time/golf booking repositories found via GitHub search

Observation: most public examples focus on booking or generic club management. RangeFlow should differentiate itself as a driving range operations system, not merely a tee-time booking tool.

---

# Current RangeFlow Position

RangeFlow already has a stronger operational engine than a basic showcase app:

- customer bay QR flow
- bucket / food / drink ordering
- payment and receipt flow
- operations queue
- menu management
- QR management
- owner summary dashboard
- Supabase database integration
- Netlify deployment

The remaining weakness is mostly web-layer maturity:

- pages feel separated
- navigation is not unified enough
- owner dashboard lacks sales breakdown by item/category
- menu management needs compact professional UI
- payment QR management needs settings UI
- page flow needs better return-to-main-menu behavior
- customer journey needs clearer next-action buttons

---

# Standard Commercial Web Layer Scope

The standard package should include:

## 1. Unified Main Menu / Frontpage

The `/hub` page should become the official frontpage for system access.

Required behavior:

- show public/customer options by default
- allow staff role access
- allow owner/admin role access
- group options clearly by layer
- show all available modules after role selection
- provide direct navigation to all major modules
- avoid making pages feel isolated

Required modules in hub:

- Customer Web
- Bay Order Flow
- Operations Queue
- Owner Dashboard
- Menu Management
- QR Management
- Payment Settings
- Reports / Sales Summary
- Settings / Range Profile

---

## 2. Unified Navigation Across All Operations Pages

Every operations page should include:

- Back to Main Menu button
- consistent top navigation
- page title
- clear current section
- quick links to Queue, Owner, Menu, QR, Payments

Pages that need this:

- `/hub`
- `/queue`
- `/owner`
- `/menu`
- `/qr`
- future `/payments`
- future `/settings`

---

## 3. Owner Dashboard Completion

Owner dashboard should show more than total sales and bay utilization.

Required standard metrics:

### Sales Summary
- today sales
- total paid orders
- unpaid / pending payment count
- completed orders
- bucket quantity sold

### Category Breakdown
- bucket sales
- food sales
- drinks sales
- other item sales

### Top Items
- best-selling food item
- best-selling drink item
- total quantity by item
- total sales by item

### Payment Summary
- DuitNow total
- Touch n Go total
- cash/manual payment total
- unpaid orders

### Bay Summary
- active bays
- used bays today
- most active bay

---

## 4. Menu Management Cleanup

Current problem:

- item cards can feel too large
- image layout can overflow
- edit/save flow is not polished enough
- page spacing is not compact

Required improvements:

- fixed image ratio
- compact table/card hybrid layout
- clear Add Item button
- clear Edit button
- clear Save button
- clear Available/Unavailable toggle
- prevent long text/image overflow
- group by category: balls, food, drinks, services

---

## 5. Payment Settings Page

The standard commercial package should include a basic payment settings page.

Required:

- DuitNow QR upload/edit field
- Touch n Go QR upload/edit field
- bank QR/manual payment field
- payment method active/inactive toggle
- payment instruction text
- preview section

This should be in a new page:

`/payments`

or as part of:

`/settings`

Recommended now:

Create `/payments` first as a focused module.

---

## 6. Range Profile / Generic Branding Settings

Since Bukit Unggul is no longer the only target, the system must avoid being locked to one range.

Required future settings:

- range name
- range short name
- logo URL
- location name
- support phone
- WhatsApp number
- homepage tagline
- payment instructions
- public display theme

This lets the system be reused for:

- XYZ Driving Range
- Driving Range UKM
- DR Semarak Cyberjaya
- future trial clients

---

## 7. Customer Flow UX Completion

After order/payment/receipt, customer should not hit a dead end.

Required buttons:

- Back to Bay
- Order More
- View Receipt
- Back to Main Menu / Home

Required clarity:

- payment success message
- receipt reference/token
- order status
- next steps for customer

---

# Research Notes From Public GitHub Direction

Public golf-related repositories usually fall into these groups:

## Golf Club Management
Focus:

- members
- bookings
- admin management
- generic club operations

Limitation:

- not specifically optimized for driving range bay operation
- often not focused on bay QR ordering

## Golf Booking / Tee-Time Systems
Focus:

- time booking
- user booking flow
- schedule/availability

Limitation:

- more golf course tee-time focused
- less suitable for driving range bucket, bay, counter queue, food and beverage flow

## RangeFlow Differentiation

RangeFlow should position itself as:

"Golf Driving Range Operations System"

Not only:

"Golf booking app"

Unique standard package value:

- bay QR ordering
- bucket sales
- F&B order queue
- staff counter workflow
- owner visibility
- QR management
- payment flow
- range-specific operations

---

# Immediate Build Priority

## Priority 1 — Unified Navigation

- make `/hub` the real main frontpage
- add all module options into hub
- all pages must link back to hub

## Priority 2 — Owner Dashboard Upgrade

- add item/category sales breakdown
- add food/drink records sold
- add top items summary
- add payment summary

## Priority 3 — Menu Page Cleanup

- compact UI
- fix image overflow
- better add/edit/save flow

## Priority 4 — Payment Settings

- add QR payment settings module
- support DuitNow and Touch n Go

## Priority 5 — Customer UX Buttons

- after receipt/payment, add return/order-more actions

---

# Not In Scope Now

Do not prioritize yet:

- PWA
- mobile app install flow
- membership ecosystem
- event/community system
- wallet
- AI analytics
- multi-branch franchise scaling

These remain future add-on or premium package directions.

---

# Final Direction

The current work should complete a proper web-based standard commercial package first.

The system should feel like one connected platform:

`Main Hub -> Customer / Staff / Owner -> Operations Modules -> Back to Main Hub`

not separate standalone pages.
