# Future Note: Preset Menu Image Library

## Purpose

Before full DIY image upload is polished, RangeFlow can ship with a preset image library for common range and cafe items.

This helps operators start quickly without needing to prepare all images on day one.

## Concept

Store default item images in Supabase Storage:

```text
Bucket: menu-images
Folder: presets/
```

Example paths:

```text
menu-images/presets/ball-bucket.jpg
menu-images/presets/mineral-water.jpg
menu-images/presets/100-plus.jpg
menu-images/presets/iced-lemon-tea.jpg
menu-images/presets/hot-coffee.jpg
menu-images/presets/hot-tea.jpg
menu-images/presets/nasi-lemak.jpg
menu-images/presets/chicken-burger.jpg
menu-images/presets/roti-canai.jpg
menu-images/presets/mee-goreng.jpg
menu-images/presets/roti-bakar.jpg
```

## Preset item coverage

Initial recommended preset images:

### Ball / Range

```text
Driving Range Ball Bucket
Golf balls in bucket
Tee / mat / bay visual
```

### Drinks

```text
Mineral Water
100 Plus
Iced Lemon Tea
Hot Coffee
Hot Tea
```

### Food / Snacks

```text
Nasi Lemak Special
Chicken Burger Set
Roti Canai Set
Mee Goreng
Roti Bakar
```

### Equipment later

```text
Driver Rental
Iron Set Rental
Glove Rental
```

## Admin behavior

Operations Menu Management should support:

```text
Use preset image
Upload own image
Paste image URL
Remove image
```

The operator can start with preset images first, then replace them later with real cafe/range photos.

## Customer behavior

Customer QR order page should show image if available:

```text
menu_items.image_url is not null -> show image
menu_items.image_url is null -> show clean placeholder / no image
```

## Implementation idea

1. Store preset images in Supabase Storage `menu-images/presets`.
2. Seed `menu_items.image_url` with matching preset public URLs.
3. Menu Management page lets admin replace preset image later.
4. Customer order page reads `image_url` live from Supabase.

## Important note

Preset images should be generic and professional, not misleading. Real operator photos should be preferred before full public launch if branding/food accuracy is important.
