# RangeFlow Printout Guide

## Decision

RangeFlow V1.0 will continue with:

- Manual QR Pay or bank transfer
- Customer uploads payment proof
- Staff verifies payment
- Staff prints order slip
- Kitchen or ball station prepares the order
- Runner delivers to bay
- Runner scans bay QR to confirm delivery

ToyyibPay is kept as a future optional payment automation add-on if the commercial fee is suitable.

## Printout Purpose

The printout is not only a receipt. It is an operational work order.

It should help:

- Counter staff confirm the order is valid
- Kitchen or cafe prepare food and drinks
- Ball station prepare or release buckets
- Runner deliver to the correct bay
- Management keep a simple audit trail

## V1 Flow

1. Customer orders from bay QR.
2. Customer uploads payment proof.
3. Staff checks proof in Counter Queue.
4. Staff clicks Verify Paid.
5. System enables Print Order Slip.
6. Staff prints from browser.
7. Kitchen or ball station prepares order.
8. Staff clicks Out for Delivery.
9. Runner delivers to bay.
10. Runner scans bay QR to confirm delivered.

## Print Button

Add button in `/queue` order card:

- Print Order Slip

The button should appear or become active only after:

- payment_status = paid

Before payment is verified, show:

- Verify payment first

## Print Page

Recommended route:

- `/print/[bookingId]`

Behavior:

- Load booking details
- Load bay details
- Load customer details
- Load order items
- Load payment verification status
- Show thermal receipt layout
- Staff prints using browser print dialog

## Slip Sections

One printout may contain these sections:

### Counter Copy

- Order ID
- Bay code
- Customer name
- Customer phone
- Order time
- Payment status
- Verified by staff
- Verified time
- Total amount

### Kitchen or Ball Station Copy

- Bay code
- Order ID
- Item name
- Quantity
- Category
- Notes
- Prepare now instruction

### Delivery Copy

- Bay code
- Order ID
- Runner instruction
- Out for delivery time
- Instruction to scan bay QR for delivery confirmation

## Payment Wording

Because RangeFlow V1.0 uses staff verification, do not use bank or gateway approval wording.

Use:

- Payment Verified by Staff
- Manual Payment Proof Verified

Do not use:

- Payment Approved by Bank
- Payment Approved by Gateway

## Printer Recommendation

Recommended printer type:

- 80mm thermal receipt printer
- USB plus LAN or Ethernet preferred
- Auto cutter preferred
- ESC POS compatible preferred

Connection priority:

1. LAN or Ethernet
2. USB
3. Bluetooth

For trial, one generic 80mm thermal printer is enough.

For production, choose a more reliable POS receipt printer with LAN, auto cutter and stable paper feed. For noisy kitchen use, consider buzzer or alarm support.

## Suggested Printer Setup for Trial

Minimum trial setup:

- One counter laptop or tablet that can open the Operations Queue
- One 80mm thermal receipt printer
- Browser print dialog enabled
- Printer selected as default receipt printer if possible

Preferred connection:

- LAN or Ethernet if the printer is shared across counter and preparation area
- USB if only one counter laptop will print
- Avoid Bluetooth as the first choice for busy operation because reconnect issues can slow down staff

Paper:

- 80mm thermal roll
- Keep spare rolls at counter
- Test paper width before trial day

## Operational Placement

Recommended physical placement:

- Counter printer near staff who verifies payment
- Printed slip passed to kitchen or ball station
- Runner takes delivery section or uses queue screen for delivery

If one printer is used:

- Print one combined slip
- Staff can separate mentally by sections
- Counter copy stays at counter if needed

If two printers are used later:

- Counter printer for customer/order copy
- Kitchen or station printer for preparation copy

## Print Slip Template

Suggested 80mm thermal slip layout:

```text
--------------------------------
RANGEFLOW ORDER SLIP
--------------------------------
Order: RF_BAY01_8H2K91
Bay: Bay 01
Customer: Test Customer
Phone: 013xxxxxxx
Time: 12 May 2026 7:45 PM

PAYMENT
Status: VERIFIED BY STAFF
Method: Manual QR Proof
Verified By: Counter Staff
Total: RM14.00

ITEMS
1x Bucket 100 Balls      RM10.00
1x Lemon Tea             RM4.00

--------------------------------
KITCHEN / STATION COPY
--------------------------------
Bay 01
1x Bucket 100 Balls
1x Lemon Tea
Prepare Now

--------------------------------
DELIVERY COPY
--------------------------------
Deliver to: Bay 01
Scan bay QR to confirm delivered
--------------------------------
Powered by RangeFlow
```

## Category Routing Rule

For V1, the system can print one combined slip. Staff will manually route the order.

For future enhancement, item categories can route automatically:

- `bucket`, `balls`, `range` → ball station
- `food`, `snack`, `drink`, `fb` → kitchen or cafe
- `equipment`, `rental`, `service` → counter or service staff
- `promo`, `membership` → counter or owner review

## Staff SOP for Printout

Counter staff:

1. Open Operations Queue.
2. Check new order.
3. Verify uploaded payment proof.
4. Click Verify Paid.
5. Click Print Order Slip.
6. Pass slip to kitchen, cafe or ball station.
7. When items are ready, click Out for Delivery.

Kitchen or ball station:

1. Receive printed slip.
2. Check bay code and items.
3. Prepare item quantity exactly as printed.
4. Inform runner or counter when ready.

Runner:

1. Take prepared items.
2. Go to bay shown on slip.
3. Deliver to customer.
4. Scan bay QR using delivery confirmation page.
5. Order becomes delivered only after successful bay scan.

## Browser Print Behavior

V1 should use normal browser printing.

Recommended behavior:

- Print page opens in a new tab
- Page loads order slip
- Staff clicks Print or page calls `window.print()`
- Browser print dialog appears
- Staff chooses thermal printer

Do not implement silent print in V1 because browsers block silent printing for security.

Silent printing should be kept for later POS integration.

## Implementation Plan

### Step 1: Backend data source

Use existing receipt or operations RPC if enough data is available. The print page needs:

- booking ID
- bay code and bay display name
- customer name and phone
- order item list
- quantities and subtotal
- total amount
- payment status
- verification status or note
- created time

### Step 2: Create print route

Create:

- `customer/app/print/[bookingId]/page.tsx`

or operations route:

- `operations/app/print/[bookingId]/page.tsx`

Preferred for V1:

- operations print route, because printing is a staff action after verification

### Step 3: Add queue button

In `/queue`, after payment is verified, show:

- Print Order Slip

Button opens:

- `/print/[bookingId]`

### Step 4: Print styling

Use CSS media print:

- hide navigation
- set receipt width suitable for 80mm thermal paper
- use black text on white background
- use compact font sizes
- avoid large images
- avoid dark background for print

### Step 5: Trial test

Test with one order:

1. Customer orders from Bay 01.
2. Customer uploads payment proof.
3. Staff verifies paid.
4. Staff prints slip.
5. Staff confirms slip is readable.
6. Kitchen or station prepares from slip.
7. Runner delivers and scans bay QR.

## V1 Scope

Build now:

- Print Order Slip page
- Print button in Counter Queue
- Browser based printing
- Thermal friendly receipt layout
- Staff verified payment wording

Keep for later:

- Direct printer integration
- Multi printer routing
- Kitchen display system
- Gateway receipt integration
- Silent print
- Auto routing to multiple printers

## Future V1.1 or V2 Enhancements

Possible upgrades:

- Separate print buttons for counter, kitchen, ball station and delivery
- Kitchen display screen
- Auto category routing
- Print history log
- Reprint slip button
- Printer status check
- Direct ESC POS printer integration
- ToyyibPay or gateway auto receipt if fees are commercially acceptable

## UKM or New Operator Trial Checklist

Before trial:

- Confirm one printer is available or bring one trial printer
- Test browser print from the counter device
- Print one sample order slip
- Confirm staff can read bay code and item quantity
- Confirm staff knows that payment wording is staff verified
- Confirm runner understands bay QR scan is required for delivered status

During trial:

- Use one bay first
- Use one small order first
- Verify payment proof
- Print slip
- Prepare item
- Deliver to bay
- Scan bay QR
- Check order status completed

After trial:

- Ask staff if slip is readable
- Ask kitchen or station if information is enough
- Ask runner if bay delivery instruction is clear
- Adjust slip wording only if required

## Product Positioning

Printout is part of the RangeFlow operational value.

RangeFlow should be presented as:

```text
A QR bay ordering and operations system that supports payment proof verification, order queue processing, operational printout, and QR confirmed bay delivery.
```

## Current Position

ToyyibPay is KIV because a fixed RM1 fee may be expensive for small orders.

RangeFlow V1.0 priority remains:

- Manual QR payment setup
- Payment proof upload
- Staff verify paid
- Print order slip
- Delivery QR confirmation
