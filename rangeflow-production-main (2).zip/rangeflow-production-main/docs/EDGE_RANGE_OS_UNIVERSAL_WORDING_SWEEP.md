# EDGE RANGE OS — Universal Wording Sweep Rule

Last locked: 2026-05-31

## Purpose

EDGE RANGE OS must look like a universal SaaS product, not a one-location UKM custom build.

This rule applies to every page reviewed after this point.

---

## Words that must not appear in normal product UI

Do not expose these terms as product identity or public/default UI labels:

```txt
UKM
DR UKM
Driving Range @ UKM
PRIMAVOC
pilot
trial
bukitunggul
staff-ops-bay
```

Exception:

```txt
Technical documentation, old deployment notes, historical migration notes, and tenant configuration records may still mention UKM when the context is explicitly historical or operational.
```

---

## Preferred universal replacements

```txt
DR UKM / Driving Range @ UKM -> Driving Range / Operator Range
UKM Staff / Student -> Preferred / Member Rate
Walk-in -> Standard / Regular Rate
PRIMAVOC payment QR -> Operator payment QR
pilot/trial -> production workspace / onboarding / active tenant
staff-ops-bay -> /counter
EDGE RangeFlow -> EDGE RANGE OS
```

---

## Page sweep requirement

Every page reviewed from now onward must include a wording sweep.

Report format:

```txt
Page reviewed:
Terms checked:
Terms found:
Action taken:
Remaining risk:
```

---

## Active app areas to sweep

```txt
operations/app/counter/page.tsx
operations/app/qr/page.tsx
operations/app/access/page.tsx
operations/app/menu/page.tsx
operations/app/owner/page.tsx
operations/app/payments/page.tsx
operations/app/print/[bookingId]/page.tsx
operations/app/deliver/[bookingId]/page.tsx
customer/app/page.tsx
customer/app/b/[bayCode]/order/page.tsx
customer/app/pay/[bookingId]/page.tsx
customer/app/receipt/[bookingId]/page.tsx
```

---

## Important current decision

The customer order page is stable and must not be reworked with risky global/layout patches.

Any future customer order wording fix must be a small direct component-level patch only.

---

## Developer instruction

When improving any page, first remove hardcoded tenant-specific wording from that page unless it is intentionally pulled from tenant data and shown as operator/location identity.

Do not claim a page is professionally clean while it still shows UKM/PRIMAVOC/pilot/trial as generic product UI.
