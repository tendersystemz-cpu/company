# RangeFlow Standard Package Closeout Scope

Status: Closing standard commercial package
Date: 2026-05-11

---

# Objective

Close the current RangeFlow standard commercial web package so that it looks and feels complete for client-facing demonstration and controlled commercial use.

The goal is not to add future premium modules.
The goal is to finish the visible web layer and operational flow so the standard package does not feel half-built.

---

# Standard Package Must Feel Complete

A standard package is considered complete only when:

- all major pages feel connected
- every page has a clear purpose
- every page has navigation back to the main hub
- owner/staff/customer access is clearly separated
- customer flow does not end at a dead page
- menu management is clean and compact
- owner dashboard includes enough business records
- payment settings are visible and editable
- range identity is configurable enough for reuse
- design looks professional, commercial, and not like a developer test screen

---

# Final Closeout Modules

## 1. Unified Main Hub

The `/hub` page is the official main frontpage for the standard package.

It must include:

- Customer/Public access
- Staff access
- Owner/Admin access
- Operations Queue
- Owner Dashboard
- Menu Management
- QR Management
- Payment Settings
- Range Settings
- Reports/Sales Summary

Every module must be accessible from this frontpage.

---

## 2. Unified Navigation

Every operations page must include:

- Main Menu button
- Queue button
- Owner button
- Menu button
- QR button
- Payments button
- Settings button

This prevents isolated pages and makes the system feel like one application.

---

## 3. Customer Web Layer

Must feel complete:

- professional homepage
- bay page with clear CTA
- order page with clear item selection
- payment page with clear instructions
- receipt page with next actions

Required receipt/payment buttons:

- Back to Bay
- Order More
- View Receipt
- Main Menu / Home

---

## 4. Owner Dashboard

Must include:

- total sales
- today sales
- total orders
- completed orders
- unpaid/pending payment summary
- bucket quantity sold
- food items sold
- drinks sold
- top selling items
- payment summary
- bay usage summary

The dashboard must be useful enough for a range owner to understand daily operation without opening raw database records.

---

## 5. Menu Management

Must include:

- compact layout
- no image overflow
- fixed image ratio
- add/edit/save flow
- category grouping
- availability toggle
- clear item price and status

The page must not feel oversized or messy.

---

## 6. Payment Settings

Must include:

- DuitNow QR field
- Touch n Go QR field
- Bank/manual payment field
- QR preview
- payment instruction text
- active/inactive method toggle

This allows the standard package to be used by different range operators.

---

## 7. Range Profile Settings

Must include editable/generalized fields:

- range name
- short display name
- location name
- support phone
- WhatsApp support number
- logo/image URL
- homepage tagline

This removes dependency on one specific driving range name.

---

## 8. Visual Standard

The system should look like:

- premium sports-tech web application
- commercial driving range system
- connected SaaS dashboard
- clean navigation experience

It should not look like:

- isolated test pages
- blank developer prototype
- disconnected admin panels
- half-completed demo

---

# Explicitly Not Included In Standard Closeout

The following are future add-ons and must not block standard package closeout:

- PWA installable app
- customer mobile app ecosystem
- membership engine
- prepaid wallet
- events/community module
- coaching marketplace
- tournament module
- AI analytics
- franchise/multi-branch system

---

# Final Closeout Principle

Close the standard package only when the visible web system feels complete enough to show as a professional commercial package.

The target user should feel:

"This is a working driving range operations system."

Not:

"This is still a developer prototype."
