# RangeFlow DIY Ball Pricing Requirement

## Purpose

Driving range ball/bucket pricing must be manageable by the range operator without developer involvement.

Customer-facing pricing must not be hardcoded in the app.

## Required admin capabilities

Operations/admin users must be able to manage ball pricing themselves:

1. View current ball/bucket pricing.
2. Edit walk-in bucket price.
3. Edit casual/member bucket price later.
4. Edit regular/pro/member pricing later.
5. Edit corporate pricing later.
6. Set pricing by time slot.
7. Set pricing by bay type.
8. Enable or disable a pricing rule.
9. Save changes to Supabase.
10. Customer QR order page must immediately use the latest active pricing.

## Current data model

Current table used:

```text
pricing_rules
```

Important fields:

```text
location_id
amenity_type
day_type
slot_label
start_time
end_time
pricing_unit
walkin_price
casual_price
regular_price
pro_price
corp_price
effective_from
effective_to
active
```

## Customer QR behavior

Customer scans bay QR:

```text
/b/{bay_code}
```

Then the order page loads active ball pricing from Supabase:

```text
pricing_rules
```

The bucket price shown to customer, payment total, and receipt total must all use the same database price.

## No hardcoded price rule

The app must not hardcode bucket price such as RM10/RM14 inside React components.

Correct rule:

```text
Supabase pricing_rules -> customer order page -> booking/order/payment -> receipt
```

## Pricing flexibility

Initial launch can use one active walk-in per-bucket price.

Future versions must support:

```text
morning price
evening/night price
weekday/weekend price
standard bay price
VVIP bay price
member price
non-member price
promo price
corporate/event price
```

## Operations requirement

Operations app must provide a pricing management screen:

```text
Operations -> Pricing Management -> Ball/Bucket Pricing
```

Staff/admin should be able to edit and save:

```text
pricing unit
walk-in price
member prices
active status
effective date
slot label
start/end time
bay/amenity type
```

## Production priority

1. Customer order page reads live bucket price from Supabase.
2. Receipt/payment use backend-calculated bucket price.
3. Operations/admin pricing management screen.
4. Time-slot pricing.
5. Member/VVIP pricing layer.
6. Promo and corporate pricing layer.
