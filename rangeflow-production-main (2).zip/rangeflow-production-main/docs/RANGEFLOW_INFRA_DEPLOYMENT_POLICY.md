# RangeFlow Infrastructure & Deployment Policy

**Created:** 2026-05-19  
**Updated:** 2026-05-19  
**Project:** RangeFlow / EDGE Golf Operating System  
**Repository:** `duniabiz2udotcom/rangeflow-production`  
**Purpose:** Prevent deployment confusion by locking Coolify as the single active deployment reference for RangeFlow.

---

## 1. Final Infrastructure Decision

The official deployment rule is now simplified:

```text
Coolify = active deployment source of truth
Netlify = historical / legacy / fallback reference only
```

From this point onward, all operational discussion, handover notes, client demo notes, production checks, smoke tests, and deployment instructions should refer to Coolify first.

Do not treat Netlify as current production unless explicitly discussing old tested fallback URLs.

---

## 2. Simple Working Rule

To avoid confusion:

1. Do not ask whether RangeFlow is on Netlify or Coolify.
2. Assume RangeFlow is already deployed in Coolify.
3. Record Coolify as the active production environment.
4. Use Netlify only as archived proof that the earlier flow worked.
5. Do not send Netlify links to client unless user explicitly asks for old/fallback URL.
6. Any future redeploy instruction should be written for Coolify.

---

## 3. Why Netlify Appeared In Previous Notes

Netlify was mentioned because the previously verified URLs during defect cleanup were:

- `https://rangeflow-bucc.netlify.app`
- `https://rangeflow-ops.netlify.app`

Those URLs are now treated as:

```text
Legacy tested pilot URLs — not the official active production reference
```

They are useful only as fallback/history if Coolify troubleshooting is needed.

---

## 4. Current Production Position

### Active production target

- Coolify-hosted RangeFlow customer app.
- Coolify-hosted RangeFlow operations app.
- Git-connected deployment from `duniabiz2udotcom/rangeflow-production`.
- Supabase project `cgewjbfycnqbyczyuthp` remains the active backend unless intentionally migrated.

### Legacy reference only

- Netlify customer site.
- Netlify operations site.

---

## 5. Coolify Details To Record

The following Coolify details still need to be filled in once confirmed from Coolify dashboard:

| Item | Value |
|---|---|
| Coolify project name | Pending |
| Coolify server label/IP | Pending |
| Customer app URL | Pending |
| Operations app URL | Pending |
| Customer app service name | Pending |
| Operations app service name | Pending |
| Git repository | `duniabiz2udotcom/rangeflow-production` |
| Git branch | `main` unless changed |
| Customer app root/build context | Pending |
| Operations app root/build context | Pending |
| Build command | Pending |
| Start command | Pending |
| SSL/domain status | Pending |
| Supabase project ref | `cgewjbfycnqbyczyuthp` |

These pending fields do not change the decision. They are only missing documentation details.

---

## 6. Required Coolify Smoke Test

After any Coolify deployment or redeployment, test these items only on Coolify URLs:

1. Customer landing opens.
2. Customer Bay 01 opens.
3. Customer order page opens.
4. Bucket default remains `0`.
5. Menu items load from Supabase.
6. Payment page loads.
7. Payment proof submission works.
8. Order appears in operations queue.
9. Verify Paid works.
10. Ball Slip opens.
11. Kitchen Slip opens.
12. Delivery Slip opens.
13. Full Slip opens.
14. Menu Management save/edit reflects on customer order page.
15. Hub access code still works.
16. Payment Setup page works.
17. QR Management page works.
18. System Health page works.

---

## 7. Deployment Communication Rule

When giving future instructions:

### Correct wording

```text
Deploy / redeploy from Coolify.
Check Coolify app logs.
Check Coolify environment variables.
Check Coolify domain/SSL.
```

### Avoid unless discussing legacy fallback

```text
Trigger Netlify deploy.
Check Netlify deploy ID.
Use Netlify as production URL.
```

---

## 8. Documentation Rule

Any future deployment, redeploy, rollback, domain change, or infrastructure decision must be recorded in Markdown before it is considered part of the official RangeFlow baseline.

Main baseline log:

```text
docs/RANGEFLOW_PRODUCTION_BASELINE_LOG.md
```

This file is the deployment policy reference:

```text
docs/RANGEFLOW_INFRA_DEPLOYMENT_POLICY.md
```

---

## 9. User Correction Recorded

User correction:

```text
"Kenapa masih gunakan Netlify padahal kita dah gunakan Coolify"
```

Follow-up clarification:

```text
"Sebab semuanya dah masuk dalam Coolify. Nanti jadi keliru."
```

Interpretation:

- The active deployment has already moved to Coolify.
- Future work should not keep switching mental model between Netlify and Coolify.
- Netlify must be treated as old/fallback reference only.

---

## 10. Hard Rule

If there is a conflict between Netlify notes and Coolify notes:

```text
Coolify wins.
```

Netlify information is historical unless the user explicitly says to use it again.
