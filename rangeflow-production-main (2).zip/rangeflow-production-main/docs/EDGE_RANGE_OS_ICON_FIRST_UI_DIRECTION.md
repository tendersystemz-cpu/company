# EDGE RANGE OS — Icon-First UI Direction

Last locked: 2026-05-30

This document is the official UI direction reference for EDGE RANGE OS operations pages.

It exists so that any next GPT, Codex agent, developer, or system analyst does not redesign the interface randomly or continue the old text-heavy layout.

---

## 1. Visual reference

Use this image as the target visual direction:

![EDGE RANGE OS Icon-First Operations Dashboard UI](./assets/edge_range_os_icon_first_operations_dashboard_ui.svg)

---

## 2. UI direction lock

The desired system UI should look like a compact, elegant SaaS dashboard.

The visual language must be:

```txt
Icon-first
Clean
Compact
Professional
Elegant
Fast to understand
Minimal large text
Minimal paragraph text
Green / white / charcoal EDGE identity
```

This is not a marketing poster. This is a real product interface direction.

The user specifically prefers this style because icons make the system easier to understand at a glance for:

```txt
Owner
Staff
Developer
System Analyst
Future GPT / Codex agent
```

---

## 3. Why this direction matters

EDGE RANGE OS has many modules.

If each module is shown with large headings and long descriptions, the app becomes heavy, confusing, and visually noisy.

Therefore, operations pages should use compact icon navigation and card-based modules.

The goal is:

```txt
A user should understand the system structure visually before reading long text.
```

---

## 4. Main UI principles

### 4.1 Persistent navigation

Navigation must remain visible and consistent when the page changes.

Do not create a different menu structure for every page.

Preferred pattern:

```txt
Persistent top navigation bar
Icon-first menu item
Short label only
Dropdown/grouping only when needed
Role/access chip on the right
```

Example top menu items:

```txt
Hub
Bay Order
Counter
Queue
POS Lite
Stock
Menu
Payments
Owner
Access
Reports
QR
Settings
```

### 4.2 Icon-first buttons

Each main action button or module card should use:

```txt
1 strong icon
1 short title
1 role/status chip
1 simple arrow/action indicator
```

Avoid:

```txt
Long paragraph descriptions inside buttons
Oversized hero text
Multiple competing button groups
Old fallback links mixed with production links
```

### 4.3 Compact operational snapshot

The dashboard should include compact metric cards such as:

```txt
Active Bays
Pending Orders
Paid Today
Low Stock
Active Staff
```

Each metric should be icon-led and concise.

### 4.4 Role/status chips

Use clear chips to explain access or status:

```txt
Customer
Staff
Owner
Protected
All Systems Operational
```

Important: visual chips are not enough for security. Protected routes must still use real access guard logic.

### 4.5 Module cards

Main module cards should follow this style:

```txt
Icon circle
Short module name
Role chip
Arrow / open indicator
```

Suggested module cards:

```txt
Customer Order
Staff Counter
POS Lite
Stock Lite
Menu Management
Payment Verification
Owner Dashboard
Bay Status
QR Management
Access Control
```

---

## 5. Target page structure

The operations home/dashboard should generally be arranged like this:

```txt
A. Brand header
B. Persistent icon navigation
C. Compact welcome/status strip
D. Operational snapshot metrics
E. Icon module grid
F. Footer/system sync status
```

### A. Brand header

Must show:

```txt
EDGE RANGE OS
Expert Digital Golf Ecosystem
```

### B. Persistent icon navigation

Must show short module labels and icons.

### C. Welcome/status strip

Example content:

```txt
Welcome back, Admin
Owner / Staff / Protected / All Systems Operational
```

### D. Operational snapshot metrics

Use compact cards, not large dashboard sections.

### E. Icon module grid

Use 2 rows or responsive grid of function cards.

### F. Footer/system sync status

Example:

```txt
EDGE RANGE OS · v1.0.0
All systems secured
Last synced: 09:45 AM
```

---

## 6. How to apply this in code later

Do not patch randomly.

Apply this UI direction only after route/auth/menu governance audit is completed.

Related required audit file:

```txt
docs/EDGE_RANGE_OS_ROUTE_AUTH_MENU_AUDIT.md
```

Recommended implementation files:

```txt
operations/lib/navigation.ts
operations/app/GlobalReturnNav.tsx
operations/app/page.tsx
operations/app/hub/page.tsx
operations/app/owner/page.tsx
operations/app/counter/page.tsx
operations/app/pos/page.tsx
operations/app/stock/page.tsx
operations/app/menu/page.tsx
operations/app/payments/page.tsx
operations/app/access/page.tsx
```

---

## 7. Navigation must use route governance

The UI must not link to old or fallback pages unless they are officially retained.

Before implementing the visual layout, answer:

```txt
Which route is production?
Which route is deprecated?
Which route redirects?
Which route requires Staff PIN?
Which route requires Owner PIN?
Which route is future Super Admin?
```

Do not decide this visually. Decide it from route governance.

---

## 8. Access control rule

Icon lock or protected chip is only visual.

Real access must still follow:

```txt
Public/customer route    = no PIN
Staff route              = staff PIN or owner PIN
Owner route              = owner PIN only
Super Admin future route = separate super admin auth
```

Existing backend direction:

```txt
verify_org_access_pin(p_org_slug, p_role_key, p_pin)
update_org_access_pin(p_org_slug, p_owner_pin, p_role_key, p_new_pin)
```

Do not hardcode PINs in frontend.

---

## 9. Do not repeat the old mistake

Do not make the system look like disconnected pages.

Do not leave:

```txt
large text-heavy pages
random old buttons
route links going to fallback pages
separate menu style per page
visual-only locks
RangeFlow / pilot / trial wording as product identity
```

EDGE RANGE OS must feel like one unified SaaS product.

---

## 10. Summary for next GPT / developer

The owner wants this UI direction:

```txt
Compact icon-first dashboard
Persistent menu across pages
Short labels
Clean module cards
Professional SaaS feel
Minimal large text
No random legacy navigation
```

The UI direction must support the confirmed product architecture:

```txt
Customer QR-first flow
Staff protected operations flow
Owner protected control/reporting flow
Super Admin future SaaS billing/control flow
```

Do not build the visual UI before route governance is clear.

Do not invent a new style.

Follow the visual reference in this document.
