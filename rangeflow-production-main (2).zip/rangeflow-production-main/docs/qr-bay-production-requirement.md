# RangeFlow QR Per Bay Requirement

## Purpose

Every bay must have its own QR code so customers can scan from the bay and place orders directly from the correct bay context.

This is a core production requirement, not an optional feature. The customer-facing version is not considered ready for real use until the same bay QR can support ball orders, food orders, and drink orders in one customer flow.

## Required customer URL format

```text
https://rangeflow-bucc.netlify.app/b/{bay_code}
```

Examples:

```text
Bay 01 -> https://rangeflow-bucc.netlify.app/b/01
Bay 02 -> https://rangeflow-bucc.netlify.app/b/02
Bay 10 -> https://rangeflow-bucc.netlify.app/b/10
```

## QR code rule

Each QR code must encode only the bay URL, not customer data and not payment data.

The app will resolve:

```text
org slug -> location -> bay -> active pricing -> available ball/menu items
```

from Supabase after the QR is scanned.

## Minimum real-customer launch flow

For internal technical progress, ball ordering can be built first. However, for real customer use, the launch flow must include balls, food, and drinks together because the same counter/team controls both range ball orders and F&B fulfilment.

Real customer launch flow:

```text
Scan QR at bay
-> /b/{bay_code}
-> confirm bay
-> choose balls
-> choose food and drinks
-> review one combined cart
-> submit one combined order
-> create booking/order/payment records
-> receipt/token
-> staff sees one bay-based queue
```

## Counter operations rule

Ball orders and food/drink orders must not become two disconnected workflows.

Correct operational model:

```text
One bay
One customer session
One combined cart
One receipt/token
One operations queue
Separate item types inside the same order
```

Item types may include:

```text
ball
food
drink
service
promo
```

## Operations requirement

Operations app must provide a QR management screen:

```text
Operations -> Bay Management -> QR Codes
```

The screen must allow staff/admin to:

1. View all bays.
2. Generate QR code for each bay.
3. Download individual QR as PNG/SVG.
4. Print QR sheet for all bays.
5. Regenerate QR if domain changes.
6. Show bay label clearly, e.g. `Bay 01`, `Bay 02`.

Operations app must also show combined order queues by bay:

```text
Bay 01
- 1 bucket balls
- 1 nasi lemak
- 2 mineral water
- payment status
- fulfilment status
```

## QR print label format

Each bay label should show:

```text
Bukit Unggul Golf Club
RangeFlow
Bay 01
Scan to order balls, food & drinks
```

## Menu requirement

The same QR route must support ball orders, food orders, and drink orders. Do not create a separate QR route for food unless needed for campaign/promotion purposes.

Correct structure:

```text
/b/01
  -> Ball Order
  -> Food & Drinks
  -> Promotions
  -> Combined Cart
  -> Payment
  -> Receipt
```

## Production priority

1. Real booking/order/payment transaction write.
2. Combined cart for balls, food, and drinks.
3. Staff operations order view by bay.
4. QR code generator per bay.
5. Print-ready QR sheet for all bays.
6. Membership/VVIP and promotion layer.
