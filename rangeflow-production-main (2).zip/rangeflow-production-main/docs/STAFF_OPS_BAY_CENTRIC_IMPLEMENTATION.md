# Staff Ops Bay-Centric Implementation

## Purpose

Admin Operasi must work by bay, because driving range operation is bay-based.

## Confirmed Direction

- Staff uses phone/tablet.
- Staff should see bay grid first.
- Actual active bay count: 25.
- System can prepare 30 bay slots.
- Bay 26-30 should be standby/disabled unless owner enables later.

## Required Dashboard Behavior

### Bay Grid

Each bay button should show:
- Bay number
- OK status
- Payment pending status
- Active order status
- Need Help blinking status
- Standby status for inactive bay

### Bay Quick Action

When staff taps a bay:
- selected bay panel opens
- active orders for that bay are shown
- staff can add order for that bay
- staff can verify payment for pending order
- staff can update preparing/ready/delivered

### Assisted Order

Staff must be able to add order for customer if:
- customer orders verbally
- customer does not want to scan QR
- customer is elderly/VIP
- customer asks staff for quick add-on order

All assisted orders must still be cashless.

Payment method:
- TNG/DuitNow only
- no cash
- staff verifies payment after customer pays

### Assistance Alert

Customer Need Help button creates assistance request.
Admin Operasi dashboard should:
- show top alert
- highlight/blink bay button
- allow staff to acknowledge

## Implementation Order

1. Add bay grid and selected bay state.
2. Group active orders by bay.
3. Add selected bay panel.
4. Add Add Order button linked to assisted order page or POS with bay parameter.
5. Add proper assisted order route if not already available.
